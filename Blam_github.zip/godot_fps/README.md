# Glock FPS (Godot 4.3+)

## CHƠI NGAY (Windows, không cần biết lập trình)
1. Giải nén file zip ra một thư mục (đừng chạy thẳng trong file zip).
2. Bấm đúp **`CHOI_GAME.bat`**. Lần đầu nó tự tải Godot (~60 MB, cần Internet) và nạp map (1-2 phút). Các lần sau vào game ngay.
3. Vẫn thấy giật? Bấm **F4** trong game để hạ độ phân giải 3D (game cũng tự hạ khi FPS thấp). Đã xoá `CHOI_GAME_MAY_YEU.bat` theo yêu cầu.
- Khi mở game: màn hình loading (tải sẵn âm thanh, map, đường đi bot, biên dịch hiệu ứng đồ họa) rồi vào menu, bấm **PLAY** để chơi. Việc tải trước giúp lúc chơi mượt hơn.
- Trong game: phím **F4** đổi độ phân giải 3D (960x540 → 512x288). Game cũng tự hạ độ phân giải nếu FPS dưới 45.
- Góc trái trên hiện số FPS.

### Đã tối ưu cho laptop yếu (ThinkPad T440)
- Độ phân giải 3D mặc định 720x405, tự hạ từng bước (xuống tối thiểu 427x240) nếu FPS dưới 40. Nếu hạ hết mà vẫn dưới 34 FPS, game bật chế độ tiết kiệm CPU (vật lý 30 Hz).
- Bản đồ đường đi (navmesh) thưa hơn nhiều, bot tìm đường tối đa 1 lần mỗi khung hình và ít phản ứng với tiếng động hơn. Vật liệu súng/bot dùng đèn theo đỉnh.
- **Hãy chạy bằng CHOI_GAME.bat, đừng bấm F5 trong trình soạn thảo Godot**: chạy trong editor (bản debug) chậm hơn rất nhiều.
- Map và bot dùng đèn tính theo đỉnh (per-vertex), tắt specular: nhẹ hơn nhiều cho card Intel HD.
- Bot quét địch thưa hơn và lệch pha nhau, tìm đường ít hơn; hiệu ứng đạn nhẹ hơn.
- Giao tranh đông: âm thanh của bot dùng chung 8 "kênh", bỏ tiếng quá xa, tắt bộ lọc âm thanh tốn CPU, giảm tần số mix; hạt, tia đạn, vết đạn được tái sử dụng thay vì tạo mới mỗi phát bắn.
- Chuột gom sự kiện theo từng khung hình; giới hạn số bước vật lý bù mỗi khung để không bị "xoắn ốc giật".

---

Game bắn súng góc nhìn thứ nhất, lối chơi kiểu CS2 (Team Deathmatch 3v3 với bot), súng và animation
theo phong cách Call of Duty. Súng đầu tiên: **Glock 17**.

## Cách chạy
1. Cài **Godot 4.3 trở lên** (bản "Standard", không cần .NET): https://godotengine.org
2. Mở Godot -> **Import** -> chọn file `project.godot` trong thư mục này.
3. Lần đầu mở, Godot sẽ tự import `assets/map.glb` (vài giây). Sau đó bấm **F5** để chơi.

Project dùng renderer **Compatibility** nên chạy được trên hầu hết laptop (kể cả card đồ họa tích hợp).
Muốn đẹp hơn trên máy mạnh: Project Settings -> Rendering -> Renderer -> Forward+.

## Cấu hình nhẹ cho laptop yếu (ví dụ ThinkPad T440)
Mặc định đã tối ưu: render ở 960x540 rồi phóng lên cửa sổ, không bóng đổ, không khử răng cưa,
map chia ô để bỏ phần ngoài tầm nhìn, vật lý 60 lần/giây. Góc trái trên hiện số FPS.
- Còn lag: Project Settings -> Display -> Window -> Viewport Width/Height đặt 854x480 hoặc 640x360.
- Máy mạnh hơn: đặt 1280x720 hoặc 1920x1080.

## Điều khiển
| Phím | Chức năng |
|---|---|
| W A S D | Di chuyển |
| Chuột | Nhìn |
| Chuột trái | Bắn (bán tự động) |
| Chuột phải | Chỉ dùng cho dao (đâm). **Game không có chức năng ngắm (ADS)** |
| R | Nạp đạn (tactical 17+1 / empty có kéo nòng) |
| F | Inspect súng |
| E | Nhìn vào súng dưới đất rồi bấm E để nhặt (chế độ Đặt bom: giữ E sát quả bom đang đặt để gỡ, phe CT) |
| G | Vứt món đang cầm (không vứt được dao) |
| Alt + Enter | Bật/tắt toàn màn hình |
| Space | Nhảy |
| Shift (giữ) | Ngồi |
| B | Mở / đóng cửa hàng mua súng |
| 1 / 2 / 3 | Chọn súng chính đang cầm (M4A1 hoặc AK-47) / Súng lục (Glock hoặc Desert Eagle, như CS2 chỉ cầm một súng lục) / Dao |
| 5 | Chọn AK-47 (mua trong cửa hàng B) |
| 6 | Trong cửa hàng B: mua MP5-SD ($1400). Ngoài cửa hàng: cầm bom C4 (khi đang mang) |
| Q | Đổi nhanh sang vũ khí trước đó (đầu trận: dao) |
| Lăn chuột | Duyệt qua các vũ khí đang có: M4A1 → AK-47 → Desert Eagle → Glock → Dao → Bom (khi đang mang bom, chế độ Đặt bom) |
| Ctrl (giữ) | Đi bộ chậm, im lặng (bot không nghe thấy bước chân) |
| Tab (giữ) | Bảng điểm |
| Esc | Menu tạm dừng (độ nhạy chuột, FOV, âm lượng) |
| F4 | Đổi độ phân giải 3D (tắt tự động) |
| F11 | Toàn màn hình |
| F3 | Bảng debug (vị trí, trạng thái từng bot) |

## Tự động nghiêng (như CoD Mobile)
Khi đứng hoặc ngồi (hoặc đi rất chậm) sát một vật cản/góc tường ngay trước mặt, mà một bên đã trống, nhân vật tự nghiêng sang bên trống để ló ra nhìn và bắn. Lùi ra hoặc di chuyển nhanh thì tự đứng thẳng lại. Bot cũng thấy và bắn trúng bạn khi đang nghiêng.

## Cửa hàng & súng
- Bấm **B** để mở cửa hàng (game tạm dừng). Bắt đầu mỗi trận có **$3000**, mỗi kill được **$300** (+$100 nếu headshot).
- **M4A1** giá $2700: bắn tự động, 30 viên/băng, sát thương cao hơn, giật mạnh hơn, đi chậm hơn Glock một chút. **Mua đạn** $200 (đầy đạn dự trữ cho mọi súng).
- Trong cửa hàng bấm **1** mua M4A1, **2** mua đạn. Hết trận thì tiền và súng về mặc định.

## Dao (đã đổi thành ĐẤM TAY KHÔNG, xem mục cuối)
- Model dao M9 Bayonet (chuyển từ file FBX, thư mục `assets/knife_m9/`, 3 texture đã thu nhỏ 512 / 512 / 1024 cho máy yếu). Gốc toạ độ = giữa cán dao, mũi dao hướng -Z, cạnh sắc xuống -Y, lưng răng cưa lên +Y.
- Dáng cầm: mũi dao chếch trái ra trước, lưỡi nằm gần phẳng, lưng răng cưa quay về phía người chơi (`HOLD_EULER` + `HOLD_ROLL`, tâm nắm tay `GRIP_LOCAL` trong `scripts/knife.gd`).
- Animation làm lại cho lưỡi thẳng: mỗi tư thế đặt theo hướng mũi dao + hướng cạnh sắc (cạnh sắc dẫn đầu nhát chém). Chém 1 quét trái -> phải (cung từ trên-trái xuống dưới-phải), chém 2 quét ngược lại, đâm chếch ~45 độ để vẫn thấy cả lưỡi, rút dao bật từ dưới lên rồi xoay quanh trục dao, múa dao lật cả hai mặt lưỡi (mặt có răng cưa rồi mặt sau).
- Cờ import đã đổi lên `imported_v22` nên lần đầu chạy sau bản này `CHOI_GAME.bat` sẽ nạp lại tài nguyên (1-2 phút).
- Luôn có sẵn từ đầu trận, bấm **3** để rút dao (có animation tung lật dao). Cầm dao **chạy nhanh hơn** cầm súng.
- **Chuột trái** chém chéo xen kẽ hai hướng kiểu Valorant (nhanh, 40 sát thương), **chuột phải** đâm (chậm hơn, 65 sát thương). **Đâm/chém từ phía sau lưng địch (khi địch đang quay lưng) = hạ gục ngay.**
- Bấm **F** để múa dao (khoe lưỡi, tung lật, xoay quanh cán), rất hợp sau khi hạ gục một mạng.

## Luật chơi
- Bạn (CT) cùng 2 bot đồng đội đấu 3 bot T. Đội nào đạt 25 kill trước thì thắng, rồi tự bắt đầu trận mới.
- Bắn vào đầu x4 sát thương, chân x0.75. Bắn càng xa sát thương giảm nhẹ.
- Độ lệch đạn tăng khi chạy/nhảy/bắn liên tục (tâm ngắm giãn ra giống CS), giảm khi ngồi hoặc ngắm.
- Bot nghe được tiếng súng và tiếng bước chân (khi chạy), nhìn thấy bạn thì phản xạ rồi bắn.

## Cấu trúc
- `assets/map.glb` – map đã chuyển từ `map.blend` (Blender 2.79) sang glTF, tỉ lệ x3 để vừa người chơi.
- `scripts/main.gd` – nạp map, tạo va chạm + navmesh, spawn, điểm số, hiệu ứng.
- `scripts/player.gd` – di chuyển, bắn, nạp đạn, camera.
- `scripts/viewmodel.gd` – súng Glock 17 + hai tay + toàn bộ animation (dựng bằng code).
- `scripts/bot.gd`, `scripts/hud.gd` – bot, giao diện. (Âm thanh đã bị xoá hết khỏi game.)

## Lưu ý
- Model súng/tay là model tự dựng bằng khối hình trong code (không dùng asset của Call of Duty vì có bản quyền).
  Animation (draw, thở, bob, sway, giật, trượt nòng, rơi vỏ đạn, reload, inspect, ADS) viết theo kiểu CoD.
  Muốn dùng model thật: thay phần `_build_gun()` / `_build_hands()` trong `viewmodel.gd` bằng model .glb của bạn.
- Thêm súng mới: copy cấu trúc của `viewmodel.gd` + hằng số trong `player.gd` (MAG_SIZE, DAMAGE, FIRE_INTERVAL...).

## Nguồn model GIGN
- (Đã xoá khỏi game ở bản dọn dẹp cuối: model GIGN từng chỉ là phương án dự phòng cho bot nên không còn được dùng.)

## Giao diện sảnh chờ + cửa hàng (bản gọn)
- Sảnh: CHƠI / QUIT. Cửa hàng (B): 4 thẻ có hình súng + giá, thẻ đã mua có dấu tick, thẻ không đủ tiền bị mờ. Phím 1-4 mua nhanh, Esc/B hoặc bấm ra ngoài để đóng.
- Màu và kiểu nút nằm ở `scripts/ui_theme.gd` (đổi màu nhấn ở hằng `ACCENT`). Hình súng nhỏ vẽ bằng code ở `scripts/ui_icon.gd`. Không có asset mới nên không cần đổi cờ `imported_v..`.

## Cảnh chết của người chơi (góc nhìn thứ 3)
- Khi bị hạ: camera rời mắt, lùi ra sau lưng thành góc nhìn thứ 3 (khoảng 0.9 giây, không xuyên tường), hơi trôi quanh xác. Nhân vật (`scripts/corpse.gd`) khuỵu gối rồi ngã theo hướng đạn, súng văng khỏi tay. Hồi sinh thì trả lại góc nhìn thứ nhất.
- Chỉnh khoảng cách/tốc độ lùi: hằng `DEATH_CAM_DIST`, `DEATH_CAM_TIME` đầu `scripts/player.gd`.

## Cài đặt + ngôi sao hạ địch
- Sảnh chờ: nút **SETTINGS**. Trong game: Esc -> **Settings**. Hiện có **ASPECT RATIO**: 16:9 (mặc định) hoặc 4:3. 4:3 là kiểu kéo giãn như CS:GO (hình 4:3 được kéo bè ra đầy màn hình, nhân vật to ngang hơn, không có viền đen). Lần sau mở game vẫn nhớ (lưu ở `user://settings.cfg`). Esc hoặc BACK để đóng.
- Huy hiệu giữa thanh dưới là một ngôi sao; hạ địch thì sao sáng lên (vàng nếu headshot).

## F4 / tự giảm độ phân giải (bản mới)
- Chỉ **hình 3D** bị giảm độ phân giải (vẽ vào một SubViewport rồi phóng ra đầy màn hình). Chữ, thanh máu/đạn, tâm ngắm, menu vẫn vẽ ở độ phân giải thật của cửa sổ nên **luôn nét và to như cũ**.
- Tâm ngắm vẽ bằng điểm ảnh thật của màn hình (nhánh dày 2 điểm ảnh ở cửa sổ 720p).

## Chuyển động bot
- Chân chạy theo hướng di chuyển (ngang/chéo/lùi) trong khi thân trên vẫn hướng về phía ngắm, giống CS 1.6. Hông đảo nhẹ theo nhịp bước, thân nghiêng theo hướng chạy, súng nảy theo bước, quay người tại chỗ thì chân bước nhỏ, vào/ra tư thế ngắm êm hơn. Code ở `_animate_alive` trong `scripts/bot.gd`.
- Bản mượt hơn: (1) hình bot và camera người chơi được **nội suy** giữa 2 nhịp vật lý nên hết khựng khi FPS khác 60; (2) bàn chân là node riêng, luôn bám mặt đất (nhón gót khi đẩy, hất mũi khi chạm đất); (3) gối khuỵu nhẹ khi chân chạm đất; (4) bot có quán tính hơn khi đổi hướng và nghiêng người vào khúc cua.
- AI di chuyển của bot (bản tự nhiên hơn): tuần tra có lúc đi bộ chậm, lúc chạy, mỗi bot một nhịp riêng; cua tròn ở khúc rẽ, chậm dần khi tới đích; đứng chờ thì từ từ ngó quanh; vừa thấy địch thì giật mình khựng lại rồi mới xoay người; giao tranh theo nhịp "đi ngang -> dừng hẳn bắn -> đổi hướng" (ít bắn khi đang chạy); mất dấu địch thì khựng lại nhìn về chỗ cũ rồi thận trọng đi kiểm tra. Code ở `_nav_move`, `_roam`, `_combat` trong `scripts/bot.gd`.

## M4A1 chi tiết hơn + giật/tỏa đạn kiểu Counter-Strike 1.6
- **Hình súng** (`scripts/rifle.gd`): thân trên có quai xách, thanh ray có răng, hộc đạn, nút chốt, cần kéo thượng đạn hình chữ T, ốp tay có gân, đầu nòng 5 khe, báng gập, báng cao su, băng đạn cong có gân + đầu đạn đồng. Vẫn dùng **cùng khe ngắm cũ** (không có ống ngắm). Quai xách **tự hạ xuống khi bạn bấm ngắm** để không che tầm nhìn. Tổng chỉ 5 khối hình (nhẹ cho laptop yếu).
- **Cảm giác bắn kiểu CS**: nhịp bắn 0.0875 giây/phát (như CS), mỗi phát súng thụt mạnh về vai rồi bật lại, lửa đầu nòng hình sao + khói nhẹ khi bắn liên tục, tiếng bắn khô giòn riêng (`shot_m4` trong `scripts/sfx.gd`).
- **Giật kiểu CS** (chỉ M4A1): mỗi phát đẩy góc nhìn lên cao hơn phát trước, rồi lệch trái/phải ngẫu nhiên; lên tới mức trần thì dừng lại và chỉ còn lắc ngang. Thả chuột là về lại từ đầu. Chạy hoặc nhảy thì giật mạnh hơn, ngồi thì giật nhẹ hơn.
- **Tỏa đạn kiểu CS**: phát đầu rất chính xác, bắn liên thanh thì tâm ngắm nở dần (như CS). Đứng yên/ngồi/đi bộ chậm (**Ctrl**) thì chụm; **chạy thì tỏa rộng**; **trên không rất tỏa**. Tâm ngắm trên màn hình nở theo đúng độ tỏa thật.
- Hai điểm game này tự thêm (CS gốc không có): ngồi chụm hơn 20%, ngắm (chuột phải) chụm hơn 40% và giật nhẹ hơn 20%.
- **Muốn chỉnh**: bảng `"cs"` của M4A1 ở đầu `scripts/player.gd` (mỗi dòng đều có chú thích). Ví dụ muốn đỡ giật thì giảm các số trong `kick_stand`; muốn chụm hơn thì giảm `stand`.
- Các số CS là ghi nhớ từ mã nguồn CS 1.6, chưa đối chiếu lại được trên mạng. Bản này **chưa chạy thử trong Godot**, nếu thấy giật/tỏa lệch cảm giác thì chỉnh bảng trên.

## Tỏa đạn theo chuyển động (mọi súng, kiểu CS/CS2/Valorant)
- **Đứng yên = chụm**, càng đi nhanh càng tỏa: đi bộ tỏa vừa, **chạy vừa bắn tỏa rất rộng**, nhảy/trên không tỏa cực rộng. Ngồi và ngắm (chuột phải) thì chụm hơn. Tâm ngắm trên màn hình nở theo đúng độ tỏa.
- M4A1: chỉnh ở bảng `"cs"` (`move_base`, `move_acc`, `move_speed`) đầu `scripts/player.gd`. Các súng khác: hệ số `5.5` (chạy) và `6.0` (trên không) trong hàm `current_spread_deg`. Chưa chạy thử trong Godot.

## M4A1: nạp đạn và xem súng làm lại
- **Nạp đạn** (phím R) kiểu CS: nghiêng súng, tay trái trượt xuống hộc đạn, bấm chốt cho băng cũ tụt ra rồi vứt đi, thò xuống thắt lưng lấy băng mới, đưa lên và **đẩy mạnh vào** (súng giật nhẹ khi băng vào chốt), rồi trả súng về tư thế bắn. Hết đạn thì kéo thêm cần thượng đạn. Thời gian: **2.4 giây** (còn đạn) / **3.0 giây** (hết đạn); đạn được nạp vào đúng lúc băng khớp chốt (~1.5 giây).
- **Xem súng** (phím F) dài 3.8 giây: đưa súng sát mắt, xoay xem một bên, lật xem bên kia, ngóc nòng lên xem hộc đạn rồi trả súng về.
- Chỉnh thời gian: hằng `RELOAD_TAC`, `RELOAD_EMPTY`, `INSPECT_TIME` đầu `scripts/rifle.gd`; các mốc chuyển động ở hàm `_build_keys` (mỗi mốc là `[giây, vị trí]`). Chưa chạy thử trong Godot.

## Sảnh chờ mới (kiểu Valorant)
- Nền đen, danh sách bên trái: **CHƠI** (to, màu xanh ngọc khi đang chọn), BỘ SƯU TẬP, CỬA HÀNG, CÀI ĐẶT, THOÁT. Bộ sưu tập và Cửa hàng hiện mới ghi "SẮP CÓ".
- Danh sách bên trái nằm sát đáy màn hình. Mới vào sảnh thì bên phải để trống. Bấm **CHƠI** -> chọn chế độ (**ĐẤU ĐỘI** hoặc **ĐẶT BOM**) -> chọn bản đồ -> vào game. Hiện chỉ có 1 bản đồ tên **MINI SIZE** (bản đồ nhỏ nên Đấu đội và Đặt bom đều **3 đấu 3**) và một thẻ "SẮP CÓ". Có nút "< QUAY LẠI".
- Thêm bản đồ sau: sửa bảng `LOBBY_MAPS` trong `scripts/main.gd` (mỗi bản đồ một dòng), rồi đọc biến `selected_map` trong `_on_play` / `_on_bomb`.
- Font + màu: hằng `LV_*` và hàm `lobby_font()` trong `scripts/ui_theme.gd`. Font Valorant thật (Tungsten) có bản quyền nên không kèm theo; game dùng font hẹp đậm có sẵn của Windows (Bahnschrift Condensed). Nếu bạn có file font riêng, chép vào `fonts/lobby.ttf` (tạo thư mục `fonts` cạnh `project.godot`) là game tự dùng. Chưa chạy thử trong Godot.

## Dao: chém làm lại cho thật hơn
- Nhát chém giờ có đủ nhịp như đánh thật: **lấy đà** (kéo dao ra sau, nâng mũi) -> khựng nhẹ -> **vung nhanh dần, vươn tay ra trước** -> thừa đà rồi thu về. Cả **cánh tay và thân người** vung theo (trước đây chỉ bàn tay tự xoay). Chém liên tiếp thì đổi hướng trái/phải xen kẽ. Đòn đâm (chuột phải) cũng kéo tay về sau rồi phóng ra.
- Nhịp chém chậm lại một chút: 0.55 giây/nhát (trước 0.42), sát thương nhận đúng lúc lưỡi dao tới mục tiêu. Chỉnh ở `SLASH_TIME` trong `scripts/knife.gd` và `"interval"` của dao trong `scripts/player.gd` (hai số này nên bằng nhau). Chưa chạy thử trong Godot.

## AK-47 bắn "đã" hơn (giống M4A1)
- AK-47 giờ dùng cùng hệ thống giật + tỏa đạn kiểu CS 1.6 như M4A1: nhịp 0.1 giây/phát (600 phát/phút, xem mục "AK-47 mới" cuối file), giật camera lên rồi lắc ngang (mạnh hơn M4A1), phát đầu chụm, xả liên thanh thì nở dần, **chạy vừa bắn tỏa rất rộng**. Bảng số ở mục `"ak47"` -> `"cs"` đầu `scripts/player.gd`.
- Súng thụt mạnh về vai rồi bật lại từng phát (lò xo cứng, không còn "mềm" như trước), và tiếng bắn AK gọn hơn (bớt vang để nghe rõ từng phát). Chưa chạy thử trong Godot.

## Chế độ mới: ĐẶT BOM (kiểu CS:GO / CS2, 3 đấu 3)
- Vào: **CHƠI -> ĐẶT BOM -> bản đồ -> chọn phe CT hoặc T**. Bản đồ hiện tại, có 2 điểm đặt bom **A** và **B** (vòng tròn cam + chữ A/B trên không).
- **Phe T** đặt bom: một T (có thể là bạn) mang bom. Người mang bom **bấm phím 6 để cầm bom trên tay**, đứng trong điểm A/B rồi **giữ chuột trái 3.2 giây** để đặt (không cầm bom thì không đặt được). **Phe CT** gỡ bom: bom đã đặt thì tới sát quả bom, **giữ E 10 giây**. Lúc giữ E bạn đứng yên.
- Mỗi round: **15 giây chuẩn bị** (đứng yên, bấm **B** để mua đồ) -> **1:55** giao tranh -> bom nổ sau **40 giây** kể từ lúc đặt (bíp nhanh dần). Bom nổ giết người trong 20 mét.
- **Chết là chờ round sau mới hồi sinh** (và mất hết súng đã mua). Còn sống thì giữ súng sang round sau.
- T thắng: bom nổ hoặc hạ hết CT. CT thắng: gỡ bom, hạ hết T khi bom chưa đặt, hoặc hết giờ mà chưa đặt bom. T chết thì bom rơi xuống, T khác đi tới nhặt.
- **Thắng 13 round là thắng trận**. Hết round 12 thì **đổi phe**, tiền về $800, mất hết súng. 12:12 sau 24 round là hoà.
- Tiền: bắt đầu $800; thắng round +$3250; thua +$1400 (+$500 mỗi round thua liên tiếp, tối đa $3400); hạ địch +$300 (SMG $600, dao $1500); đặt bom hoặc gỡ bom +$300; T thua nhưng đã đặt bom +$800; tối đa $16000.
- Bot chơi theo nhiệm vụ: T kéo nhau tới một điểm, người mang bom đi đặt, CT chia nhau giữ hai điểm và đi gỡ khi bom đã đặt.
- Chỉnh luật: các hằng ở đầu `scripts/bomb.gd` (thời gian, tiền, vị trí hai điểm `SITE_WANT`, mặc định ở giữa bản đồ cho công bằng). Chưa có: bộ gỡ bom (defuse kit), lựu đạn, bot tự mua súng (bot dùng súng cố định). Chưa chạy thử trong Godot.
- Phím mới: **6** = cầm bom, **E** (giữ) = gỡ bom.

## Súng lục DESERT EAGLE (kiểu CS2)
- Mua trong cửa hàng (**B**, bấm **4**, hoặc bấm vào thẻ DEAGLE) giá **$700** như CS2. Cửa hàng giờ có 4 thẻ: M4A1 (1), AK-47 (2), Desert Eagle (3), Mua đạn (4).
- **Giống CS2, chỉ cầm một súng lục**: mua Desert Eagle thì Glock mất, phím **2** chọn súng lục đang có. Chết ở chế độ Đặt bom thì về lại Glock như thường.
- **Chỉ số** (`"deagle"` trong bảng `WEAPONS` ở `player.gd`): 7 viên / dự trữ 35, nhát bắn mỗi **0,33 giây** (nặng, phải chờ giữa hai phát), sát thương **63** (đầu x4 = **252**, chân x0,75), giảm 19% mỗi ~12,7 m (CS2 giảm 19% mỗi 500 đơn vị), đi hơi chậm hơn Glock (0,96), nạp đạn **2,2 giây**. Hai phát vào thân là hạ (100 máu), một phát vào đầu là hạ.
- **Giật lên trời**: một phát hất tâm ngắm lên ~**6,5 độ** kèm một cú nảy của súng, và tâm hạ về **rất chậm** (như CS2). Bấm liên tục thì cộng dồn: phát 1 = 6,5 độ, phát 2 = ~12 độ, phát 3 = ~17 độ, phát 5 trở đi chạm trần **28 độ** (thẳng lên trời). Muốn giữ tâm thì bắn chậm, chừng 0,7 giây một phát, lúc đó tâm chỉ nhích lên ~8 độ.
- **Tỏa đạn** (độ lớn tính theo góc): đứng yên và bắn chậm = **gần như trúng đúng tâm** (~0,2 độ), ngồi chụm hơn. Đi bộ chậm vẫn chính xác, **chạy = tỏa rất rộng** (~9,5 độ), **nhảy = tỏa cực rộng** (~17 độ). Bắn nhanh liền nhau thì lệch tăng dần (mỗi phát +4 độ, tối đa ~8 độ) và phải nghỉ ~0,7 giây mới hồi lại. Muốn trúng: dừng lại, chờ tâm chụm, rồi bắn.
- **Hình dáng (làm lại kiểu CS2 / CS:GO)**: súng bạc crôm với báng cao su đen. Nòng trượt dài, phẳng, có viền vát sáng ở mép, rãnh cò sâu phía sau, cửa thoát vỏ đạn bên phải có khung sáng và đầu vỏ đồng, chữ khắc "DESERT EAGLE" / ".50 AE" bên trái. Cụm nòng hình thang bậc màu xám đậm tách khỏi nòng trượt, ray trên có rãnh ngang, lỗ nòng to có vòng thép, ngắm trước/sau có chấm trắng. Thân súng có cần gạt an toàn hai bên, chốt giữ nòng trượt, nút nhả băng, vòng cò vuông có vát góc. Báng có lưng cao su, hai tấm có vân và huy hiệu tròn bên trái; đế băng đạn thò thấp hơn báng. Khi bắn: nòng trượt lùi dài, súng hất mạnh, tia lửa to, vỏ đạn .50 to văng ra.
- **Dáng cầm kiểu CS2**: **cầm một tay** (tay phải), súng nằm thấp và lệch phải, nòng chúc nhẹ vào trong. Tay trái không hiện ra khi đứng/bắn, chỉ thò vào từ mép dưới màn hình khi **nạp đạn** (lấy băng mới) và khi **múa súng (F)** (kéo nòng trượt). Vẫn có nạp khi hết đạn (nòng trượt khóa ở phía sau) và ngắm (chuột phải).
- **Animation đổi súng**: **rút súng** (khi bấm phím / lăn chuột sang DE) mất 0,8 giây: súng trồi lên từ dưới-phải, nòng chúi xuống rồi hất lên quá đà, nảy nhẹ, nòng trượt giật một cái rồi vào vị trí. **Cất súng** (khi đang cầm DE mà đổi sang súng khác) mất 0,24 giây: súng nhấc lên một chút rồi hạ nhanh xuống dưới-phải, xong mới hiện súng mới. Trong lúc cất súng không bắn/nạp được.
- **Âm thanh** `shot_deagle` trong `sfx.gd`: nổ to, trầm, rền và vọng.
- Hạ địch bằng Desert Eagle ở chế độ Đặt bom được thưởng **$300** như CS2 (súng lục).
- Chỉnh độ giật/tỏa đạn ở bảng `"cs"` của `"deagle"` trong `player.gd` (có chú thích), hình dáng, dáng cầm, animation rút/cất súng ở `scripts/deagle.gd` (hàm `request_switch` trong `player.gd` lo việc chờ cất súng), giá ở `PRICE_DEAGLE` trong `main.gd`.


## Súng không xuyên tường nữa
- Khi đứng sát tường, súng tự hạ nòng xuống và lùi tay lại, đủ sâu để đầu nòng không chọc qua tường. Áp dụng cho mọi vũ khí: Glock, Desert Eagle, M4A1, AK-47, dao, bom C4.
- Súng càng dài (M4A1, AK-47) thì bắt đầu hạ càng sớm; lùi ra khỏi tường thì súng tự nâng lên lại.
- Nếu sau này thêm súng mới: thêm một dòng cho súng đó vào bảng `WALL_DIMS` trong `player.gd` (và hằng `WALL_BACK` / `WALL_RX` trong file mô hình súng).

## Bản đồ MIRAGE (5 đấu 5) - thay cho bản đồ THÀNH PHỐ
- Có trong cả ĐẤU ĐỘI và ĐẶT BOM: vào CHƠI -> chọn chế độ -> chọn bản đồ "MIRAGE". Mỗi phe 5 người (bạn + 4 đồng đội đấu với 5 bot).
- Đây là map CS 1.6 "cs2_mirage" (TheButch3r). Đã xoá hẳn bản đồ thành phố (`assets/city_map.glb`).
- Nhúng thẳng vào game: file map là `assets/mirage_map.glb` (đổi từ `cs2_mirage.bsp` bằng `python3 tools/bsp2glb.py <map.bsp> assets/mirage_map.glb 0.0254 160`). Texture lấy từ trong file bsp, ánh sáng lightmap nướng sẵn vào màu đỉnh nên map vẽ nhẹ (không cần đèn).
- Hai điểm bom A và B lấy đúng vị trí của map gốc. CT xuất phát bên trái, T bên phải, mỗi phe 16 điểm.
- Chưa có: cây cọ, xe, thùng gỗ (các mô hình rời `.mdl` của map), nên một số chỗ trông trống hơn bản gốc. Phần vật cản chính (tường, thùng, cửa) đã có trong map.
- Cấu hình (số bot, điểm xuất phát, điểm bom, độ cao) nằm ở `MAP_CFG` mục `mirage` đầu file `scripts/main.gd`.

## Bot biết suy nghĩ chiến thuật (chế độ ĐẶT BOM)
- Hết giờ chuẩn bị, bot **đứng lại 2.5 - 5 giây** nhìn quanh để "nghĩ" rồi mới đi, không còn lao ra bắn ngay.
- **T**: chọn một điểm bom, cả đội tụ ở **điểm tập kết** cách điểm bom khoảng 10 - 17 mét, tới khoảng giây thứ 26 mới cùng xông vào, người mang bom đặt, số còn lại bảo vệ.
- **CT**: chia nhau đứng **trấn giữ các vị trí khác nhau** quanh điểm bom của mình. Khi một CT thấy địch, tin được báo cho cả đội: **tối đa 2 CT ở điểm kia chạy sang chi viện**. Bom đặt xong thì CT kéo tới gỡ.
- Chỉnh: các hằng `THINK_MIN`, `THINK_MAX`, `T_WAIT`, `STAGE_*`, `HOLD_*` ở đầu `scripts/bomb.gd`. Chưa chạy thử trong Godot.

## Desert Eagle dùng mô hình .glb mới  (ĐÃ THAY THẾ: xem mục "Desert Eagle mới" cuối file)
- Mô hình súng Desert Eagle (file `assets/deagle/desert_eagle.glb`) đã được **nhúng thẳng** vào game thay cho hình dựng bằng code. Nòng trượt, băng đạn và cò vẫn chạy bằng animation cũ của game: giật khi bắn, nạp đạn 2.2 giây, rút súng, múa súng (F).
- Súng được thu nhỏ còn 90% cho vừa bàn tay. Muốn đổi cỡ hoặc vị trí thì sửa `MODEL_SCALE` và `MODEL_OFF` đầu file `scripts/deagle.gd`.
- Lần đầu mở game sau khi cập nhật, Godot sẽ nạp lại tài nguyên (chờ vài chục giây). Nếu vì lý do nào đó không nạp được file .glb thì game tự dùng lại hình súng cũ, không bị lỗi.
- File gốc còn có bản màu Crom và Vàng; hiện game chỉ dùng bản Đen. Chưa chạy thử trong Godot.

## Desert Eagle: báng nhỏ gọn, tay ôm đúng báng, súng tự nạp đạn  (ĐÃ THAY THẾ: xem mục "Desert Eagle mới" cuối file)
- **Báng súng** (phần cầm) đã được thu nhỏ: hẹp hơn khoảng 16% và ngắn (từ trước ra sau) hơn khoảng 24%, nhìn gọn và giống súng thật hơn.
- **Bàn tay phải** được đặt lại quanh báng mới nên không còn bị súng xuyên qua tay.
- **Nạp đạn**: không còn bàn tay nào chạm vào. Băng đạn cũ tự tụt xuống rồi rơi, băng mới tự trồi lên từ dưới báng; nếu hết đạn thì nòng trượt tự giật lùi rồi bật về. Thời gian nạp vẫn 2.2 giây.
- Chưa chạy thử trong Godot. Nếu bàn tay còn lệch, chụp ảnh gửi mình.

## Desert Eagle màu bạc, báng thon hơn  (ĐÃ THAY THẾ: xem mục "Desert Eagle mới" cuối file)
- Súng đổi sang bản **màu bạc (Crom)**: file `assets/deagle/desert_eagle.glb` giờ lấy từ bản Crom của bạn.
- Báng súng thu hẹp ngang thêm: còn khoảng 70% bề ngang gốc (trước là 84%). Bàn tay phải được dời sát lại theo.
- Chưa chạy thử trong Godot.

## Desert Eagle: animation nạp đạn mới  (ĐÃ THAY THẾ: xem mục "Desert Eagle mới" cuối file)
- Súng nghiêng và ngóc nòng để đáy báng quay về phía mắt, nên thấy rõ băng đạn.
- Băng cũ trượt ra rồi văng đi; súng lắc nhẹ như kiểm tra; băng mới trượt chéo từ dưới-trái lên (không còn bị bàn tay che) và đập vào báng làm súng giật.
- Hết đạn thì nòng trượt tự kéo lùi mạnh hơn rồi bật về. Vẫn tự động, không có bàn tay nào can thiệp, vẫn 2.2 giây.
- Chưa chạy thử trong Godot.

## Desert Eagle: cách cầm và nạp đạn kiểu CS2 (thay thế các mục nạp đạn phía trên)  (ĐÃ THAY THẾ: xem mục "Desert Eagle mới" cuối file)
- **Cách cầm**: tay phải ôm báng như CS2, gót bàn tay ôm lưng báng, **bốn ngón tách rời** quấn phía trước, ngón cái nằm dọc mặt trái thân súng, ngón trỏ duỗi dọc mặt phải.
- **Nạp đạn**: súng nghiêng sang trái, **tay trái** thò lên từ dưới-trái nắm đáy băng, kéo băng cũ ra rồi hất đi, bao lấy băng mới, đẩy vào báng (súng giật nhẹ). Nếu hết đạn thì tay trái vươn lên kéo nòng trượt cho đóng lại. Vẫn 2.2 giây.
- Chưa chạy thử trong Godot. Nếu bàn tay lệch, chụp ảnh gửi mình.

## Desert Eagle: màu bạc sáng + xem súng (phím F) dài 7 giây  (ĐÃ THAY THẾ: xem mục "Desert Eagle mới" cuối file)
- **Màu bạc**: trước đây kim loại "nguyên chất" của file model bị tối thành đen vì trong game không có ánh phản chiếu. Giờ thân súng, nòng trượt, băng đạn đã được sơn bạc sáng, độ kim loại vừa phải nên luôn sáng. Báng cao su vẫn đen.
- **Bấm F** xem súng dài **7 giây** (trước 3.2 giây), 5 nhịp: nâng súng lên trước mặt ngắm mặt phải, lật sang mặt trái, ngóc nòng lên và tay trái kéo nòng trượt lùi xem buồng đạn rồi thả bật về, xoay nhẹ xem phần trước nòng, hạ về tư thế cầm.
- Chưa chạy thử trong Godot.

## Desert Eagle cầm hai tay + người chơi phe T luôn mang bom
- **Cầm hai tay**: tay trái đỡ ngay dưới và trước tay phải, lòng bàn tay ép mặt trái báng, các ngón quấn phía trước đè lên ngón tay phải. Khi nạp đạn hoặc bấm F, tay trái rời ra làm việc rồi quay về đỡ báng.
- **Bom**: trước đây bom được giao ngẫu nhiên cho một trong ba người phe T, nên nhiều vòng người chơi không có bom (lăn chuột bao nhiêu cũng không ra). Giờ **người chơi phe T luôn là người mang bom** mỗi vòng (nếu còn sống). Bấm 6 hoặc lăn chuột để cầm bom, giữ chuột trái ở điểm A/B để đặt. Bot chỉ mang bom khi người chơi đã chết.
- Chưa chạy thử trong Godot.

## Nhân vật phe T và CT: người thật, chuyển động mượt (Đấu đội + Đặt bom)
- Bot không còn là các khối hộp. Giờ dùng **mô hình người thật có xương** (file `assets/gign/gign.fbx`), có mặt, tay, găng, áo giáp, mũ.
- **CT** mặc đồ xanh đen nguyên bản. **T** được nhuộm sang màu kaki nâu để dễ phân biệt.
- **Chuyển động giữ nguyên bộ chuyển động mượt cũ** của bot: bước chân theo hướng đi (tiến, lùi, ngang, chéo), đứng yên thì chân xoay chậm theo thân, hạ thấp người khi giao tranh, hông nhấp nhô, thân trên xoay theo hướng ngắm, giật khi trúng đạn, ngã theo hướng đạn khi chết. Bộ khối hộp vẫn chạy ngầm (ẩn đi) và các xương thật làm theo từng khung hình, hai tay dùng IK để cầm súng.
- File mới: `scripts/skin_rig.gd`. Nếu vì lý do nào đó không nạp được model thì tự dùng lại hình khối hộp cũ, không bị lỗi.
- Chưa chạy thử trong Godot. Lưu ý: cơ thể người chơi khi chết vẫn là hình khối cũ.

## Desert Eagle: đổi sang mô hình CS2 (nhúng thẳng)  (ĐÃ THAY THẾ: xem mục "Desert Eagle mới" cuối file)
- Súng DE trong game giờ là **mô hình Desert Eagle của CS2** (file `assets/deagle/desert_eagle.glb`, thay hoàn toàn mô hình cũ). Màu bạc sáng, báng cao su đen.
- File gốc nặng 48 MB vì có ba ảnh 4096x4096, sẽ làm máy yếu bị giật nên mình **thu ảnh về 1024x1024** (còn 2.5 MB) và bỏ phần animation kèm theo. Hình dạng súng giữ nguyên.
- **Nòng trượt, cò, băng đạn** là các xương của mô hình, được game điều khiển bằng animation sẵn có (giật khi bắn, nạp đạn, múa súng F). Băng rơi khi nạp đạn là một khối hộp bạc, vì băng của mô hình CS2 là một phần của thân súng.
- Bàn tay phải/trái được đặt lại cho khớp báng của mô hình mới (cầm hai tay).
- Nếu không nạp được file này, game tự dùng lại hình súng dựng bằng code, không bị lỗi.
- Chưa chạy thử trong Godot. Nếu súng bị lệch, quay ngược, quá to/nhỏ, hoặc nòng trượt/băng đạn chạy sai chiều thì chụp ảnh gửi mình.

## Desert Eagle dùng animation CÓ SẴN trong file CS2  (ĐÃ THAY THẾ: xem mục "Desert Eagle mới" cuối file)
- Trong file model có sẵn các animation của CS2, game giờ dùng chúng thay cho animation tự viết:
  - **Rút súng** (`firstperson_draw`, 1 giây, có cú xoay súng của CS2).
  - **Nạp đạn** (`firstperson_reload`, 2.17 giây): rút băng cũ, băng mới bay vào, kéo nòng trượt. Tay trái của game bám theo băng đạn và nòng trượt (file CS2 không có tay).
  - **Bắn**: ngẫu nhiên 1 trong 3 animation `shoot1/2/3` (nòng trượt giật, cò, búa), **viên cuối** dùng `shoot_empty` (nòng trượt kẹt lùi).
  - **Xem súng (F)**: ngẫu nhiên `lookat01` (5.7 giây) hoặc `lookat02` (8.5 giây).
  - **Đứng yên**: `idle`.
- Các animation còn lại trong file (`dropped`, `holstered`, `inventory_*`, `sh_pstl_*`, các bản `_additive`, `_start/_loop/_end`) cũng được giữ trong file model, nhưng chưa dùng vì dành cho nhân vật cầm súng ở góc nhìn thứ ba hoặc để xếp lớp.
- Chuyển động của cả khẩu súng trong animation được áp lên cả súng lẫn bàn tay phải nên tay cầm theo súng.
- Chưa chạy thử trong Godot. Nếu súng bay lệch khi nạp đạn hoặc xem súng, hoặc tay trái nắm sai chỗ, chụp ảnh gửi mình.

## Sửa cảnh báo / lỗi đỏ khi mở game lần đầu
- Lỗi đỏ "Animation name firstperson_lookat01 already exists": đã sửa trong file súng Desert Eagle (đổi tên các animation `_loop` bị trùng tên).
- Cảnh báo vàng "non-finite normal in LOD generation": đã tắt tạo LOD cho mô hình GIGN.
- Cảnh báo "Adding ... as child to Skeleton3D": là cảnh báo vô hại của Godot khi nạp file .fbx lần đầu, không ảnh hưởng game. Chúng được ghi vào file `godot_engine\import_log.txt` thay vì hiện ra cửa sổ đen.
- Lần đầu mở bản này game sẽ nạp lại tài nguyên (1-2 phút), các lần sau mở ngay.

## Bàn tay thật (từ pack "M4 FPS weapon animations")
- Tay trong game là **bàn tay + cẳng tay thật** có găng tay (không lấy súng của pack). Hai file `assets/hands/hand_r.glb` (phải) và `hand_l.glb` (trái) nướng sẵn từ tư thế cầm súng của pack, nên ngón tay **giữ nguyên một tư thế**.
- Bàn tay được **gắn vào đúng node tay của từng súng** (tâm vòng ôm của bốn ngón đặt trùng tâm báng / ốp tay / cán dao), nên tay đi theo mọi động tác nạp đạn, xem súng, rút súng.
- Glock và Desert Eagle: tay phải cầm báng, tay trái là bàn tay phải lật đối xứng ôm báng bên trái. M4A1 và AK-47: tay phải cầm báng, tay trái ôm ốp tay. Dao: tay phải nắm cán (không xoay theo cú lật dao). Bom C4 vẫn dùng tay khối hộp cũ.
- Chỉnh nếu tay lệch: hằng `HAND_SCALE`, `GM_R`, `GM_L` ở đầu `scripts/hands.gd`; điểm đặt tay từng súng là các dòng `limb_r.attach(...)` / `limb_l.attach(...)` cuối hàm `_ready` của từng file súng (tham số cuối của tay trái súng trường = độ nâng bàn tay lên ôm ốp tay lúc nghỉ, tự mất đi khi tay đi nạp đạn)./
- Không nạp được file `.glb` thì tự quay về tay khối hộp.


## Đã bỏ: ngắm (ADS), hạ súng sát tường, tự nghiêng người sát góc
- **Không còn ngắm** (chuột phải không làm gì với súng; dao vẫn dùng chuột phải để đâm). Camera không zoom, tốc độ đi và độ tỏa đạn không còn phụ thuộc ngắm.
- **Không còn cụp / hạ súng khi sát tường** và **không còn tự nghiêng người (peek) khi đứng sát góc vật cản**. Các đoạn code này đã xoá khỏi `scripts/player.gd`.
- Trong các file mô hình súng (`viewmodel.gd`, `rifle.gd`, ...) còn sót code ADS / `wall_push` nhưng không còn được kích hoạt (player không bao giờ bật `ads` hay `wall_push`). **Đừng thêm lại.**

## Thêm súng mới: luôn dùng bàn tay thật
- Xem `CLAUDE.md` (quy tắc cho Claude) và mục "Bàn tay thật" ở trên. Súng mới chỉ cần tạo `Hands.Arm` như các súng khác, bàn tay thật tự hiện, tay khối hộp tự ẩn.

## Desert Eagle: rút súng chỉ xoay súng, tay đứng yên  (ĐÃ THAY THẾ: xem mục "Desert Eagle mới" cuối file)
- Khi đổi sang Desert Eagle, hai bàn tay giữ yên, chỉ cây súng xoay trong tay (trước đây tay xoay theo súng).
- Bỏ đoạn mở đầu của animation (lúc đó trông như đang cầm bình thường rồi mới giật sang xoay): animation vào thẳng cú xoay từ khung hình đầu tiên, chạy nhanh hơn 1,4 lần (còn khoảng 0,57 giây).
- Chỉnh ở đầu `scripts/deagle.gd`: `DRAW_ANIM_START` (bỏ bao nhiêu giây đầu), `DRAW_ANIM_SPEED` (độ nhanh).

## Đã bỏ: cụp nhẹ súng khi chạy nước rút
- Chạy nước rút không còn hạ/nghiêng súng; súng luôn ở tư thế sẵn sàng như CS2 (`vm.run_amount` luôn 0 trong `player.gd`).

## Glock 17: đổi sang mô hình mới
- Cây Glock 17 giờ dùng mô hình 3D thật (`assets/glock17/glock17.glb`, làm từ file bạn gửi, kèm bản đồ pháp tuyến để thấy chi tiết nổi), thay cho cây ghép bằng khối hộp.
- Nòng trượt vẫn chạy lùi khi bắn, đế băng đạn vẫn đi theo băng đạn khi nạp. Mô hình gốc là một khối liền nên cò súng không nhúc nhích riêng.
- Báng súng mới nằm lùi/nhô khác cây cũ nên bàn tay có thể cần chỉnh lại sau khi bạn xem thử.
- Lần mở đầu sau khi cập nhật, game sẽ nhập lại tài nguyên một lần (lâu hơn bình thường).
- Glock 17: dời vị trí cầm súng trên màn hình để bàn tay phải nằm lại chỗ cũ (gọn như trước), nòng súng hơi ngắn đi trên màn hình.

## Nhặt / vứt đồ (E / G), mua đồ không còn bị khóa
- **Mỗi người chơi cầm tối đa:** 1 súng chính (M4A1 / AK-47) + 1 súng lục (Glock / Desert Eagle) + 1 dao. Loại của từng súng nằm trong bảng `SLOT_OF` ở đầu `player.gd`.
- **Mua đồ không còn bị khóa món:** thẻ trong cửa hàng luôn hiện giá và luôn bấm mua được nếu đủ tiền (kể cả khẩu đang có). Nếu đang cầm khẩu **cùng loại** thì khẩu cũ **tự rơi xuống đất** (kèm số đạn hiện tại), khẩu mới được cầm luôn. Súng chính và súng lục không ảnh hưởng nhau. Mua M4A1 khi đang cầm AK-47 thì AK-47 rơi ra.
- **Vứt (G):** vứt món đang cầm ra trước mặt, rồi tự cầm món tốt nhất còn lại (súng chính > súng lục > dao). **Dao không vứt được** (hiện chữ "Không thể vứt dao"). Cầm bom C4 bấm G cũng vứt được (xem dưới).
- **Nhặt (E):** nhìn thẳng vào súng dưới đất trong vòng khoảng 2,6 m (không bị tường che), hiện dòng "Bấm E để nhặt ..." rồi bấm E. Nếu đang cầm khẩu cùng loại thì hai khẩu **đổi chỗ**. Súng nhặt lại giữ nguyên số đạn lúc bị vứt.
- **Súng nằm dưới đất đến hết round:** chế độ Đặt bom dọn sạch khi sang round mới; các chế độ khác dọn khi bắt đầu trận mới. Tối đa 36 khẩu cùng lúc (quá thì mất khẩu cũ nhất).
- **Bom C4:** phe **T** chỉ cần **đi tới** là tự nhặt (không cần bấm E). Phe **CT không nhặt được** bom. T bấm G khi đang cầm bom thì bom nằm lại trước mặt, khoảng 2 giây sau mới tự nhặt lại được (để khỏi nhặt lại ngay lập tức).
- Bấm E gần bom đang đặt (CT gỡ bom) có ưu tiên hơn nhặt súng: khi đang hiện dòng nhắc gỡ / đặt bom thì không nhặt súng.
- Phím **1** giờ chọn súng chính bất kỳ đang cầm (M4A1 / AK-47). Phím **2** chọn súng lục; vứt hết súng lục thì phím 2 về dao.
- Code: `scripts/pickups.gd` (đồ rơi, mô hình súng dưới đất ghép bằng khối hộp, nhìn + nhặt), `Player.give_weapon / drop_current / slot_of` trong `player.gd`, `bomb.gd` (`player_drop_c4`, `_pickup_check`).

## Phím 3: DAO BƯỚM CS:GO (thay cho nắm đấm tay không)
- Phím **3** giờ là **dao bướm** nhúng thẳng từ gói `butterfly_knife` (`CT/v_knife.mdl` và `T/v_knife.mdl`): dao + hai bàn tay + mọi animation gốc. Phe **CT** thấy tay áo xanh (FBI), phe **T** thấy tay trần găng hở ngón; đổi phe giữa trận thì tay áo đổi theo. Nắm đấm cũ (dựng bằng code) đã **xoá hẳn**.
- Chỉ lấy **MỘT con dao** (dao bướm với skin mặc định nhúng sẵn trong model). 24 skin sơn khác trong thư mục `Textures` của gói (Fade, Doppler, Tiger Tooth...) không dùng.
- **Chuột trái**: chém, `slash1` và `slash2` xen kẽ. **Chuột phải**: đâm mạnh (`heavy_miss`); nếu có địch đang quay lưng trong tầm đâm thì chạy animation **đâm sau lưng** (`backstab`, hạ gục ngay). **F**: múa dao (3 kiểu xen kẽ). Rút dao có 2 kiểu xen kẽ. Sát thương (40 / 65 / 195 sau lưng), tầm với và thưởng hạ gục $1500 giữ nguyên như dao cũ. Tên trên giao diện: BUTTERFLY.
- **Âm thanh có sẵn trong gói nên đã nhúng** (`assets/knife/sounds/`, 9 file): tiếng rút dao, múa dao (hai tiếng mỗi kiểu), đâm sau lưng, phát đúng thời điểm sự kiện ghi trong model. Gói không có tiếng chém / trúng nên không thêm tiếng đó. Tiếng tự tắt khi đổi súng.
- Code: `scripts/knife.gd` (cùng giao diện với `mp5.gd`, thêm tín hiệu `melee_hit` đúng lúc lưỡi dao chạm: chém 0.17 s, đâm mạnh 0.38 s, đâm sau lưng 0.5 s, đo từ chuyển động lưỡi dao), `Player.melee_backstab_ready()` (hỏi có địch quay lưng trong tầm đâm không), model `assets/knife/v_knife_ct.glb` (2.5 MB) và `v_knife_t.glb` (2.1 MB). Khác AK-47: model dao vẽ đúng cho tay phải nên **không lật gương**.
- Đổi model: `python3 tools/mdl2glb.py CT/v_knife.mdl assets/knife/v_knife_ct.glb --vm --atlas --jpeg` (và tương tự cho T). Tool `mdl2glb.py` giờ lưu track dịch chuyển / xoay bất biến chỉ 1 khoá nên file animation nhẹ hơn. File `.mdl` gốc không đưa vào project cho nhẹ game (để đủ dưới 25 MB mình cũng bỏ `assets/mp5/v_mp5.mdl`: chỉ là file nguồn, game không đọc; muốn đổi lại thì lấy từ gói model MP5 của bạn). **Chưa chạy thử trong Godot**: cần xem dao có nằm ở tay phải, đòn chém / đâm có trúng đúng lúc nhìn thấy lưỡi dao chạm, tiếng có đúng khớp animation.

## Hình 3D nét hơn (địch ở xa bớt mờ)
- Độ phân giải 3D mặc định tăng từ 720x405 lên **960x540** (trước đây bị phóng to ra cửa sổ nên mờ). Thêm mức cao nhất 1280x720. Bấm **F4** để đổi mức; nếu FPS dưới 40 game vẫn tự hạ độ phân giải. Chưa chạy thử trong Godot.

## Phe T đổi sang model "Faithful Terror" (Counter-Strike 1.6)
- Bot **phe T** (Đấu đội / Đặt bom) giờ là nhân vật khủng bố đeo mặt nạ, áo giáp, ba lô của file `faithful_terror.zip` (model `.mdl` của CS 1.6, mình đã **tự đổi sang `assets/terror/terror.glb`** vì Godot không đọc được `.mdl`: giữ nguyên xương, ảnh và **toàn bộ 100 animation** của file gốc). Chỉ đổi ngoại hình nhìn từ bên ngoài, **tay ở góc nhìn thứ nhất của bạn không đổi**. Phe CT vẫn là GIGN.
- Cách dùng animation (`scripts/terror_rig.gd`, bot.gd tự chọn): đứng yên = `idle1`; đi bộ = `walk`; chạy = `run` (tốc độ phát khớp tốc độ thật của bot nên chân không trượt nhiều); đang ở trên không = `jump`; **chết** = `head` (bị bắn vào đầu) / `back` (ngã ngửa) / `forward` (ngã sấp) / `left` / `right` / `death1` / `death2` / `death3` / `gutshot` / `crouch_die` (chọn theo hướng đạn, thêm chút ngẫu nhiên cho đỡ giống nhau). Hông xoay theo hướng chạy, thân trên và đầu theo hướng ngắm, hai tay vẫn IK để cầm khẩu súng của bot.
- 100 animation còn lại (ngắm, bắn, nạp đạn từng loại súng, ngồi, bơi...) đã nằm sẵn trong file `terror.glb` nhưng **chưa dùng**: bot chỉ có một khẩu súng khối hộp và tay đã bám súng bằng IK. Dùng thêm được nếu sau này bot có nhiều loại súng.
- Nếu không nạp được model, bot phe T quay về model GIGN nhuộm kaki như cũ (nhánh dự phòng). `CHOI_GAME.bat` đã đổi cờ import lên `imported_v24` nên lần chạy đầu sẽ import model mới (mất thêm khoảng nửa phút). Công cụ đổi `.mdl` -> `.glb` nằm ở `tools/` (Godot bỏ qua). Chưa chạy thử trong Godot.

## Phe CT đổi sang model "Yuri Classic" (CS Online)
- Bot **phe CT** giờ là cô gái Yuri (áo đỏ, buộc tóc đuôi ngựa) từ file `cso_yuri_classic`, đổi từ `.mdl` sang `assets/yuri/yuri.glb` bằng cùng công cụ như phe T (97 xương, **toàn bộ 108 animation** của file gốc, cao khoảng 1,72 m, texture có phần trong suốt cho tóc và viền áo). Chỉ đổi ngoại hình bên ngoài; tay góc nhìn thứ nhất của bạn không đổi. File âm thanh trong gói (tiếng chết, tiếng trúng đạn) chưa dùng.
- Cách dùng animation giống phe T (cùng `scripts/terror_rig.gd`, chỉ khác cấu hình `CONFIGS`): đứng = `idle`, đi = `walk`, chạy = `run`, trên không = `jump`, chết = `head` / `back` / `forward` / `left` / `right` / `death1-3` / `gutshot` / `crouch_die` theo hướng đạn; hông xoay theo hướng chạy, thân và đầu theo hướng ngắm, hai tay IK cầm súng. Các animation ngắm / bắn / nạp đạn từng loại súng đã nằm trong file nhưng chưa dùng.
- Hỏng thì phe CT quay về model GIGN như cũ. Chưa chạy thử trong Godot.


## Người chơi cũng dùng model Yuri (CT) / Terror (T)
- Trước đây chỉ bot đổi model, người chơi vẫn là hình hộp vuông. Giờ thân người của **bạn** cũng là model thật: chọn phe CT thì là Yuri, phe T thì là Terror.
- Góc nhìn thứ nhất không thấy thân mình (chỉ thấy tay như cũ), nên model hiện ra ở **camera lúc chết**: nhân vật ngã bằng animation chết thật (đạn từ trước thì ngửa ra sau, từ sau thì sấp, bắn vào đầu thì kiểu trúng đầu, ngẫu nhiên vài kiểu khác). Khẩu súng vẫn văng ra khỏi tay như cũ.
- Nếu không nạp được model thì tự quay về hình hộp cũ. Code: `scripts/corpse.gd` + `scripts/terror_rig.gd`.

## Skin mới "Midnight Miho" (CT) + Cửa hàng + Bộ sưu tập
- Model `cso_midnight_miho` (CS Online) đã đổi sang `assets/miho/miho.glb`, đủ 108 animation như Yuri. Skin này **chỉ dành cho phe CT**; phe T không dùng được.
- **Mua**: ở sảnh chờ bấm **CỬA HÀNG**, bấm thẻ Miho (hiện đang **miễn phí**, sau này đặt giá ở `scripts/skins.gd`). Mua xong skin nằm trong **BỘ SƯU TẬP**.
- **Dùng**: vào **BỘ SƯU TẬP**, **bấm chuột phải** vào thẻ Miho sẽ ra 3 lựa chọn:
  1. **Áp dụng skin cho phe CT** (khi đang dùng thì đổi thành **Gỡ skin**, phe CT quay về Yuri mặc định).
  2. **Dùng cho cả phe**: bạn và toàn bộ bot CT đều là Miho.
  3. **Dùng chỉ riêng mình**: chỉ thân của bạn là Miho, bot CT vẫn là Yuri. Góc nhìn thứ nhất không thấy thân mình, nên thân Miho chỉ hiện ở camera lúc bạn chết.
- Lựa chọn được lưu ở `user://skins.cfg`, mở lại game vẫn còn. Đổi skin lúc đang ở sảnh thì bot CT đổi ngay.
- Thêm skin mới: thêm mục vào `DATA` trong `scripts/skins.gd` + mục trong `CONFIGS` của `terror_rig.gd` + ảnh icon. Chưa chạy thử trong Godot (cờ import đã lên `imported_v26`, lần chạy đầu import thêm model).

## Skin mới "Abia" (CT) trong Cửa hàng
- Model `[CSO]Abia` (CS Online, file `buffclass25s4tr.mdl`) đã đổi sang `assets/abia/abia.glb` bằng `tools/mdl2glb.py` (76 xương, **108 animation** như Yuri, tỉ lệ chỉnh để cao bằng Yuri ~1,85 m). Ảnh thẻ cửa hàng: `assets/abia/abia_icon.png` (render toàn thân từ chính model). Skin **chỉ dành cho phe CT**; phe T không dùng được.
- **Mua**: sảnh chờ, bấm **CỬA HÀNG**, bấm thẻ **ABIA** (đang **miễn phí**; sau này đặt giá ở mục `"abia"` trong `scripts/skins.gd`). Chưa mua thì chưa thấy trong BỘ SƯU TẬP.
- **Dùng**: vào **BỘ SƯU TẬP**, **bấm chuột phải** vào thẻ ABIA ra 3 lựa chọn (giống Miho):
  1. **Áp dụng skin cho phe CT** (đang dùng thì thành **Gỡ skin**: phe CT quay về **Yuri** mặc định).
  2. **Dùng cho cả phe**: bạn và bot CT đều là Abia.
  3. **Dùng chỉ riêng mình**: chỉ thân bạn là Abia (hiện ở camera lúc chết), bot CT vẫn là Yuri.
- Cùng lúc chỉ dùng được MỘT skin (Miho hoặc Abia); chọn skin này sẽ thay skin kia. Lựa chọn lưu ở `user://skins.cfg`.
- Cờ import đã lên `imported_v26`: lần chạy đầu game sẽ import thêm model Abia (vài chục giây). CHƯA chạy thử trong Godot.
- Chưa dùng: âm thanh trong gói skin (tiếng chết / trúng đạn trong thư mục `sound`).

## Sửa Cửa hàng / Bộ sưu tập: cuộn ngang
- Hàng thẻ skin giờ nằm trong khung **cuộn ngang**: skin nào vượt chiều rộng thì lăn chuột hoặc kéo thanh cuộn bên dưới để xem. Đã xoá các dòng chữ "ĐÃ CÓ · XEM Ở BỘ SƯU TẬP" và "mua xong xem trong BỘ SƯU TẬP". CHƯA chạy thử trong Godot.

## Skin Nekopara (2 skin, chỉ phe CT) trong Cửa hàng
- Gói `nekopara_skins` (2 model CS 1.6 `gign.mdl`, `gsg9.mdl`) đã đổi sang `assets/neko_gign/neko_gign.glb` (**NEKO TÓC NÂU**) và `assets/neko_gsg9/neko_gsg9.glb` (**NEKO TÓC TRẮNG**) bằng `tools/mdl2glb.py` (tỉ lệ chỉnh để cao bằng Yuri ~1,85 m, đủ **108 animation**). Model được nhúng thẳng vào game (texture nằm trong file .glb), ảnh thẻ cửa hàng là `neko_*_icon.png` (render toàn thân từ chính model).
- Hai skin **chỉ dành cho phe CT**; phe T không dùng được.
- **Mua**: sảnh chờ, bấm **CỬA HÀNG**, bấm thẻ skin (đang **miễn phí**; sau này đặt giá ở mục `"neko_gign"` / `"neko_gsg9"` trong `scripts/skins.gd`). Chưa mua thì chưa thấy trong BỘ SƯU TẬP. Danh sách thẻ có thanh cuộn ngang, lăn chuột để xem thêm.
- **Dùng**: vào **BỘ SƯU TẬP**, **bấm chuột phải** vào thẻ skin ra 3 lựa chọn:
  1. **Áp dụng skin cho phe CT** (đang dùng thì đổi thành **Gỡ skin (về Yuri)**): gỡ skin sẽ trả phe CT về skin mặc định **Yuri**.
  2. **Dùng cho cả phe**: bạn và toàn bộ bot CT đều dùng skin đó.
  3. **Dùng chỉ riêng mình**: chỉ thân bạn dùng skin (hiện ở camera lúc chết), bot CT vẫn là Yuri.
- Cùng lúc chỉ dùng được MỘT skin (Miho, Abia hoặc một trong hai skin Nekopara); chọn skin này sẽ thay skin kia. Lựa chọn lưu ở `user://skins.cfg`.
- Cờ import đã lên `imported_v27`: lần chạy đầu game sẽ import thêm 2 model (vài chục giây). CHƯA chạy thử trong Godot.

## Cầm súng tay trái (Cài đặt)
- **CÀI ĐẶT** (ở sảnh hoặc trong menu tạm dừng Esc) có thêm mục **CẦM SÚNG TAY TRÁI**, bấm **BẬT** / **TẮT**. Đổi được ngay giữa trận, lưu ở `user://settings.cfg`.
- Khi bật, mọi mô hình súng góc nhìn thứ nhất (Glock, Desert Eagle, M4A1, AK-47, dao bướm, C4) được **lật gương** sang trái: súng + bàn tay phải thành súng + bàn tay trái; vỏ đạn, băng đạn rơi, tia lửa nòng cũng lật theo. Cách làm: `Player.set_left_hand()` đặt `scale.x = -1` cho từng viewmodel (con của camera); chuột lắc súng được đảo chiều cho đúng cảm giác.
- Chỉ đổi góc nhìn thứ nhất; thân nhân vật (bot / xác) không đổi. Chữ khắc trên súng sẽ bị ngược như soi gương. CHƯA chạy thử trong Godot.

## Đã xoá: Dual Uzi và chế độ ZOMBIE DEFENSE (theo yêu cầu người dùng)
- **Dual Uzi**: bỏ khỏi game (súng, mô hình, âm thanh, hình trong cửa hàng, súng rơi dưới đất). Phím 4 không còn chọn súng nào. Cửa hàng còn 4 thẻ: M4A1 (1), AK-47 (2), Desert Eagle (3), Mua đạn (4).
- **Chế độ ZOMBIE** và mọi thứ đi kèm: nút ZOMBIE ở sảnh, map zombie, zombie thường, zombie chó, Brute (zombie trâu), đồng đội GIGN, căn nhà thủ thành trên đồi, ngày sống sót + chữ "Ngày N" + đồng hồ góc phải, yếu tố kinh dị (sương, sấm chớp, đèn pin phím V, tim đập), âm thanh môi trường zombie.
- Đã xoá các file: `scripts/uzi.gd`, `zombie.gd`, `dog.gd`, `brute.gd`, `ally.gd`, `horror.gd`; thư mục `assets/uzi`, `assets/zombie`, `assets/dog`, `assets/brute`, `assets/audio`; file `assets/zombie_map.glb`. `assets/gign` giữ lại vì bot còn dùng làm model dự phòng.
- Chỉ còn hai chế độ: ĐẤU ĐỘI và ĐẶT BOM. Lần đầu chạy sau bản này `CHOI_GAME.bat` nạp lại tài nguyên (cờ `imported_v28`), mất 1-2 phút. Chưa chạy thử trong Godot.
- Dọn file rác: xoá `CHOI_GAME_MAY_YEU.bat`, thư mục `tools/__pycache__`, và vài hằng số / hàm không ai dùng (`C_PAD`, `SITE_WANT`, `strafe_t`, `ARM_LEN`, `ARM_THICK`, `eye_position`, `_TZ`, `DEFAULT_T`, `BG`, `ACCENT_DIM`). Không đổi cách chơi.

## Bot giống người chơi thật hơn (cập nhật)
- **Tầm nhìn**: bot chỉ thấy địch trong góc 120 độ phía trước, không còn nhìn được sau lưng. Địch ở xa / đứng yên thì bot nhận ra chậm hơn (khoảng 0,2-0,7 giây), địch đang chạy thì dễ thấy hơn.
- **Nghe**: bot nghe thấy bước chân khi địch CHẠY ở gần (đi bộ / ngồi thì không), và nghe tiếng súng của địch. Nghe thấy gần thì đứng lại lắng nghe rồi mới đi kiểm tra.
- **Hô đồng đội**: bot thấy địch sẽ báo cho đồng đội ở gần, khoảng 1 giây sau họ quay về phía đó.
- **Tính cách**: mỗi bot có độ hung hăng và độ kiên nhẫn riêng. Kẻ hung hăng tiến lên áp sát, kẻ thủ đứng bắn từ xa và canh góc lâu hơn.
- **Bắn**: ngắm chưa chuẩn lúc mới thấy địch rồi chuẩn dần; bắn từng loạt ngắn (xa) hoặc xả dài (gần), giật súng khi xả liên tục, chạy hoặc địch chạy ngang thì lệch nhiều hơn. Thỉnh thoảng nhắm đầu. Băng 30 viên, hết đạn phải nạp (khoảng 2,3 giây) nên có điểm yếu.
- **Biết giữ mạng**: máu yếu hoặc đang nạp đạn mà bị địch nhìn thấy thì chạy về chỗ nấp rồi đứng canh góc vài giây, không lao ra liền. Mất dấu địch thì đoán hướng địch chạy tiếp để đi kiểm tra.
- **Đặt bom (T)**: mỗi round tụ lại với thời gian khác nhau (thỉnh thoảng rush sớm). Người mang bom chỉ vào điểm bom khi có đồng đội tới dọn đường (hoặc sắp hết giờ). Sau khi đặt bom, T chọn chỗ nhìn thấy quả bom để canh, không đi lang thang.
- **Gỡ bom (CT)**: người gần bom nhất đi gỡ, nhưng nếu vừa thấy địch canh bom thì chờ đồng đội dọn trước (trừ khi sắp hết giờ). Tính thời gian: không kịp gỡ thì bỏ cuộc và chạy đi (save). CT khác chọn chỗ xa hơn để yểm trợ.
- **Canh điểm bom (CT)**: đứng lâu ở vị trí, nhìn về hướng T sẽ tới, thỉnh thoảng mới đổi chỗ.
- Chỉnh số trong `scripts/bot.gd` (đầu file: `FOV_HALF`, `MAG_SIZE`) và `scripts/bomb.gd` (`T_WAIT`, hàm `_t_ready`, `pick_goal`).

## Súng và tiền của bot (cập nhật)
- Bot dùng đúng 4 khẩu súng của game: **Glock 17, Desert Eagle, M4A1, AK-47**. Sát thương, băng đạn, đạn dự trữ, suy giảm theo khoảng cách, nhân sát thương đầu / chân và tiếng súng lấy thẳng từ bảng súng của người chơi (`Player.WEAPONS`). Mô hình súng trên tay bot là mô hình súng rơi dưới đất của game.
- **Round pistol (đầu trận / đầu hiệp 2): ai cũng $800, cầm Glock**, một số bot mua Desert Eagle ($700).
- Từ round sau bot **mua theo tiền**: đủ tiền thì T mua AK-47 ($2700), CT mua M4A1 ($2700). Không đủ thì giữ súng lục (thỉnh thoảng mua Desert Eagle) để dành tiền.
- Tiền bot tính cùng luật với người chơi: thắng +$3250; thua +$1400 + $500 cho mỗi round thua liên tiếp (T đã đặt bom mà thua +$800); giết địch +$300; đặt bom / gỡ bom +$300.
- Bot **còn sống thì giữ súng sang round sau**, **chết thì mất súng** (về Glock). Bot chết sẽ **thả khẩu súng xuống đất, bạn bấm E để nhặt**.
- Cách bắn khác nhau theo súng: AK / M4 xả loạt ngắn rồi nghỉ, súng lục bắn nhát một, Desert Eagle bắn chậm nhưng một phát rất đau; nạp đạn theo từng khẩu (khoảng 2,2-3 giây).
- Chế độ ĐẤU ĐỘI (không có round): bot chết rồi hồi sinh sẽ mất súng, tiền tích từ việc giết địch, đủ tiền thì mua lại.
- Khi chết, súng văng ra khỏi tay (người chơi và bot) giờ là đúng khẩu đang cầm, không còn khẩu súng hộp lạ. Bot chết thả khẩu đang cầm (kể cả Glock) xuống đất để nhặt.
- Bot cầm súng lục giờ duỗi hai tay thẳng trước ngực (không còn vác lên vai như cầm súng trường). Tư thế cầm của từng khẩu nằm trong `WEAPON_AI` (`ready_pos`, `ready_rot`, `aim_pos`, `grip_r`, `grip_l`) ở đầu `scripts/bot.gd`.

## Skin KRATOS (phe T) và bỏ âm thanh (cập nhật)
- Thêm skin **KRATOS** (model CS 1.6 `kratos_ct.rar`, đổi sang `assets/kratos/kratos.glb`, giữ đủ 100 animation, texture ép còn 256 px). Có trong **CỬA HÀNG** (miễn phí). Mua xong vào **BỘ SƯU TẬP**, chuột phải vào thẻ để chọn: *Áp dụng skin cho phe T / Gỡ skin (về Terror)*, *Dùng cho cả phe* (bạn + bot T), *Dùng chỉ riêng mình*. Gỡ skin thì phe T quay về skin mặc định **Terror**.
- Hệ thống skin giờ nhớ riêng skin đang dùng của từng phe (CT và T). Bộ sưu tập hiện hai skin mặc định (Yuri cho CT, Terror cho T).
- Đổi model: `python3 tools/mdl2glb.py <file.mdl> out.glb 0.027111` rồi `python3 tools/glbslim.py out.glb assets/<tên>/<tên>.glb 256 -` (ép texture, gộp keyframe thừa, giữ nguyên mọi animation). Thêm mục vào `CONFIGS` (`terror_rig.gd`) và `DATA` / `ORDER` (`skins.gd`).
- **Đã xoá toàn bộ âm thanh**: không còn tiếng nào, bỏ file `sfx.gd`, bỏ thanh Volume trong cài đặt, bus âm thanh tắt hẳn.

## Sửa kẹt bậc thềm ở Mirage (cập nhật)
- **Nguyên nhân**: ánh sáng nướng vào màu đỉnh làm map bị chia thành rất nhiều tam giác nhỏ, và chính các tam giác này cũng được dùng làm va chạm nên người / bot hay vấp vào mép tam giác. Thuật toán bước lên bậc cũ cũng chỉ thử một độ nhấc và một độ dài bước, gặp cầu thang nhiều bậc liên tiếp là đụng bậc kế tiếp nên thất bại.
- **Va chạm riêng**: `mirage_map.glb` giờ có mesh nhìn (`chunk_*_nocol`, không va chạm) và mesh va chạm riêng (`col_*_hide`, không chia nhỏ, vô hình). Dựng lại bằng `python3 tools/bsp2glb.py <map.bsp> assets/mirage_map.glb 0.0254 160`.
- **Bước lên bậc mới** (người chơi và bot, hàm `_slide_with_step`): khi bị chặn thì thử nhiều độ nhấc (0,24 / 0,42 / 0,6 m) và nhiều độ dài bước tới (0,2 - 0,55 m), chọn cách đầu tiên đặt chân được lên mặt phẳng. Hết chân khỏi sàn trong 0,12 giây vẫn bước được. Sửa số ở `STEP_HEIGHTS`, `STEP_FWD` đầu hàm trong `player.gd` / `bot.gd`.

## Mirage: lấp các vách "trong suốt mà là tường" + bot hết kẹt (cập nhật)
- Map Mirage có nhiều vách vô hình (có va chạm nhưng không được vẽ), ví dụ cổng vòm cạnh chỗ xuất phát của CT: nhìn xuyên qua được nhưng đi không lọt. Các vách đứng đó giờ được vẽ bằng gạch (cao tối đa 14 m). Chỗ có hàng rào chạm vào được giữ nguyên để vẫn nhìn xuyên.
- Bot không còn va cứng vào nhau (chỉ đẩy nhẹ ra xa), nên hai bot không chặn nhau ở lối hẹp.
- Bot bị kẹt (muốn đi mà không nhích): khoảng 1 giây thì nhảy + né sang bên, khoảng 2,5 giây thì đổi đích, khoảng 3,5 giây thì được đưa tới điểm kế tiếp trên đường đi (chỉ khi người chơi không nhìn thấy; kẹt quá 8 giây thì đưa luôn).
- Chưa chạy thử trong Godot. Lần mở game đầu sẽ import lại map nên hơi lâu (cờ `imported_v30`).

## AWP kiểu CS:GO / CS2 (mới)
- **Mua:** bấm B mở cửa hàng, thẻ AWP (phím 5), giá $4750. Cầm AWP là súng chính (phím 1 hoặc lăn chuột để đổi súng). 5 viên / dự trữ 30.
- **Model + tay + animation nhúng thẳng từ file `v_awp.mdl` của CS** (`assets/awp/v_awp.glb`, file gốc `assets/awp/v_awp.mdl` để cạnh đó): rút súng, bắn + kéo bolt, nạp đạn, inspect (phím F) đều là animation của model.
- **Cách chơi như CS:** chuột PHẢI = ngắm (zoom 1), bấm chuột phải thêm lần nữa = zoom 2, lần nữa = tắt ngắm. Chuột TRÁI = bắn. Bắn xong tự thoát ngắm (phải bấm chuột phải lại), bolt-action 1.45 giây mới bắn được phát nữa.
- **Sát thương:** 115. Trúng thân = chết ngay, trúng đầu = chết chắc, trúng chân còn ~14 máu.
- **Độ chính xác:** ngắm + đứng yên = trúng đúng tâm. Ngắm mà đang đi / chạy = lệch rất nhiều (đứng lại rồi hãy bắn). Bắn khi KHÔNG ngắm hoặc đang nhảy = lệch rộng. Đang ngắm đi chậm một nửa. Chuột chậm lại theo độ zoom. Nạp đạn / đổi súng tự thoát ngắm.
- Chưa chạy thử trong Godot. Lần mở game đầu sẽ import lại model nên hơi lâu (cờ `imported_v31`).

## Tối ưu FPS toàn game (mới)
- **Map Mirage:** gộp toàn bộ texture thành một tấm lớn và chia mặt theo ô lặp, giảm số lần vẽ của map từ 100-550 xuống khoảng 10-30 mỗi khung hình (đây là chỗ nặng nhất với card Intel HD). Hình ảnh và va chạm giữ nguyên. File map nặng hơn (28 MB) và **lần mở đầu tiên Godot import lại mất 1-3 phút, đừng tắt cửa sổ**.
- **Bot:** bot ở sau lưng / ngoài màn hình không còn tính animation (đỡ CPU), bot ở xa cập nhật nửa số khung hình.
- **Tắt vsync** (vsync bật trên màn 60 Hz làm FPS rơi thẳng xuống 30 khi chậm hơn chút). Game tự hạ độ phân giải 3D nếu FPS trung bình dưới 50.
- Bấm **F3** để xem FPS, thời gian script/vật lý, số lần vẽ (draw calls). Gửi dòng đó nếu vẫn chậm.

## Dọn dẹp và nén file (mới)
- File zip từ khoảng 40 MB xuống khoảng 20 MB mà game giữ nguyên: các model nhân vật chỉ giữ lại 16 animation game thật sự dùng (đi, chạy, nhảy, đứng yên, ngồi, các kiểu chết), map được nén gọn hơn, xoá model GIGN dự phòng và code không còn ai dùng.
- Hình ảnh và hành vi trong game không đổi. **Lần mở đầu tiên Godot vẫn import lại nên hơi lâu.**

## MP5-SD (kiểu CS2) - súng mới, nhúng thẳng model CS (mới)
- **Mua ở cửa hàng (B), phím 6, giá $1400**. Là súng chính (cầm chung chỗ với M4A1 / AK-47 / AWP, phím 1 chọn lại). Dùng model + hai bàn tay + animation + âm thanh lấy thẳng từ gói `low_poly_mp5-sd` (bản tay áo GSG9; còn 4 bản tay áo khác trong gói, xem `CLAUDE.md` nếu muốn đổi).
- **Chỉ số lấy theo CS2 (dữ liệu game mới nhất):** băng 30 viên, dự trữ 120, bắn tự động 750 phát/phút, sát thương 28 (thân), đầu x4 = 112, chân x0.75 = 21, hao dần theo khoảng cách (0.87 mỗi 12.7 m), đi chậm hơn dao một chút (235/250), nạp đạn 2.97 giây, **hạ gục được thưởng $600** (súng khác vẫn $300). Giật nhẹ hơn M4A1, tỏa đạn rộng hơn một chút (SMG).
- **Có ống giảm thanh:** bot chỉ nghe thấy tiếng bắn trong khoảng 20 m (các súng khác là 42 m); tia lửa đầu nòng nhỏ.
- **Âm thanh:** MP5-SD là súng DUY NHẤT trong game có tiếng (tiếng bắn, kéo khoá, tháo / lắp băng đạn, rút súng), phát đúng thời điểm trong animation. Các súng khác vẫn im lặng như trước. Muốn tắt hẳn: đặt `AudioServer.set_bus_mute(0, true)` lại trong `main.gd`.
- Animation: rút súng, 3 kiểu bắn, nạp đạn (chạy chậm lại một chút cho đủ 2.97 s), xem súng (F). Không có ngắm.
- Game chưa có giáp nên chưa dùng "xuyên giáp 62.5%" của CS2.
- **Chưa chạy thử trong Godot.** Lần mở đầu sẽ import model và âm thanh mới nên hơi lâu (cờ `imported_v35`). Nếu súng nằm lệch trên màn hình, chỉnh `VM_OFFSET` ở đầu `scripts/mp5.gd`.

## AK-47 mới: model CS2 + tay + animation (thay AK cũ)
- AK-47 giờ là model thật trong gói `cs2ak47_cfrigs` (file `v_ak47.mdl`): thân súng gỗ, **hai bàn tay đeo găng đen + cẳng tay có sẵn trong model** (phe **CT = tay áo xanh**, phe **T = tay trần**; đổi phe giữa trận thì súng tự đổi tay áo), và mọi animation gốc: rút súng, bắn (3 kiểu xen kẽ), nạp đạn (tháo băng, lắp băng, kéo khoá), kiểm tra súng (**F**), thở nhẹ khi đứng yên. Móc khoá cú mèo treo ở súng là của model gốc, nó đung đưa theo animation.
- **Không có âm thanh** vì gói không kèm file âm thanh nào (thư mục `sound` trong gói rỗng). AK-47 vẫn im lặng như các súng khác, trừ MP5-SD.
- **Chỉ số y như CS2:** sát thương **36** (đầu x4 = 144, chân x0.75), hao dần theo khoảng cách 0.98 mỗi 12.7 m, bắn tự động **600 phát/phút** (0.1 giây/phát), băng **30** / dự trữ **90**, nạp đạn **2.43 giây**, đi chậm hơn dao (215/250 = 0.86), giá **$2700** (trước là $2500 kiểu CS 1.6; bot phe T cũng mua giá này), thưởng hạ gục $300. Game chưa có giáp nên không dùng "xuyên giáp 77.5%". Bảng giật / tỏa đạn (`"cs"`) giữ nguyên như cũ.
- Code: `scripts/ak47.gd` (viewmodel, cùng giao diện với `mp5.gd` / `awp.gd`), model `assets/ak47/v_ak47.glb` (phe T) và `assets/ak47/v_ak47_ct.glb` (phe CT), mỗi file ~2.5 MB, một mảnh + một texture 2048x2048 JPEG nên chỉ 1 lệnh vẽ; chỉ model của phe đang chơi được nạp vào súng. Model CS 1.6 vẽ cho tay trái nên script xoay 180 độ rồi lật gương để tay phải cầm báng; súng được thu nhỏ đều quanh mắt (`GUN_SCALE`) nên hình trên màn hình không đổi nhưng không dài xuyên tường.
- **Đã xoá:** model AK-47 cũ dựng bằng code (khoảng 1400 dòng, khối hộp + tay hộp). Lớp dựng lưới `MB` mà M4A1 còn dùng được tách ra `scripts/mesh_builder.gd`. File gốc `.mdl` (14 MB) KHÔNG đưa vào project cho nhẹ game.
- Súng AK rơi dưới đất và súng trên tay bot vẫn là mô hình khối hộp đơn giản như các súng khác.
- Công cụ `tools/mdl2glb.py` có thêm `--atlas-scale=0.5` (thu nhỏ texture khi gộp atlas) và `--jpeg` (lưu atlas JPEG). Lệnh đổi: `python3 tools/mdl2glb.py v_ak47.mdl assets/ak47/v_ak47.glb --vm --atlas --atlas-scale=0.5 --jpeg`. Bản CT: cùng lệnh với `alt/v_ak47.mdl` và ghi ra `v_ak47_ct.glb`.
- **Chưa chạy thử trong Godot.** Cần xem: súng nằm đúng chỗ trên màn hình không (hằng `VM_OFFSET`, `GUN_SCALE` đầu `ak47.gd`), tay phải cầm báng / tay trái đỡ ốp tay có bị đảo bên không, phe CT có tay áo xanh và phe T có tay trần không (đổi phe ở chế độ ĐẶT BOM nữa), tia lửa nòng đúng đầu nòng không (xương `Box001`), nạp đạn đủ 30 viên sau khi lắp băng.

## Desert Eagle mới: model + tay + animation + âm thanh CS:GO (thay hoàn toàn Desert Eagle cũ)
- Desert Eagle giờ là model thật trong gói `cs_go_deagle_74536`: **súng + hai bàn tay + mọi animation gốc** (rút súng, bắn 2 kiểu xen kẽ, bắn viên cuối với nòng trượt kẹt lại, nạp đạn tháo băng / lắp băng / kéo khoá, đứng yên thở nhẹ). Phe **CT** thấy găng + tay áo ô-liu, phe **T** thấy găng đen tay trần; đổi phe giữa trận thì súng tự đổi tay. Model và code Desert Eagle cũ (hình dựng bằng code, `desert_eagle.glb`, animation tự viết, mọi chỉnh dáng cầm / nạp đạn / xem súng ở các mục phía trên) đã **xoá hẳn**, các mục đó chỉ còn là lịch sử.
- **Âm thanh có sẵn trong gói nên đã nhúng** (`assets/deagle/sounds/`, 6 file): tiếng rút súng, tháo băng, lắp băng, kéo khoá phát đúng thời điểm ghi trong model; tiếng bắn `deagle-1` / `deagle-2` xen kẽ mỗi phát. Tiếng tự tắt khi đổi súng.
- **Chỉ lấy MỘT skin súng**: hai file `.mdl` của gói (CT Arms / T Arms) nhúng hai skin khác nhau (đen trắng vàng và đỏ cam); mình cho cả hai phe dùng skin của CT Arms để cùng một khẩu súng. 9 skin trong thư mục `Texture(s)` của gói không dùng. Mô-đun StatTrak (số đếm bên hông súng) là của model gốc nên giữ lại.
- Model **không có animation xem súng**, nên bấm **F** khi cầm Desert Eagle không làm gì. Chỉ số (63 sát thương, 7/35 viên, 0,33 giây/phát, $700, độ giật / tỏa đạn) **giữ nguyên**.
- Code: `scripts/deagle.gd` (cùng giao diện với `ak47.gd`), model `assets/deagle/v_deagle_ct.glb` (~2 MB) và `v_deagle_t.glb` (~1.6 MB). Như AK-47: model vẽ cho tay trái nên script xoay 180 độ rồi lật gương; bản T trong gói to gấp ~2.6 lần bản CT nên mỗi phe một hệ số thu nhỏ (`SCALE_CT`, `SCALE_T`; hình trên màn hình không đổi). Đổi model: `python3 tools/mdl2glb.py "CT Arms/v_deagle.mdl" assets/deagle/v_deagle_ct.glb --vm --atlas --jpeg --no-normals` (bản T thêm `--gun-tex-from="CT Arms/v_deagle.mdl"`). File `.mdl` gốc không đưa vào project cho nhẹ game.
- **Chưa chạy thử trong Godot.** Cần xem: súng nằm đúng chỗ trên màn hình, tay phải / trái có bị đảo bên không, tia lửa nòng đúng đầu nòng, nạp xong đủ 7 viên, tiếng khớp animation, phe T và phe CT đều đúng tay.

## AWP: có âm thanh (từ gói cs_10_beta_awp)
- AWP trước đây im lặng, giờ có **4 âm thanh lấy từ gói `cs_10_beta_awp`** (`assets/awp/sounds/`): **tiếng bắn** (`awp1`) mỗi phát, rồi **3 tiếng kéo khoá**: nâng nắp (`boltup`), kéo về (`boltpull1`), đẩy xuống (`boltdown`) phát lần lượt khoảng 0,43 / 0,54 / 0,91 giây sau phát bắn, đúng các mốc ghi trong animation bắn của model AWP trong game.
- Gói chỉ có đúng 4 âm thanh này cho AWP. **Không có tiếng nạp đạn và tiếng rút súng** nên hai hành động đó vẫn im lặng. Bắn lúc đang ngắm (viewmodel đang ẩn) vẫn nghe đủ tiếng. Đổi súng giữa chừng thì tiếng tắt ngay. File `go.wav` ("okay, let's go" của CS 1.0 beta, thư mục `bonus`) và model `v_awp.mdl` trong gói không dùng.
- Code: `scripts/awp.gd` (`_build_audio`, `BOLT_EVENTS`). Âm lượng: tiếng bắn 0 dB, tiếng kéo khoá -3 dB (sửa ở `_build_audio`). **Chưa chạy thử trong Godot**: cần nghe tiếng bắn có đủ to và 3 tiếng kéo khoá có khớp lúc tay kéo nắp.



## Điều khiển cảm ứng (điện thoại Android)
- Mới thêm `scripts/touch_controls.gd`: nút ảo vẽ bằng code, chỉ hiện trên Android / iOS. Trên máy tính script tự tắt. Muốn xem thử bố cục trên máy tính: chạy `CHOI_GAME_THU_NUT_CAM_UNG.bat` (truyền tham số `touch`, bấm chuột thay ngón tay).
- Cần di chuyển nổi: chạm nửa trái màn hình. Vuốt nửa phải để xoay camera (`Player.touch_look`, độ nhạy `TOUCH_SENS` đầu file và thanh Mouse sensitivity trong menu tạm dừng). Giữ nút FIRE rồi kéo ngón tay vẫn xoay được.
- Nút: FIRE (2 nút, trái và phải), JUMP, CROUCH (bật / tắt), WALK (bật / tắt), AIM (ngắm AWP, dao đâm), RELOAD, USE (giữ để đặt / gỡ bom, nhặt súng), 1 / 2 / 3 / Q chọn súng, C4 (chỉ hiện khi mang bom), F soi súng, G vứt, BUY, TAB, || tạm dừng.
- Trên điện thoại `fire` và `aim` không còn gắn với chuột, vì chạm màn hình bị tính là bấm chuột. Đang chơi thì tắt `Input.emulate_mouse_from_touch`; mở menu / cửa hàng / tạm dừng thì bật lại để bấm nút bằng ngón tay.
- Nút Back của Android mở tạm dừng (`config/quit_on_go_back=false`). Màn hình khóa ngang (`window/handheld/orientation=4`).
- Xuất APK: `export_presets.cfg` đã có sẵn mục Android, `debug.keystore` đi kèm. Các bước đọc trong `HUONG_DAN_ANDROID.txt`.
- Chưa chạy thử trong Godot.
