class_name Viewmodel
extends Node3D
const Hands := preload("res://scripts/hands.gd")
## Súng Glock 17 góc nhìn thứ nhất (dựng hoàn toàn bằng code) + hai tay + animation
## theo phong cách Call of Duty: draw, idle thở, bob khi chạy, sway theo chuột,
## recoil + trượt nòng, ADS, reload (tactical / empty), inspect, nhả vỏ đạn, rơi băng đạn.
##
## Hệ trục của súng: +X phải, +Y lên, -Z là hướng nòng. Gốc = phía sau-dưới của nòng trượt.

signal sound(sound_name: String)
signal reload_inserted()
signal action_finished(action_name: String)

const D2R := 0.0174533

const HIP_POS := Vector3(0.100, -0.152, -0.239)   # bàn tay phải về đúng chỗ cũ trên màn hình sau khi đổi mô hình
const HIP_ROT := Vector3(0.0, 0.0436, 0.0)
const VM_SCALE := 1.3
const ADS_POS := Vector3(0.0, -0.0527, -0.20)

const GRIP_POS := Vector3(0.0, 0.0099, -0.0541)   # khớp báng của mô hình Glock 17 (assets/glock17)
const MODEL_PATH := "res://assets/glock17/glock17.glb"   # Glock 17 (3 phần: slide, frame, baseplate băng đạn)
const GRIP_TILT := -22.0 * D2R
const MAG_CENTER_GRIP := Vector3(0.0, -0.038, 0.0)
const MAG_TRAVEL := 0.13
const LH_HOLD_GRIP := Vector3(-0.0245, -0.054, 0.0)
const HAND_MAG_OFF_GRIP := Vector3(-0.026, -0.056, 0.0)
const LH_WRIST_LOCAL := Vector3(-0.004, -0.030, 0.034)
const RH_WRIST_GRIP := Vector3(0.026, -0.064, 0.040)
const ELBOW_L := Vector3(-0.27, -0.38, 0.30)
const ELBOW_R := Vector3(0.28, -0.40, 0.32)
const MUZZLE := Vector3(0.0, 0.0165, -0.192)

const SLIDE_LOCK := 0.034
const SLIDE_KICK := 0.040

const RELOAD_TAC := 1.75
const RELOAD_EMPTY := 2.25
const DRAW_TIME := 0.85
const INSPECT_TIME := 3.2

enum Mode { NONE, DRAW, RELOAD, INSPECT }
enum MagMode { AXIS, HAND, HIDDEN }


class Limb:
	var cuff: MeshInstance3D
	var sleeve: MeshInstance3D

	func _init(parent: Node3D, glove: Material, sleeve_mat: Material) -> void:
		var cm := BoxMesh.new()
		cm.size = Vector3(0.052, 1.0, 0.052)
		cuff = MeshInstance3D.new()
		cuff.mesh = cm
		cuff.material_override = glove
		cuff.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		parent.add_child(cuff)
		var sm := BoxMesh.new()
		sm.size = Vector3(0.076, 1.0, 0.076)
		sleeve = MeshInstance3D.new()
		sleeve.mesh = sm
		sleeve.material_override = sleeve_mat
		sleeve.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		parent.add_child(sleeve)

	func update(wrist: Vector3, elbow: Vector3) -> void:
		var dir := elbow - wrist
		var length := dir.length()
		if length < 0.01:
			return
		var d := dir / length
		var b := Basis(Quaternion(Vector3.UP, d))
		var cuff_len := minf(0.075, length)
		cuff.transform = Transform3D(b * Basis.from_scale(Vector3(1.0, cuff_len, 1.0)), wrist + d * (cuff_len * 0.5 - 0.012))
		var s_len := maxf(length - cuff_len * 0.85, 0.01)
		sleeve.transform = Transform3D(b * Basis.from_scale(Vector3(1.0, s_len, 1.0)), wrist + d * (cuff_len * 0.85 + s_len * 0.5))


# ---------------- trạng thái nhận từ Player ----------------
var move_amount := 0.0   # 0..1 tốc độ di chuyển tương đối
var run_amount := 0.0    # 0..1 khi đang chạy hết tốc độ
var grounded := true
var ads := false
var crouched := false
var mouse_delta := Vector2.ZERO
var wall_push := 0.0   # 0..1: gần tường thì hạ súng xuống
var _wall_s := 0.0
const WALL_BACK := 0.12   # hạ súng khi sát tường: lùi tay (mét) - khớp bảng WALL_DIMS trong player.gd
const WALL_RX := 1.3     # hạ súng khi sát tường: góc chúc nòng xuống (rad)
var ads_t := 0.0

# ---------------- node ----------------
var rig: Node3D
var gun: Node3D
var slide: Node3D
var grip: Node3D
var mag: Node3D
var trigger: MeshInstance3D
var lh: Node3D
var lh_thumb: Node3D
var lh_fingers: Array[Node3D] = []
var flash: Node3D
var limb_l
var limb_r
var rh_node: Node3D
var glb_mode := false

# ---------------- vật liệu ----------------
var m_slide: StandardMaterial3D
var m_frame: StandardMaterial3D
var m_dark: StandardMaterial3D
var m_steel: StandardMaterial3D
var m_white: StandardMaterial3D
var m_glove: StandardMaterial3D
var m_sleeve: StandardMaterial3D
var m_brass: StandardMaterial3D

# ---------------- trạng thái animation ----------------
var mode: int = Mode.NONE
var mode_t := 0.0
var mode_len := 1.0
var reload_is_empty := false
var cues: Array = []

var a_pos := Vector3.ZERO
var a_rot := Vector3.ZERO
var lh_pos := Vector3.ZERO
var lh_rot := Vector3.ZERO
var lh_curl := 0.0
var slide_anim := -1.0
var mag_mode: int = MagMode.AXIS
var mag_out := 0.0

var lh_hold_pos := Vector3.ZERO
var slide_rest := 0.0
var slide_t := -1.0
var trigger_t := 0.0
var flash_t := 0.0
var _time := 0.0
var bob_phase := 0.0
var bob_smooth := 0.0
var run_t := 0.0
var air_t := 0.0
var sway := Vector2.ZERO
var kick_pos := Vector3.ZERO
var kick_pos_v := Vector3.ZERO
var kick_rot := Vector3.ZERO
var kick_rot_v := Vector3.ZERO
var shells: Array = []
var drops: Array = []

# keyframes
var k_draw_pos: Array
var k_draw_rot: Array
var k_rel_pos_t: Array
var k_rel_rot_t: Array
var k_rel_pos_e: Array
var k_rel_rot_e: Array
var k_rel_lh_t: Array
var k_rel_lh_e: Array
var k_rel_lhrot_e: Array
var k_rel_curl_t: Array
var k_rel_curl_e: Array
var k_rel_magout: Array
var k_rel_slide_e: Array
var k_insp_pos: Array
var k_insp_rot: Array
var k_insp_lh: Array
var k_insp_lhrot: Array
var k_insp_curl: Array
var k_insp_slide: Array


func _ready() -> void:
	_build_env()
	rig = Node3D.new()
	rig.scale = Vector3.ONE * VM_SCALE
	add_child(rig)
	gun = Node3D.new()
	rig.add_child(gun)
	_make_materials()
	_build_gun()
	_build_hands()
	_build_flash()
	_build_keys()
	lh_pos = lh_hold_pos
	limb_l = Hands.Arm.new(rig, true)
	limb_r = Hands.Arm.new(rig)
	var tilt := Basis(Vector3.RIGHT, GRIP_TILT)
	limb_r.attach(rh_node, tilt, Vector3(0.0, -0.050, 0.002), Vector3(0.0, -1.0, 0.0), 0.0, 0)
	limb_l.attach(lh, tilt, Vector3(0.0245, 0.004, -0.012), Vector3(0.0, -1.0, 0.0), 0.0, 2)


# =====================================================================
#  DỰNG MÔ HÌNH
# =====================================================================
func _mat(color: Color, rough: float, metal: float) -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.albedo_color = color
	m.roughness = rough
	m.metallic = metal
	m.metallic_specular = 0.6
	return m


func _make_materials() -> void:
	m_slide = _mat(Color(0.075, 0.078, 0.085), 0.42, 0.55)
	m_frame = _mat(Color(0.115, 0.118, 0.125), 0.78, 0.0)
	m_dark = _mat(Color(0.02, 0.02, 0.022), 0.9, 0.0)
	m_steel = _mat(Color(0.30, 0.31, 0.33), 0.35, 0.8)
	m_white = _mat(Color(0.95, 0.95, 0.9), 0.6, 0.0)
	m_glove = Hands.material()   # tay dùng chung mọi súng (scripts/hands.gd)
	m_sleeve = Hands.material()
	m_brass = _mat(Color(0.85, 0.62, 0.22), 0.35, 0.9)


func _box(parent: Node, size: Vector3, pos: Vector3, mat: Material, rot_deg: Vector3 = Vector3.ZERO) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = size
	mi.mesh = bm
	mi.material_override = mat
	mi.position = pos
	mi.rotation = rot_deg * D2R
	mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	parent.add_child(mi)
	return mi


func _build_env() -> void:
	pass  # viewmodel gắn thẳng vào camera chính, không cần camera/đèn riêng


func _build_gun() -> void:
	var scn: Node = null
	if ResourceLoader.exists(MODEL_PATH):
		var ps := load(MODEL_PATH) as PackedScene
		if ps != null:
			scn = ps.instantiate()
	if scn != null:
		var n_slide := scn.find_child("slide", true, false)
		var n_frame := scn.find_child("frame", true, false)
		var n_base := scn.find_child("base", true, false)
		if n_slide != null and n_frame != null and n_base != null:
			_build_gun_glb(scn, n_slide, n_frame, n_base)
			return
		scn.queue_free()
	_build_gun_boxes()


## Glock 17 từ file .glb: nòng trượt (slide) chạy lùi khi bắn, khung (frame) đứng yên, đế băng đạn (base) đi theo băng đạn.
func _build_gun_glb(scn: Node, n_slide: Node, n_frame: Node, n_base: Node) -> void:
	glb_mode = true
	slide = Node3D.new()
	gun.add_child(slide)
	grip = Node3D.new()
	grip.position = GRIP_POS
	grip.rotation = Vector3(GRIP_TILT, 0.0, 0.0)
	gun.add_child(grip)
	mag = Node3D.new()
	gun.add_child(mag)
	for pair in [[n_slide, slide], [n_frame, gun], [n_base, mag]]:
		var nd: Node = pair[0]
		nd.get_parent().remove_child(nd)
		(pair[1] as Node).add_child(nd)
		if nd is GeometryInstance3D:
			(nd as GeometryInstance3D).cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	scn.queue_free()
	var gb := Basis.from_euler(Vector3(GRIP_TILT, 0.0, 0.0))
	var mag_rest := Transform3D(gb, GRIP_POS + gb * MAG_CENTER_GRIP)
	(n_base as Node3D).transform = mag_rest.affine_inverse()   # đế băng đạn nằm đúng chỗ khi băng ở vị trí nghỉ
	# thân băng đạn nằm khuất trong báng, chỉ lộ ra khi nạp đạn
	_box(mag, Vector3(0.0215, 0.086, 0.028), Vector3.ZERO, m_steel)
	for i in 3:
		_box(mag, Vector3(0.0006, 0.004, 0.004), Vector3(-0.0110, 0.012 - 0.016 * i, 0.0), m_white)
	trigger = MeshInstance3D.new()   # cò là một phần của khung nên không chuyển động riêng; giữ nút giả để code cũ không lỗi
	gun.add_child(trigger)


func _build_gun_boxes() -> void:
	# ---------- NÒNG TRƯỢT (slide) ----------
	slide = Node3D.new()
	gun.add_child(slide)
	_box(slide, Vector3(0.030, 0.027, 0.186), Vector3(0.0, 0.0135, -0.093), m_slide)
	_box(slide, Vector3(0.021, 0.006, 0.186), Vector3(0.0, 0.030, -0.093), m_slide)
	# rãnh cò phía sau và phía trước (hai bên)
	for i in 6:
		_box(slide, Vector3(0.0315, 0.020, 0.0018), Vector3(0.0, 0.0145, -0.010 - 0.0055 * i), m_dark)
	for i in 4:
		_box(slide, Vector3(0.0315, 0.020, 0.0018), Vector3(0.0, 0.0145, -0.136 - 0.0055 * i), m_dark)
	# cửa thoát vỏ đạn bên phải
	_box(slide, Vector3(0.0012, 0.013, 0.036), Vector3(0.0153, 0.0195, -0.062), m_dark)
	# khấc chữ ở thân trái (chi tiết nhỏ)
	_box(slide, Vector3(0.0008, 0.004, 0.030), Vector3(-0.0152, 0.022, -0.100), m_steel)
	# thước ngắm sau (hai khối + khe) và ngắm trước
	_box(slide, Vector3(0.0055, 0.006, 0.012), Vector3(-0.0055, 0.0365, -0.013), m_dark)
	_box(slide, Vector3(0.0055, 0.006, 0.012), Vector3(0.0055, 0.0365, -0.013), m_dark)
	_box(slide, Vector3(0.0018, 0.0018, 0.0008), Vector3(-0.0055, 0.0385, -0.0068), m_white)
	_box(slide, Vector3(0.0018, 0.0018, 0.0008), Vector3(0.0055, 0.0385, -0.0068), m_white)
	_box(slide, Vector3(0.0045, 0.007, 0.008), Vector3(0.0, 0.0375, -0.176), m_dark)
	_box(slide, Vector3(0.0030, 0.0030, 0.0008), Vector3(0.0, 0.0385, -0.1714), m_white)
	# đầu nòng
	var bar := MeshInstance3D.new()
	var cm := CylinderMesh.new()
	cm.top_radius = 0.0052
	cm.bottom_radius = 0.0052
	cm.height = 0.008
	cm.radial_segments = 10
	bar.mesh = cm
	bar.material_override = m_steel
	bar.rotation = Vector3(90.0 * D2R, 0.0, 0.0)
	bar.position = Vector3(0.0, 0.0165, -0.1865)
	bar.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	slide.add_child(bar)
	var bore := MeshInstance3D.new()
	var bm := CylinderMesh.new()
	bm.top_radius = 0.0036
	bm.bottom_radius = 0.0036
	bm.height = 0.0085
	bm.radial_segments = 10
	bore.mesh = bm
	bore.material_override = m_dark
	bore.rotation = Vector3(90.0 * D2R, 0.0, 0.0)
	bore.position = Vector3(0.0, 0.0165, -0.1866)
	bore.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	slide.add_child(bore)

	# ---------- KHUNG (frame) ----------
	_box(gun, Vector3(0.0265, 0.020, 0.161), Vector3(0.0, -0.010, -0.0775), m_frame)
	_box(gun, Vector3(0.0275, 0.003, 0.010), Vector3(0.0, -0.0195, -0.135), m_dark)
	_box(gun, Vector3(0.0275, 0.003, 0.010), Vector3(0.0, -0.0195, -0.118), m_dark)
	# chốt giữ slide (slide stop) và nút tháo
	_box(gun, Vector3(0.0045, 0.005, 0.020), Vector3(-0.0145, -0.005, -0.041), m_steel)
	_box(gun, Vector3(0.0035, 0.005, 0.009), Vector3(-0.0140, -0.005, -0.072), m_steel)
	# nút nhả băng
	_box(gun, Vector3(0.0045, 0.009, 0.008), Vector3(-0.0163, -0.027, -0.019), m_dark)
	# vòng bảo vệ cò
	_box(gun, Vector3(0.0078, 0.005, 0.062), Vector3(0.0, -0.0430, -0.057), m_frame)
	_box(gun, Vector3(0.0078, 0.026, 0.006), Vector3(0.0, -0.0325, -0.085), m_frame)
	# cò
	trigger = _box(gun, Vector3(0.005, 0.021, 0.005), Vector3(0.0, -0.031, -0.049), m_dark, Vector3(-12.0, 0.0, 0.0))
	_box(trigger, Vector3(0.003, 0.010, 0.0025), Vector3(0.0, 0.004, -0.003), m_steel)

	# ---------- TAY CẦM (grip) ----------
	grip = Node3D.new()
	grip.position = GRIP_POS
	grip.rotation = Vector3(GRIP_TILT, 0.0, 0.0)
	gun.add_child(grip)
	_box(grip, Vector3(0.032, 0.108, 0.046), Vector3(0.0, -0.054, 0.0), m_frame)
	_box(grip, Vector3(0.030, 0.012, 0.018), Vector3(0.0, 0.002, 0.028), m_frame)  # beavertail
	_box(grip, Vector3(0.0265, 0.002, 0.038), Vector3(0.0, -0.1085, 0.0), m_dark)   # miệng báng băng

	# ---------- BĂNG ĐẠN ----------
	mag = Node3D.new()
	gun.add_child(mag)
	_box(mag, Vector3(0.0255, 0.100, 0.0355), Vector3.ZERO, m_steel)
	_box(mag, Vector3(0.0335, 0.008, 0.048), Vector3(0.0, -0.054, 0.002), m_frame)
	for i in 3:
		_box(mag, Vector3(0.0006, 0.004, 0.004), Vector3(-0.0130, 0.012 - 0.016 * i, 0.0), m_white)


func _build_hands() -> void:
	var hold_basis := Basis.from_euler(Vector3(GRIP_TILT, 0.0, 0.0))

	# ----- tay trái (tay đỡ) -----
	lh = Node3D.new()
	gun.add_child(lh)
	_box(lh, Vector3(0.014, 0.072, 0.058), Vector3.ZERO, m_glove)
	_box(lh, Vector3(0.0145, 0.020, 0.020), Vector3(-0.001, -0.030, 0.030), m_glove)  # cổ tay
	# tay khối (như Unturned / Roblox): bốn ngón gộp thành một tấm, không có ngón cái
	_box(lh, Vector3(0.037, 0.067, 0.012), Vector3(0.0185, 0.0, -0.0375), m_glove)
	var hold_gun := GRIP_POS + hold_basis * LH_HOLD_GRIP
	lh_hold_pos = hold_gun

	# ----- tay phải (tay cầm) -----
	var rh := Node3D.new()
	rh_node = rh
	grip.add_child(rh)
	_box(rh, Vector3(0.012, 0.070, 0.052), Vector3(0.0235, -0.050, 0.004), m_glove)
	_box(rh, Vector3(0.036, 0.030, 0.022), Vector3(0.004, -0.006, 0.034), m_glove)   # hổ khẩu tay
	_box(rh, Vector3(0.016, 0.012, 0.024), Vector3(-0.017, -0.012, 0.030), m_glove)  # gốc ngón cái
	_box(rh, Vector3(0.040, 0.044, 0.012), Vector3(0.0035, -0.050, -0.0255), m_glove)   # các ngón gộp thành một khối


func _build_flash() -> void:
	flash = Node3D.new()
	flash.position = MUZZLE
	flash.visible = false
	gun.add_child(flash)
	var img := Image.create(64, 64, false, Image.FORMAT_RGBA8)
	for y in 64:
		for x in 64:
			var dx := (x - 31.5) / 31.5
			var dy := (y - 31.5) / 31.5
			var r := sqrt(dx * dx + dy * dy)
			var star := maxf(0.0, 1.0 - r) * (0.55 + 0.45 * pow(absf(cos(atan2(dy, dx) * 3.0)), 3.0))
			var a := clampf(star * 1.6, 0.0, 1.0)
			img.set_pixel(x, y, Color(1.0, 0.85 - 0.3 * r, 0.45 - 0.3 * r, a))
	var tex := ImageTexture.create_from_image(img)
	var fm := StandardMaterial3D.new()
	fm.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	fm.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	fm.blend_mode = BaseMaterial3D.BLEND_MODE_ADD
	fm.albedo_texture = tex
	fm.billboard_mode = BaseMaterial3D.BILLBOARD_ENABLED
	fm.billboard_keep_scale = true
	fm.cull_mode = BaseMaterial3D.CULL_DISABLED
	var q := QuadMesh.new()
	q.size = Vector2(0.11, 0.11)
	var mi := MeshInstance3D.new()
	mi.mesh = q
	mi.material_override = fm
	mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	flash.add_child(mi)


# =====================================================================
#  KEYFRAME
# =====================================================================
func _v(x: float, y: float, z: float) -> Vector3:
	return Vector3(x, y, z)


func _d(x: float, y: float, z: float) -> Vector3:
	return Vector3(x, y, z) * D2R


func _build_keys() -> void:
	var gb := Basis.from_euler(Vector3(GRIP_TILT, 0.0, 0.0))
	var gt := Transform3D(gb, GRIP_POS)
	var hold: Vector3 = lh_hold_pos
	var c0: Vector3 = gt * MAG_CENTER_GRIP
	var up: Vector3 = gb * Vector3(0.0, -MAG_TRAVEL, 0.0)
	var off: Vector3 = gb * HAND_MAG_OFF_GRIP
	var belt := _v(-0.09, -0.26, 0.16)
	var sh := _v(-0.031, 0.020, -0.035)
	var z3 := Vector3.ZERO

	# ---- DRAW ----
	k_draw_pos = [[0.0, _v(0.04, -0.30, 0.08)], [0.50, _v(0.0, 0.012, -0.004)], [DRAW_TIME, z3]]
	k_draw_rot = [[0.0, _d(-55, -25, -20)], [0.50, _d(5, 0, 0)], [DRAW_TIME, z3]]

	# ---- RELOAD (chung) ----
	var rot_a := _d(12, 10, -26)
	var rot_b := _d(14, 12, -28)
	var pos_a := _v(-0.050, 0.022, 0.060)
	var pos_b := _v(-0.055, 0.026, 0.065)
	k_rel_pos_t = [[0.0, z3], [0.22, pos_a], [1.05, pos_b], [1.35, _v(-0.02, 0.008, 0.02)], [1.65, z3]]
	k_rel_rot_t = [[0.0, z3], [0.22, rot_a], [1.05, rot_b], [1.35, _d(6, 5, -12)], [1.65, z3]]
	k_rel_pos_e = [[0.0, z3], [0.22, pos_a], [1.05, pos_b], [1.36, _v(-0.02, 0.008, 0.02)], [1.60, _v(-0.02, 0.010, 0.03)], [1.84, _v(-0.02, 0.010, 0.03)], [2.2, z3]]
	k_rel_rot_e = [[0.0, z3], [0.22, rot_a], [1.05, rot_b], [1.36, _d(8, 5, -14)], [1.60, _d(4, -4, -6)], [1.84, _d(4, -4, -6)], [2.2, z3]]

	var lh_common := [
		[0.0, hold],
		[0.30, c0 + off],
		[0.56, c0 + up + off],
		[0.66, c0 + up + off + gb * _v(-0.03, -0.07, 0.03)],
		[0.88, belt],
		[0.96, belt + _v(0.0, 0.01, 0.0)],
		[1.10, c0 + up + off],
		[1.28, c0 + off],
		[1.36, c0 + off + gb * _v(0.0, -0.005, 0.0)],
	]
	k_rel_lh_t = lh_common.duplicate()
	k_rel_lh_t.append([1.65, hold])
	k_rel_lh_e = lh_common.duplicate()
	k_rel_lh_e.append_array([
		[1.50, sh + _v(-0.03, 0.0, 0.02)],
		[1.60, sh],
		[1.72, sh + _v(0.0, 0.0, 0.008)],
		[1.78, sh + _v(0.0, 0.0, 0.008)],
		[1.84, sh + _v(0.0, 0.0, 0.002)],
		[1.96, sh + _v(-0.045, -0.01, 0.03)],
		[2.20, hold],
	])
	k_rel_lhrot_e = [[0.0, z3], [1.36, z3], [1.60, _d(22, 0, 0)], [1.84, _d(22, 0, 0)], [2.10, z3]]

	var curl_common := [
		[0.0, 0.0], [0.18, 0.65], [0.30, 0.25], [0.56, 0.25], [0.70, 0.7],
		[0.88, 0.8], [0.96, 0.3], [1.10, 0.3], [1.28, 0.3],
	]
	k_rel_curl_t = curl_common.duplicate()
	k_rel_curl_t.append_array([[1.40, 0.0], [1.65, 0.0]])
	k_rel_curl_e = curl_common.duplicate()
	k_rel_curl_e.append_array([[1.40, 0.6], [1.52, 0.8], [1.60, 0.2], [1.78, 0.2], [1.86, 0.8], [2.0, 0.5], [2.25, 0.0]])
	k_rel_magout = [[0.0, 0.0], [0.30, 0.0], [0.56, 1.0], [1.10, 1.0], [1.28, 0.0]]
	k_rel_slide_e = [[0.0, SLIDE_LOCK], [1.60, SLIDE_LOCK], [1.72, SLIDE_LOCK + 0.008], [1.78, SLIDE_LOCK + 0.008], [1.84, 0.0], [2.25, 0.0]]

	# ---- INSPECT ----
	k_insp_pos = [[0.0, z3], [0.5, _v(-0.030, 0.035, 0.060)], [1.3, _v(-0.040, 0.040, 0.070)], [2.0, _v(-0.025, 0.025, 0.050)], [2.7, _v(-0.005, 0.005, 0.01)], [INSPECT_TIME, z3]]
	k_insp_rot = [[0.0, z3], [0.5, _d(6, 38, -34)], [1.3, _d(10, -28, 26)], [2.0, _d(8, 12, -14)], [2.7, _d(2, 4, -3)], [INSPECT_TIME, z3]]
	k_insp_lh = [
		[0.0, hold],
		[0.40, hold + _v(-0.07, -0.04, 0.03)],
		[1.70, hold + _v(-0.09, -0.06, 0.05)],
		[2.05, sh + _v(-0.03, 0.0, 0.02)],
		[2.15, sh],
		[2.28, sh + _v(0.0, 0.0, 0.03)],
		[2.45, sh + _v(0.0, 0.0, 0.03)],
		[2.55, sh],
		[2.75, sh + _v(-0.04, 0.0, 0.02)],
		[3.10, hold],
	]
	k_insp_lhrot = [[0.0, z3], [1.9, z3], [2.1, _d(22, 0, 0)], [2.6, _d(22, 0, 0)], [3.0, z3]]
	k_insp_curl = [[0.0, 0.0], [0.4, 0.6], [1.7, 0.6], [2.0, 0.8], [2.15, 0.2], [2.45, 0.2], [2.55, 0.8], [3.0, 0.3], [3.2, 0.0]]
	k_insp_slide = [[0.0, 0.0], [2.15, 0.0], [2.28, 0.03], [2.45, 0.03], [2.53, 0.0], [INSPECT_TIME, 0.0]]


func _kf(t: float, keys: Array) -> Variant:
	if t <= keys[0][0]:
		return keys[0][1]
	for i in range(1, keys.size()):
		if t <= keys[i][0]:
			var t0: float = keys[i - 1][0]
			var t1: float = keys[i][0]
			var w := (t - t0) / maxf(t1 - t0, 0.0001)
			w = w * w * (3.0 - 2.0 * w)
			return lerp(keys[i - 1][1], keys[i][1], w)
	return keys[keys.size() - 1][1]


# =====================================================================
#  API CHO PLAYER
# =====================================================================
func is_busy() -> bool:
	return mode != Mode.NONE


func current_mode() -> int:
	return mode


func play_draw() -> void:
	_start_mode(Mode.DRAW, DRAW_TIME)
	cues = [[0.12, "sfx", "rustle"], [0.58, "sfx", "slide_fwd"]]


func play_reload(empty: bool) -> float:
	reload_is_empty = empty
	var length := RELOAD_EMPTY if empty else RELOAD_TAC
	_start_mode(Mode.RELOAD, length)
	cues = [[0.30, "sfx", "mag_out"], [0.64, "drop", ""], [0.96, "sfx", "rustle"], [1.26, "sfx", "mag_in"], [1.26, "inserted", ""]]
	if empty:
		cues.append([1.62, "sfx", "slide_back"])
		cues.append([1.82, "sfx", "slide_fwd"])
		cues.append([1.84, "unlock", ""])
	return length


func play_inspect() -> void:
	_start_mode(Mode.INSPECT, INSPECT_TIME)
	cues = [[0.10, "sfx", "rustle"], [2.14, "sfx", "slide_back"], [2.50, "sfx", "slide_fwd"]]


func cancel() -> void:
	mode = Mode.NONE
	mode_t = 0.0
	cues = []


func set_slide_locked(locked: bool) -> void:
	slide_rest = SLIDE_LOCK if locked else 0.0


func is_slide_locked() -> bool:
	return slide_rest > 0.0


func land(strength: float) -> void:
	kick_pos_v.y -= 0.35 * strength
	kick_rot_v.x -= 0.6 * strength


func fire(last_round: bool) -> void:
	var k := 0.55 if ads_t > 0.5 else 1.0
	kick_pos_v += Vector3(randf_range(-0.03, 0.03), randf_range(0.02, 0.06), 0.50) * k
	kick_rot_v += Vector3(1.55 + randf_range(0.0, 0.5), randf_range(-0.6, 0.6), randf_range(-0.7, 0.7)) * k
	slide_t = 0.0
	slide_rest = SLIDE_LOCK if last_round else 0.0
	trigger_t = 0.07
	flash_t = 0.045
	flash.visible = true
	flash.rotation = Vector3(0.0, 0.0, randf() * TAU)
	flash.scale = Vector3.ONE * randf_range(0.8, 1.35)
	_spawn_shell()


func dry_fire() -> void:
	trigger_t = 0.07
	kick_pos_v.z += 0.06
	kick_rot_v.x += 0.2


# =====================================================================
#  NỘI BỘ
# =====================================================================
func _start_mode(m: int, length: float) -> void:
	mode = m
	mode_t = 0.0
	mode_len = length


func _do_cue(kind: String, arg: String) -> void:
	match kind:
		"sfx":
			sound.emit(arg)
		"drop":
			_spawn_dropped_mag()
		"inserted":
			reload_inserted.emit()
		"unlock":
			slide_rest = 0.0


func _advance_mode(delta: float) -> void:
	if mode == Mode.NONE:
		return
	var prev := mode_t
	mode_t += delta
	for c in cues:
		var ct: float = c[0]
		if prev < ct and mode_t >= ct:
			_do_cue(c[1], c[2])
	if mode_t >= mode_len:
		var finished := mode
		mode = Mode.NONE
		mode_t = 0.0
		cues = []
		var nm := "draw"
		if finished == Mode.RELOAD:
			nm = "reload"
		elif finished == Mode.INSPECT:
			nm = "inspect"
		action_finished.emit(nm)


func _eval_anim() -> void:
	a_pos = Vector3.ZERO
	a_rot = Vector3.ZERO
	lh_pos = lh_hold_pos
	lh_rot = Vector3.ZERO
	lh_curl = 0.0
	slide_anim = -1.0
	mag_mode = MagMode.AXIS
	mag_out = 0.0
	if mode == Mode.NONE:
		return
	var t := mode_t
	match mode:
		Mode.DRAW:
			a_pos = _kf(t, k_draw_pos)
			a_rot = _kf(t, k_draw_rot)
		Mode.RELOAD:
			var e := reload_is_empty
			a_pos = _kf(t, k_rel_pos_e if e else k_rel_pos_t)
			a_rot = _kf(t, k_rel_rot_e if e else k_rel_rot_t)
			lh_pos = _kf(t, k_rel_lh_e if e else k_rel_lh_t)
			lh_curl = _kf(t, k_rel_curl_e if e else k_rel_curl_t)
			if e:
				lh_rot = _kf(t, k_rel_lhrot_e)
				slide_anim = _kf(t, k_rel_slide_e)
			mag_out = _kf(t, k_rel_magout)
			if t >= 0.56 and t < 0.64:
				mag_mode = MagMode.HAND
			elif t >= 0.64 and t < 0.96:
				mag_mode = MagMode.HIDDEN
			elif t >= 0.96 and t < 1.10:
				mag_mode = MagMode.HAND
			else:
				mag_mode = MagMode.AXIS
		Mode.INSPECT:
			a_pos = _kf(t, k_insp_pos)
			a_rot = _kf(t, k_insp_rot)
			lh_pos = _kf(t, k_insp_lh)
			lh_rot = _kf(t, k_insp_lhrot)
			lh_curl = _kf(t, k_insp_curl)
			slide_anim = _kf(t, k_insp_slide)


func _spring(delta: float) -> void:
	var kp := 180.0
	var cp := 18.0
	kick_pos_v += (-kp * kick_pos - cp * kick_pos_v) * delta
	kick_pos += kick_pos_v * delta
	var kr := 140.0
	var cr := 15.0
	kick_rot_v += (-kr * kick_rot - cr * kick_rot_v) * delta
	kick_rot += kick_rot_v * delta


func _slide_offset(delta: float) -> float:
	if slide_t >= 0.0:
		slide_t += delta
		if slide_t < 0.035:
			return SLIDE_KICK * (slide_t / 0.035)
		var k := clampf((slide_t - 0.035) / 0.08, 0.0, 1.0)
		k = k * k * (3.0 - 2.0 * k)
		if slide_t >= 0.115:
			slide_t = -1.0
		return lerpf(SLIDE_KICK, slide_rest, k)
	return slide_rest


func _process(delta: float) -> void:
	delta = minf(delta, 0.05)
	_time += delta
	_advance_mode(delta)
	_eval_anim()

	# --- ADS ---
	var ads_target := 1.0 if (ads and mode == Mode.NONE) else 0.0
	ads_t = move_toward(ads_t, ads_target, delta * 8.0)
	var ae := ads_t * ads_t * (3.0 - 2.0 * ads_t)
	var pos := HIP_POS.lerp(ADS_POS, ae)
	var rot := HIP_ROT.lerp(Vector3.ZERO, ae)

	# --- bob khi di chuyển ---
	if move_amount > 0.05 and grounded:
		bob_phase += delta * (5.5 + 5.5 * move_amount)
	var bob_amp := move_amount * (1.0 - 0.85 * ae) * (0.6 if crouched else 1.0)
	if not grounded:
		bob_amp = 0.0
	bob_smooth = lerpf(bob_smooth, bob_amp, 1.0 - exp(-10.0 * delta))
	pos += Vector3(cos(bob_phase) * 0.0050, sin(bob_phase * 2.0) * 0.0040, 0.0) * bob_smooth
	rot += Vector3(sin(bob_phase * 2.0) * 0.010, cos(bob_phase) * 0.014, cos(bob_phase) * 0.020) * bob_smooth

	# --- thở ---
	var br := sin(_time * 1.7)
	pos.y += br * 0.0008 * (1.0 - 0.6 * ae)
	rot.x += br * 0.0025 * (1.0 - 0.6 * ae)

	# --- tư thế chạy ---
	var run_target := run_amount if mode == Mode.NONE else 0.0
	run_t = lerpf(run_t, run_target, 1.0 - exp(-8.0 * delta))
	pos += Vector3(0.012, -0.030, 0.035) * run_t
	rot += Vector3(-0.10, 0.30, -0.22) * run_t

	# --- sway theo chuột ---
	var sway_target := (mouse_delta * 0.0009).limit_length(0.06)
	mouse_delta = Vector2.ZERO
	sway = sway.lerp(sway_target, 1.0 - exp(-14.0 * delta))
	rot.y += sway.x * (1.0 - 0.7 * ae)
	rot.x += sway.y * (1.0 - 0.7 * ae)
	pos.x -= sway.x * 0.10

	# --- trên không ---
	air_t = move_toward(air_t, 0.0 if grounded else 1.0, delta * 5.0)
	pos.y += 0.007 * air_t
	rot.x += 0.03 * air_t

	# --- gần tường: hạ súng, tránh xuyên tường ---
	_wall_s = lerpf(_wall_s, wall_push, 1.0 - exp(-(28.0 if wall_push > _wall_s else 9.0) * delta))
	pos += Vector3(0.02, -0.03, WALL_BACK) * _wall_s
	rot += Vector3(-WALL_RX, 0.35, -0.2) * _wall_s

	# --- lò xo recoil ---
	_spring(delta)
	pos += kick_pos
	rot += kick_rot

	# --- animation (draw / reload / inspect) ---
	pos += a_pos
	rot += a_rot
	rig.position = pos
	rig.rotation = rot

	# --- nòng trượt ---
	var s_off := slide_anim if slide_anim >= 0.0 else _slide_offset(delta)
	slide.position.z = s_off
	trigger_t = maxf(trigger_t - delta, 0.0)
	if not glb_mode:
		trigger.position.z = -0.049 + (0.004 if trigger_t > 0.0 else 0.0)

	# --- tay trái ---
	var gb := grip.transform.basis
	lh.transform = Transform3D(gb * Basis.from_euler(lh_rot), lh_pos)
	for f in lh_fingers:
		f.rotation = Vector3(0.0, lh_curl * 1.35, 0.0)

	# --- băng đạn ---
	match mag_mode:
		MagMode.AXIS:
			mag.visible = true
			mag.transform = Transform3D(gb, grip.transform * (MAG_CENTER_GRIP + Vector3(0.0, -MAG_TRAVEL * mag_out, 0.0)))
		MagMode.HAND:
			mag.visible = true
			mag.transform = Transform3D(gb, lh_pos + gb * (-HAND_MAG_OFF_GRIP))
		MagMode.HIDDEN:
			mag.visible = false

	# --- cánh tay ---
	limb_l.update(rig.basis, lh.transform * LH_WRIST_LOCAL, ELBOW_L, delta)
	limb_r.update(rig.basis, grip.transform * RH_WRIST_GRIP, ELBOW_R, delta)

	# --- tia lửa đầu nòng ---
	if flash_t > 0.0:
		flash_t -= delta
		if flash_t <= 0.0:
			flash.visible = false

	_update_shells(delta)
	_update_drops(delta)


# ---------------- vỏ đạn & băng đạn rơi ----------------
func _spawn_shell() -> void:
	var sm := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = Vector3(0.0045, 0.0045, 0.0105)
	sm.mesh = bm
	sm.material_override = m_brass
	sm.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(sm)
	var local_pos := Vector3(0.016, 0.022, -0.050 + slide.position.z)
	sm.position = rig.transform * (gun.transform * local_pos)
	var v := rig.transform.basis * Vector3(randf_range(0.9, 1.5), randf_range(0.9, 1.5), randf_range(0.1, 0.7))
	shells.append({"node": sm, "vel": v, "spin": Vector3(randf_range(-20, 20), randf_range(-20, 20), randf_range(-20, 20)), "t": 0.0})


func _spawn_dropped_mag() -> void:
	var m := mag.duplicate() as Node3D
	add_child(m)
	m.visible = true
	m.global_transform = mag.global_transform
	var v := rig.transform.basis * Vector3(-0.6, -0.4, 0.5)
	drops.append({"node": m, "vel": v, "spin": Vector3(randf_range(-5, 5), randf_range(-5, 5), randf_range(-5, 5)), "t": 0.0})


func _update_shells(delta: float) -> void:
	for i in range(shells.size() - 1, -1, -1):
		var s: Dictionary = shells[i]
		var n: Node3D = s["node"]
		s["t"] = float(s["t"]) + delta
		var vel: Vector3 = s["vel"]
		vel.y -= 9.8 * delta
		s["vel"] = vel
		n.position += vel * delta
		n.rotation += (s["spin"] as Vector3) * delta
		if float(s["t"]) > 0.8:
			n.queue_free()
			shells.remove_at(i)


func _update_drops(delta: float) -> void:
	for i in range(drops.size() - 1, -1, -1):
		var s: Dictionary = drops[i]
		var n: Node3D = s["node"]
		s["t"] = float(s["t"]) + delta
		var vel: Vector3 = s["vel"]
		vel.y -= 9.8 * delta
		s["vel"] = vel
		n.position += vel * delta
		n.rotation += (s["spin"] as Vector3) * delta
		if float(s["t"]) > 0.7:
			n.queue_free()
			drops.remove_at(i)
