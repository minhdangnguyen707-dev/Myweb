extends Node3D
## Thân người của MÌNH khi chết (nhìn từ góc thứ 3): đứng cầm súng, khuỵu gối rồi đổ ra sau/theo hướng đạn,
## súng văng khỏi tay. Dựng bằng khối hộp giống bot (nhẹ máy). Player tạo ra lúc chết và xoá khi hồi sinh.
## Là con của Player nên tự xoay theo hướng nhìn lúc chết (gốc ở chân).
## Thân người là model thật có animation chết (phe CT = Yuri, phe T = Terror, xem terror_rig.gd); các khối hộp dưới đây chỉ còn
## chạy ngầm (ẩn) để lấy vị trí khẩu súng văng ra, và là nhánh dự phòng nếu không nạp được model.
const TerrorRig := preload("res://scripts/terror_rig.gd")

const HIP_Y := 0.88
const ARM_L1 := 0.30
const SHOULDER_X := 0.29
const SHOULDER_Y := 0.54
static var _mats: Dictionary = {}

var body: Node3D
var hips: Node3D
var torso: Node3D
var head: Node3D
var gun: Node3D
var thigh: Array = []
var shin: Array = []
var up_arm: Array = []
var fore_arm: Array = []
var death_t := 0.0
var death_dir := Vector3(0.0, 0.0, 1.0)
var death_seed := 1.0
var death_q: Array = []
var gun_vel := Vector3.ZERO
var gun_spin := Vector3.ZERO
var gun_floor := 0.0
var gun_dropped := false
var kind := ""            # model của thân người ("yuri" / "terror" / "miho"...); rỗng = theo phe
var rig = null            # TerrorRig (model thật); null = vẫn dùng các khối hộp
var aim_t := 0.0          # rig.on_death đọc biến này (xác không "giao tranh" nên luôn 0)


func _mat(color: Color) -> StandardMaterial3D:
	var key := color.to_html()
	if not _mats.has(key):
		var m := StandardMaterial3D.new()
		m.albedo_color = color
		m.roughness = 0.9
		m.shading_mode = BaseMaterial3D.SHADING_MODE_PER_VERTEX
		m.specular_mode = BaseMaterial3D.SPECULAR_DISABLED
		_mats[key] = m
	return _mats[key]


func _part(parent: Node3D, size: Vector3, pos: Vector3, color: Color, rot: Vector3 = Vector3.ZERO) -> void:
	var mi := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = size
	mi.mesh = bm
	mi.material_override = _mat(color)
	mi.position = pos
	mi.rotation = rot
	mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	parent.add_child(mi)


## dir_local: hướng ngã (toạ độ của Player). vel: vận tốc lúc chết (để súng văng theo).
func setup(ct: bool, dir_local: Vector3, vel: Vector3, headshot: bool) -> void:
	death_seed = 1.0 if randf() < 0.5 else -1.0
	_build(ct)
	# tư thế lúc bị hạ: hai tay giơ trước ngực cầm súng
	for i in 2:
		var sx := -1.0 if i == 0 else 1.0
		(up_arm[i] as Node3D).rotation = Vector3(0.95, 0.0, sx * 0.12)
		(fore_arm[i] as Node3D).rotation = Vector3(0.65, 0.0, 0.0)
	gun.position = Vector3(0.10, 0.40, -0.26)
	death_q = [up_arm[0].quaternion, up_arm[1].quaternion, fore_arm[0].quaternion, fore_arm[1].quaternion]
	death_dir = dir_local
	# súng văng khỏi tay
	var gt := gun.global_transform
	gun.top_level = true
	gun.global_transform = gt
	gun_dropped = true
	gun_floor = global_position.y + 0.04
	gun_vel = Vector3(vel.x * 0.5 + randf_range(-0.8, 0.8), 1.6 if headshot else 1.2, vel.z * 0.5 + randf_range(-0.8, 0.8))
	gun_spin = Vector3(randf_range(-6.0, 6.0), randf_range(-6.0, 6.0), randf_range(-6.0, 6.0))
	# model thật: phát animation chết theo hướng đạn / bắn vào đầu, ẩn các khối hộp (trừ súng)
	var r = TerrorRig.new()
	r.configure(kind if kind != "" else ("yuri" if ct else "terror"))
	if r.setup(self, 0):
		rig = r
		r.on_death(self, headshot)
		_hide_boxes(body)


## Thay khẩu súng văng ra bằng đúng khẩu người chơi đang cầm (mô hình súng của game, dựng thẳng, nòng hướng -Z).
## root = null (đang cầm dao / bom) thì không có súng văng ra.
func set_gun_model(root: Node3D) -> void:
	if gun == null:
		return
	if root == null or root.get_child_count() == 0:
		gun.visible = false
		return
	for c in gun.get_children():
		c.queue_free()
	var m: Node3D = root.get_child(0)
	root.remove_child(m)
	m.rotation = Vector3.ZERO
	gun.add_child(m)
	root.queue_free()


## Ẩn mọi khối hộp của thân (trừ khẩu súng văng ra).
func _hide_boxes(n: Node) -> void:
	for c in n.get_children():
		if c == gun:
			continue
		if c is MeshInstance3D:
			(c as MeshInstance3D).visible = false
		_hide_boxes(c)


func _build(ct: bool) -> void:
	body = Node3D.new()
	add_child(body)
	var cloth := Color(0.16, 0.29, 0.58) if ct else Color(0.58, 0.42, 0.22)
	var cloth_d := Color(0.09, 0.15, 0.32) if ct else Color(0.36, 0.26, 0.15)
	var pants := Color(0.12, 0.13, 0.17) if ct else Color(0.27, 0.22, 0.15)
	var dark := Color(0.07, 0.07, 0.08)
	var skin := Color(0.84, 0.64, 0.52)
	var helmet := Color(0.08, 0.11, 0.19) if ct else Color(0.30, 0.25, 0.15)

	hips = Node3D.new()
	hips.position = Vector3(0.0, HIP_Y, 0.0)
	body.add_child(hips)
	_part(hips, Vector3(0.39, 0.17, 0.24), Vector3.ZERO, pants)
	for i in 2:
		var sx := -1.0 if i == 0 else 1.0
		var th := Node3D.new()
		th.position = Vector3(0.105 * sx, 0.0, 0.0)
		hips.add_child(th)
		_part(th, Vector3(0.17, 0.46, 0.2), Vector3(0.0, -0.23, 0.0), pants)
		var sh := Node3D.new()
		sh.position = Vector3(0.0, -0.45, 0.0)
		th.add_child(sh)
		_part(sh, Vector3(0.15, 0.42, 0.17), Vector3(0.0, -0.21, 0.0), pants)
		_part(sh, Vector3(0.155, 0.09, 0.27), Vector3(0.0, -0.385, -0.05), dark)
		thigh.append(th)
		shin.append(sh)

	torso = Node3D.new()
	torso.position = Vector3(0.0, 0.02, 0.0)
	hips.add_child(torso)
	_part(torso, Vector3(0.46, 0.54, 0.27), Vector3(0.0, 0.33, 0.0), cloth)
	_part(torso, Vector3(0.42, 0.36, 0.05), Vector3(0.0, 0.36, -0.155), cloth_d)
	_part(torso, Vector3(0.30, 0.36, 0.14), Vector3(0.0, 0.34, 0.20), cloth_d)
	_part(torso, Vector3(0.47, 0.06, 0.285), Vector3(0.0, 0.07, 0.0), dark)
	_part(torso, Vector3(0.1, 0.1, 0.07), Vector3(-0.16, 0.12, -0.17), dark)
	_part(torso, Vector3(0.1, 0.1, 0.07), Vector3(0.16, 0.12, -0.17), dark)
	_part(torso, Vector3(0.10, 0.10, 0.10), Vector3(0.0, 0.60, 0.0), skin)

	head = Node3D.new()
	head.position = Vector3(0.0, 0.62, 0.0)
	torso.add_child(head)
	_part(head, Vector3(0.22, 0.24, 0.23), Vector3(0.0, 0.10, 0.0), skin)
	_part(head, Vector3(0.20, 0.05, 0.02), Vector3(0.0, 0.13, -0.12), Color(0.04, 0.05, 0.07))
	_part(head, Vector3(0.255, 0.10, 0.265), Vector3(0.0, 0.235, 0.0), helmet)
	_part(head, Vector3(0.255, 0.03, 0.08), Vector3(0.0, 0.195, -0.15), helmet)

	for i in 2:
		var sx2 := -1.0 if i == 0 else 1.0
		var up := Node3D.new()
		up.position = Vector3(SHOULDER_X * sx2, SHOULDER_Y, 0.0)
		torso.add_child(up)
		_part(up, Vector3(0.13, 0.30, 0.13), Vector3(0.0, -0.15, 0.0), cloth)
		_part(up, Vector3(0.17, 0.09, 0.17), Vector3.ZERO, cloth_d)
		var fo := Node3D.new()
		fo.position = Vector3(0.0, -ARM_L1, 0.0)
		up.add_child(fo)
		_part(fo, Vector3(0.115, 0.28, 0.115), Vector3(0.0, -0.14, 0.0), cloth)
		_part(fo, Vector3(0.10, 0.10, 0.11), Vector3(0.0, -0.30, 0.0), dark)
		up_arm.append(up)
		fore_arm.append(fo)

	gun = Node3D.new()
	torso.add_child(gun)
	var gm := Color(0.09, 0.09, 0.10)
	_part(gun, Vector3(0.055, 0.085, 0.30), Vector3(0.0, 0.0, -0.02), gm)
	_part(gun, Vector3(0.06, 0.07, 0.24), Vector3(0.0, -0.005, -0.28), Color(0.13, 0.12, 0.11))
	_part(gun, Vector3(0.026, 0.026, 0.22), Vector3(0.0, 0.012, -0.52), gm)
	_part(gun, Vector3(0.036, 0.036, 0.05), Vector3(0.0, 0.012, -0.64), dark)
	_part(gun, Vector3(0.045, 0.095, 0.20), Vector3(0.0, -0.01, 0.23), Color(0.14, 0.12, 0.10))
	_part(gun, Vector3(0.04, 0.11, 0.05), Vector3(0.0, -0.085, 0.07), gm, Vector3(0.25, 0.0, 0.0))
	_part(gun, Vector3(0.045, 0.15, 0.07), Vector3(0.0, -0.11, -0.09), Color(0.12, 0.12, 0.13), Vector3(-0.15, 0.0, 0.0))


func _process(delta: float) -> void:
	if rig != null:
		rig.drive_corpse(minf(delta, 0.05))
	if body == null or death_t > 2.5:
		return
	delta = minf(delta, 0.05)
	death_t += delta
	var buckle := clampf(death_t / 0.30, 0.0, 1.0)
	var fall := clampf((death_t - 0.08) / 0.55, 0.0, 1.0)
	var fall_ang := 1.52 * fall * fall
	var axis := Vector3.UP.cross(death_dir)
	if axis.length() > 0.001:
		body.basis = Basis(axis.normalized(), fall_ang)
	var bounce := 0.0
	if death_t > 0.63 and death_t < 0.9:
		bounce = sin((death_t - 0.63) / 0.27 * PI) * 0.05
	body.position.y = 0.13 * fall + bounce

	var cr := buckle * 0.9
	for i in 2:
		var sx := -1.0 if i == 0 else 1.0
		var th: Node3D = thigh[i]
		var sh: Node3D = shin[i]
		var splay := fall * (0.15 + 0.12 * float(i) * death_seed)
		th.rotation = Vector3(cr * 0.5 + fall * 0.25 * (1.0 if i == 0 else -0.4), 0.0, sx * splay)
		sh.rotation = Vector3(-cr * (1.0 - 0.5 * fall), 0.0, 0.0)
	hips.position.y = HIP_Y - HIP_Y * (1.0 - cos(0.5 * cr))
	torso.rotation = Vector3(0.25 * fall, death_seed * 0.15 * fall, death_seed * 0.12 * fall)
	head.rotation = Vector3(0.35 * fall * (1.0 if death_dir.z > 0.0 else -1.0), death_seed * 0.3 * fall, 0.12 * fall * death_seed)

	# tay buông thõng ra hai bên
	var k := clampf(death_t / 0.35, 0.0, 1.0)
	k = k * k * (3.0 - 2.0 * k)
	for i in 2:
		var sx2 := -1.0 if i == 0 else 1.0
		var tu := Quaternion(Basis.from_euler(Vector3(-0.25, 0.0, sx2 * (0.55 + 0.7 * fall))))
		var tf := Quaternion(Basis.from_euler(Vector3(-0.6 - 0.3 * fall, 0.0, 0.0)))
		var qu: Quaternion = death_q[i]
		var qf: Quaternion = death_q[2 + i]
		(up_arm[i] as Node3D).quaternion = qu.slerp(tu, k)
		(fore_arm[i] as Node3D).quaternion = qf.slerp(tf, k)

	# súng rơi xuống đất
	if gun_dropped:
		gun_vel.y -= 14.0 * delta
		var gpos := gun.global_position + gun_vel * delta
		if gpos.y < gun_floor:
			gpos.y = gun_floor
			gun_vel = gun_vel * exp(-8.0 * delta)
			gun_vel.y = 0.0
			gun_spin = gun_spin * exp(-10.0 * delta)
		gun.global_position = gpos
		gun.rotate_x(gun_spin.x * delta)
		gun.rotate_y(gun_spin.y * delta)
		gun.rotate_z(gun_spin.z * delta)
