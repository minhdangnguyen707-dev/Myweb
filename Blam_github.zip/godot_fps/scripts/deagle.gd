extends Node3D
## DESERT EAGLE kiểu CS:GO (người dùng yêu cầu: NHÚNG THẲNG model + tay + animation + âm thanh trong file gửi kèm, xoá model cũ).
## Súng + hai bàn tay + mọi animation (rút súng, bắn 2 kiểu, bắn viên cuối, nạp đạn, đứng yên) lấy từ MỘT file:
## assets/deagle/v_deagle_ct.glb (phe CT: găng + tay áo xanh ô-liu) hoặc v_deagle_t.glb (phe T: găng đen, tay trần), đổi từ "CT Arms/v_deagle.mdl" và
## "T Arms/v_deagle.mdl" của gói cs_go_deagle_74536 bằng `python3 tools/mdl2glb.py "CT Arms/v_deagle.mdl" v_deagle_ct.glb --vm --atlas --jpeg --no-normals`
## (bản T thêm `--gun-tex-from="CT Arms/v_deagle.mdl"` để cả hai phe cùng MỘT lớp sơn súng: hai file .mdl nhúng hai skin súng khác nhau).
## Chỉ lấy MỘT skin súng (skin nhúng sẵn trong CT Arms: đen trắng vàng); 9 skin trong thư mục Texture(s) của gói KHÔNG dùng.
## Mô-đun StatTrak (số đếm bên hông súng) là của model gốc nên giữ nguyên.
## Âm thanh: assets/deagle/sounds/*.wav: rút súng, tháo băng, lắp băng, kéo khoá phát ĐÚNG thời điểm sự kiện ghi trong model; tiếng bắn deagle-1 / deagle-2 xen kẽ.
## NGOẠI LỆ so với quy tắc "súng mới phải dùng Hands.Arm": Desert Eagle dùng tay CÓ SẴN trong model (giống AWP / MP5 / AK-47 / dao), KHÔNG dùng hands.gd.
## Cùng giao diện (API) với Viewmodel / Rifle / Mp5 / Ak47 để Player dùng thay thế qua lại. KHÔNG có ngắm (ADS), không có xem súng (model không có animation inspect).
## Model Desert Eagle cũ (dựng bằng code + file desert_eagle.glb) đã bị XOÁ.
##
## Hệ trục model (glTF, đổi từ GoldSrc): +X trái, +Y lên, +Z phía trước. Model CS 1.6 vẽ cho tay TRÁI (engine lật gương khi chơi tay phải), nên như AK-47:
## xoay 180 độ quanh Y RỒI lật gương X (x_game = +x_model, z_game = -z_model). Bản T trong gói được phóng to ~2.6 lần so với bản CT (súng dài 0.72 m thay vì 0.29 m),
## nên mỗi phe một GUN_SCALE: thu nhỏ đều quanh mắt thì hình trên màn hình Y NGUYÊN, súng dài đúng cỡ thật.

signal sound(sound_name: String)
signal reload_inserted()
signal action_finished(action_name: String)

# Phe CT (team 0) = tay áo xanh ô-liu, phe T (team 1) = găng đen. Đổi phe giữa trận (bomb.gd) thì súng tự đổi model.
const MODEL_CT := "res://assets/deagle/v_deagle_ct.glb"
const MODEL_T := "res://assets/deagle/v_deagle_t.glb"
const SND_DIR := "res://assets/deagle/sounds/"
const SND_NAMES := ["clipin", "clipout", "deagle-1", "deagle-2", "draw", "slide"]

# Thu nhỏ đều quanh mắt: hình không đổi (phép chiếu). CT: model đã đúng cỡ thật (1.0). T: model to gấp ~2.6 lần (0.29 / 0.72 = 0.39).
const SCALE_CT := 1.0
const SCALE_T := 0.39
const VM_OFFSET := Vector3(0.0, 0.0, 0.0)   # model đã đặt súng đúng chỗ kiểu CS

# Đầu nòng = attachment 0 của model, gắn vào xương "deagle_parent": (x trước, y trái, z lên) đơn vị GoldSrc (1 đơn vị = 2.54 cm) đổi sang hệ glTF (trái, lên, trước).
# CT: (0, 3, 9) -> (3, 9, 0) x 0.0254 ; T: (0, 8, 23) -> (8, 23, 0) x 0.0254 (xương của hai bản có hướng khác nhau)
const MUZZLE_BONE := "deagle_parent"
const MUZZLE_LOCAL_CT := Vector3(0.0762, 0.2286, 0.0)
const MUZZLE_LOCAL_T := Vector3(0.2032, 0.5842, 0.0)

enum Mode { NONE, DRAW, RELOAD, INSPECT }

# CS2: nạp đạn Desert Eagle = 2.2 s (animation gốc 2.208 s). Băng mới vào súng ngay sau cú "clipin" (0.75 / 0.79 s) và cú vỗ băng.
const RELOAD_TIME := 2.2
const RELOAD_INSERT_AT := 1.0
const RELOAD_ANIMS := ["reload", "EMMASTONE"]   # bản T trong gói đặt tên animation nạp đạn là "EMMASTONE"
# true = DỪNG animation khi súng đứng yên. Mặc định false: model chỉ 1 mảnh, 1 vật liệu nên rất nhẹ, lại giữ được hiệu ứng thở của CS.
const FREEZE_IDLE := false

# Sự kiện âm thanh ghi trong model (giây trong animation): [thời điểm, tên file wav bỏ đuôi]
const EVENTS_CT := {
	"draw": [[0.0, "draw"]],
	"reload": [[0.292, "clipout"], [0.75, "clipin"], [1.667, "slide"]],
}
const EVENTS_T := {
	"draw": [[0.034, "draw"]],
	"EMMASTONE": [[0.333, "clipout"], [0.792, "clipin"], [1.708, "slide"]],
}

# ---------------- trạng thái nhận từ Player ----------------
var move_amount := 0.0
var run_amount := 0.0
var grounded := true
var crouched := false
var ads := 0.0           # luôn 0 (game không có ngắm)
var ads_t := 0.0
var wall_push := 0.0
var mouse_delta := Vector2.ZERO
var planting := false    # bomb.gd gán biến này cho viewmodel đang cầm; Desert Eagle không dùng

var rig: Node3D = null            # gốc model (đã xoay 180 độ + lật gương + thu nhỏ + dời vị trí)
var model: Node3D = null          # model đang dùng (CT hoặc T)
var model_team := -1              # phe của model đang dựng (-1 = chưa dựng)
var owner_player: Node = null     # Player đang cầm súng (để đọc phe)
var anim: AnimationPlayer = null
var skel: Skeleton3D = null
var muzzle_bone := -1
var flash: MeshInstance3D = null
var flash_t := 0.0

var mode: int = Mode.NONE
var mode_t := 0.0
var mode_len := 0.0
var mode_speed := 1.0
var insert_at := 1.0
var insert_sent := false
var fire_t := 0.0                 # còn đang chạy animation bắn
var shoot_i := 0
var ev_list: Array = []
var ev_i := 0

var snd := {}
var foley_players: Array = []
var foley_i := 0
var shot_players: Array = []
var shot_i := 0
var shot_alt := 0

var idle_hold_t := 0.0            # chỉ dùng khi FREEZE_IDLE = true
var sway := Vector2.ZERO
var bob_t := 0.0
var land_off := 0.0


func _ready() -> void:
	rig = Node3D.new()
	rig.rotation.y = PI
	rig.position = VM_OFFSET
	add_child(rig)
	_build_flash()   # main._warmup() đụng tới `flash` của mọi viewmodel nên luôn phải có
	_build_audio()
	# tìm Player (tổ tiên có biến `team` và `viewmodels`) để biết đang chơi phe nào
	var n: Node = get_parent()
	while n != null:
		if "team" in n and "viewmodels" in n:
			owner_player = n
			break
		n = n.get_parent()
	_set_team(_player_team())
	visibility_changed.connect(_on_visibility_changed)


## Nạp các file wav (thiếu file / chưa import thì im lặng bỏ qua, súng vẫn chạy bình thường) và dựng các kênh phát.
func _build_audio() -> void:
	for n in SND_NAMES:
		var p: String = SND_DIR + n + ".wav"
		if ResourceLoader.exists(p):
			var s = load(p)
			if s != null:
				snd[n] = s
	for i in 2:
		var ap := AudioStreamPlayer.new()
		ap.volume_db = -3.0
		add_child(ap)
		foley_players.append(ap)
	for i in 2:
		var ap := AudioStreamPlayer.new()
		ap.volume_db = -2.0
		add_child(ap)
		shot_players.append(ap)


func _play_snd(sname: String) -> void:
	if not snd.has(sname):
		return
	var ap: AudioStreamPlayer = foley_players[foley_i % foley_players.size()]
	foley_i += 1
	ap.stream = snd[sname]
	ap.play()


func _play_shot() -> void:
	shot_alt = (shot_alt + 1) % 2
	var nm := "deagle-1" if shot_alt == 0 else "deagle-2"
	if not snd.has(nm):
		return
	var ap: AudioStreamPlayer = shot_players[shot_i % shot_players.size()]
	shot_i += 1
	ap.stream = snd[nm]
	ap.play()


func _stop_snd() -> void:
	for ap in foley_players:
		(ap as AudioStreamPlayer).stop()
	for ap in shot_players:
		(ap as AudioStreamPlayer).stop()


## Phe của người chơi đang cầm súng: 0 = CT, 1 = T. Không tìm thấy Player thì coi như CT.
func _player_team() -> int:
	if owner_player != null and is_instance_valid(owner_player):
		return 1 if int(owner_player.team) == 1 else 0
	return 0


## Đổi phe thì dựng lại model cho đúng tay, giữ nguyên animation đang chạy.
func _sync_team() -> void:
	var t := _player_team()
	if t != model_team:
		_set_team(t)


func _set_team(t: int) -> void:
	var cur_name := ""
	var cur_pos := 0.0
	if anim != null:
		cur_name = anim.current_animation
		cur_pos = anim.current_animation_position
	if model != null:
		rig.remove_child(model)
		model.queue_free()
		model = null
		skel = null
		anim = null
		muzzle_bone = -1
	model_team = t
	var sc := SCALE_T if t == 1 else SCALE_CT
	rig.scale = Vector3(-sc, sc, sc)   # xoay 180 độ + lật gương X: x_game = +x_model * s, z_game = -z_model * s
	var path := MODEL_T if t == 1 else MODEL_CT
	var scene = load(path)
	if scene == null:
		push_warning("Không nạp được " + path + " (chạy CHOI_GAME.bat để Godot import lại)")
		return
	model = (scene as PackedScene).instantiate()
	rig.add_child(model)
	skel = _find_skeleton(model)
	anim = _find_anim(model)
	if skel != null:
		muzzle_bone = skel.find_bone(MUZZLE_BONE)
		if muzzle_bone < 0:
			muzzle_bone = _find_bone_by_suffix(MUZZLE_BONE.to_lower())
	_fix_meshes(model)
	if anim != null:
		_complete_tracks()
		anim.playback_default_blend_time = 0.05
		anim.active = is_visible_in_tree()
		if cur_name != "" and anim.has_animation(cur_name):
			var sp := mode_speed if mode != Mode.NONE else 1.0
			_play(cur_name, 0.0, sp)
			anim.seek(cur_pos, true)
		else:
			_play("idle")


## Khi import, Godot có thể bỏ các track xương "bất biến" (bằng tư thế nghỉ). Nếu animation sau không còn track của xương đó thì xương giữ nguyên
## tư thế của animation trước (tay / băng đạn không quay về chỗ cũ). Thêm lại các track thiếu bằng đúng tư thế nghỉ để animation nào cũng ghi đè đủ mọi xương.
func _complete_tracks() -> void:
	if skel == null:
		return
	var base: Node = anim.get_node_or_null(anim.root_node)
	if base == null:
		return
	var sp := str(base.get_path_to(skel))
	for an in anim.get_animation_list():
		var a: Animation = anim.get_animation(an)
		for b in skel.get_bone_count():
			var path := NodePath(sp + ":" + skel.get_bone_name(b))
			var rest := skel.get_bone_rest(b)
			if a.find_track(path, Animation.TYPE_POSITION_3D) < 0:
				var tp_i := a.add_track(Animation.TYPE_POSITION_3D)
				a.track_set_path(tp_i, path)
				a.position_track_insert_key(tp_i, 0.0, rest.origin)
			if a.find_track(path, Animation.TYPE_ROTATION_3D) < 0:
				var tr_i := a.add_track(Animation.TYPE_ROTATION_3D)
				a.track_set_path(tr_i, path)
				a.rotation_track_insert_key(tr_i, 0.0, rest.basis.get_rotation_quaternion())


func _find_skeleton(n: Node) -> Skeleton3D:
	if n is Skeleton3D:
		return n
	for c in n.get_children():
		var r := _find_skeleton(c)
		if r != null:
			return r
	return null


func _find_anim(n: Node) -> AnimationPlayer:
	if n is AnimationPlayer:
		return n
	for c in n.get_children():
		var r := _find_anim(c)
		if r != null:
			return r
	return null


## Tìm xương theo đuôi tên (không phân biệt hoa thường), phòng khi Godot đổi dấu trong tên xương.
func _find_bone_by_suffix(suffix: String) -> int:
	for i in skel.get_bone_count():
		if skel.get_bone_name(i).to_lower().ends_with(suffix):
			return i
	return -1


## Texture CS vẽ không đổ bóng (giống các súng khác + nhẹ cho máy yếu); mesh có xương nên nới hộp cắt hình để không bị mất khi animation đưa súng ra xa.
func _fix_meshes(n: Node) -> void:
	if n is MeshInstance3D:
		var mi := n as MeshInstance3D
		mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		mi.custom_aabb = AABB(Vector3(-3.0, -3.0, -3.0), Vector3(6.0, 6.0, 6.0))
		if mi.mesh != null:
			for i in mi.mesh.get_surface_count():
				var m = mi.mesh.surface_get_material(i)
				if m is BaseMaterial3D:
					var d := (m as BaseMaterial3D).duplicate() as BaseMaterial3D
					d.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
					d.cull_mode = BaseMaterial3D.CULL_DISABLED   # model bị lật gương nên chiều mặt đảo: tắt cắt mặt sau cho chắc
					mi.set_surface_override_material(i, d)
	for c in n.get_children():
		_fix_meshes(c)


## Tia lửa đầu nòng: Desert Eagle nổ to nên loé sáng và lớn.
func _build_flash() -> void:
	var g := Gradient.new()
	g.set_color(0, Color(1.0, 0.95, 0.7, 0.95))
	g.set_color(1, Color(1.0, 0.5, 0.1, 0.0))
	var gt := GradientTexture2D.new()
	gt.gradient = g
	gt.fill = GradientTexture2D.FILL_RADIAL
	gt.fill_from = Vector2(0.5, 0.5)
	gt.fill_to = Vector2(1.0, 0.5)
	gt.width = 64
	gt.height = 64
	var q := QuadMesh.new()
	q.size = Vector2(0.14, 0.14)
	var mat := StandardMaterial3D.new()
	mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	mat.blend_mode = BaseMaterial3D.BLEND_MODE_ADD
	mat.billboard_mode = BaseMaterial3D.BILLBOARD_ENABLED
	mat.albedo_texture = gt
	mat.no_depth_test = true
	flash = MeshInstance3D.new()
	flash.mesh = q
	flash.material_override = mat
	flash.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	flash.visible = false
	add_child(flash)


## Ẩn viewmodel (đổi súng) thì tắt luôn animation + tiếng cho nhẹ máy.
func _on_visibility_changed() -> void:
	if anim != null:
		anim.active = is_visible_in_tree()
	if not is_visible_in_tree():
		_stop_snd()


func _play(anim_name: String, blend: float = -1.0, speed: float = 1.0) -> void:
	if anim == null or not anim.has_animation(anim_name):
		return
	idle_hold_t = 0.3 if (anim_name == "idle" and FREEZE_IDLE) else 0.0
	anim.play(anim_name, blend, speed)


func _anim_len(anim_name: String, fallback: float) -> float:
	if anim != null and anim.has_animation(anim_name):
		return anim.get_animation(anim_name).length
	return fallback


func _reload_anim() -> String:
	for nm in RELOAD_ANIMS:
		if anim != null and anim.has_animation(nm):
			return nm
	return "reload"


# =====================================================================
#  API CHO PLAYER
# =====================================================================
func is_busy() -> bool:
	return mode != Mode.NONE or fire_t > 0.0


func current_mode() -> int:
	return mode


func play_draw() -> void:
	_sync_team()
	_start_mode(Mode.DRAW, "draw", _anim_len("draw", 0.9), 1.0)


func play_reload(_empty: bool) -> float:
	_sync_team()
	var nm := _reload_anim()
	var a_len := _anim_len(nm, 2.208)
	_start_mode(Mode.RELOAD, nm, RELOAD_TIME, a_len / RELOAD_TIME)
	return mode_len


## Model không có animation xem súng: bấm F không làm gì.
func play_inspect() -> void:
	pass


func cancel() -> void:
	mode = Mode.NONE
	mode_t = 0.0
	fire_t = 0.0
	flash_t = 0.0
	ev_list = []
	if flash != null:
		flash.visible = false
	_stop_snd()   # đổi súng giữa chừng thì tắt tiếng nạp đạn / tiếng bắn
	_play("idle", 0.05)


func set_slide_locked(_locked: bool) -> void:
	pass


func is_slide_locked() -> bool:
	return false


func land(strength: float) -> void:
	land_off = minf(land_off - 0.035 * strength, 0.0)


func dry_fire() -> void:
	pass   # model không có animation bắn rỗng


## Bắn: animation shoot1 / shoot2 xen kẽ (viên cuối: shoot_empty, nòng trượt kẹt lại) + loé lửa đầu nòng + tiếng bắn.
func fire(last_round: bool) -> void:
	_sync_team()
	var nm := "shoot_empty"
	if not (last_round and anim != null and anim.has_animation("shoot_empty")):
		shoot_i = (shoot_i + 1) % 2
		nm = "shoot%d" % (shoot_i + 1)
	_play(nm, 0.0)
	fire_t = _anim_len(nm, 0.8)
	flash_t = 0.05
	if flash != null:
		flash.visible = true
		flash.global_position = muzzle_global()
	_play_shot()
	sound.emit("shot_deagle")


## Vị trí đầu nòng trong thế giới (theo xương "deagle_parent" đang chuyển động) cho vạch đạn / loé lửa.
func muzzle_global() -> Vector3:
	if skel != null and muzzle_bone >= 0:
		var local := MUZZLE_LOCAL_T if model_team == 1 else MUZZLE_LOCAL_CT
		var t: Transform3D = skel.global_transform * skel.get_bone_global_pose(muzzle_bone)
		return t * local
	return global_transform * Vector3(0.1, -0.1, -0.5)


# =====================================================================
#  NỘI BỘ
# =====================================================================
func _start_mode(m: int, anim_name: String, total_len: float, speed: float) -> void:
	mode = m
	mode_t = 0.0
	fire_t = 0.0
	insert_sent = false
	mode_speed = maxf(speed, 0.01)
	mode_len = total_len
	insert_at = RELOAD_INSERT_AT / mode_speed
	var table: Dictionary = EVENTS_T if model_team == 1 else EVENTS_CT
	var list: Array = table.get(anim_name, [])
	ev_list = []
	for e in list:   # đổi thời điểm sự kiện (giây trong animation gốc) sang giây thật khi animation chạy nhanh / chậm hơn
		ev_list.append([float((e as Array)[0]) / mode_speed, (e as Array)[1]])
	ev_i = 0
	_play(anim_name, 0.03, speed)


func _process(delta: float) -> void:
	delta = minf(delta, 0.05)
	_sync_team()   # đổi phe giữa trận (bomb.gd) thì đổi tay
	# đồng hồ của hành động (rút súng / nạp đạn) chạy song song với animation của model
	if mode != Mode.NONE:
		mode_t += delta
		while ev_i < ev_list.size() and mode_t >= float((ev_list[ev_i] as Array)[0]):
			_play_snd(str((ev_list[ev_i] as Array)[1]))
			ev_i += 1
		if mode == Mode.RELOAD and not insert_sent and mode_t >= insert_at:
			insert_sent = true
			reload_inserted.emit()
		if mode_t >= mode_len:
			var finished := mode
			mode = Mode.NONE
			mode_t = 0.0
			ev_list = []
			_play("idle", 0.08)
			var nm := "draw"
			if finished == Mode.RELOAD:
				nm = "reload"
				if not insert_sent:
					insert_sent = true
					reload_inserted.emit()
			action_finished.emit(nm)
	elif fire_t > 0.0:
		fire_t -= delta
		if fire_t <= 0.0:
			fire_t = 0.0
			_play("idle", 0.08)
	if idle_hold_t > 0.0:
		idle_hold_t -= delta
		if idle_hold_t <= 0.0 and anim != null and mode == Mode.NONE and fire_t <= 0.0:
			anim.pause()   # chỉ khi FREEZE_IDLE = true
	if flash_t > 0.0:
		flash_t -= delta
		if flash != null:
			flash.global_position = muzzle_global()
			if flash_t <= 0.0:
				flash.visible = false

	# lắc nhẹ theo chuột + nhún khi đi + dội khi tiếp đất (cộng lên trên animation của model)
	var target := Vector2(clampf(-mouse_delta.x * 0.0005, -0.018, 0.018), clampf(mouse_delta.y * 0.0005, -0.018, 0.018))
	mouse_delta = Vector2.ZERO
	sway = sway.lerp(target, 1.0 - exp(-9.0 * delta))
	bob_t += delta * (3.0 + move_amount * 7.0)
	var bob := Vector3(sin(bob_t) * 0.004, -absf(cos(bob_t)) * 0.005, 0.0) * move_amount
	land_off = lerpf(land_off, 0.0, 1.0 - exp(-10.0 * delta))
	if rig != null:
		rig.position = VM_OFFSET + Vector3(sway.x, sway.y + land_off, 0.0) + bob
