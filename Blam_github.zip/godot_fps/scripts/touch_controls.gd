extends CanvasLayer
## NÚT CẢM ỨNG cho điện thoại (không dùng class_name; main.gd nạp bằng preload).
## Chỉ hiện trên Android / iOS. Trên máy tính không làm gì, trừ khi chạy với tham số "touch" (xem thử bố cục bằng chuột).
## Cách hoạt động: nút bấm gọi Input.action_press / action_release cho các phím đã có (jump, reload, fire...),
## cần di chuyển đẩy move_*, vuốt màn hình gọi Player.touch_look(). Chưa chạy thử trong Godot.

const TOUCH_SENS := 2.2      # độ nhạy vuốt xoay camera (tăng = xoay nhanh hơn)
const DEAD := 0.12           # vùng chết của cần di chuyển
const STICK_R := 52.0        # bán kính cần di chuyển (đơn vị ảo, khung 720x405)
const STICK_ZONE_X := 0.40   # chạm nửa trái màn hình (dưới mức này) = bật cần di chuyển
const REACH := 1.15          # vùng chạm rộng hơn hình nút 15%

var main = null              # main.gd gán vào
var active := false          # có dùng nút cảm ứng không
var test_mode := false       # chạy trên máy tính để xem thử bố cục
var pad: Control
var font: Font
var playing := false
var buttons: Array = []
var fingers := {}            # số thứ tự ngón tay -> thông tin
var stick_id := -1
var stick_center := Vector2.ZERO
var stick_pos := Vector2.ZERO
var held := {}               # action đang giữ -> true
var toggles := {"crouch": false, "walk": false}
var view_size := Vector2.ZERO
var dirty := true


func _ready() -> void:
	layer = 12
	process_mode = Node.PROCESS_MODE_ALWAYS
	test_mode = "touch" in OS.get_cmdline_user_args()
	active = OS.has_feature("android") or OS.has_feature("ios") or test_mode
	if not active:
		set_process(false)
		set_process_input(false)
		return
	font = ThemeDB.fallback_font
	# chuột trái / phải không còn là "bắn / ngắm": chạm vào màn hình sẽ bị tính là bấm chuột, nên chỉ để nút bấm điều khiển
	for a in ["fire", "aim"]:
		if InputMap.has_action(a):
			InputMap.action_erase_events(a)
		else:
			InputMap.add_action(a)
	if test_mode:
		Input.emulate_touch_from_mouse = true
	pad = Control.new()
	pad.set_anchors_preset(Control.PRESET_FULL_RECT)
	pad.mouse_filter = Control.MOUSE_FILTER_IGNORE
	pad.visible = false
	pad.draw.connect(_paint)
	add_child(pad)
	_build_buttons()
	_layout()


# =====================================================================
#  DANH SÁCH NÚT
# =====================================================================
# kind: hold = giữ là bấm, tap = chạm một lần gọi hàm fn, toggle = bấm bật / bấm tắt
func _add(id: String, label: String, ax: float, ay: float, ox: float, oy: float, r: float, kind: String, arg: String) -> void:
	buttons.append({"id": id, "label": label, "ax": ax, "ay": ay, "ox": ox, "oy": oy, "r": r,
		"kind": kind, "arg": arg, "pos": Vector2.ZERO, "down": false, "shown": true})


func _build_buttons() -> void:
	# cụm nút phải dưới
	_add("fire", "FIRE", 1, 1, -92, -96, 46, "hold", "fire")
	_add("jump", "JUMP", 1, 1, -168, -62, 30, "hold", "jump")
	_add("aim", "AIM", 1, 1, -176, -130, 26, "hold", "aim")
	_add("crouch", "CROUCH", 1, 1, -92, -196, 26, "toggle", "crouch")
	_add("reload", "RELOAD", 1, 1, -252, -84, 26, "hold", "reload")
	_add("use", "USE", 1, 1, -244, -150, 26, "hold", "use")
	# nút bắn thứ hai bên trái, cho người thích bắn bằng ngón trái
	_add("fire2", "FIRE", 0, 1, 185, -150, 32, "hold", "fire")
	# cột chọn súng sát mép phải
	_add("w1", "1", 1, 0, -30, 104, 17, "tap", "_do_primary")
	_add("w2", "2", 1, 0, -30, 146, 17, "tap", "_do_pistol")
	_add("w3", "3", 1, 0, -30, 188, 17, "tap", "_do_knife")
	_add("wq", "Q", 1, 0, -30, 230, 17, "tap", "_do_last")
	_add("c4", "C4", 1, 0, -30, 62, 17, "tap", "_do_c4")
	# hàng nút nhỏ góc trên trái
	_add("pause", "||", 0, 0, 30, 52, 17, "tap", "_do_pause")
	_add("buy", "BUY", 0, 0, 72, 52, 17, "tap", "_do_buy")
	_add("tab", "TAB", 0, 0, 114, 52, 17, "hold", "scoreboard")
	# cột nút nhỏ bên trái
	_add("inspect", "F", 0, 0, 30, 96, 16, "hold", "inspect")
	_add("drop", "G", 0, 0, 30, 134, 16, "tap", "_do_drop")
	_add("walk", "WALK", 0, 0, 30, 172, 16, "toggle", "walk")


func _layout() -> void:
	view_size = get_viewport().get_visible_rect().size
	for b in buttons:
		b["pos"] = Vector2(view_size.x * float(b["ax"]) + float(b["ox"]), view_size.y * float(b["ay"]) + float(b["oy"]))
	dirty = true


# =====================================================================
#  TRẠNG THÁI
# =====================================================================
func _is_playing() -> bool:
	if main == null or main.hud == null:
		return false
	if main.in_menu or main.paused_menu or main.shop_open or main.settings_open:
		return false
	return main.player != null and is_instance_valid(main.player)


func _process(_delta: float) -> void:
	var now := _is_playing()
	if now != playing:
		playing = now
		# đang chơi: tắt "chạm = chuột" để chạm không bị tính là bắn / xoay. Ở menu, cửa hàng, tạm dừng thì bật lại để bấm được nút.
		Input.emulate_mouse_from_touch = not playing
		pad.visible = playing
		if not playing:
			_release_all()
		dirty = true
	if not playing:
		return
	if test_mode and Input.mouse_mode == Input.MOUSE_MODE_CAPTURED:
		Input.mouse_mode = Input.MOUSE_MODE_VISIBLE   # xem thử trên máy tính: giữ con trỏ chuột để bấm nút
	if get_viewport().get_visible_rect().size != view_size:
		_layout()
	# nút C4 chỉ hiện khi đang mang bom
	var has_c4 := bool(main.player.owned.get("c4", false))
	for b in buttons:
		if b["id"] == "c4" and bool(b["shown"]) != has_c4:
			b["shown"] = has_c4
			dirty = true
	if dirty:
		dirty = false
		pad.queue_redraw()


func _notification(what: int) -> void:
	# nút Back / vuốt Back của Android: mở tạm dừng thay vì thoát game
	if what == NOTIFICATION_WM_GO_BACK_REQUEST and active and main != null and main.hud != null:
		if main.settings_open:
			main._close_settings()
		elif main.shop_open:
			main._toggle_shop()
		elif not main.in_menu:
			main._toggle_pause()


func _release_all() -> void:
	for a in held.keys():
		Input.action_release(a)
	held.clear()
	for k in toggles.keys():
		toggles[k] = false
	for m in ["move_left", "move_right", "move_forward", "move_back"]:
		Input.action_release(m)
	stick_id = -1
	fingers.clear()
	for b in buttons:
		b["down"] = false


# =====================================================================
#  CHẠM
# =====================================================================
func _input(event: InputEvent) -> void:
	if not active or not playing:
		return
	if event is InputEventScreenTouch:
		var t := event as InputEventScreenTouch
		if t.pressed and not t.canceled:
			_touch_down(t.index, t.position)
		else:
			_touch_up(t.index)
	elif event is InputEventScreenDrag:
		var d := event as InputEventScreenDrag
		_touch_move(d.index, d.position)


func _hit_button(pos: Vector2) -> Dictionary:
	for i in range(buttons.size() - 1, -1, -1):
		var b: Dictionary = buttons[i]
		if bool(b["shown"]) and pos.distance_to(b["pos"] as Vector2) <= float(b["r"]) * REACH:
			return b
	return {}


func _touch_down(idx: int, pos: Vector2) -> void:
	var b := _hit_button(pos)
	if not b.is_empty():
		fingers[idx] = {"type": "button", "id": str(b["id"]), "last": pos}
		_press(b)
		return
	if pos.x < view_size.x * STICK_ZONE_X and stick_id == -1:
		stick_id = idx
		stick_center = Vector2(clampf(pos.x, STICK_R + 8.0, view_size.x), clampf(pos.y, 0.0, view_size.y - STICK_R - 8.0))
		stick_pos = pos
		fingers[idx] = {"type": "stick", "last": pos}
		_update_stick()
		dirty = true
		return
	fingers[idx] = {"type": "look", "last": pos}


func _touch_move(idx: int, pos: Vector2) -> void:
	if not fingers.has(idx):
		return
	var f: Dictionary = fingers[idx]
	var delta: Vector2 = pos - (f["last"] as Vector2)
	f["last"] = pos
	match str(f["type"]):
		"stick":
			stick_pos = pos
			_update_stick()
			dirty = true
		"look":
			_look(delta)
		"button":
			# vừa giữ nút bắn vừa kéo ngón tay thì vẫn xoay được camera
			if str(f["id"]) == "fire" or str(f["id"]) == "fire2":
				_look(delta)


func _touch_up(idx: int) -> void:
	if not fingers.has(idx):
		return
	var f: Dictionary = fingers[idx]
	fingers.erase(idx)
	match str(f["type"]):
		"stick":
			stick_id = -1
			for m in ["move_left", "move_right", "move_forward", "move_back"]:
				Input.action_release(m)
			dirty = true
		"button":
			for b in buttons:
				if b["id"] == f["id"]:
					_release(b)


func _press(b: Dictionary) -> void:
	b["down"] = true
	dirty = true
	var arg := str(b["arg"])
	match str(b["kind"]):
		"hold":
			held[arg] = true
			Input.action_press(arg)
		"toggle":
			toggles[arg] = not bool(toggles[arg])
			if bool(toggles[arg]):
				Input.action_press(arg)
				held[arg] = true
			else:
				Input.action_release(arg)
				held.erase(arg)
		"tap":
			call(arg)


func _release(b: Dictionary) -> void:
	b["down"] = false
	dirty = true
	if str(b["kind"]) == "hold":
		var arg := str(b["arg"])
		Input.action_release(arg)
		held.erase(arg)


func _update_stick() -> void:
	var v := (stick_pos - stick_center) / STICK_R
	if v.length() > 1.0:
		v = v.normalized()
	if v.length() < DEAD:
		v = Vector2.ZERO
	else:
		v = v.normalized() * ((v.length() - DEAD) / (1.0 - DEAD))
	_axis("move_left", "move_right", v.x)
	_axis("move_forward", "move_back", v.y)


func _axis(neg: String, pos_action: String, v: float) -> void:
	if v > 0.0:
		Input.action_press(pos_action, v)
		Input.action_release(neg)
	elif v < 0.0:
		Input.action_press(neg, -v)
		Input.action_release(pos_action)
	else:
		Input.action_release(neg)
		Input.action_release(pos_action)


func _look(delta: Vector2) -> void:
	var p = main.player
	if p != null and is_instance_valid(p) and p.has_method("touch_look"):
		p.touch_look(delta * TOUCH_SENS)


# =====================================================================
#  CÁC NÚT CHẠM MỘT LẦN
# =====================================================================
func _player():
	if main != null and main.player != null and is_instance_valid(main.player):
		return main.player
	return null


func _do_primary() -> void:
	var p = _player()
	if p != null and p.primary_id() != "":
		p.request_switch(p.primary_id())


func _do_pistol() -> void:
	var p = _player()
	if p != null:
		p.request_switch(p.pistol_id())


func _do_knife() -> void:
	var p = _player()
	if p != null:
		p.request_switch("knife")


func _do_c4() -> void:
	var p = _player()
	if p != null:
		p.request_switch("c4")


func _do_last() -> void:
	var p = _player()
	if p != null:
		p.request_switch(p.last_w)


func _do_drop() -> void:
	var p = _player()
	if p != null:
		p.drop_current()


func _do_pause() -> void:
	main._toggle_pause()


func _do_buy() -> void:
	main._toggle_shop()


# =====================================================================
#  VẼ
# =====================================================================
func _paint() -> void:
	# cần di chuyển
	var base := stick_center if stick_id != -1 else Vector2(100.0, view_size.y - 100.0)
	pad.draw_circle(base, STICK_R, Color(1, 1, 1, 0.08))
	pad.draw_arc(base, STICK_R, 0.0, TAU, 40, Color(1, 1, 1, 0.30), 2.0)
	if stick_id != -1:
		var off := stick_pos - stick_center
		if off.length() > STICK_R:
			off = off.normalized() * STICK_R
		pad.draw_circle(stick_center + off, 22.0, Color(1, 1, 1, 0.32))
	# các nút
	for b in buttons:
		if not bool(b["shown"]):
			continue
		var pos: Vector2 = b["pos"]
		var r := float(b["r"])
		var on := bool(b["down"])
		var fill := Color(0.08, 0.09, 0.12, 0.40)
		if str(b["kind"]) == "toggle" and bool(toggles[str(b["arg"])]):
			fill = Color(1.0, 0.75, 0.15, 0.55)
		elif on:
			fill = Color(1, 1, 1, 0.50)
		pad.draw_circle(pos, r, fill)
		pad.draw_arc(pos, r, 0.0, TAU, 32, Color(1, 1, 1, 0.45), 1.5)
		var txt := str(b["label"])
		var fs := 13
		var w := font.get_string_size(txt, HORIZONTAL_ALIGNMENT_LEFT, -1, fs).x
		while w > r * 1.7 and fs > 6:
			fs -= 1
			w = font.get_string_size(txt, HORIZONTAL_ALIGNMENT_LEFT, -1, fs).x
		pad.draw_string(font, Vector2(pos.x - w * 0.5, pos.y + fs * 0.35), txt, HORIZONTAL_ALIGNMENT_LEFT, -1, fs, Color(1, 1, 1, 0.9))
