extends RefCounted
## TAY CHUNG CHO MỌI VŨ KHÍ (không dùng class_name; nạp bằng: const Hands := preload("res://scripts/hands.gd")).
## Quy tắc: mọi viewmodel dùng CÙNG màu tay xanh quân đội (Hands.material()) và CÙNG kiểu cánh tay (Hands.Arm).
##  - Bàn tay: khối hộp chữ nhật, không ngón (Hands.add_hand).
##  - Cánh tay: khối hộp thẳng, độ dài cố định, chui lên từ mép DƯỚI màn hình (Hands.Arm + Hands.arm_dir).
## Khi thêm súng mới: dùng đúng 3 thứ này, đừng tự tạo màu da / tay áo riêng.

const GREEN := Color(0.21, 0.25, 0.17)

## BÀN TAY THẬT (lấy từ pack "M4 FPS weapon animations"): hai file .glb đã nướng sẵn tư thế cầm súng.
## Gốc của mô hình = cổ tay, cẳng tay kéo dài về phía khuỷu theo hướng AXIS_* (hệ trục của súng trong game).
## Không nạp được file -> tự quay về tay khối hộp cũ.
const HAND_PATH_R := "res://assets/hands/hand_r.glb"
const HAND_PATH_L := "res://assets/hands/hand_l.glb"
const AXIS_R := Vector3(0.29081, -0.39541, 0.87125)
const AXIS_L := Vector3(-0.50421, -0.58800, 0.63248)
## Tâm vòng ôm của bốn ngón (điểm mà báng súng / cán dao / ốp tay xuyên qua) và hướng "trục báng" (từ ngón trỏ xuống ngón út), tính trong hệ mô hình (gốc = cổ tay).
const GM_R := Vector3(-0.035, -0.017, -0.145)
const YM_R := Vector3(0.163, -0.920, 0.358)
const GM_L := Vector3(0.075, 0.038, -0.110)
const HAND_SCALE := 0.9    # thu nhỏ bàn tay một chút cho vừa các khẩu súng của game
## Chỉ dùng cho súng MỚI chưa gọi attach(): đặt bàn tay theo điểm cổ tay + hướng khuỷu mà súng truyền vào update().
const HAND_BACK := 0.045
const HAND_SHIFT := Vector3(0.0, 0.045, 0.02)
const SKIN := Color(0.83, 0.60, 0.51)   # màu da cho đoạn cẳng tay kéo dài xuống mép màn hình

static var _mat: StandardMaterial3D
static var _skin_mat: StandardMaterial3D


## Vật liệu tay dùng chung (một màu xanh quân đội, không vân).
static func material() -> StandardMaterial3D:
	if _mat == null:
		_mat = StandardMaterial3D.new()
		_mat.albedo_color = GREEN
		_mat.roughness = 0.95
		_mat.metallic = 0.0
	return _mat


## Màu da cho đoạn cẳng tay kéo dài (nối tiếp cẳng tay của mô hình thật).
static func skin_material() -> StandardMaterial3D:
	if _skin_mat == null:
		_skin_mat = StandardMaterial3D.new()
		_skin_mat.albedo_color = SKIN
		_skin_mat.roughness = 0.9
	return _skin_mat


## Dựng một bàn tay thật (left = true: tay trái). Trả về null nếu không nạp được file -> dùng tay khối hộp.
static func load_hand(left: bool) -> Node3D:
	var path := HAND_PATH_L if left else HAND_PATH_R
	if not ResourceLoader.exists(path):
		return null
	var ps = load(path)
	if not (ps is PackedScene):
		return null
	var n = (ps as PackedScene).instantiate()
	if not (n is Node3D):
		return null
	var root := n as Node3D
	var list: Array = root.find_children("*", "MeshInstance3D", true, false)
	if root is MeshInstance3D:
		list.append(root)
	for c in list:
		(c as MeshInstance3D).cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	return root


## Ẩn mọi khối hộp tay cũ (dùng vật liệu tay chung) dưới root, trừ các node trong keep.
static func hide_boxes(root: Node, keep: Array) -> void:
	var m := material()
	for c in root.find_children("*", "MeshInstance3D", true, false):
		var mi := c as MeshInstance3D
		if mi != null and not keep.has(mi) and mi.material_override == m:
			mi.visible = false


## Thêm một bàn tay (một khối hộp) vào node cha. size = (rộng X, cao Y, dài Z), offset = lệch so với gốc node.
static func add_hand(parent: Node3D, size: Vector3, offset: Vector3 = Vector3.ZERO) -> MeshInstance3D:
	var bm := BoxMesh.new()
	bm.size = size
	var mi := MeshInstance3D.new()
	mi.mesh = bm
	mi.material_override = material()
	mi.position = offset
	mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	parent.add_child(mi)
	return mi


## Hướng cánh tay (trong hệ của rig): từ cổ tay về phía khuỷu tay, nhưng LUÔN chúc xuống dưới màn hình
## (so với camera) để tay chui lên từ mép dưới, không bao giờ vắt lên che trước mặt khi súng nghiêng.
static func arm_dir(rig_basis: Basis, wrist: Vector3, elbow: Vector3) -> Vector3:
	var v: Vector3 = rig_basis * (elbow - wrist)
	if v.length() < 0.001:
		v = Vector3(-0.3, -1.0, 0.4)
	v = v.normalized()
	if v.y > -0.6:
		var h := Vector3(v.x, 0.0, v.z)
		if h.length() < 0.001:
			h = Vector3(-0.4, 0.0, 0.9)
		h = h.normalized() * 0.8
		v = Vector3(h.x, -0.6, h.z)
	return rig_basis.inverse() * v.normalized()


## Cánh tay: khối hộp thẳng, ĐỘ DÀI CỐ ĐỊNH, bắt đầu từ cổ tay và kéo dài xuống ngoài khung hình.
## Chỉ xoay, không co giãn nên không bị méo.
class Arm:
	extends RefCounted
	var box: MeshInstance3D          # tay khối cũ (khi không có mô hình thật) hoặc đoạn cẳng tay nối dài (có mô hình thật)
	var hand: Node3D = null          # bàn tay + cẳng tay thật (null = dùng tay khối)
	var cur_dir := Vector3(-0.4, -0.45, 0.8).normalized()
	var _parent: Node3D
	var _axis := Vector3.BACK        # hướng cẳng tay (từ cổ tay về khuỷu) trong hệ mô hình
	var _boxes_hidden := false
	var _attached := false
	var extra := Vector3.ZERO        # dịch thêm (hệ của node tay) khi tay đang ở chỗ nghỉ, nhân với rest_k
	var rest_k := 1.0                # 1 = tay đang ở chỗ nghỉ (ốp tay), 0 = tay đang đi làm việc khác (nạp đạn...)
	var _base_pos := Vector3.ZERO
	var _b0 := Basis.IDENTITY
	var _gm := Vector3.ZERO
	var _grip := Vector3.ZERO
	var ch_yaw := 0.0                # xoay bàn tay quanh trục đứng (rad) khi nắm cần gạt, nhân với ch_k
	var mag_extra := Vector3.ZERO    # dịch thêm khi tay đang cầm băng đạn (tâm băng đạn so với gốc node tay)
	var mag_target := 0.0            # 1 = đang cầm băng đạn
	var mag_k := 0.0
	var ch_extra := Vector3.ZERO     # dịch thêm khi tay nắm cần gạt kéo thượng đạn (nhéo núm cần gạt giữa ngón cái và ngón trỏ)
	var ch_k := 0.0                  # 0..1, do súng đặt mỗi khung hình
	var freeze_node: Node3D = null   # nút "gun" (cha của tay): khi freeze_k > 0 bàn tay KHÔNG đi theo chuyển động của nút này (vd. xoay súng lúc rút súng)
	var freeze_k := 0.0              # 0..1, do súng đặt mỗi khung hình

	func _init(parent: Node3D, is_left: bool = false) -> void:
		var H = load("res://scripts/hands.gd")
		_parent = parent
		hand = H.load_hand(is_left)
		var bm := BoxMesh.new()
		var cyl: CylinderMesh = null
		box = MeshInstance3D.new()
		if hand != null:
			_axis = H.AXIS_L if is_left else H.AXIS_R
			bm.size = Vector3(0.09, 0.6, 0.09)
			box.material_override = H.skin_material()
			# đoạn cẳng tay nối dài: hình trụ TRÒN (không còn khối hộp vuông), hơi thon về phía cổ tay
			cyl = CylinderMesh.new()
			cyl.top_radius = 0.038
			cyl.bottom_radius = 0.046
			cyl.height = 0.6
			cyl.radial_segments = 14
			cyl.rings = 1
			parent.add_child(hand)
		else:
			bm.size = Vector3(0.046, 1.0, 0.046)
			box.material_override = H.material()
		if cyl != null:
			box.mesh = cyl
		else:
			box.mesh = bm
		box.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		parent.add_child(box)

	## Gắn bàn tay vào một node của súng (node đó cử động thế nào, bàn tay đi theo thế ấy).
	## node: node tay của súng. rest: xoay của node đó so với thân súng lúc nghỉ.
	## grip_local: tâm báng / ốp tay / cán dao trong hệ của node. axis_local: trục báng chiều "xuống" trong hệ của node.
	## roll_deg: xoay thêm quanh trục báng. mode: 0 = tay phải cầm báng, 1 = tay trái đỡ ốp tay (giữ nguyên tư thế gốc),
	## 2 = tay trái cầm báng súng ngắn (dùng bàn tay phải lật đối xứng).
	func attach(node: Node3D, rest: Basis, grip_local: Vector3, axis_local: Vector3, roll_deg: float, mode: int, rest_extra: Vector3 = Vector3.ZERO) -> void:
		if hand == null or node == null:
			return
		var H = load("res://scripts/hands.gd")
		var s: float = H.HAND_SCALE
		var gm: Vector3 = H.GM_R
		var ym: Vector3 = H.YM_R
		var mir := 1.0
		if mode == 2:
			if hand.get_parent() != null:
				hand.get_parent().remove_child(hand)
			hand.queue_free()
			hand = H.load_hand(false)
			_axis = H.AXIS_R
			mir = -1.0
			ym = Vector3(-ym.x, ym.y, ym.z)
		elif mode == 1:
			gm = H.GM_L
		var q := Quaternion.IDENTITY
		if mode != 1:
			var g_dir: Vector3 = (rest * axis_local).normalized()
			q = Quaternion(ym.normalized(), g_dir)
			if absf(roll_deg) > 0.01:
				q = Quaternion(g_dir, deg_to_rad(roll_deg)) * q
		var b: Basis = rest.inverse() * Basis(q) * Basis.from_scale(Vector3(mir * s, s, s))
		var org: Vector3 = grip_local - b * gm
		if hand.get_parent() != null:
			hand.get_parent().remove_child(hand)
		node.add_child(hand)
		hand.transform = Transform3D(b, org)
		_base_pos = org
		_b0 = b
		_gm = gm
		_grip = grip_local
		extra = rest_extra
		_attached = true

	## Hiện / ẩn cả cánh tay (dùng cho súng cầm một tay: tay trái chỉ hiện khi nạp đạn).
	func set_shown(v: bool) -> void:
		box.visible = v
		if hand != null:
			hand.visible = v

	## Đoạn cẳng tay nối dài từ đầu cẳng tay của mô hình xuống mép dưới màn hình (không còn dùng wrist / elbow của súng).
	func update_tail(delta: float = 0.016) -> void:
		if hand == null or not _attached or not hand.is_inside_tree():
			return
		var H = load("res://scripts/hands.gd")
		if not _boxes_hidden:
			_boxes_hidden = true
			H.hide_boxes(_parent, [box])   # tay khối hộp của từng súng không còn cần nữa
		mag_k = lerpf(mag_k, mag_target, 1.0 - exp(-14.0 * delta))
		var ck := clampf(ch_k, 0.0, 1.0)
		var bb: Basis = _b0
		if absf(ch_yaw) > 0.0001 and ck > 0.0:
			bb = Basis(Vector3.UP, ch_yaw * ck) * _b0
		var center: Vector3 = _grip + extra * clampf(rest_k, 0.0, 1.0) + mag_extra * mag_k + ch_extra * ck
		hand.transform = Transform3D(bb, center - bb * _gm)
		if freeze_node != null and freeze_k > 0.0 and freeze_node.is_inside_tree() and freeze_node.get_parent() is Node3D:
			# giữ bàn tay đứng yên như thể nút gun đang ở tư thế nghỉ (chỉ súng xoay, tay không xoay theo)
			var pg: Transform3D = (freeze_node.get_parent() as Node3D).global_transform
			var comp: Transform3D = pg * freeze_node.transform.affine_inverse() * pg.affine_inverse() * hand.global_transform
			if freeze_k >= 0.999:
				hand.global_transform = comp
			else:
				hand.global_transform = hand.global_transform.interpolate_with(comp, freeze_k)
		var t: Transform3D = _parent.global_transform.affine_inverse() * hand.global_transform
		var dir: Vector3 = (t.basis * _axis).normalized()
		var tail: Vector3 = t * (_axis * 0.29)
		box.transform = Transform3D(Basis(Quaternion(Vector3.UP, dir)), tail + dir * 0.30)

	## wrist: cổ tay (hệ rig). elbow: khuỷu tay (hệ rig). rig_basis: rig.basis.
	func update(rig_basis: Basis, wrist: Vector3, elbow: Vector3, delta: float) -> void:
		if hand != null and _attached:
			update_tail(delta)
			return
		var H = load("res://scripts/hands.gd")
		var dir: Vector3 = H.arm_dir(rig_basis, wrist, elbow)
		cur_dir = cur_dir.slerp(dir, 1.0 - exp(-22.0 * delta)).normalized()
		var d := cur_dir
		if hand != null:
			# SÚNG MỚI chưa gọi attach(): vẫn dùng bàn tay thật, đặt tạm theo cổ tay / khuỷu của súng (và ẩn tay khối hộp)
			if not _boxes_hidden:
				_boxes_hidden = true
				H.hide_boxes(_parent, [box])
			var org: Vector3 = wrist + d * H.HAND_BACK + H.HAND_SHIFT
			hand.transform = Transform3D(Basis(Quaternion(_axis, d)) * Basis.from_scale(Vector3.ONE * H.HAND_SCALE), org)
			var tl: Vector3 = org + d * (0.29 * H.HAND_SCALE)
			box.transform = Transform3D(Basis(Quaternion(Vector3.UP, d)), tl + d * 0.30)
			return
		var b := Basis(Quaternion(Vector3.UP, d))
		var start := wrist - d * 0.012
		box.transform = Transform3D(b * Basis.from_scale(Vector3(1.0, 0.8, 1.0)), start + d * 0.4)
