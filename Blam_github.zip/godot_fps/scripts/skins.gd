extends RefCounted
## Skin nhân vật: cửa hàng (mua), bộ sưu tập (chọn dùng) và nơi lưu lựa chọn.
## Mỗi skin chỉ dành cho MỘT phe (team 0 = CT, 1 = T). Skin mặc định của CT là Yuri, của T là Terror (xem terror_rig.gd).
## Mỗi phe có skin đang dùng + phạm vi dùng (cả phe / riêng mình) riêng.
## Muốn thêm skin: thêm một mục vào DATA (rig = tên trong terror_rig.gd CONFIGS), nhớ có ảnh icon.

const SAVE_PATH := "user://skins.cfg"
const DEFAULT_CT := "yuri"
const DEFAULT_T := "terror"
const DEFAULT_RIG := ["yuri", "terror"]           # rig mặc định theo phe [CT, T]
const DEFAULT_NAME := ["YURI", "TERROR"]

const DATA := {
	"miho": {
		"name": "MIDNIGHT MIHO",
		"desc": "Skin riêng phe CT. Váy xanh đen, tóc hai bím.",
		"team": 0,
		"price": 0,                      # 0 = miễn phí (bản thử); sau này đặt giá thật ở đây
		"icon": "res://assets/miho/miho_icon.png",
		"rig": "miho",
	},
	"abia": {
		"name": "ABIA",
		"desc": "Skin riêng phe CT. Áo khoác trắng, tóc hồng ngắn, kính cam.",
		"team": 0,
		"price": 0,                      # 0 = miễn phí (bản thử); sau này đặt giá thật ở đây
		"icon": "res://assets/abia/abia_icon.png",
		"rig": "abia",
	},
	"neko_gign": {
		"name": "NEKO TÓC NÂU",
		"desc": "Skin riêng phe CT. Nekopara: hầu gái mèo tóc nâu hai búi, đuôi vằn.",
		"team": 0,
		"price": 0,                      # 0 = miễn phí (bản thử); sau này đặt giá thật ở đây
		"icon": "res://assets/neko_gign/neko_gign_icon.png",
		"rig": "neko_gign",
	},
	"neko_gsg9": {
		"name": "NEKO TÓC TRẮNG",
		"desc": "Skin riêng phe CT. Nekopara: hầu gái mèo tóc trắng dài, đuôi trắng xù.",
		"team": 0,
		"price": 0,                      # 0 = miễn phí (bản thử); sau này đặt giá thật ở đây
		"icon": "res://assets/neko_gsg9/neko_gsg9_icon.png",
		"rig": "neko_gsg9",
	},
	"kratos": {
		"name": "KRATOS",
		"desc": "Skin riêng phe T. Chiến thần Kratos: râu đen, sẹo đỏ, giáp da.",
		"team": 1,
		"price": 0,                      # 0 = miễn phí (bản thử); sau này đặt giá thật ở đây
		"icon": "res://assets/kratos/kratos_icon.png",
		"rig": "kratos",
	},
}
const ORDER := ["miho", "abia", "neko_gign", "neko_gsg9", "kratos"]

# phạm vi dùng skin
const SCOPE_TEAM := "team"      # cả phe: người chơi + bot CT
const SCOPE_SELF := "self"      # chỉ riêng người chơi

var owned: Array = []            # id các skin đã mua
var equipped_by: Array = ["", ""]                  # skin đang dùng theo phe [CT, T] ("" = mặc định)
var scope_by: Array = [SCOPE_TEAM, SCOPE_TEAM]     # phạm vi dùng theo phe [CT, T]


func load_state() -> void:
	var cfg := ConfigFile.new()
	if cfg.load(SAVE_PATH) != OK:
		return
	owned.clear()
	for id in cfg.get_value("skins", "owned", []):
		if DATA.has(str(id)):
			owned.append(str(id))
	var keys := [["equipped", "scope"], ["equipped_t", "scope_t"]]
	for t in 2:
		var e := str(cfg.get_value("skins", keys[t][0], ""))
		if not owned.has(e) or int((DATA[e] as Dictionary)["team"]) != t:
			e = ""
		equipped_by[t] = e
		var sc := str(cfg.get_value("skins", keys[t][1], SCOPE_TEAM))
		scope_by[t] = SCOPE_SELF if sc == SCOPE_SELF else SCOPE_TEAM


func save_state() -> void:
	var cfg := ConfigFile.new()
	cfg.set_value("skins", "owned", owned)
	cfg.set_value("skins", "equipped", equipped_by[0])
	cfg.set_value("skins", "scope", scope_by[0])
	cfg.set_value("skins", "equipped_t", equipped_by[1])
	cfg.set_value("skins", "scope_t", scope_by[1])
	cfg.save(SAVE_PATH)


func has_skin(id: String) -> bool:
	return owned.has(id)


func price_of(id: String) -> int:
	return int((DATA[id] as Dictionary)["price"])


func team_of(id: String) -> int:
	return int((DATA[id] as Dictionary)["team"])


## Mua (hiện miễn phí). Trả về true nếu thành công hoặc đã có sẵn.
func buy(id: String) -> bool:
	if not DATA.has(id):
		return false
	if not owned.has(id):
		owned.append(id)
		save_state()
	return true


## Skin này đang được dùng?
func is_on(id: String) -> bool:
	return DATA.has(id) and str(equipped_by[team_of(id)]) == id


## Phạm vi đang dùng của phe (SCOPE_TEAM / SCOPE_SELF).
func scope_of_team(team: int) -> String:
	return str(scope_by[team])


## Dùng skin: scope_new = SCOPE_TEAM hoặc SCOPE_SELF. Áp dụng cho phe của skin đó.
func equip(id: String, scope_new: String) -> void:
	if not owned.has(id):
		return
	var t := team_of(id)
	equipped_by[t] = id
	scope_by[t] = scope_new
	save_state()


## Gỡ skin của một phe: về skin mặc định (CT = Yuri, T = Terror).
func unequip(team: int) -> void:
	equipped_by[team] = ""
	save_state()


## Model (rig trong terror_rig.gd) của BOT thuộc phe `team`: skin chỉ đổi cho bot khi chọn "cả phe".
func model_for_bot(team: int) -> String:
	var e := str(equipped_by[team])
	if e != "" and str(scope_by[team]) == SCOPE_TEAM:
		return str((DATA[e] as Dictionary)["rig"])
	return str(DEFAULT_RIG[team])


## Model thân người chơi khi chơi phe `team` (chọn "cả phe" hay "riêng mình" đều dùng).
func model_for_player(team: int) -> String:
	var e := str(equipped_by[team])
	if e != "":
		return str((DATA[e] as Dictionary)["rig"])
	return str(DEFAULT_RIG[team])


## Dòng trạng thái ngắn cho thẻ trong bộ sưu tập.
func status_of(id: String) -> String:
	if is_on(id):
		return "ĐANG DÙNG · CẢ PHE" if str(scope_by[team_of(id)]) == SCOPE_TEAM else "ĐANG DÙNG · RIÊNG MÌNH"
	return ""
