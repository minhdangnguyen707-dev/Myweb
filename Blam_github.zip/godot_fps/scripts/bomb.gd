extends Node
## Chế độ ĐẶT BOM kiểu CS:GO / CS2 (3 đấu 3 với bot, vì bản đồ nhỏ):
##  - Chọn phe CT (gỡ bom) hoặc T (đặt bom). Chết là chờ round sau mới hồi sinh.
##  - Mỗi round: 15 giây chuẩn bị (mua đồ, đứng yên) -> 1:55 giao tranh -> bom nổ sau 40 giây kể từ lúc đặt.
##  - Đặt bom 3.2 giây (giữ E trong vùng điểm A/B khi đang cầm bom), gỡ bom 10 giây (giữ E sát quả bom).
##  - T thắng: bom nổ hoặc hạ hết CT. CT thắng: gỡ xong bom, hạ hết T khi bom chưa đặt, hoặc hết giờ mà chưa đặt bom.
##  - Thắng 13 round là thắng trận (MR12). Hết round 12 thì đổi phe, tiền về $800 và mất hết súng.
##  - Tiền: thắng $3250, thua $1400 (+$500 mỗi round thua liên tiếp, tối đa $3400), hạ địch $300
##    (SMG $600, dao $1500), đặt/gỡ bom +$300, T thua nhưng đã đặt bom +$800. Tối đa $16000.
## Script này gắn vào main.gd khi chọn chế độ ĐẶT BOM. Mọi con số chỉnh được ở các hằng ngay bên dưới.

const FREEZE_TIME := 15.0
const ROUND_TIME := 115.0
const BOMB_TIME := 40.0
const PLANT_TIME := 3.2
const DEFUSE_TIME := 10.0
const END_TIME := 5.0
const OVER_TIME := 9.0
const WIN_ROUNDS := 13
const HALF_ROUNDS := 12
const START_MONEY := 800
const MAX_MONEY := 16000
const WIN_BONUS := 3250
const LOSS_BASE := 1400
const LOSS_STEP := 500
const PLANT_BONUS := 300
const DEFUSE_BONUS := 300
const PLANTED_LOSS_BONUS := 800
const SITE_R := 3.5          # bán kính vùng đặt bom (mét)
const BLAST_R := 20.0        # bán kính vụ nổ (mét)
const BOT_SPEED := 3.4       # tốc độ đi của bot khi làm nhiệm vụ (bằng SPEED_PATROL trong bot.gd)
const T_WAIT := 26.0         # người mang bom (bot) chờ đồng đội tụ lại ở điểm tập kết rồi mới cùng xông vào đặt (giây)
const THINK_MIN := 2.5       # vừa hết giờ chuẩn bị: bot đứng lại "suy nghĩ chiến thuật" ít nhất bấy nhiêu giây
const THINK_MAX := 5.0
const STAGE_MIN := 10.0      # điểm tập kết của T cách điểm bom bấy nhiêu mét (phía mình)
const STAGE_MAX := 17.0
const HOLD_MIN := 6.0        # CT trấn giữ cách điểm bom bấy nhiêu mét
const HOLD_MAX := 13.0
const INTEL_LIFE := 14.0     # tin báo thấy địch còn giá trị trong bấy nhiêu giây
# vị trí hai điểm đặt bom (x, z); game tự dịch tới chỗ đi được gần nhất trên navmesh. Muốn đổi chỗ thì sửa 2 số này.

enum S { FREEZE, LIVE, PLANTED, END, OVER }

var main = null
var active := false
var state: int = S.FREEZE
var t := 0.0
var round_no := 0
var wins := [0, 0]            # số round thắng của phe [CT, T] (đổi chỗ cho nhau khi đổi phe)
var streak := [0, 0]          # số round thua liên tiếp của phe [CT, T] (tính tiền thưởng khi thua)
var first_side := 0
var player_side := 0
var reset_all := true         # round này mọi người về tay không + $800 (đầu trận / sau khi đổi phe)
var sites: Array = []
var site_nodes: Array = []
var bomb_state := "none"      # none | carried | dropped | planted
var busy_prompt := ""         # dòng nhắc của việc đặt / gỡ bom (pickups.gd thấy rỗng mới cho nhặt súng bằng phím E)
var c4_ignore_until := 0      # sau khi người chơi vứt bom (G): chưa nhặt lại ngay trong thời gian này (ms)
var carrier = null
var bomb_pos := Vector3.ZERO
var bomb_node: Node3D
var bomb_led: MeshInstance3D
var led_t := 0.0
var site_planted := -1
var exec_site := 0
var round_elapsed := 0.0
var plant_prog := 0.0
var defuse_prog := 0.0
var bot_prog := {}
var intel_pos := Vector3.ZERO     # chỗ gần nhất một bot CT vừa thấy địch (CT báo cho nhau)
var intel_t := -99.0
var rotated := 0                   # số CT đã chạy sang điểm bom kia trong round này
var stage_pts: Array = [Vector3.ZERO, Vector3.ZERO]   # điểm tập kết của T cho mỗi điểm bom
var hold_pts: Array = [[], []]                        # các vị trí CT trấn giữ quanh mỗi điểm bom
var exec_time := 26.0                                 # giây T đợi rồi mới cùng xông vào điểm bom (mỗi round một khác, thỉnh thoảng rush)
var pp_pts: Array = []                                # sau khi bom đặt: các chỗ nhìn thấy quả bom để canh / yểm trợ
var beep_t := 0.0
var blink := 0.0
var boom: MeshInstance3D
var boom_mat: StandardMaterial3D
var boom_t := -1.0
var hud_text := ""


# =====================================================================
#  BẮT ĐẦU TRẬN
# =====================================================================
func start_match(side: int) -> void:
	first_side = side
	player_side = side
	active = true
	wins = [0, 0]
	streak = [0, 0]
	round_no = 0
	reset_all = true
	_build_sites()
	_build_positions()
	_build_bomb_node()
	main.player.team = player_side
	main._rebuild_bots(player_side)
	for n in get_tree().get_nodes_in_group("combatants"):
		n.kills = 0
		n.deaths = 0
	_start_round()


func _build_sites() -> void:
	for n in site_nodes:
		if is_instance_valid(n):
			(n as Node).queue_free()
	site_nodes.clear()
	sites.clear()
	for i in 2:
		var w: Vector2 = main.site_want[i]
		sites.append(_ground_point(w))
	# map lạ làm hai điểm dính vào nhau: đẩy điểm B sang phía đối diện
	if Vector2(sites[0].x - sites[1].x, sites[0].z - sites[1].z).length() < 6.0:
		sites[1] = _ground_point(Vector2(-main.site_want[0].x, -main.site_want[0].y))
	for i in 2:
		var root := Node3D.new()
		root.position = sites[i]
		main.world.add_child(root)
		var col := Color(1.0, 0.62, 0.15)
		# mặt đất: đĩa mờ + viền sáng
		var disc := MeshInstance3D.new()
		var cm := CylinderMesh.new()
		cm.top_radius = SITE_R
		cm.bottom_radius = SITE_R
		cm.height = 0.02
		cm.radial_segments = 40
		cm.rings = 1
		disc.mesh = cm
		disc.material_override = _site_mat(Color(col.r, col.g, col.b, 0.16))
		disc.position.y = 0.06
		disc.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		root.add_child(disc)
		var ring := MeshInstance3D.new()
		var tm := TorusMesh.new()
		tm.outer_radius = SITE_R
		tm.inner_radius = SITE_R - 0.14
		tm.rings = 40
		tm.ring_segments = 3
		ring.mesh = tm
		ring.material_override = _site_mat(Color(col.r, col.g, col.b, 0.95))
		ring.scale = Vector3(1.0, 0.05, 1.0)
		ring.position.y = 0.09
		ring.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		root.add_child(ring)
		# chữ A / B to ngay giữa sàn + chữ nổi trên không
		var letter := "A" if i == 0 else "B"
		var fl := Label3D.new()
		fl.text = letter
		fl.font_size = 128
		fl.pixel_size = 0.02
		fl.outline_size = 0
		fl.modulate = Color(col.r, col.g, col.b, 0.55)
		fl.rotation_degrees = Vector3(-90.0, 0.0, 0.0)
		fl.position.y = 0.1
		root.add_child(fl)
		var lb := Label3D.new()
		lb.text = letter
		lb.billboard = BaseMaterial3D.BILLBOARD_ENABLED
		lb.font_size = 96
		lb.pixel_size = 0.02
		lb.outline_size = 14
		lb.modulate = col
		lb.no_depth_test = true
		lb.position.y = 5.0
		root.add_child(lb)
		# cột sáng cao để từ xa cũng thấy điểm bom nằm ở đâu
		var beam := MeshInstance3D.new()
		var bcm := CylinderMesh.new()
		bcm.top_radius = 0.18
		bcm.bottom_radius = 0.18
		bcm.height = 26.0
		bcm.radial_segments = 8
		bcm.rings = 1
		beam.mesh = bcm
		beam.material_override = _site_mat(Color(col.r, col.g, col.b, 0.28))
		beam.position.y = 13.0
		beam.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		root.add_child(beam)
		site_nodes.append(root)


## Điểm đi được trên MẶT ĐẤT (không phải nóc thùng / bệ cao) gần vị trí mong muốn nhất, và PHẢI đi tới được từ cả hai chỗ xuất phát.
func _ground_point(want: Vector2) -> Vector3:
	var cand: Array = []
	for w in main.waypoints:
		if w.y < main.site_ymax:
			cand.append(w)
	cand.sort_custom(func(a, b): return Vector2(a.x - want.x, a.z - want.y).length() < Vector2(b.x - want.x, b.z - want.y).length())
	for w in cand:
		if _site_reachable(w):
			return w
	var best := Vector3(want.x, 0.0, want.y)
	if main.nav_ok:
		best = NavigationServer3D.map_get_closest_point(main.nav_map, Vector3(want.x, 0.0, want.y))
	elif not cand.is_empty():
		best = cand[0]
	return best


func _site_reachable(p: Vector3) -> bool:
	if not main.nav_ok:
		return true
	for team in 2:
		var l: Array = main.spawns[team]
		if l.is_empty():
			continue
		var path := NavigationServer3D.map_get_path(main.nav_map, l[0], p, true)
		if path.size() < 2 or (path[path.size() - 1] as Vector3).distance_to(p) > 1.5:
			return false
	return true


## Tính điểm tập kết của T và các chỗ CT trấn giữ cho mỗi điểm bom (dựa trên điểm tuần tra có sẵn trên navmesh).
func _build_positions() -> void:
	var tc := Vector3.ZERO
	var cc := Vector3.ZERO
	var tl: Array = main.spawns[1]
	var cl: Array = main.spawns[0]
	for v in tl:
		tc += v
	for v in cl:
		cc += v
	if not tl.is_empty():
		tc /= float(tl.size())
	if not cl.is_empty():
		cc /= float(cl.size())
	for i in 2:
		var sp: Vector3 = sites[i]
		var best: Vector3 = sp
		var bd := 1.0e9
		var holds: Array = []
		for w in main.waypoints:
			if w.y > main.site_ymax:
				continue
			var d := _flat(w, sp)
			if d >= STAGE_MIN and d <= STAGE_MAX:
				var dt := _flat(w, tc)
				if dt < bd:
					bd = dt
					best = w
			if d >= HOLD_MIN and d <= HOLD_MAX:
				holds.append(w)
		stage_pts[i] = best
		holds.sort_custom(func(a, b): return _flat(a, cc) < _flat(b, cc))
		hold_pts[i] = holds


func _site_mat(c: Color) -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	m.albedo_color = c
	return m


func _build_bomb_node() -> void:
	if bomb_node != null and is_instance_valid(bomb_node):
		return
	bomb_node = Node3D.new()
	bomb_node.visible = false
	main.world.add_child(bomb_node)
	var body := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = Vector3(0.34, 0.12, 0.22)
	body.mesh = bm
	var mat := StandardMaterial3D.new()
	mat.albedo_color = Color(0.16, 0.18, 0.12)
	mat.roughness = 0.8
	body.material_override = mat
	body.position.y = 0.06
	bomb_node.add_child(body)
	bomb_led = MeshInstance3D.new()
	var sm := SphereMesh.new()
	sm.radius = 0.028
	sm.height = 0.056
	bomb_led.mesh = sm
	var lm := StandardMaterial3D.new()
	lm.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	lm.albedo_color = Color(1.0, 0.1, 0.05)
	bomb_led.material_override = lm
	bomb_led.position = Vector3(0.10, 0.14, 0.0)
	bomb_node.add_child(bomb_led)
	# quả cầu lửa khi nổ
	boom = MeshInstance3D.new()
	var bs := SphereMesh.new()
	bs.radius = 1.0
	bs.height = 2.0
	bs.radial_segments = 16
	bs.rings = 8
	boom.mesh = bs
	boom_mat = StandardMaterial3D.new()
	boom_mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	boom_mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	boom_mat.albedo_color = Color(1.0, 0.6, 0.15, 0.8)
	boom.material_override = boom_mat
	boom.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	boom.visible = false
	main.world.add_child(boom)


# =====================================================================
#  ROUND
# =====================================================================
func _shuffled_spawns(team: int) -> Array:
	var l: Array = (main.spawns[team] as Array).duplicate()
	l.shuffle()
	return l


func _start_round() -> void:
	round_no += 1
	state = S.FREEZE
	t = FREEZE_TIME
	round_elapsed = 0.0
	bomb_state = "none"
	carrier = null
	site_planted = -1
	plant_prog = 0.0
	defuse_prog = 0.0
	bot_prog.clear()
	if bomb_node != null:
		bomb_node.visible = false
	main.round_frozen = true
	main.player_locked = false
	busy_prompt = ""
	c4_ignore_until = 0
	if main.pickups != null:
		main.pickups.clear_all()   # sang round mới: súng vứt dưới đất ở round trước biến mất
	var p: Player = main.player
	if reset_all:
		main.money = START_MONEY
	var full_reset := reset_all
	var lose_guns := reset_all or not p.alive   # chết là mất hết súng
	reset_all = false
	main.hud.set_money(main.money)

	# mọi người hồi sinh ở khu xuất phát của phe mình
	var lists := [_shuffled_spawns(0), _shuffled_spawns(1)]
	var idx := [0, 0]
	var ts: Array = []
	var cts: Array = []
	var h_info := false
	for n in get_tree().get_nodes_in_group("combatants"):
		var tm := int(n.team)
		var list: Array = lists[tm]
		var pos: Vector3 = list[int(idx[tm]) % list.size()]
		idx[tm] = int(idx[tm]) + 1
		if n == p:
			var dir := Vector3(-pos.x, 0.0, -pos.z).normalized()
			p.respawn(pos, atan2(-dir.x, -dir.z))
			if lose_guns:
				p.reset_loadout()   # sau khi hồi sinh (đang sống) để đổi súng được
			p.owned["c4"] = false
			if p.cur_w == "c4":
				p.switch_weapon(p.last_w if bool(p.owned.get(p.last_w, false)) else p.pistol_id())
		else:
			var lost: bool = full_reset or not n.alive   # bot chết hoặc đầu trận: mất súng, về súng lục
			n.respawn(pos)
			n.round_start(full_reset, lost)   # bot mua súng theo số tiền của mình
		if tm == 1:
			ts.append(n)
		else:
			cts.append(n)

	# phân vai cho bot: T cùng đi một điểm (đa số), CT chia đều hai điểm
	intel_t = -99.0
	rotated = 0
	for n in get_tree().get_nodes_in_group("combatants"):
		n.set_meta("think", randf_range(THINK_MIN, THINK_MAX))   # hết giờ chuẩn bị: đứng lại nghĩ chiến thuật chừng này giây
		n.set_meta("rotated", false)
		n.set_meta("spot", -1)
	exec_site = randi() % 2
	exec_time = 4.0 if randf() < 0.22 else randf_range(14.0, T_WAIT)   # đôi khi rush, thường thì đợi tụ rồi mới vào
	pp_pts = []
	for n in ts:
		n.set_meta("site", exec_site if randf() < 0.7 else 1 - exec_site)
	cts.shuffle()
	for i in cts.size():
		(cts[i] as Node).set_meta("site", i % 2)
	if not ts.is_empty():
		# người chơi phe T luôn là người mang bom (trước đây chọn ngẫu nhiên nên nhiều vòng người chơi không có bom để cầm)
		carrier = p if ts.has(p) else ts[randi() % ts.size()]
		bomb_state = "carried"
		carrier.set_meta("site", exec_site)
		if carrier == p:
			p.owned["c4"] = true
			h_info = true

	var h: Hud = main.hud
	h.show_center("", 0.1)
	h.show_info("Bấm 6 để cầm bom" if h_info else "", 4.0 if h_info else 0.1)
	h.set_score(int(wins[0]), int(wins[1]))
	hud_text = ""


func _process(delta: float) -> void:
	if not active or main == null or main.hud == null:
		return
	_tick_boom(delta)
	led_t = maxf(led_t - delta, 0.0)
	blink += delta
	if bomb_state == "dropped" and bomb_node != null:
		bomb_led.visible = fmod(blink, 1.0) < 0.15
	elif bomb_state == "planted":
		bomb_led.visible = led_t > 0.0
	match state:
		S.FREEZE:
			t -= delta
			_pickup_check()
			if t <= 0.0:
				state = S.LIVE
				t = ROUND_TIME
				main.round_frozen = false
				if main.shop_open:
					main._toggle_shop()
		S.LIVE:
			t -= delta
			round_elapsed += delta
			_player_interact(delta)
			_pickup_check()
			if t <= 0.0:
				_end_round(0, "Hết giờ, bom chưa được đặt")
		S.PLANTED:
			t -= delta
			round_elapsed += delta
			_player_interact(delta)
			_beep(delta)
			if t <= 0.0:
				_explode()
		S.END:
			t -= delta
			if t <= 0.0:
				_after_round()
		S.OVER:
			t -= delta
			if t <= 0.0:
				start_match(first_side)
	_update_hud()


func _update_hud() -> void:
	var s := ""
	var col := Color(1, 1, 1)
	match state:
		S.FREEZE:
			s = "%d" % ceili(t)
			col = Color(0.55, 1.0, 0.55)
		S.LIVE:
			s = "%d:%02d" % [floori(t / 60.0), int(t) % 60]
		S.PLANTED:
			s = "%d" % ceili(t)
			col = Color(1.0, 0.3, 0.25)
		_:
			s = ""
	if s != hud_text:
		hud_text = s
		main.hud.set_round_text(s, col)


# =====================================================================
#  NGƯỜI CHƠI: ĐẶT / GỠ / NHẶT BOM
# =====================================================================
func _flat(a: Vector3, b: Vector3) -> float:
	return Vector2(a.x - b.x, a.z - b.z).length()


func _site_at(pos: Vector3) -> int:
	for i in 2:
		var sp: Vector3 = sites[i]
		if _flat(pos, sp) < SITE_R and absf(pos.y - sp.y) < 2.5:
			return i
	return -1


func _player_interact(delta: float) -> void:
	var p: Player = main.player
	var h: Hud = main.hud
	var locked := false
	var prompt := ""
	var prog := -1.0
	if p.alive and not main.shop_open and not get_tree().paused:
		var use := Input.is_action_pressed("use")
		var pp := p.global_position
		if p.team == 1 and state == S.LIVE and bomb_state == "carried" and carrier == p and _site_at(pp) >= 0 and p.is_on_floor():
			var si := _site_at(pp)
			if p.cur_w != "c4":
				prompt = "Bấm 6 để cầm bom"
				plant_prog = 0.0
			else:
				prompt = "Giữ chuột trái để đặt bom"
				if Input.is_action_pressed("fire"):
					locked = true
					p.vm.planting = true
					plant_prog += delta
					prog = plant_prog / PLANT_TIME
					if plant_prog >= PLANT_TIME:
						_plant(pp, si)
						plant_prog = 0.0
						locked = false
						prog = -1.0
						prompt = ""
				else:
					p.vm.planting = false
					plant_prog = 0.0
		elif p.team == 0 and state == S.PLANTED and _flat(pp, bomb_pos) < 1.9 and absf(pp.y - bomb_pos.y) < 2.0 and p.is_on_floor():
			prompt = "Giữ E để gỡ bom"
			if use:
				locked = true
				defuse_prog += delta
				prog = defuse_prog / DEFUSE_TIME
				if defuse_prog >= DEFUSE_TIME:
					defuse_prog = 0.0
					locked = false
					_defuse(p)
					prog = -1.0
					prompt = ""
			else:
				defuse_prog = 0.0
		else:
			plant_prog = 0.0
			defuse_prog = 0.0
	else:
		plant_prog = 0.0
		defuse_prog = 0.0
	if p.cur_w == "c4" and not locked:
		p.vm.planting = false
	main.player_locked = locked
	busy_prompt = prompt
	if prompt == "" and main.pickups != null:
		prompt = str(main.pickups.prompt)   # không bận đặt / gỡ bom thì hiện dòng "Bấm E để nhặt ..." của đồ dưới đất
	h.set_prompt(prompt)
	h.set_action_progress(prog)


func _pickup_check() -> void:
	if bomb_state != "dropped":
		return
	if Time.get_ticks_msec() < c4_ignore_until:
		return
	var p: Player = main.player
	# chỉ phe T (team 1) đi tới là tự nhặt; phe CT không nhặt được bom
	if p.alive and p.team == 1 and _flat(p.global_position, bomb_pos) < 1.4 and absf(p.global_position.y - bomb_pos.y) < 2.0:
		_pickup(p)


## Người chơi (phe T) bấm G khi đang cầm bom: bom nằm lại trước mặt, đi tới chỗ đó là nhặt lại (sau khoảng 2 giây).
func player_drop_c4() -> void:
	var p: Player = main.player
	if bomb_state != "carried" or carrier != p or (state != S.FREEZE and state != S.LIVE):
		return
	var fwd: Vector3 = -(p.camera.global_transform.basis.z)
	fwd.y = 0.0
	fwd = fwd.normalized() if fwd.length() > 0.01 else Vector3.FORWARD
	var space: PhysicsDirectSpaceState3D = main.get_world_3d().direct_space_state
	var chest := p.global_position + Vector3(0.0, 1.0, 0.0)
	var dist := 1.5
	var h0 := space.intersect_ray(PhysicsRayQueryParameters3D.create(chest, chest + fwd * 1.5, 1))
	if not h0.is_empty():
		dist = maxf(0.0, chest.distance_to(h0["position"]) - 0.35)   # có tường ngay trước mặt thì thả sát chân
	var pos := p.global_position + fwd * dist
	var h1 := space.intersect_ray(PhysicsRayQueryParameters3D.create(pos + Vector3(0.0, 1.5, 0.0), pos + Vector3(0.0, -3.0, 0.0), 1))
	pos = (h1["position"] as Vector3) if not h1.is_empty() else p.global_position
	carrier = null
	bomb_state = "dropped"
	bomb_pos = pos
	bomb_node.global_position = pos
	bomb_node.visible = true
	bomb_led.visible = true
	p.owned["c4"] = false
	if p.cur_w == "c4":
		p.vm.planting = false
		p.switch_weapon(p.last_w if bool(p.owned.get(p.last_w, false)) else p.best_weapon())
	c4_ignore_until = Time.get_ticks_msec() + 2000
	main.hud.show_info("Đã vứt bom - đi tới để nhặt lại", 2.0)
	main.play_at("mag_in", pos, 2.0, 0.7, 40.0)


func _pickup(n) -> void:
	carrier = n
	bomb_state = "carried"
	bomb_node.visible = false
	n.set_meta("site", exec_site)
	if n == main.player:
		main.player.owned["c4"] = true
		main.hud.show_info("Bấm 6 để cầm bom", 3.0)
		main.player.play("mag_in", -2.0)


func _plant(pos: Vector3, si: int) -> void:
	var planter = carrier
	carrier = null
	if planter is Bot:
		(planter as Bot).money = mini((planter as Bot).money + PLANT_BONUS, MAX_MONEY)
	bomb_state = "planted"
	state = S.PLANTED
	t = BOMB_TIME
	site_planted = si
	bomb_pos = pos
	bomb_node.global_position = pos
	bomb_node.visible = true
	bomb_led.visible = true
	beep_t = 0.0
	bot_prog.clear()
	if planter == main.player:
		var pl: Player = main.player
		pl.owned["c4"] = false
		if pl.cur_w == "c4":
			pl.vm.planting = false
			pl.switch_weapon(pl.last_w if bool(pl.owned.get(pl.last_w, false)) else pl.pistol_id())
		main.money = mini(main.money + PLANT_BONUS, MAX_MONEY)
		main.hud.set_money(main.money)
	main.hud.show_center("BOM ĐÃ ĐƯỢC ĐẶT", 2.0)
	main.play_at("mag_in", pos, 6.0, 0.7, 80.0)
	_build_pp()


func _defuse(defuser) -> void:
	if state != S.PLANTED:
		return
	if defuser is Bot:
		(defuser as Bot).money = mini((defuser as Bot).money + DEFUSE_BONUS, MAX_MONEY)
	if defuser == main.player:
		main.money = mini(main.money + DEFUSE_BONUS, MAX_MONEY)
		main.hud.set_money(main.money)
	main.play_at("mag_in", bomb_pos, 6.0, 1.2, 80.0)
	_end_round(0, "Bom đã được gỡ")


func _beep(delta: float) -> void:
	beep_t -= delta
	if beep_t <= 0.0:
		beep_t = lerpf(0.10, 1.0, clampf(t / BOMB_TIME, 0.0, 1.0))
		led_t = 0.08
		main.play_at("beep", bomb_pos + Vector3(0.0, 0.2, 0.0), 6.0, 1.0, 120.0)


func _explode() -> void:
	var pos := bomb_pos
	bomb_node.visible = false
	boom.global_position = pos + Vector3(0.0, 0.5, 0.0)
	boom.visible = true
	boom_t = 0.0
	main.play_at("explode", pos, 10.0, 1.0, 150.0)
	_end_round(1, "Bom đã phát nổ")
	for n in get_tree().get_nodes_in_group("combatants"):
		if not n.alive:
			continue
		var d := _flat(n.global_position, pos)
		if d < BLAST_R:
			n.take_damage(520.0 * (1.0 - d / BLAST_R), null, false)
	var p: Player = main.player
	var dp := p.global_position.distance_to(pos)
	if dp < 45.0:
		var k := clampf(1.0 - dp / 45.0, 0.0, 1.0)
		p.punch_v += Vector2(randf_range(-1.0, 1.0), randf_range(-1.0, 1.0)) * 6.0 * k
		main.hud.damage_indicator(0.5 * k)


func _tick_boom(delta: float) -> void:
	if boom_t < 0.0:
		return
	boom_t += delta
	var k := boom_t / 1.0
	if k >= 1.0:
		boom.visible = false
		boom_t = -1.0
		return
	var e := 1.0 - pow(1.0 - k, 3.0)
	boom.scale = Vector3.ONE * lerpf(0.5, 9.0, e)
	boom_mat.albedo_color = Color(1.0, lerpf(0.65, 0.25, k), 0.1, 0.85 * (1.0 - k))


# =====================================================================
#  KẾT THÚC ROUND / TRẬN
# =====================================================================
func on_kill(killer, victim, headshot: bool) -> void:
	var h: Hud = main.hud
	if killer != null and is_instance_valid(killer) and killer != victim:
		killer.kills += 1
		h.add_kill(str(killer.display_name), str(victim.display_name), headshot, int(killer.team))
		if killer == main.player:
			h.kill_flash(headshot)
			var rw := 300
			var cw: String = main.player.cur_w
			if cw == "knife":
				rw = 1500
			elif cw == "mp5":
				rw = 600   # MP5-SD: thưởng hạ gục $600 như CS2
			main.money = mini(main.money + rw, MAX_MONEY)
			h.set_money(main.money)
		elif killer is Bot:
			(killer as Bot).money = mini((killer as Bot).money + 300, MAX_MONEY)
	else:
		h.add_kill("Bom", str(victim.display_name), false, 1)
	if bomb_state == "carried" and carrier == victim:
		carrier = null
		bomb_state = "dropped"
		bomb_pos = (victim as Node3D).global_position
		bomb_node.global_position = bomb_pos
		bomb_node.visible = true
		bomb_led.visible = true
	if state == S.LIVE or state == S.PLANTED:
		_check_end()


func _check_end() -> void:
	var a := [0, 0]
	for n in get_tree().get_nodes_in_group("combatants"):
		if n.alive:
			a[int(n.team)] = int(a[int(n.team)]) + 1
	if int(a[0]) == 0:
		_end_round(1, "Toàn bộ CT đã bị hạ")
	elif int(a[1]) == 0 and state == S.LIVE:
		_end_round(0, "Toàn bộ T đã bị hạ")


func _end_round(winner: int, reason: String) -> void:
	if state == S.END or state == S.OVER:
		return
	state = S.END
	t = END_TIME
	main.player_locked = false
	busy_prompt = ""
	main.hud.set_prompt("")
	main.hud.set_action_progress(-1.0)
	wins[winner] = int(wins[winner]) + 1
	# tiền thưởng cho người chơi
	var loser := 1 - winner
	var gain := 0
	if winner == player_side:
		gain = WIN_BONUS
	else:
		gain = LOSS_BASE + LOSS_STEP * int(streak[player_side])
		if player_side == 1 and site_planted >= 0:
			gain += PLANTED_LOSS_BONUS
	# tiền thưởng cho bot (cùng luật với người chơi: thắng $3250, thua $1400 + $500 mỗi round thua liên tiếp, T đã đặt bom mà thua +$800)
	for ob in main.bots:
		if not is_instance_valid(ob):
			continue
		var og := 0
		if int(ob.team) == winner:
			og = WIN_BONUS
		else:
			og = LOSS_BASE + LOSS_STEP * int(streak[int(ob.team)])
			if int(ob.team) == 1 and site_planted >= 0:
				og += PLANTED_LOSS_BONUS
		ob.money = mini(int(ob.money) + og, MAX_MONEY)
	streak[winner] = maxi(int(streak[winner]) - 1, 0)
	streak[loser] = mini(int(streak[loser]) + 1, 4)
	main.money = mini(main.money + gain, MAX_MONEY)
	main.hud.set_money(main.money)
	main.hud.set_score(int(wins[0]), int(wins[1]))
	var who := "CT" if winner == 0 else "T"
	main.hud.show_center("%s THẮNG" % who, END_TIME)


func _after_round() -> void:
	if int(wins[0]) >= WIN_ROUNDS or int(wins[1]) >= WIN_ROUNDS or round_no >= HALF_ROUNDS * 2:
		_match_over()
		return
	if round_no == HALF_ROUNDS:
		_swap_sides()
	_start_round()
	if round_no == HALF_ROUNDS + 1:
		main.hud.show_center("ĐỔI PHE", 3.0)


func _swap_sides() -> void:
	wins = [wins[1], wins[0]]
	streak = [0, 0]
	player_side = 1 - player_side
	main.player.team = player_side
	main._rebuild_bots(player_side)
	reset_all = true


func _match_over() -> void:
	state = S.OVER
	t = OVER_TIME
	main.round_frozen = false
	var mine := int(wins[player_side])
	var theirs := int(wins[1 - player_side])
	var s := "HOÀ"
	if mine > theirs:
		s = "THẮNG"
	elif mine < theirs:
		s = "THUA"
	main.hud.show_center("%s  %d : %d" % [s, mine, theirs], OVER_TIME)


func score_text() -> String:
	var all: Array = get_tree().get_nodes_in_group("combatants")
	all.sort_custom(func(a, b): return a.kills > b.kills)
	var s := "CT %d : %d T\n\n" % [int(wins[0]), int(wins[1])]
	for n in all:
		s += "[%s]  %s   K %d   D %d   %s\n" % ["CT" if n.team == 0 else "T", str(n.display_name).rpad(10), n.kills, n.deaths, "" if n.alive else "x"]
	return s


# =====================================================================
#  BOT: NHIỆM VỤ (được bot.gd gọi mỗi nhịp vật lý khi không thấy địch)
# =====================================================================
func _nearest_bot(team: int, pos: Vector3):
	var best = null
	var bd := 1.0e9
	for b in main.bots:
		if is_instance_valid(b) and b.alive and int(b.team) == team:
			var d := _flat(b.global_position, pos)
			if d < bd:
				bd = d
				best = b
	return best


func _go(b, p: Vector3, speed: float, delta: float) -> bool:
	if (not b.has_goal) or (b.goal as Vector3).distance_to(p) > 1.0:
		b._set_goal(p)
	return b._nav_move(speed, delta)


func _bprog(b, delta: float) -> float:
	var f := Engine.get_physics_frames()
	var e: Array = bot_prog.get(b, [0.0, f])
	if f - int(e[1]) > 4:
		e[0] = 0.0
	e[0] = float(e[0]) + delta
	e[1] = f
	bot_prog[b] = e
	return float(e[0])


## Một bot CT/T vừa thấy địch: báo cho cả đội biết (CT dùng tin này để chạy chi viện).
func report_enemy(from_team: int, pos: Vector3) -> void:
	if not active or from_team != 0:
		return
	intel_pos = pos
	intel_t = round_elapsed


func _nearest_site(pos: Vector3) -> int:
	return 0 if _flat(pos, sites[0]) <= _flat(pos, sites[1]) else 1


## Hướng bot nhìn khi đang "suy nghĩ": T nhìn về điểm bom sẽ đi, CT nhìn về phía địch sẽ kéo tới.
func _think_look(b) -> Vector3:
	var bp: Vector3 = b.global_position
	var target: Vector3
	if int(b.team) == 1:
		target = sites[int(b.get_meta("site", exec_site))]
	else:
		var l: Array = main.spawns[1]
		target = Vector3.ZERO
		for v in l:
			target += v
		if not l.is_empty():
			target /= float(l.size())
	return Vector3(target.x - bp.x, 0.0, target.z - bp.z)


## Trả về true nếu bot đang bận nhiệm vụ (đi đặt bom, đặt bom, nhặt bom, gỡ bom) trong nhịp này.
func bot_special(b, delta: float) -> bool:
	if not active or (state != S.LIVE and state != S.PLANTED):
		return false
	var bp: Vector3 = b.global_position
	# vừa hết giờ chuẩn bị: đứng lại, nhìn quanh, nghĩ xem đi đâu (chưa chạy ra ngay)
	if state == S.LIVE and round_elapsed < float(b.get_meta("think", 0.0)):
		b._steer(Vector3.ZERO, delta)
		var d := _think_look(b)
		if d.length() > 0.5:
			var yaw := atan2(-d.x, -d.z) + sin(round_elapsed * 0.9 + float(b.get_instance_id() % 7)) * 0.5
			b._turn_to(yaw, delta, 3.0, 2.2)
		return true
	if int(b.team) == 1:
		if bomb_state == "carried" and carrier == b:
			var si := int(b.get_meta("site", exec_site))
			var sp: Vector3 = sites[si]
			# chờ đồng đội tới điểm bom dọn đường rồi mới vào đặt (còn ít giờ thì vào luôn)
			if round_elapsed < exec_time or (_flat(bp, sp) > 14.0 and not _t_ready(b, si)):
				return false
			if _flat(bp, sp) > 2.0:
				_go(b, sp, BOT_SPEED, delta)
				return true
			b._steer(Vector3.ZERO, delta)
			if _bprog(b, delta) >= PLANT_TIME:
				_plant(bp, si)
			return true
		if bomb_state == "dropped" and _nearest_bot(1, bomb_pos) == b:
			if _flat(bp, bomb_pos) < 1.2:
				_pickup(b)
				return true
			_go(b, bomb_pos, BOT_SPEED, delta)
			return true
	else:
		if state == S.PLANTED and _nearest_bot(0, bomb_pos) == b:
			var dd := _flat(bp, bomb_pos)
			var e: Array = bot_prog.get(b, [0.0, 0])
			var prog: float = float(e[0]) if Engine.get_physics_frames() - int(e[1]) <= 4 else 0.0
			var need: float = (DEFUSE_TIME - prog) if dd <= 1.4 else (DEFUSE_TIME + dd / BOT_SPEED)
			if t < need + 0.4:
				return false   # không kịp gỡ nữa: bỏ cuộc, chạy đi (người thật cũng "save")
			if dd > 1.4:
				# có địch đang canh quả bom: chờ đồng đội dọn rồi mới vào (trừ khi sắp hết giờ)
				if round_elapsed - intel_t < 4.0 and _flat(intel_pos, bomb_pos) < 18.0 and t > DEFUSE_TIME + 9.0 and _ct_alive_count() > 1:
					return false
				_go(b, bomb_pos, BOT_SPEED, delta)
				return true
			b._steer(Vector3.ZERO, delta)
			if _bprog(b, delta) >= DEFUSE_TIME:
				_defuse(b)
			return true
		# CT nghe tin báo có địch ở điểm bom kia: một nửa số CT chạy sang chi viện (mỗi bot chỉ đổi một lần)
		if state == S.LIVE and bomb_state != "planted" and round_elapsed - intel_t < INTEL_LIFE and not bool(b.get_meta("rotated", false)):
			var isite := _nearest_site(intel_pos)
			if isite != int(b.get_meta("site", 0)) and rotated < 2 and randf() < 0.5:
				b.set_meta("rotated", true)
				rotated += 1
				b.set_meta("site", isite)
				b.set_meta("spot", -1)
				b.has_goal = false
	return false


## Chỗ bot đi tới khi không có nhiệm vụ riêng.
##  - T (trước khi xông vào): tụ lại ở điểm tập kết của điểm bom đã chọn, rồi mới cùng đi đặt
##  - CT (trước khi bom nổ): đứng trấn giữ quanh điểm bom của mình, mỗi bot một vị trí khác nhau
##  - sau khi bom được đặt: cả hai bên quanh quả bom
func pick_goal(b) -> Vector3:
	var si := int(b.get_meta("site", 0))
	var is_t := int(b.team) == 1
	if state == S.PLANTED:
		if (not is_t) and t < DEFUSE_TIME - 0.5:
			var sl: Array = main.spawns[0]
			if not sl.is_empty():
				return sl[randi() % sl.size()]   # hết kịp gỡ: chạy về (save)
		if pp_pts.is_empty():
			return _around(bomb_pos, 9.0)
		# sau khi bom đặt: T chọn chỗ nhìn thấy bom ở gần để canh, CT chọn chỗ xa hơn để yểm trợ người gỡ
		var n := pp_pts.size()
		var lo := 0 if is_t else int(float(n) * 0.4)
		var hi := maxi(lo + 1, int(float(n) * 0.6) if is_t else n)
		var k := int(b.get_meta("pp", -1))
		if k < lo or k >= hi or randf() < 0.15:
			k = lo + randi() % (hi - lo)
			b.set_meta("pp", k)
		return pp_pts[k]
	if is_t:
		var wait_stage := round_elapsed < exec_time
		if (not wait_stage) and b == carrier and bomb_state == "carried" and _flat(b.global_position, sites[si]) > 14.0 and not _t_ready(b, si):
			wait_stage = true
		if wait_stage:
			var sg: Vector3 = stage_pts[si]
			return _around(sg, 3.0)
		return _around(sites[si], 7.0)
	var holds: Array = hold_pts[si]
	if holds.is_empty():
		return _around(sites[si], 9.0)
	# mỗi CT giữ một chỗ cố định (chia đều các hướng), thỉnh thoảng đổi sang chỗ khác
	var spot := int(b.get_meta("spot", -1))
	if spot < 0 or randf() < 0.25:
		spot = (randi() + int(b.get_instance_id())) % holds.size()
		b.set_meta("spot", spot)
	return holds[spot]


## T chỉ vào điểm bom khi đồng đội đã tới dọn đường (hoặc sắp hết giờ / chờ quá lâu).
func _t_ready(b, si: int) -> bool:
	if t < 55.0 or round_elapsed > exec_time + 14.0:
		return true
	var mates := 0
	var alive_t := 0
	for n in main.bots:
		if is_instance_valid(n) and n.alive and int(n.team) == 1 and n != b:
			alive_t += 1
			if _flat(n.global_position, sites[si]) < 11.0:
				mates += 1
	return alive_t == 0 or mates >= mini(2, alive_t)


func _ct_alive_count() -> int:
	var c := 0
	for n in main.bots:
		if is_instance_valid(n) and n.alive and int(n.team) == 0:
			c += 1
	return c


## Sau khi đặt bom: tìm các chỗ có tầm nhìn thẳng tới quả bom (5-17 m) để canh / yểm trợ.
func _build_pp() -> void:
	pp_pts = []
	var space: PhysicsDirectSpaceState3D = main.get_world_3d().direct_space_state
	var cand: Array = []
	for w in main.waypoints:
		var d := _flat(w, bomb_pos)
		if d < 5.5 or d > 17.0 or absf(w.y - bomb_pos.y) > 3.5:
			continue
		var q := PhysicsRayQueryParameters3D.create(w + Vector3(0.0, 1.5, 0.0), bomb_pos + Vector3(0.0, 0.6, 0.0), 1)
		if space.intersect_ray(q).is_empty():
			cand.append(w)
	cand.sort_custom(func(a, c): return _flat(a, bomb_pos) < _flat(c, bomb_pos))
	pp_pts = cand
	for n in get_tree().get_nodes_in_group("combatants"):
		n.set_meta("pp", -1)


## Hướng bot nhìn khi đứng canh: CT nhìn về phía T sẽ tới, T nhìn về điểm bom, sau khi đặt thì nhìn quả bom.
func approach_dir(b) -> Vector3:
	var si := int(b.get_meta("site", 0))
	var bp: Vector3 = b.global_position
	var tgt: Vector3
	if state == S.PLANTED:
		tgt = bomb_pos
	elif int(b.team) == 1:
		tgt = sites[si]
	else:
		tgt = stage_pts[si]
	return Vector3(tgt.x - bp.x, 0.0, tgt.z - bp.z)


## Đứng canh bao lâu rồi mới đổi chỗ: CT kiên nhẫn đứng lâu, T tụ điểm tập kết thì ngắn hơn.
func hold_wait(b) -> float:
	if state == S.PLANTED:
		return randf_range(3.0, 7.0)
	if int(b.team) == 0:
		return randf_range(3.0, 9.0) * (0.6 + float(b.patience) * 0.8)
	return randf_range(1.5, 4.0)


func _around(anchor: Vector3, r: float) -> Vector3:
	var near: Array = []
	for w in main.waypoints:
		if Vector2(w.x - anchor.x, w.z - anchor.z).length() < r:
			near.append(w)
	if near.is_empty():
		return anchor
	return near[randi() % near.size()]
