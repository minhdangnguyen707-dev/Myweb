extends RefCounted
## Giao diện chung cho sảnh chờ + cửa hàng: nền tối, phẳng, MỘT màu nhấn (vàng ấm).
## Muốn đổi màu cả hai màn hình: sửa mấy hằng ngay bên dưới.

const SURFACE := Color(0.075, 0.083, 0.098)
const SURFACE_HI := Color(0.11, 0.122, 0.145)
const LINE := Color(0.17, 0.19, 0.225)
const TEXT := Color(0.93, 0.94, 0.96)
const MUTED := Color(0.47, 0.5, 0.56)
const ACCENT := Color(0.96, 0.78, 0.36)
const CLEAR := Color(0, 0, 0, 0)

# --- riêng sảnh chờ (kiểu Valorant): chữ trắng hơi tím, mục đang chọn màu xanh ngọc ---
const LV_TEXT := Color(0.91, 0.90, 0.96)
const LV_TEAL := Color(0.235, 0.95, 0.82)
const LV_MUTED := Color(0.58, 0.57, 0.66)
const LV_CARD := Color(1, 1, 1, 0.05)
const LV_CARD_LINE := Color(1, 1, 1, 0.20)

static var _lobby_font: Font


static func box(bg: Color, border: Color = CLEAR, bw: int = 0, radius: int = 6, mx: int = 16, my: int = 10) -> StyleBoxFlat:
	var s := StyleBoxFlat.new()
	s.bg_color = bg
	s.border_color = border
	s.set_border_width_all(bw)
	s.set_corner_radius_all(radius)
	s.content_margin_left = mx
	s.content_margin_right = mx
	s.content_margin_top = my
	s.content_margin_bottom = my
	return s


static func title_font() -> Font:
	var fv := FontVariation.new()
	fv.base_font = ThemeDB.fallback_font
	fv.variation_embolden = 0.4
	fv.spacing_glyph = 8
	return fv


## Font sảnh chờ: chữ đậm, hẹp, viết hoa (gần giống font Tungsten của Valorant, vì font thật có bản quyền nên không đi kèm).
## Muốn dùng đúng font khác: chép file .ttf/.otf vào thư mục fonts/ cạnh project.godot và đặt tên lobby.ttf (hoặc lobby.otf).
static func lobby_font() -> Font:
	if _lobby_font != null:
		return _lobby_font
	for path in ["res://fonts/lobby.ttf", "res://fonts/lobby.otf"]:
		if FileAccess.file_exists(path):
			var ff := FontFile.new()
			if ff.load_dynamic_font(path) == OK:
				_lobby_font = ff
				return ff
	var sf := SystemFont.new()
	sf.font_names = PackedStringArray(["Bahnschrift SemiBold Condensed", "Bahnschrift Condensed", "Bahnschrift", "Arial Narrow", "Impact", "Arial"])
	sf.font_weight = 700
	sf.allow_system_fallback = true
	var fv := FontVariation.new()
	fv.base_font = sf
	fv.spacing_glyph = 1
	_lobby_font = fv
	return fv


static func make_theme() -> Theme:
	var t := Theme.new()
	var fv := FontVariation.new()
	fv.base_font = ThemeDB.fallback_font
	fv.spacing_glyph = 1
	t.default_font = fv
	t.default_font_size = 15

	t.set_color("font_color", "Label", TEXT)

	# --- nút thường: viền mảnh, rê chuột thì viền chuyển màu nhấn ---
	t.set_font_size("font_size", "Button", 16)
	t.set_stylebox("normal", "Button", box(SURFACE, LINE, 1))
	t.set_stylebox("hover", "Button", box(SURFACE_HI, ACCENT, 1))
	t.set_stylebox("pressed", "Button", box(SURFACE, ACCENT, 1))
	t.set_stylebox("disabled", "Button", box(SURFACE, LINE, 1))
	t.set_stylebox("focus", "Button", StyleBoxEmpty.new())
	t.set_color("font_color", "Button", TEXT)
	t.set_color("font_hover_color", "Button", Color(1, 1, 1))
	t.set_color("font_pressed_color", "Button", ACCENT)
	t.set_color("font_disabled_color", "Button", MUTED)
	t.set_color("font_focus_color", "Button", TEXT)

	# --- nút chữ trơn (QUIT, ESC, NEW) ---
	t.set_type_variation("Ghost", "Button")
	t.set_font_size("font_size", "Ghost", 13)
	t.set_stylebox("normal", "Ghost", box(CLEAR, CLEAR, 0, 4, 12, 6))
	t.set_stylebox("hover", "Ghost", box(Color(1, 1, 1, 0.06), CLEAR, 0, 4, 12, 6))
	t.set_stylebox("pressed", "Ghost", box(Color(1, 1, 1, 0.1), CLEAR, 0, 4, 12, 6))
	t.set_stylebox("disabled", "Ghost", box(CLEAR, CLEAR, 0, 4, 12, 6))
	t.set_stylebox("focus", "Ghost", StyleBoxEmpty.new())
	t.set_color("font_color", "Ghost", MUTED)
	t.set_color("font_hover_color", "Ghost", TEXT)
	t.set_color("font_pressed_color", "Ghost", ACCENT)

	# --- thẻ hàng trong cửa hàng ---
	t.set_type_variation("Card", "Button")
	t.set_stylebox("normal", "Card", box(SURFACE, LINE, 1, 8, 0, 0))
	t.set_stylebox("hover", "Card", box(SURFACE_HI, ACCENT, 1, 8, 0, 0))
	t.set_stylebox("pressed", "Card", box(SURFACE_HI, ACCENT, 1, 8, 0, 0))
	t.set_stylebox("disabled", "Card", box(SURFACE, LINE, 1, 8, 0, 0))

	# --- thanh tải ---
	t.set_stylebox("background", "ProgressBar", box(LINE, CLEAR, 0, 2, 0, 0))
	t.set_stylebox("fill", "ProgressBar", box(ACCENT, CLEAR, 0, 2, 0, 0))
	return t
