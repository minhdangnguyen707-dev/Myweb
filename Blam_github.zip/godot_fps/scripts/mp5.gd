extends Node3D
## MP5-SD góc nhìn thứ nhất (người dùng yêu cầu: NHÚNG THẲNG model + tay + animation + âm thanh trong file gửi kèm).
## Súng + hai bàn tay (găng GSG9) + mọi animation (rút súng, bắn 3 kiểu, nạp đạn, inspect) lấy từ MỘT file: assets/mp5/v_mp5.glb,
## đổi từ v_mp5.mdl (CS 1.6; file .mdl gốc đã bỏ khỏi project cho nhẹ, lấy lại từ gói model của người dùng) bằng `python3 tools/mdl2glb.py v_mp5.mdl v_mp5.glb --vm --atlas`.
## Âm thanh: assets/mp5/sounds/*.wav (tiếng bắn, kéo khoá, tháo / lắp băng đạn, rút súng) - ĐÚNG thời điểm sự kiện ghi trong model.
## Đây là súng DUY NHẤT trong game có tiếng (người dùng yêu cầu riêng cho MP5): player.gd / các súng khác vẫn im lặng.
## NGOẠI LỆ so với quy tắc "súng mới phải dùng Hands.Arm": MP5 dùng tay CÓ SẴN trong model (giống AWP), KHÔNG dùng hands.gd.
## Cùng giao diện (API) với Viewmodel / Rifle / Awp để Player dùng thay thế qua lại. KHÔNG có ngắm (ADS).
##
## Hệ trục model (glTF, giống GoldSrc xoay): +X trái, +Y lên, +Z phía trước. Ta xoay 180 độ quanh Y để nòng súng chĩa về -Z (hướng nhìn camera).

signal sound(sound_name: String)
signal reload_inserted()
signal action_finished(action_name: String)

const MODEL_PATH := "res://assets/mp5/v_mp5.glb"
const SND_DIR := "res://assets/mp5/sounds/"
# Model GoldSrc đặt súng lệch TRÁI mắt ~12 cm (gốc toạ độ = mắt): dời sang phải cho giống cách cầm súng của CS. (x phải, y lên, z trước = -z)
const VM_OFFSET := Vector3(0.27, 0.0, 0.0)
# xương "flash" của model (v_weapon.flash) nằm ngay trước đầu ống giảm thanh; tên xương có thể bị Godot đổi dấu chấm nên tìm theo đuôi tên
const MUZZLE_BONE_SUFFIX := "flash"

enum Mode { NONE, DRAW, RELOAD, INSPECT }

# Thời gian nạp đạn CS2 = 2.97 s; animation gốc của model dài ~2.575 s nên chạy chậm lại cho vừa (xem _start_mode).
const RELOAD_TIME := 2.97
# Sự kiện âm thanh của model (giây TRONG animation gốc, lấy từ v_mp5.mdl): [thời điểm, tên file wav]
const RELOAD_EVENTS := [[0.125, "mp5_slideback"], [0.575, "mp5_clipout"], [1.6, "mp5_clipin"], [2.125, "mp5_slideforward"]]
const DRAW_EVENTS := [[0.2, "mp5_draw"], [0.571, "mp5_slideforward"]]
# băng đạn mới vào súng ngay sau tiếng "clipin" (giây trong animation gốc)
const RELOAD_INSERT_AT := 1.65

# ---------------- trạng thái nhận từ Player ----------------
var move_amount := 0.0
var run_amount := 0.0
var grounded := true
var crouched := false
var ads := 0.0           # luôn 0 (game không có ngắm)
var ads_t := 0.0
var wall_push := 0.0
var mouse_delta := Vector2.ZERO
var planting := false    # bomb.gd gán biến này cho viewmodel đang cầm; MP5 không dùng

var rig: Node3D = null            # gốc model (đã xoay 180 độ + dời vị trí)
var anim: AnimationPlayer = null
var skel: Skeleton3D = null
var muzzle_bone := -1
var flash: MeshInstance3D = null
var flash_t := 0.0

var mode: int = Mode.NONE
var mode_t := 0.0
var mode_len := 0.0
var mode_speed := 1.0             # tốc độ chạy animation của hành động hiện tại (nạp đạn chạy chậm lại cho đúng 2.97 s)
var insert_at := 1.9              # giây (đã tính tốc độ) băng đạn mới vào súng
var insert_sent := false
var fire_t := 0.0                 # còn đang chạy animation bắn
var shoot_i := 0

var idle_hold_t := 0.0            # sau khi về tư thế nghỉ ~0.3 s thì DỪNG animation (không cập nhật xương mỗi khung hình khi súng đứng yên)
var sway := Vector2.ZERO
var bob_t := 0.0
var land_off := 0.0

# ---------------- âm thanh ----------------
var snd := {}                     # tên file -> AudioStream
var shot_players: Array = []      # tiếng bắn: xoay vòng nhiều kênh để tiếng chồng lên nhau khi bắn liên thanh
var foley_players: Array = []     # tiếng kéo khoá / băng đạn / rút súng
var shot_i := 0
var foley_i := 0
var ev_list: Array = []
var ev_i := 0


func _ready() -> void:
	rig = Node3D.new()
	rig.rotation.y = PI
	rig.position = VM_OFFSET
	add_child(rig)
	_build_flash()   # main._warmup() đụng tới `flash` của mọi viewmodel nên luôn phải có
	_build_audio()
	var scene = load(MODEL_PATH)
	if scene == null:
		push_warning("Không nạp được " + MODEL_PATH + " (chạy CHOI_GAME.bat để Godot import lại)")
		return
	var model: Node3D = (scene as PackedScene).instantiate()
	rig.add_child(model)
	skel = _find_skeleton(model)
	anim = _find_anim(model)
	if skel != null:
		muzzle_bone = _find_bone_by_suffix(MUZZLE_BONE_SUFFIX)
	_fix_meshes(model)
	if anim != null:
		_complete_tracks()
		anim.playback_default_blend_time = 0.05
		# animation "idle" của model chỉ có MỘT khung (độ dài 0): nới ra một chút và cho lặp để chắc chắn tư thế cầm súng luôn được áp dụng
		if anim.has_animation("idle"):
			var ia := anim.get_animation("idle") as Animation
			ia.length = maxf(ia.length, 0.1)
			ia.loop_mode = Animation.LOOP_LINEAR
		_play("idle")
	visibility_changed.connect(_on_visibility_changed)


## Khi import, Godot có thể bỏ các track xương "bất biến" (bằng tư thế nghỉ). Nếu animation sau không còn track của xương đó thì xương giữ nguyên
## tư thế của animation trước (tay / băng đạn không quay về chỗ cũ). Thêm lại các track thiếu bằng đúng tư thế nghỉ để animation nào cũng ghi đè đủ mọi xương.
func _complete_tracks() -> void:
	if skel == null:
		return
	var base: Node = anim.get_node_or_null(anim.root_node)
	if base == null:
		return
	var sp := str(base.get_path_to(skel))
	for an in anim.get_animation_list():
		var a: Animation = anim.get_animation(an)
		for b in skel.get_bone_count():
			var path := NodePath(sp + ":" + skel.get_bone_name(b))
			var rest := skel.get_bone_rest(b)
			if a.find_track(path, Animation.TYPE_POSITION_3D) < 0:
				var tp_i := a.add_track(Animation.TYPE_POSITION_3D)
				a.track_set_path(tp_i, path)
				a.position_track_insert_key(tp_i, 0.0, rest.origin)
			if a.find_track(path, Animation.TYPE_ROTATION_3D) < 0:
				var tr_i := a.add_track(Animation.TYPE_ROTATION_3D)
				a.track_set_path(tr_i, path)
				a.rotation_track_insert_key(tr_i, 0.0, rest.basis.get_rotation_quaternion())


func _find_skeleton(n: Node) -> Skeleton3D:
	if n is Skeleton3D:
		return n
	for c in n.get_children():
		var r := _find_skeleton(c)
		if r != null:
			return r
	return null


func _find_anim(n: Node) -> AnimationPlayer:
	if n is AnimationPlayer:
		return n
	for c in n.get_children():
		var r := _find_anim(c)
		if r != null:
			return r
	return null


## Tìm xương theo đuôi tên (không phân biệt hoa thường): "v_weapon.flash" / "v_weapon_flash" / "v_weaponflash" đều khớp.
func _find_bone_by_suffix(suffix: String) -> int:
	for i in skel.get_bone_count():
		if skel.get_bone_name(i).to_lower().ends_with(suffix):
			return i
	return -1


## Texture CS vẽ không đổ bóng (giống các súng khác + nhẹ cho máy yếu); mesh có xương nên nới hộp cắt hình để không bị mất khi animation đưa súng ra xa.
func _fix_meshes(n: Node) -> void:
	if n is MeshInstance3D:
		var mi := n as MeshInstance3D
		mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		mi.custom_aabb = AABB(Vector3(-3.0, -3.0, -3.0), Vector3(6.0, 6.0, 6.0))
		if mi.mesh != null:
			for i in mi.mesh.get_surface_count():
				var m = mi.mesh.surface_get_material(i)
				if m is BaseMaterial3D:
					var d := (m as BaseMaterial3D).duplicate() as BaseMaterial3D
					d.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
					d.cull_mode = BaseMaterial3D.CULL_DISABLED
					mi.set_surface_override_material(i, d)
	for c in n.get_children():
		_fix_meshes(c)


## Tia lửa đầu nòng: MP5-SD có ống giảm thanh nên chỉ loé nhỏ và mờ.
func _build_flash() -> void:
	var g := Gradient.new()
	g.set_color(0, Color(1.0, 0.95, 0.7, 0.8))
	g.set_color(1, Color(1.0, 0.5, 0.1, 0.0))
	var gt := GradientTexture2D.new()
	gt.gradient = g
	gt.fill = GradientTexture2D.FILL_RADIAL
	gt.fill_from = Vector2(0.5, 0.5)
	gt.fill_to = Vector2(1.0, 0.5)
	gt.width = 64
	gt.height = 64
	var q := QuadMesh.new()
	q.size = Vector2(0.2, 0.2)
	var mat := StandardMaterial3D.new()
	mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	mat.blend_mode = BaseMaterial3D.BLEND_MODE_ADD
	mat.billboard_mode = BaseMaterial3D.BILLBOARD_ENABLED
	mat.albedo_texture = gt
	mat.no_depth_test = true
	flash = MeshInstance3D.new()
	flash.mesh = q
	flash.material_override = mat
	flash.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	flash.visible = false
	add_child(flash)


## Nạp các file wav (nếu thiếu file / chưa import thì im lặng bỏ qua, súng vẫn chạy bình thường) và dựng các kênh phát.
func _build_audio() -> void:
	for n in ["mp5-1", "mp5_clipin", "mp5_clipout", "mp5_draw", "mp5_slideback", "mp5_slideforward"]:
		var p: String = SND_DIR + n + ".wav"
		if ResourceLoader.exists(p):
			var s = load(p)
			if s != null:
				snd[n] = s
	for i in 3:
		var ap := AudioStreamPlayer.new()
		ap.volume_db = -2.0
		add_child(ap)
		shot_players.append(ap)
	for i in 2:
		var ap2 := AudioStreamPlayer.new()
		ap2.volume_db = -5.0
		add_child(ap2)
		foley_players.append(ap2)


func _play_snd(sname: String, foley: bool, pitch: float = 1.0) -> void:
	if not snd.has(sname):
		return
	var ap: AudioStreamPlayer
	if foley:
		ap = foley_players[foley_i % foley_players.size()]
		foley_i += 1
	else:
		ap = shot_players[shot_i % shot_players.size()]
		shot_i += 1
	ap.stream = snd[sname]
	ap.pitch_scale = pitch
	ap.play()


## Ẩn viewmodel (đổi súng) thì tắt luôn animation cho nhẹ máy.
func _on_visibility_changed() -> void:
	if anim != null:
		anim.active = is_visible_in_tree()


func _play(anim_name: String, blend: float = -1.0, speed: float = 1.0) -> void:
	if anim == null or not anim.has_animation(anim_name):
		return
	idle_hold_t = 0.3 if anim_name == "idle" else 0.0
	anim.play(anim_name, blend, speed)


func _anim_len(anim_name: String, fallback: float) -> float:
	if anim != null and anim.has_animation(anim_name):
		return anim.get_animation(anim_name).length
	return fallback


# =====================================================================
#  API CHO PLAYER
# =====================================================================
func is_busy() -> bool:
	return mode != Mode.NONE or fire_t > 0.0


func current_mode() -> int:
	return mode


func play_draw() -> void:
	_start_mode(Mode.DRAW, "draw", _anim_len("draw", 1.0), 1.0, DRAW_EVENTS)


func play_reload(_empty: bool) -> float:
	var a_len := _anim_len("reload", 2.575)
	_start_mode(Mode.RELOAD, "reload", RELOAD_TIME, a_len / RELOAD_TIME, RELOAD_EVENTS)
	return mode_len


func play_inspect() -> void:
	_start_mode(Mode.INSPECT, "inspect", _anim_len("inspect", 7.67), 1.0, [])


func cancel() -> void:
	mode = Mode.NONE
	mode_t = 0.0
	fire_t = 0.0
	flash_t = 0.0
	ev_list = []
	for ap in foley_players:
		(ap as AudioStreamPlayer).stop()   # đổi súng / bỏ nạp giữa chừng thì tắt tiếng kéo khoá, băng đạn
	if flash != null:
		flash.visible = false
	_play("idle", 0.05)


func set_slide_locked(_locked: bool) -> void:
	pass


func is_slide_locked() -> bool:
	return false


func land(strength: float) -> void:
	land_off = minf(land_off - 0.035 * strength, 0.0)


func dry_fire() -> void:
	pass   # model không có animation bắn rỗng, và game đã bỏ tiếng "cạch" chung


## Bắn: chạy animation bắn (3 kiểu như model gốc) + loé lửa đầu nòng + tiếng bắn.
func fire(_last_round: bool) -> void:
	if mode == Mode.INSPECT:
		cancel()
	shoot_i = (shoot_i + 1) % 3
	var nm := "shoot%d" % (shoot_i + 1)
	_play(nm, 0.0)
	fire_t = _anim_len(nm, 0.42)
	flash_t = 0.04
	if flash != null:
		flash.visible = true
		flash.global_position = muzzle_global()
	_play_snd("mp5-1", false, randf_range(0.97, 1.03))
	sound.emit("shot_mp5")


## Vị trí đầu nòng trong thế giới (theo xương "flash" đang chuyển động) cho vạch đạn.
func muzzle_global() -> Vector3:
	if skel != null and muzzle_bone >= 0:
		var t: Transform3D = skel.global_transform * skel.get_bone_global_pose(muzzle_bone)
		return t.origin
	return global_transform * Vector3(0.12, -0.11, -0.9)


# =====================================================================
#  NỘI BỘ
# =====================================================================
func _start_mode(m: int, anim_name: String, total_len: float, speed: float, events: Array) -> void:
	mode = m
	mode_t = 0.0
	fire_t = 0.0
	insert_sent = false
	mode_speed = maxf(speed, 0.01)
	mode_len = total_len
	insert_at = RELOAD_INSERT_AT / mode_speed
	ev_list = events
	ev_i = 0
	_play(anim_name, 0.03, speed)


func _process(delta: float) -> void:
	delta = minf(delta, 0.05)
	# đồng hồ của hành động (rút súng / nạp đạn / inspect) chạy song song với animation của model
	if mode != Mode.NONE:
		mode_t += delta
		# tiếng động theo đúng thời điểm sự kiện của model (đã quy theo tốc độ animation)
		while ev_i < ev_list.size() and mode_t * mode_speed >= float((ev_list[ev_i] as Array)[0]):
			_play_snd(str((ev_list[ev_i] as Array)[1]), true)
			ev_i += 1
		if mode == Mode.RELOAD and not insert_sent and mode_t >= insert_at:
			insert_sent = true
			reload_inserted.emit()
		if mode_t >= mode_len:
			var finished := mode
			mode = Mode.NONE
			mode_t = 0.0
			ev_list = []
			_play("idle", 0.08)
			var nm := "draw"
			if finished == Mode.RELOAD:
				nm = "reload"
				if not insert_sent:
					insert_sent = true
					reload_inserted.emit()
			elif finished == Mode.INSPECT:
				nm = "inspect"
			action_finished.emit(nm)
	elif fire_t > 0.0:
		fire_t -= delta
		if fire_t <= 0.0:
			fire_t = 0.0
			_play("idle", 0.08)
	if idle_hold_t > 0.0:
		idle_hold_t -= delta
		if idle_hold_t <= 0.0 and anim != null and mode == Mode.NONE and fire_t <= 0.0:
			anim.pause()   # súng đứng yên: không cần cập nhật bộ xương mỗi khung hình (đỡ tốn máy yếu)
	if flash_t > 0.0:
		flash_t -= delta
		if flash != null:
			flash.global_position = muzzle_global()
			if flash_t <= 0.0:
				flash.visible = false

	# lắc nhẹ theo chuột + nhún khi đi + dội khi tiếp đất (cộng lên trên animation của model)
	var target := Vector2(clampf(-mouse_delta.x * 0.0005, -0.018, 0.018), clampf(mouse_delta.y * 0.0005, -0.018, 0.018))
	mouse_delta = Vector2.ZERO
	sway = sway.lerp(target, 1.0 - exp(-9.0 * delta))
	bob_t += delta * (3.0 + move_amount * 7.0)
	var bob := Vector3(sin(bob_t) * 0.004, -absf(cos(bob_t)) * 0.005, 0.0) * move_amount
	land_off = lerpf(land_off, 0.0, 1.0 - exp(-10.0 * delta))
	if rig != null:
		rig.position = VM_OFFSET + Vector3(sway.x, sway.y + land_off, 0.0) + bob
