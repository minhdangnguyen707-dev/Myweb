extends RefCounted
## Công cụ dựng lưới bằng code (lớp MB) cho mô hình M4A1 (scripts/rifle.gd).
## Trước đây nằm trong ak47.gd; khi AK-47 được thay bằng model thật (assets/ak47/v_ak47.glb) thì tách ra file này để M4A1 vẫn chạy.

# =====================================================================
#  CÔNG CỤ DỰNG LƯỚI: gộp nhiều chi tiết nhỏ thành MỘT khối lưới
# =====================================================================
## Mặt cắt đa giác (lồi, hoặc lõm như báng súng) được "đùn" dọc trục Z (từ z0 đến z1), có thể thu nhỏ dần về phía z1.
## Hộp, hình trụ, thanh chéo đều là trường hợp riêng. Có màu đỉnh (nhân với ảnh vân),
## tự tính pháp tuyến (cạnh nhẹ thì làm mịn, cạnh gắt thì giữ sắc) và chiều mặt (Godot: thuận kim đồng hồ = mặt trước).
class MB:
	extends RefCounted
	var verts := PackedVector3Array()
	var norms := PackedVector3Array()
	var uvs := PackedVector2Array()
	var cols := PackedColorArray()
	var idx := PackedInt32Array()
	var uv_scale := Vector2(6.0, 12.0)

	func _uv(p: Vector3, n: Vector3) -> Vector2:
		var an := n.abs()
		if an.y >= an.x and an.y >= an.z:
			return Vector2(p.z * uv_scale.x, p.x * uv_scale.y)
		if an.x >= an.z:
			return Vector2(p.z * uv_scale.x, p.y * uv_scale.y)
		return Vector2(p.x * uv_scale.y, p.y * uv_scale.y)

	func _push(p: Vector3, n: Vector3, col: Color, uv_n: Vector3) -> int:
		verts.append(p)
		norms.append(n)
		uvs.append(_uv(p, uv_n))
		cols.append(col)
		return verts.size() - 1

	func _tri(a: int, b: int, c: int, n: Vector3) -> void:
		var cr := (verts[b] - verts[a]).cross(verts[c] - verts[a])
		if cr.dot(n) > 0.0:
			idx.append(a)
			idx.append(c)
			idx.append(b)
		else:
			idx.append(a)
			idx.append(b)
			idx.append(c)

	func add_prism(profile: PackedVector2Array, z0: float, z1: float, xf: Transform3D, col: Color, end_scale: float = 1.0, caps: bool = true) -> void:
		var n := profile.size()
		if n < 3:
			return
		var pts := profile
		var area := 0.0
		for i in n:
			var pa := pts[i]
			var pb := pts[(i + 1) % n]
			area += pa.x * pb.y - pb.x * pa.y
		if area < 0.0:
			pts = PackedVector2Array()
			for i in range(n - 1, -1, -1):
				pts.append(profile[i])
		var en: Array = []
		for i in n:
			var d := pts[(i + 1) % n] - pts[i]
			var nn := Vector2(d.y, -d.x)
			if nn.length() < 0.0000001:
				nn = Vector2(0.0, 1.0)
			en.append(nn.normalized())
		for i in n:
			var j := (i + 1) % n
			var k := (i + n - 1) % n
			var e: Vector2 = en[i]
			var ep: Vector2 = en[k]
			var enx: Vector2 = en[j]
			var na := e
			if e.dot(ep) > 0.6:
				na = (e + ep).normalized()
			var nb := e
			if e.dot(enx) > 0.6:
				nb = (e + enx).normalized()
			_quad(pts[i], pts[j], na, nb, e, z0, z1, xf, col, end_scale)
		if caps:
			var nz0 := Vector3(0.0, 0.0, 1.0 if z0 > z1 else -1.0)
			_cap(pts, z0, 1.0, nz0, xf, col)
			_cap(pts, z1, end_scale, -nz0, xf, col)

	func _quad(a: Vector2, b: Vector2, na2: Vector2, nb2: Vector2, e2: Vector2, z0: float, z1: float, xf: Transform3D, col: Color, es: float) -> void:
		var pa0 := xf * Vector3(a.x, a.y, z0)
		var pb0 := xf * Vector3(b.x, b.y, z0)
		var pb1 := xf * Vector3(b.x * es, b.y * es, z1)
		var pa1 := xf * Vector3(a.x * es, a.y * es, z1)
		var fn := (xf.basis * Vector3(e2.x, e2.y, 0.0)).normalized()
		var na := (xf.basis * Vector3(na2.x, na2.y, 0.0)).normalized()
		var nb := (xf.basis * Vector3(nb2.x, nb2.y, 0.0)).normalized()
		var i0 := _push(pa0, na, col, fn)
		var i1 := _push(pb0, nb, col, fn)
		var i2 := _push(pb1, nb, col, fn)
		var i3 := _push(pa1, na, col, fn)
		_tri(i0, i1, i2, fn)
		_tri(i0, i2, i3, fn)

	func _is_convex(pts: PackedVector2Array) -> bool:
		var n := pts.size()
		var sgn := 0.0
		for i in n:
			var a := pts[i]
			var b := pts[(i + 1) % n]
			var c := pts[(i + 2) % n]
			var cr := (b - a).cross(c - b)
			if absf(cr) < 0.000000000001:
				continue
			if sgn == 0.0:
				sgn = signf(cr)
			elif signf(cr) != sgn:
				return false
		return true

	func _cap(pts: PackedVector2Array, z: float, s: float, nz: Vector3, xf: Transform3D, col: Color) -> void:
		var wn := (xf.basis * nz).normalized()
		var first := verts.size()
		for p in pts:
			_push(xf * Vector3(p.x * s, p.y * s, z), wn, col, wn)
		# mặt cắt lõm (như báng súng) phải chia tam giác đúng cách, mặt cắt lồi thì quạt từ đỉnh đầu như cũ
		var tri := PackedInt32Array()
		if not _is_convex(pts):
			tri = Geometry2D.triangulate_polygon(pts)
		if tri.size() >= 3:
			for i in range(0, tri.size() - 2, 3):
				_tri(first + tri[i], first + tri[i + 1], first + tri[i + 2], wn)
		else:
			for i in range(1, pts.size() - 1):
				_tri(first, first + i, first + i + 1, wn)

	func add_box(size: Vector3, xf: Transform3D, col: Color) -> void:
		var hw := size.x * 0.5
		var hh := size.y * 0.5
		var prof := PackedVector2Array([Vector2(-hw, -hh), Vector2(hw, -hh), Vector2(hw, hh), Vector2(-hw, hh)])
		add_prism(prof, size.z * 0.5, -size.z * 0.5, xf, col)

	func add_cyl(r: float, z0: float, z1: float, xf: Transform3D, col: Color, segs: int = 10, end_scale: float = 1.0) -> void:
		var prof := PackedVector2Array()
		for i in segs:
			var ang := TAU * float(i) / float(segs)
			prof.append(Vector2(cos(ang) * r, sin(ang) * r))
		add_prism(prof, z0, z1, xf, col, end_scale)

	## Thanh nối hai điểm a -> b (toạ độ trong cùng hệ với mesh). w = bề rộng (theo X), h = bề dày vuông góc.
	func add_rod(a: Vector3, b: Vector3, w: float, h: float, col: Color, rad: float = 0.002, end_scale: float = 1.0) -> void:
		var d := b - a
		var length := d.length()
		if length < 0.0001:
			return
		var dn := d / length
		var zax := -dn
		var xax := Vector3.RIGHT - zax * Vector3.RIGHT.dot(zax)
		if xax.length() < 0.1:
			xax = Vector3.UP - zax * Vector3.UP.dot(zax)
		xax = xax.normalized()
		var yax := zax.cross(xax)
		var xf := Transform3D(Basis(xax, yax, zax), (a + b) * 0.5)
		var r := minf(rad, minf(w, h) * 0.45)
		var seg := 2
		var hw := w * 0.5
		var hh := h * 0.5
		var pts := PackedVector2Array()
		if r < 0.0004:
			pts = PackedVector2Array([Vector2(-hw, -hh), Vector2(hw, -hh), Vector2(hw, hh), Vector2(-hw, hh)])
		else:
			var corners := [
				[Vector2(hw - r, -hh + r), -90.0],
				[Vector2(hw - r, hh - r), 0.0],
				[Vector2(-hw + r, hh - r), 90.0],
				[Vector2(-hw + r, -hh + r), 180.0],
			]
			for c in corners:
				var ctr: Vector2 = c[0]
				var a0: float = c[1]
				for s in range(seg + 1):
					var ang := deg_to_rad(a0 + 90.0 * float(s) / float(seg))
					pts.append(ctr + Vector2(cos(ang), sin(ang)) * r)
		add_prism(pts, length * 0.5, -length * 0.5, xf, col, end_scale)

	func make_mesh() -> ArrayMesh:
		var arrays := []
		arrays.resize(Mesh.ARRAY_MAX)
		arrays[Mesh.ARRAY_VERTEX] = verts
		arrays[Mesh.ARRAY_NORMAL] = norms
		arrays[Mesh.ARRAY_TEX_UV] = uvs
		arrays[Mesh.ARRAY_COLOR] = cols
		arrays[Mesh.ARRAY_INDEX] = idx
		var mesh := ArrayMesh.new()
		mesh.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, arrays)
		return mesh
