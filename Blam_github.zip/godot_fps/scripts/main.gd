extends Node3D
## Quản lý trận đấu: nạp map, tạo va chạm + navmesh, spawn người chơi/bot, điểm số, hiệu ứng.

const BombScript := preload("res://scripts/bomb.gd")           # chế độ ĐẶT BOM (CT gỡ bom / T đặt bom)
const PickupsScript := preload("res://scripts/pickups.gd")     # súng rơi dưới đất: nhìn + E nhặt, G vứt
const Skins := preload("res://scripts/skins.gd")          # skin nhân vật: cửa hàng + bộ sưu tập (sảnh chờ)
const UI := preload("res://scripts/ui_theme.gd")          # màu + kiểu nút chung cho sảnh chờ / cửa hàng
const UIIcon := preload("res://scripts/ui_icon.gd")      # hình súng nhỏ vẽ bằng code
const UI_BASE_H := 405.0                                  # chiều cao khung thiết kế giao diện (đơn vị ảo)
const KILL_LIMIT := 25
const BOTS_CT := 2
const BOTS_T := 3
# Cấu hình từng bản đồ của chế độ ĐẤU ĐỘI / ĐẶT BOM. Thêm bản đồ mới: thêm một mục ở đây + một dòng trong LOBBY_MAPS.
#  file = tệp .glb | bots_ct / bots_t = số bot cùng phe người chơi / phe địch (3 đấu 3 = 2 và 3, 5 đấu 5 = 4 và 5)
#  probe_a, probe_b = hai điểm thử đường đi (phải cần rẽ ít nhất một lần) | half = nửa cạnh khu chơi, có tường vô hình bao quanh
#  nav_aabb = vùng bake navmesh | site_want = 2 điểm đặt bom (x, z) | wp_* = cách rải điểm tuần tra của bot
#  spawn_ct / spawn_t = các điểm xuất phát của hai phe: Vector2 (x, z) hoặc Vector3 (x, độ cao mặt sàn, z) cho map nhiều tầng
#  site_ymax / spawn_ymax = độ cao tối đa của mặt đất đặt bom / điểm xuất phát (mặc định 0.6 / 0.7) | wp_y = khoảng độ cao thử rải điểm tuần tra | unshaded = map đã nướng sẵn ánh sáng vào màu đỉnh
const MAP_CFG := {
	"default": {
		"file": "res://assets/map.glb", "bots_ct": 2, "bots_t": 3,
		"probe_a": Vector3(0.0, 0.1, -20.0), "probe_b": Vector3(0.0, 0.1, 20.0),
		"site_want": [Vector2(-6.5, 0.0), Vector2(6.5, 0.0)],
	},
	"mirage": {
		"file": "res://assets/mirage_map.glb", "bots_ct": 4, "bots_t": 5,
		"probe_a": Vector3(-37.58, 0.3, 22.34), "probe_b": Vector3(36.99, 2.8, -20.46),
		"nav_aabb": AABB(Vector3(-62.0, -4.0, -80.0), Vector3(118.0, 28.0, 156.0)),
		"site_want": [Vector2(-5.07, 28.43), Vector2(-45.91, -32.33)],
		"site_ymax": 3.6, "spawn_ymax": 4.0, "unshaded": true,
		"wp_x": 58.0, "wp_z": 78.0, "wp_y": Vector2(0.4, 6.0), "wp_tries": 1800, "wp_gap": 5.0, "wp_max": 170,
		"spawn_ct": [Vector3(-40.38, -0.18, 22.34), Vector3(-39.00, 0.25, 24.37), Vector3(-39.00, 0.25, 19.90), Vector3(-37.58, 0.25, 22.34), Vector3(-35.96, 0.25, 19.90), Vector3(-34.74, 0.25, 22.13), Vector3(-35.96, 0.25, 24.37), Vector3(-35.35, 0.25, 26.81), Vector3(-34.48, 0.25, 18.17), Vector3(-33.31, 0.25, 20.10), Vector3(-33.31, 0.25, 24.16), Vector3(-41.50, -0.41, 19.93), Vector3(-41.50, -0.41, 24.40), Vector3(-44.24, -0.84, 19.82), Vector3(-44.24, -0.84, 24.29), Vector3(-37.12, 0.25, 18.12)],
		"spawn_t": [Vector3(38.72, 2.69, -24.45), Vector3(36.99, 2.69, -22.90), Vector3(36.99, 2.69, -18.03), Vector3(36.99, 2.69, -20.46), Vector3(39.02, 2.69, -21.76), Vector3(39.02, 2.69, -26.64), Vector3(41.06, 2.69, -25.42), Vector3(41.06, 2.69, -22.98), Vector3(39.02, 2.69, -17.69), Vector3(41.06, 2.69, -20.54), Vector3(41.06, 2.69, -18.10), Vector3(34.91, 2.69, -17.91), Vector3(34.91, 2.69, -25.30), Vector3(34.91, 2.69, -22.79), Vector3(34.91, 2.69, -20.35), Vector3(37.04, 2.69, -25.82)],
	}
}
const BOT_NAMES := ["Alpha", "Bravo", "Charlie", "Delta", "Echo", "Foxtrot", "Golf", "Hotel", "India"]

var world: Node3D
var map_root: Node3D
var nav_region: NavigationRegion3D
var nav_map: RID
var nav_ok := false

var load_center: Control              # tên game + thanh tải (ẩn khi vào sảnh chờ)
var lobby_tab_btns: Array = []
var lobby_tab_dots: Array = []
var lobby_head: Label
var lobby_sub: Label
var lobby_row: HBoxContainer
var lobby_back: Button
var lobby_play_box: Control
var lobby_shop_box: Control      # trang CỬA HÀNG trong sảnh
var lobby_coll_box: Control      # trang BỘ SƯU TẬP trong sảnh
var lobby_shop_row: HBoxContainer
var lobby_coll_row: HBoxContainer
var lobby_shop_msg: Label
var lobby_coll_msg: Label
var skin_menu: Control = null    # menu chuột phải của skin (đang mở)
var skins = null                 # Skins: đã mua / đang dùng, lưu ở user://skins.cfg
var lobby_mode := ""                 # chế độ đã chọn: "tdm" hoặc "bomb"
var loaded_map := "default"          # bản đồ ĐẤU ĐỘI / ĐẶT BOM đang nằm trong thế giới
var bots_ct := BOTS_CT
var bots_t := BOTS_T
var site_ymax := 0.6                  # độ cao tối đa của "mặt đất" đặt bom (bomb.gd đọc)
var site_want: Array = [Vector2(-6.5, 0.0), Vector2(6.5, 0.0)]   # 2 điểm đặt bom của bản đồ đang chơi (bomb.gd đọc)
var bomb = null                      # chế độ ĐẶT BOM (scripts/bomb.gd), null khi không chơi chế độ này
var touch = null                     # nút cảm ứng cho điện thoại (scripts/touch_controls.gd)
var pickups = null                   # súng rơi dưới đất (scripts/pickups.gd)
var round_frozen := false            # đang thời gian chuẩn bị round: mọi người đứng yên
var player_locked := false           # người chơi đang giữ E đặt/gỡ bom nên không di chuyển
var lobby_step := 0                  # 0 = chọn chế độ, 1 = chọn bản đồ, 2 = chọn phe
var env: Environment
var sun: DirectionalLight3D
var waypoints: Array = []
var spawns: Array = [[], []]   # [0] = CT (phía bắc, z âm), [1] = T (phía nam, z dương)

var player: Player
var bots: Array = []
var hud: Hud
var team_score := [0, 0]
var match_over := false
var loading_label: Label
var ui_layer: CanvasLayer
var progress: ProgressBar
var load_box: Control
var menu_box: Control
var in_menu := true
var path_budget_frame := -1   # khung hình gần nhất đã cấp quyền tìm đường

# --- kinh tế + cửa hàng ---
const START_MONEY := 3000
const KILL_REWARD := 300
const HEADSHOT_BONUS := 100
const PRICE_M4 := 2700
const PRICE_AK := 2700   # AK-47: $2700 như CS:GO / CS2 (CS 1.6 là $2500)
const PRICE_DEAGLE := 700   # Desert Eagle: $700 như CS2
const PRICE_AWP := 4750   # AWP: $4750 như CS:GO / CS2
const PRICE_MP5 := 1400   # MP5-SD: $1400 như CS2 (dữ liệu game mới nhất; bản CS:GO cũ là $1500)
const MP5_KILL_REWARD := 600   # thưởng hạ gục bằng MP5-SD: $600 như CS2 (SMG thưởng cao hơn súng trường)
const PRICE_AMMO := 200
var money := START_MONEY
var shop_open := false
var shop_layer: CanvasLayer
var shop_money_label: Label
var shop_cards: Dictionary = {}      # id hàng -> {btn, price, tick}
var ui_theme: Theme
var ui_roots: Array = []             # các khung giao diện tự co theo độ phân giải
var fx_root: Node3D
var decals: Array = []
var hole_tex: ImageTexture
var decal_mat: StandardMaterial3D
var tracer_mat: StandardMaterial3D
var spark_mat: StandardMaterial3D
var blood_mat: StandardMaterial3D
var score_timer := 0.0
var paused_menu := false
var debug_on := false

# --- pool tái sử dụng (tránh tạo/huỷ node liên tục khi giao tranh đông) ---
var burst_pools: Dictionary = {}
var burst_idx: Dictionary = {}
var tracer_pool: Array = []
var tracer_time: Array = []
var tracer_i := 0

# --- tự động giảm độ phân giải 3D khi máy yếu (giữ FPS ổn định) ---
const SETTINGS_PATH := "user://settings.cfg"
# cùng chiều cao với bảng 16:9 bên dưới, nhưng tỉ lệ 4:3
const RES_STEPS_43 := [Vector2i(960, 720), Vector2i(720, 540), Vector2i(640, 480), Vector2i(540, 405), Vector2i(480, 360), Vector2i(420, 315), Vector2i(360, 270), Vector2i(320, 240)]
const RES_STEPS := [Vector2i(1280, 720), Vector2i(960, 540), Vector2i(854, 480), Vector2i(720, 405), Vector2i(640, 360), Vector2i(560, 315), Vector2i(480, 270), Vector2i(427, 240)]
var res_idx := 1   # mặc định 960x540 (nét hơn trước, máy giật thì tự hạ xuống)
var aspect_43 := false              # false = 16:9 (mặc định), true = 4:3
var settings_layer: CanvasLayer
var sub: SubViewport                 # nơi vẽ thế giới 3D (độ phân giải riêng, F4 chỉnh cái này)
var cam3d: Camera3D                  # camera vẽ 3D, bám theo camera của người chơi
var view_tex: TextureRect            # phóng ảnh 3D ra đầy màn hình (giao diện nằm phía trên, luôn nét)
var settings_open := false
var aspect_btns: Array = []         # [nút 16:9, nút 4:3]
var left_hand := false              # cài đặt: cầm súng tay trái
var left_btns: Array = []           # [nút TẮT, nút BẬT]
var cpu_saver := false
var res_check_pending := false   # đã hạ độ phân giải, đang chờ xem FPS có khá hơn không
var res_prev_avg := 0.0
var res_prev_idx := 1
var auto_res := true
var res_cooldown := 5.0
var fps_acc := 0.0
var fps_frames := 0


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	Engine.max_fps = 144   # vsync đã tắt (bật vsync trên màn 60 Hz làm FPS rơi thẳng xuống 30 khi chậm hơn một chút)
	var args := OS.get_cmdline_user_args()
	if "low" in args:
		res_idx = 5
	elif "high" in args:
		res_idx = 0
		auto_res = false
	_load_settings()
	skins = Skins.new()
	skins.load_state()
	_apply_ui_scale()
	_build_view3d()
	_setup_input()
	_setup_touch()
	_setup_environment()
	world = Node3D.new()
	world.process_mode = Node.PROCESS_MODE_PAUSABLE
	add_child(world)
	fx_root = Node3D.new()
	world.add_child(fx_root)
	_make_fx_resources()

	_build_loading_ui()
	_build_shop()
	_build_settings()
	await get_tree().process_frame
	await get_tree().process_frame
	var loaded: bool = await _start_game()
	if loaded:
		await _warmup()
		_show_menu()


# =====================================================================
#  MÀN HÌNH LOADING + MENU CHÍNH
# =====================================================================
func _make_label(text: String, size: int, color: Color = Color(1, 1, 1)) -> Label:
	var l := Label.new()
	l.text = text
	l.add_theme_font_size_override("font_size", size)
	l.add_theme_color_override("font_color", color)
	l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	return l


## Khung giao diện có kích thước "ảo" 720x405, tách riêng khỏi độ phân giải 3D.
func _ui_root(layer: CanvasLayer) -> Control:
	var r := Control.new()
	r.set_anchors_preset(Control.PRESET_TOP_LEFT)
	r.mouse_filter = Control.MOUSE_FILTER_IGNORE
	r.theme = ui_theme
	layer.add_child(r)
	ui_roots.append(r)
	_fit_ui()
	return r


func _fit_ui() -> void:
	var vp := Vector2(get_window().content_scale_size)
	if vp.y <= 0.0:
		return
	var u := clampf(vp.y / UI_BASE_H, 0.4, 2.0)
	for r in ui_roots:
		(r as Control).scale = Vector2(u, u)
		(r as Control).size = vp / u


func _spacer(h: float) -> Control:
	var c := Control.new()
	c.custom_minimum_size = Vector2(0, h)
	c.mouse_filter = Control.MOUSE_FILTER_IGNORE
	return c


func _build_loading_ui() -> void:
	ui_theme = UI.make_theme()
	ui_layer = CanvasLayer.new()
	ui_layer.layer = 50
	add_child(ui_layer)
	var bg := ColorRect.new()
	bg.color = Color(0, 0, 0)
	bg.set_anchors_preset(Control.PRESET_FULL_RECT)
	ui_layer.add_child(bg)
	var root := _ui_root(ui_layer)
	var center := CenterContainer.new()
	center.set_anchors_preset(Control.PRESET_FULL_RECT)
	root.add_child(center)
	load_center = center
	var vb := VBoxContainer.new()
	vb.custom_minimum_size = Vector2(260, 0)
	vb.add_theme_constant_override("separation", 0)
	center.add_child(vb)

	# --- tên game + một vạch nhấn ---
	var title := _make_label("GLOCK FPS", 44, UI.TEXT)
	title.add_theme_font_override("font", UI.title_font())
	vb.add_child(title)
	vb.add_child(_spacer(12))
	var mark := ColorRect.new()
	mark.color = UI.ACCENT
	mark.custom_minimum_size = Vector2(28, 2)
	mark.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	vb.add_child(mark)
	vb.add_child(_spacer(44))

	# --- khối đang tải: một thanh mảnh + một dòng nhỏ ---
	var lb := VBoxContainer.new()
	lb.add_theme_constant_override("separation", 10)
	lb.custom_minimum_size = Vector2(260, 0)
	lb.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	vb.add_child(lb)
	load_box = lb
	progress = ProgressBar.new()
	progress.min_value = 0.0
	progress.max_value = 100.0
	progress.value = 0.0
	progress.show_percentage = false
	progress.custom_minimum_size = Vector2(0, 3)
	lb.add_child(progress)
	loading_label = _make_label("", 12, UI.MUTED)
	loading_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	lb.add_child(loading_label)

	_build_lobby(root)


# =====================================================================
#  SẢNH CHỜ kiểu Valorant: danh sách bên trái, nền đen
#  CHƠI -> chọn chế độ -> chọn bản đồ -> vào game
# =====================================================================
const LOBBY_TABS := ["CHƠI", "BỘ SƯU TẬP", "CỬA HÀNG"]
const LOBBY_MODES := [
	{"id": "tdm", "name": "ĐẤU ĐỘI", "desc": "Đấu với bot, đội nào hạ đủ 25 mạng trước thì thắng"},
	{"id": "bomb", "name": "ĐẶT BOM", "desc": "3 hoặc 5 đấu 5, CT gỡ bom, T đặt bom"},
]
const LOBBY_SIDES := [
	{"id": 0, "name": "CT", "desc": "Gỡ bom"},
	{"id": 1, "name": "T", "desc": "Đặt bom"},
]
# Muốn thêm bản đồ: thêm một dòng {"id": ..., "name": ..., "desc": ...} vào danh sách của chế độ đó,
# rồi _lobby_pick_map (dựng bản đồ qua _switch_classic_map, nhớ bản đồ hiện tại trong loaded_map) sẽ tự dùng.
const LOBBY_MAPS := {
	"tdm": [{"id": "default", "name": "MINI SIZE", "desc": "Bản đồ nhỏ, 3 đấu 3"}, {"id": "mirage", "name": "MIRAGE", "desc": "Map CS 1.6 Mirage, 5 đấu 5"}],
	"bomb": [{"id": "default", "name": "MINI SIZE", "desc": "Bản đồ nhỏ, 3 đấu 3, hai điểm A và B"}, {"id": "mirage", "name": "MIRAGE", "desc": "Map CS 1.6 Mirage, 5 đấu 5, hai điểm A và B"}],
}


func _lobby_btn(text: String, size: int, col: Color) -> Button:
	var b := Button.new()
	b.text = text
	b.flat = true
	b.focus_mode = Control.FOCUS_NONE
	b.alignment = HORIZONTAL_ALIGNMENT_LEFT
	b.add_theme_font_override("font", UI.lobby_font())
	b.add_theme_font_size_override("font_size", size)
	for st in ["normal", "hover", "pressed", "disabled", "focus"]:
		b.add_theme_stylebox_override(st, StyleBoxEmpty.new())
	_lobby_color(b, col)
	return b


func _lobby_color(b: Button, col: Color) -> void:
	b.add_theme_color_override("font_color", col)
	b.add_theme_color_override("font_hover_color", Color(1, 1, 1) if col != UI.LV_TEAL else col)
	b.add_theme_color_override("font_pressed_color", UI.LV_TEAL)
	b.add_theme_color_override("font_focus_color", col)


func _lobby_dot() -> ColorRect:
	var d := ColorRect.new()
	d.color = UI.LV_TEXT
	d.custom_minimum_size = Vector2(4, 4)
	d.rotation = PI * 0.25
	d.pivot_offset = Vector2(2, 2)
	d.mouse_filter = Control.MOUSE_FILTER_IGNORE
	return d


func _lobby_row(btn: Button) -> Array:
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 6)
	var holder := CenterContainer.new()
	holder.custom_minimum_size = Vector2(12, 0)
	holder.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var dot := _lobby_dot()
	holder.add_child(dot)
	row.add_child(holder)
	row.add_child(btn)
	return [row, dot]


func _build_lobby(root: Control) -> void:
	var mb := Control.new()
	mb.set_anchors_preset(Control.PRESET_FULL_RECT)
	mb.mouse_filter = Control.MOUSE_FILTER_IGNORE
	mb.visible = false
	root.add_child(mb)
	menu_box = mb

	# --- danh sách bên trái ---
	var list := VBoxContainer.new()
	# căn xuống đáy màn hình, góc trái: danh sách mọc lên trên, mục dưới cùng (THOÁT) đứng yên
	list.set_anchors_preset(Control.PRESET_BOTTOM_LEFT)
	list.offset_left = 14.0
	list.offset_bottom = -26.0
	list.grow_vertical = Control.GROW_DIRECTION_BEGIN
	list.add_theme_constant_override("separation", 4)
	mb.add_child(list)
	for i in LOBBY_TABS.size():
		var b := _lobby_btn(LOBBY_TABS[i], 22, UI.LV_TEXT)
		b.pressed.connect(_lobby_set_tab.bind(i))
		var rd := _lobby_row(b)
		list.add_child(rd[0])
		lobby_tab_btns.append(b)
		lobby_tab_dots.append(rd[1])
	list.add_child(_spacer(10))
	var set_b := _lobby_btn("CÀI ĐẶT", 22, UI.LV_TEXT)
	set_b.pressed.connect(_open_settings)
	list.add_child(_lobby_row(set_b)[0])
	var quit_b := _lobby_btn("THOÁT", 22, UI.LV_TEXT)
	quit_b.pressed.connect(func(): get_tree().quit())
	list.add_child(_lobby_row(quit_b)[0])

	# --- vùng nội dung bên phải danh sách ---
	var area := MarginContainer.new()
	area.set_anchors_preset(Control.PRESET_FULL_RECT)
	area.add_theme_constant_override("margin_left", 210)
	area.add_theme_constant_override("margin_top", 62)
	area.add_theme_constant_override("margin_right", 40)
	area.add_theme_constant_override("margin_bottom", 40)
	area.mouse_filter = Control.MOUSE_FILTER_IGNORE
	mb.add_child(area)

	var pv := VBoxContainer.new()
	pv.add_theme_constant_override("separation", 10)
	pv.mouse_filter = Control.MOUSE_FILTER_IGNORE
	area.add_child(pv)
	lobby_play_box = pv
	pv.resized.connect(_lobby_fit_cards)
	pv.visible = false   # chỉ hiện khi bấm CHƠI
	lobby_head = Label.new()
	lobby_head.add_theme_font_override("font", UI.lobby_font())
	lobby_head.add_theme_font_size_override("font_size", 28)
	lobby_head.add_theme_color_override("font_color", UI.LV_TEXT)
	pv.add_child(lobby_head)
	lobby_sub = Label.new()
	lobby_sub.add_theme_font_size_override("font_size", 13)
	lobby_sub.add_theme_color_override("font_color", UI.LV_MUTED)
	pv.add_child(lobby_sub)
	lobby_row = HBoxContainer.new()
	lobby_row.add_theme_constant_override("separation", 10)
	lobby_row.mouse_filter = Control.MOUSE_FILTER_IGNORE
	pv.add_child(lobby_row)
	lobby_back = _lobby_btn("< QUAY LẠI", 16, UI.LV_MUTED)
	lobby_back.pressed.connect(_lobby_back)
	pv.add_child(lobby_back)

	var cp := _lobby_skin_page("BỘ SƯU TẬP", "Chuột phải vào skin để chọn cách dùng")
	area.add_child(cp[0])
	lobby_coll_box = cp[0]
	lobby_coll_row = cp[1]
	lobby_coll_msg = cp[2]
	var sp := _lobby_skin_page("CỬA HÀNG", "Skin nhân vật · hiện đang miễn phí")
	area.add_child(sp[0])
	lobby_shop_box = sp[0]
	lobby_shop_row = sp[1]
	lobby_shop_msg = sp[2]


func _lobby_set_tab(i: int, open_panel: bool = true) -> void:
	for j in lobby_tab_btns.size():
		var b: Button = lobby_tab_btns[j]
		var on := j == i
		# mở trang BỘ SƯU TẬP / CỬA HÀNG thì chữ tab đang chọn chỉ to vừa phải, để không chèn lên khung nội dung bên phải
		var big := 28 if (open_panel and i != 0) else 44
		b.add_theme_font_size_override("font_size", big if on else 22)
		_lobby_color(b, UI.LV_TEAL if on else UI.LV_TEXT)
		(lobby_tab_dots[j] as ColorRect).color = UI.LV_TEAL if on else UI.LV_TEXT
	lobby_play_box.visible = open_panel and i == 0
	lobby_coll_box.visible = open_panel and i == 1
	lobby_shop_box.visible = open_panel and i == 2
	_close_skin_menu()
	if open_panel and i == 1:
		_lobby_fill_collection()
	elif open_panel and i == 2:
		_lobby_fill_shop()
	if open_panel and i == 0:
		_lobby_show_modes()


## Một trang trong sảnh (BỘ SƯU TẬP / CỬA HÀNG): tiêu đề, dòng phụ, hàng thẻ skin, dòng thông báo. Trả về [hộp, hàng thẻ, nhãn thông báo].
func _lobby_skin_page(title: String, sub: String) -> Array:
	var box := VBoxContainer.new()
	box.add_theme_constant_override("separation", 10)
	box.mouse_filter = Control.MOUSE_FILTER_IGNORE
	box.visible = false
	var hl := Label.new()
	hl.text = title
	hl.add_theme_font_override("font", UI.lobby_font())
	hl.add_theme_font_size_override("font_size", 28)
	hl.add_theme_color_override("font_color", UI.LV_TEXT)
	box.add_child(hl)
	var sl := Label.new()
	sl.text = sub
	sl.add_theme_font_size_override("font_size", 13)
	sl.add_theme_color_override("font_color", UI.LV_MUTED)
	box.add_child(sl)
	# hàng thẻ nằm trong khung cuộn ngang: nhiều skin hơn chiều rộng thì lăn chuột / kéo thanh cuộn để xem
	var sc := ScrollContainer.new()
	sc.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_AUTO
	sc.vertical_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	sc.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	sc.custom_minimum_size = Vector2(0, 222)
	sc.gui_input.connect(func(ev: InputEvent):
		if ev is InputEventMouseButton and (ev as InputEventMouseButton).pressed:
			var bi: int = (ev as InputEventMouseButton).button_index
			if bi == MOUSE_BUTTON_WHEEL_DOWN or bi == MOUSE_BUTTON_WHEEL_RIGHT:
				sc.scroll_horizontal += 80
				sc.accept_event()
			elif bi == MOUSE_BUTTON_WHEEL_UP or bi == MOUSE_BUTTON_WHEEL_LEFT:
				sc.scroll_horizontal = maxi(sc.scroll_horizontal - 80, 0)
				sc.accept_event())
	box.add_child(sc)
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 10)
	row.mouse_filter = Control.MOUSE_FILTER_IGNORE
	sc.add_child(row)
	var msg := Label.new()
	msg.add_theme_font_size_override("font_size", 13)
	msg.add_theme_color_override("font_color", UI.LV_TEAL)
	box.add_child(msg)
	return [box, row, msg]


## Thông tin hiển thị của một skin (Yuri / Terror = skin mặc định của phe, không nằm trong Skins.DATA).
func _skin_info(id: String) -> Dictionary:
	if id == Skins.DEFAULT_CT:
		return {"name": "YURI", "desc": "Skin mặc định phe CT", "icon": "res://assets/yuri/yuri_icon.png"}
	if id == Skins.DEFAULT_T:
		return {"name": "TERROR", "desc": "Skin mặc định phe T", "icon": "res://assets/terror/terror_icon.png"}
	return Skins.DATA[id]


## Thẻ skin: ảnh nhân vật, tên, một dòng trạng thái. Bấm trái = cb; bấm phải = cb_right (nếu có).
func _skin_card(id: String, status: String, status_col: Color, cb: Callable, cb_right: Callable = Callable(), clickable: bool = true) -> Control:
	var info := _skin_info(id)
	var card := Control.new()
	card.custom_minimum_size = Vector2(150, 205)
	card.size_flags_horizontal = Control.SIZE_SHRINK_BEGIN
	var b := Button.new()
	b.set_anchors_preset(Control.PRESET_FULL_RECT)
	b.focus_mode = Control.FOCUS_NONE
	b.disabled = not clickable
	b.add_theme_stylebox_override("normal", UI.box(UI.LV_CARD, UI.LV_CARD_LINE, 1, 0, 0, 0))
	b.add_theme_stylebox_override("hover", UI.box(Color(0.235, 0.95, 0.82, 0.10), UI.LV_TEAL, 1, 0, 0, 0))
	b.add_theme_stylebox_override("pressed", UI.box(Color(0.235, 0.95, 0.82, 0.18), UI.LV_TEAL, 1, 0, 0, 0))
	b.add_theme_stylebox_override("disabled", UI.box(UI.LV_CARD, UI.LV_CARD_LINE, 1, 0, 0, 0))
	b.add_theme_stylebox_override("focus", StyleBoxEmpty.new())
	if clickable and cb.is_valid():
		b.pressed.connect(cb)
	if cb_right.is_valid():
		b.gui_input.connect(func(ev: InputEvent):
			if ev is InputEventMouseButton and (ev as InputEventMouseButton).pressed and (ev as InputEventMouseButton).button_index == MOUSE_BUTTON_RIGHT:
				cb_right.call())
	card.add_child(b)
	var v := VBoxContainer.new()
	v.set_anchors_preset(Control.PRESET_FULL_RECT)
	v.offset_left = 8.0
	v.offset_right = -8.0
	v.offset_top = 8.0
	v.offset_bottom = -10.0
	v.add_theme_constant_override("separation", 4)
	v.mouse_filter = Control.MOUSE_FILTER_IGNORE
	card.add_child(v)
	var tex = null
	if ResourceLoader.exists(str(info["icon"])):
		tex = load(str(info["icon"]))
	var pic := TextureRect.new()
	pic.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	pic.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	pic.size_flags_vertical = Control.SIZE_EXPAND_FILL
	pic.mouse_filter = Control.MOUSE_FILTER_IGNORE
	if tex is Texture2D:
		pic.texture = tex
	v.add_child(pic)
	var nl := Label.new()
	nl.text = str(info["name"])
	nl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	nl.add_theme_font_override("font", UI.lobby_font())
	nl.add_theme_font_size_override("font_size", 17)
	nl.add_theme_color_override("font_color", UI.LV_TEXT)
	nl.mouse_filter = Control.MOUSE_FILTER_IGNORE
	v.add_child(nl)
	var sl := Label.new()
	sl.text = status
	sl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	sl.add_theme_font_size_override("font_size", 11)
	sl.add_theme_color_override("font_color", status_col)
	sl.mouse_filter = Control.MOUSE_FILTER_IGNORE
	v.add_child(sl)
	return card


func _lobby_fill_shop() -> void:
	for c in lobby_shop_row.get_children():
		lobby_shop_row.remove_child(c)
		c.queue_free()
	lobby_shop_msg.text = ""
	for id in Skins.ORDER:
		var have: bool = skins.has_skin(id)
		var price: int = skins.price_of(id)
		var status := ""
		var col: Color = UI.LV_TEAL
		if not have:
			status = "MIỄN PHÍ · BẤM ĐỂ MUA" if price == 0 else "$" + _fmt_money(price)
			col = UI.ACCENT
		lobby_shop_row.add_child(_skin_card(id, status, col, _buy_skin.bind(id), Callable(), not have))


func _buy_skin(id: String) -> void:
	if skins.buy(id):
		_lobby_fill_shop()
		lobby_shop_msg.text = "Đã mua %s." % str((Skins.DATA[id] as Dictionary)["name"])


func _lobby_fill_collection() -> void:
	for c in lobby_coll_row.get_children():
		lobby_coll_row.remove_child(c)
		c.queue_free()
	# skin mặc định của hai phe (luôn có, không có menu): Yuri (CT) và Terror (T)
	for dt in 2:
		var d_on: bool = str(skins.equipped_by[dt]) == ""
		var d_name := "MẶC ĐỊNH CT" if dt == 0 else "MẶC ĐỊNH T"
		lobby_coll_row.add_child(_skin_card(Skins.DEFAULT_CT if dt == 0 else Skins.DEFAULT_T, d_name + (" · ĐANG DÙNG" if d_on else ""), UI.LV_TEAL if d_on else UI.LV_MUTED, Callable(), Callable(), false))
	for id in Skins.ORDER:
		if not skins.has_skin(id):
			continue
		var st: String = skins.status_of(id)
		var on := st != ""
		lobby_coll_row.add_child(_skin_card(id, st if on else "Chuột phải để chọn", UI.LV_TEAL if on else UI.LV_MUTED, _open_skin_menu.bind(id), _open_skin_menu.bind(id)))
	if lobby_coll_row.get_child_count() == 2:
		lobby_coll_msg.text = "Chưa có skin nào. Vào CỬA HÀNG để mua."


func _close_skin_menu() -> void:
	if skin_menu != null and is_instance_valid(skin_menu):
		skin_menu.queue_free()
	skin_menu = null


## Menu chuột phải của một skin: áp dụng / gỡ, dùng cho cả phe, dùng riêng mình.
func _open_skin_menu(id: String) -> void:
	_close_skin_menu()
	var data: Dictionary = Skins.DATA[id]
	var team_txt := "CT" if int(data["team"]) == 0 else "T"
	var on: bool = skins.is_on(id)
	var catcher := ColorRect.new()
	catcher.color = Color(0, 0, 0, 0.35)
	catcher.set_anchors_preset(Control.PRESET_FULL_RECT)
	catcher.gui_input.connect(func(ev: InputEvent):
		if ev is InputEventMouseButton and (ev as InputEventMouseButton).pressed:
			_close_skin_menu())
	menu_box.add_child(catcher)
	skin_menu = catcher
	var panel := PanelContainer.new()
	panel.add_theme_stylebox_override("panel", UI.box(Color(0.07, 0.075, 0.095, 0.98), UI.LV_CARD_LINE, 1, 0, 10, 8))
	catcher.add_child(panel)
	var vb := VBoxContainer.new()
	vb.add_theme_constant_override("separation", 2)
	panel.add_child(vb)
	var hl := Label.new()
	hl.text = "%s · chỉ dành cho phe %s" % [str(data["name"]), team_txt]
	hl.add_theme_font_size_override("font_size", 12)
	hl.add_theme_color_override("font_color", UI.LV_MUTED)
	vb.add_child(hl)
	var sk_team: int = int(data["team"])
	var sc_team: bool = on and skins.scope_of_team(sk_team) == Skins.SCOPE_TEAM
	var sc_self: bool = on and skins.scope_of_team(sk_team) == Skins.SCOPE_SELF
	var items := [
		["Gỡ skin (về %s)" % str(Skins.DEFAULT_NAME[sk_team]).capitalize() if on else "Áp dụng skin cho phe " + team_txt, "toggle", false],
		["Dùng cho cả phe" + ("  (đang dùng)" if sc_team else ""), "team", sc_team],
		["Dùng chỉ riêng mình" + ("  (đang dùng)" if sc_self else ""), "self", sc_self],
	]
	for it in items:
		var ib := _lobby_btn(str(it[0]), 16, UI.LV_TEAL if bool(it[2]) else UI.LV_TEXT)
		ib.pressed.connect(_skin_action.bind(id, str(it[1])))
		vb.add_child(ib)
	# đặt tại con trỏ chuột, không cho tràn ra ngoài khung
	var vp: Vector2 = menu_box.size
	var pos: Vector2 = menu_box.get_local_mouse_position()
	panel.position = pos
	await get_tree().process_frame
	if is_instance_valid(panel):
		panel.position = Vector2(clampf(pos.x, 4.0, maxf(vp.x - panel.size.x - 4.0, 4.0)), clampf(pos.y, 4.0, maxf(vp.y - panel.size.y - 4.0, 4.0)))


func _skin_action(id: String, act: String) -> void:
	var nm := str((Skins.DATA[id] as Dictionary)["name"])
	var tm: int = skins.team_of(id)
	var tt := "CT" if tm == 0 else "T"
	var dn := str(Skins.DEFAULT_NAME[tm]).capitalize()
	var msg := ""
	match act:
		"toggle":
			if skins.is_on(id):
				skins.unequip(tm)
				msg = "Đã gỡ skin. Phe %s dùng lại %s." % [tt, dn]
			else:
				var sc: String = skins.scope_of_team(tm)
				skins.equip(id, sc)
				msg = "%s: %s." % [nm, ("cả phe %s dùng" % tt) if sc == Skins.SCOPE_TEAM else "chỉ riêng bạn dùng"]
		"team":
			skins.equip(id, Skins.SCOPE_TEAM)
			msg = "%s: cả phe %s dùng (bạn và bot %s)." % [nm, tt, tt]
		"self":
			skins.equip(id, Skins.SCOPE_SELF)
			msg = "%s: chỉ riêng bạn dùng (bot %s vẫn là %s). Thân bạn chỉ lộ ra ở camera lúc chết." % [nm, tt, dn]
	_close_skin_menu()
	_apply_skins_to_bots()
	_lobby_fill_collection()
	lobby_coll_msg.text = msg


## Bot đã dựng sẵn thì dựng lại model theo skin mới (bot dựng mới sẽ tự lấy đúng skin).
func _apply_skins_to_bots() -> void:
	for b in bots:
		if is_instance_valid(b):
			b.reload_rig()


func _lobby_clear_cards() -> void:
	for c in lobby_row.get_children():
		lobby_row.remove_child(c)
		c.queue_free()


func _lobby_back() -> void:
	if lobby_step == 2:
		_lobby_show_maps()
	else:
		_lobby_show_modes()


func _lobby_show_modes() -> void:
	lobby_step = 0
	_lobby_clear_cards()
	lobby_head.text = "CHỌN CHẾ ĐỘ"
	lobby_sub.text = ""
	lobby_back.visible = false
	for m in LOBBY_MODES:
		lobby_row.add_child(_lobby_card(str(m["name"]), str(m["desc"]), _lobby_pick_mode.bind(str(m["id"]))))
	_lobby_fit_cards()


func _lobby_pick_mode(id: String) -> void:
	lobby_mode = id
	_lobby_show_maps()


func _lobby_show_maps() -> void:
	lobby_step = 1
	_lobby_clear_cards()
	lobby_head.text = "CHỌN BẢN ĐỒ"
	lobby_sub.text = ""
	for m in LOBBY_MODES:
		if str(m["id"]) == lobby_mode:
			lobby_sub.text = str(m["name"])
	lobby_back.visible = true
	for m in LOBBY_MAPS[lobby_mode]:
		lobby_row.add_child(_lobby_card(str(m["name"]), str(m["desc"]), _lobby_pick_map.bind(str(m["id"]))))
	lobby_row.add_child(_lobby_card("SẮP CÓ", "Thêm bản đồ sau", Callable(), true))
	_lobby_fit_cards()


func _lobby_pick_map(id: String) -> void:
	if id != loaded_map:
		var ok: bool = await _switch_classic_map(id)
		if not ok:
			return
	if lobby_mode == "bomb":
		_lobby_show_sides()
	else:
		_on_play()


func _lobby_show_sides() -> void:
	lobby_step = 2
	_lobby_clear_cards()
	lobby_head.text = "CHỌN PHE"
	lobby_sub.text = "ĐẶT BOM"
	lobby_back.visible = true
	for sd in LOBBY_SIDES:
		lobby_row.add_child(_lobby_card(str(sd["name"]), str(sd["desc"]), _on_bomb.bind(int(sd["id"]))))
	_lobby_fit_cards()


func _lobby_card(title: String, desc: String, cb: Callable, disabled: bool = false) -> Control:
	# thẻ = Control đơn giản (kích thước do _lobby_fit_cards đặt), nút bấm nằm phủ lên toàn thẻ
	var card := Control.new()
	card.custom_minimum_size = Vector2(100, 190)
	card.size_flags_horizontal = Control.SIZE_SHRINK_BEGIN
	card.clip_contents = true
	var b := Button.new()
	b.set_anchors_preset(Control.PRESET_FULL_RECT)
	b.focus_mode = Control.FOCUS_NONE
	b.disabled = disabled
	b.add_theme_stylebox_override("normal", UI.box(UI.LV_CARD, UI.LV_CARD_LINE, 1, 0, 0, 0))
	b.add_theme_stylebox_override("hover", UI.box(Color(0.235, 0.95, 0.82, 0.10), UI.LV_TEAL, 1, 0, 0, 0))
	b.add_theme_stylebox_override("pressed", UI.box(Color(0.235, 0.95, 0.82, 0.18), UI.LV_TEAL, 1, 0, 0, 0))
	b.add_theme_stylebox_override("disabled", UI.box(Color(1, 1, 1, 0.02), Color(1, 1, 1, 0.08), 1, 0, 0, 0))
	b.add_theme_stylebox_override("focus", StyleBoxEmpty.new())
	if not disabled:
		b.pressed.connect(cb)
	card.add_child(b)
	var v := VBoxContainer.new()
	v.set_anchors_preset(Control.PRESET_FULL_RECT)
	v.offset_left = 10.0
	v.offset_right = -10.0
	v.offset_top = 10.0
	v.offset_bottom = -12.0
	v.alignment = BoxContainer.ALIGNMENT_END
	v.add_theme_constant_override("separation", 6)
	v.mouse_filter = Control.MOUSE_FILTER_IGNORE
	card.add_child(v)
	var tl := Label.new()
	tl.text = title
	tl.add_theme_font_override("font", UI.lobby_font())
	tl.add_theme_font_size_override("font_size", 26)
	tl.add_theme_color_override("font_color", UI.LV_MUTED if disabled else UI.LV_TEXT)
	tl.custom_minimum_size = Vector2(0, 30)   # chừa chỗ phía trên cho dấu của chữ hoa (Ấ, Ặ...) không bị cắt
	tl.mouse_filter = Control.MOUSE_FILTER_IGNORE
	v.add_child(tl)
	card.set_meta("tl", tl)
	var dl := Label.new()
	dl.text = desc
	dl.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	dl.add_theme_font_size_override("font_size", 11)
	dl.custom_minimum_size = Vector2(0, 64)
	dl.vertical_alignment = VERTICAL_ALIGNMENT_TOP
	dl.add_theme_color_override("font_color", UI.LV_MUTED)
	dl.mouse_filter = Control.MOUSE_FILTER_IGNORE
	v.add_child(dl)
	return card


## Chia đều bề ngang cho các thẻ để không bao giờ tràn ra ngoài màn hình (3 thẻ trở lên vẫn vừa).
func _lobby_fit_cards() -> void:
	var n := lobby_row.get_child_count()
	if n == 0 or lobby_play_box == null:
		return
	var avail: float = lobby_play_box.size.x
	if avail <= 10.0:
		return
	var gap := 10.0
	var w := clampf((avail - gap * float(n - 1)) / float(n), 80.0, 150.0)
	# cỡ chữ tiêu đề: cùng một cỡ cho mọi thẻ, đủ nhỏ để chữ dài nhất vẫn nằm gọn trong thẻ
	var fs := 26.0
	for c in lobby_row.get_children():
		var tl: Label = c.get_meta("tl")
		fs = minf(fs, (w - 20.0) / (maxf(float(tl.text.length()), 1.0) * 0.74))
	fs = clampf(fs, 12.0, 26.0)
	for c in lobby_row.get_children():
		(c as Control).custom_minimum_size = Vector2(w, 190.0)
		(c as Control).size = Vector2(w, 190.0)
		(c.get_meta("tl") as Label).add_theme_font_size_override("font_size", int(fs))


func _build_shop() -> void:
	shop_layer = CanvasLayer.new()
	shop_layer.layer = 40
	shop_layer.visible = false
	add_child(shop_layer)
	var dim := ColorRect.new()
	dim.color = Color(0.02, 0.025, 0.035, 0.8)
	dim.set_anchors_preset(Control.PRESET_FULL_RECT)
	# bấm ra ngoài các thẻ = đóng cửa hàng
	dim.gui_input.connect(func(ev: InputEvent):
		if ev is InputEventMouseButton and (ev as InputEventMouseButton).pressed and (ev as InputEventMouseButton).button_index == MOUSE_BUTTON_LEFT:
			_toggle_shop())
	shop_layer.add_child(dim)
	var root := _ui_root(shop_layer)
	var center := CenterContainer.new()
	center.set_anchors_preset(Control.PRESET_FULL_RECT)
	center.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.add_child(center)
	var vb := VBoxContainer.new()
	vb.add_theme_constant_override("separation", 22)
	vb.mouse_filter = Control.MOUSE_FILTER_IGNORE
	center.add_child(vb)

	# tiền: một con số duy nhất
	shop_money_label = _make_label("$0", 30, UI.ACCENT)
	vb.add_child(shop_money_label)

	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 10)
	row.mouse_filter = Control.MOUSE_FILTER_IGNORE
	vb.add_child(row)
	row.add_child(_make_card("m4a1", "1", "M4A1", "m4", _buy_m4))
	row.add_child(_make_card("ak47", "2", "AK-47", "ak", _buy_ak))
	row.add_child(_make_card("deagle", "3", "DEAGLE", "deagle", _buy_deagle))
	row.add_child(_make_card("ammo", "4", "AMMO", "ammo", _buy_ammo))
	row.add_child(_make_card("awp", "5", "AWP", "awp", _buy_awp))
	row.add_child(_make_card("mp5", "6", "MP5-SD", "mp5", _buy_mp5))

	# nút đóng nhỏ ở góc
	var esc := Button.new()
	esc.text = "ESC"
	esc.theme_type_variation = "Ghost"
	esc.focus_mode = Control.FOCUS_NONE
	esc.anchor_left = 1.0
	esc.anchor_right = 1.0
	esc.offset_left = -76.0
	esc.offset_right = -14.0
	esc.offset_top = 12.0
	esc.offset_bottom = 40.0
	esc.pressed.connect(_toggle_shop)
	root.add_child(esc)


func _make_card(id: String, key: String, label: String, icon_kind: String, cb: Callable) -> Button:
	var b := Button.new()
	b.theme_type_variation = "Card"
	b.focus_mode = Control.FOCUS_NONE
	b.custom_minimum_size = Vector2(120, 176)
	b.pressed.connect(cb)
	# số phím tắt: nhỏ, mờ, góc trên trái
	var kl := _make_label(key, 12, UI.MUTED)
	kl.position = Vector2(12, 9)
	kl.mouse_filter = Control.MOUSE_FILTER_IGNORE
	b.add_child(kl)
	var v := VBoxContainer.new()
	v.set_anchors_preset(Control.PRESET_FULL_RECT)
	v.offset_left = 8.0
	v.offset_right = -8.0
	v.offset_top = 22.0
	v.offset_bottom = -14.0
	v.alignment = BoxContainer.ALIGNMENT_CENTER
	v.add_theme_constant_override("separation", 14)
	v.mouse_filter = Control.MOUSE_FILTER_IGNORE
	b.add_child(v)
	var ic = UIIcon.new()
	ic.kind = icon_kind
	ic.col = UI.TEXT
	ic.custom_minimum_size = Vector2(0, 46)
	ic.mouse_filter = Control.MOUSE_FILTER_IGNORE
	v.add_child(ic)
	var nm := _make_label(label, 15, UI.TEXT)
	nm.mouse_filter = Control.MOUSE_FILTER_IGNORE
	v.add_child(nm)
	# dòng cuối: giá, hoặc dấu tick nếu đã sở hữu
	var slot := Control.new()
	slot.custom_minimum_size = Vector2(0, 20)
	slot.mouse_filter = Control.MOUSE_FILTER_IGNORE
	v.add_child(slot)
	var price := _make_label("", 15, UI.ACCENT)
	price.set_anchors_preset(Control.PRESET_FULL_RECT)
	price.mouse_filter = Control.MOUSE_FILTER_IGNORE
	slot.add_child(price)
	var tick = UIIcon.new()
	tick.kind = "tick"
	tick.col = UI.ACCENT
	tick.anchor_left = 0.5
	tick.anchor_right = 0.5
	tick.anchor_top = 0.5
	tick.anchor_bottom = 0.5
	tick.offset_left = -10.0
	tick.offset_right = 10.0
	tick.offset_top = -10.0
	tick.offset_bottom = 10.0
	tick.visible = false
	tick.mouse_filter = Control.MOUSE_FILTER_IGNORE
	slot.add_child(tick)
	shop_cards[id] = {"btn": b, "price": price, "tick": tick}
	return b


func _fmt_money(n: int) -> String:
	var s := str(absi(n))
	var out := ""
	while s.length() > 3:
		out = "," + s.substr(s.length() - 3) + out
		s = s.substr(0, s.length() - 3)
	return ("-" if n < 0 else "") + s + out


func _set_card(id: String, price: int, _owned: bool) -> void:
	var c: Dictionary = shop_cards[id]
	var b: Button = c["btn"]
	var pl: Label = c["price"]
	pl.text = "$" + _fmt_money(price)
	# không còn khóa món: đã có rồi vẫn mua được (khẩu cùng loại đang cầm sẽ rơi xuống đất), nên luôn hiện giá
	pl.visible = true
	(c["tick"] as Control).visible = false
	var poor := money < price
	b.disabled = poor
	b.modulate = Color(1, 1, 1, 0.38) if poor else Color(1, 1, 1, 1)
	b.remove_theme_stylebox_override("disabled")


func _refresh_shop() -> void:
	shop_money_label.text = "$" + _fmt_money(money)
	# 6 thẻ: màn 4:3 (rộng 540) thì thu hẹp thẻ để vẫn vừa khung
	var card_w := 76.0 if aspect_43 else 100.0   # 6 thẻ
	for cid in shop_cards:
		((shop_cards[cid] as Dictionary)["btn"] as Button).custom_minimum_size = Vector2(card_w, 176.0)
	_set_card("m4a1", PRICE_M4, bool(player.owned["m4a1"]))
	_set_card("ak47", PRICE_AK, bool(player.owned["ak47"]))
	_set_card("deagle", PRICE_DEAGLE, bool(player.owned["deagle"]))
	_set_card("ammo", PRICE_AMMO, false)
	_set_card("awp", PRICE_AWP, bool(player.owned["awp"]))
	_set_card("mp5", PRICE_MP5, bool(player.owned["mp5"]))


# =====================================================================
#  CÀI ĐẶT (mở từ sảnh chờ hoặc menu tạm dừng)
# =====================================================================
## Giao diện (HUD, menu) vẽ ở độ phân giải thật của cửa sổ nên luôn nét, kích thước cố định.
## Khung thiết kế 720x405 (4:3 kéo giãn: 540x405).
func _apply_ui_scale() -> void:
	var w := get_window()
	w.content_scale_mode = Window.CONTENT_SCALE_MODE_CANVAS_ITEMS
	w.content_scale_size = Vector2i(540, 405) if aspect_43 else Vector2i(720, 405)
	_apply_aspect_mode()


## Thế giới 3D vẽ vào một SubViewport có độ phân giải riêng (F4 / tự giảm khi lag chỉ đổi cái này),
## rồi phóng ra đầy màn hình dưới lớp giao diện.
func _build_view3d() -> void:
	sub = SubViewport.new()
	sub.size = _res_size(res_idx)
	sub.gui_disable_input = true
	sub.audio_listener_enable_3d = true
	sub.msaa_3d = Viewport.MSAA_DISABLED
	sub.render_target_update_mode = SubViewport.UPDATE_ALWAYS
	add_child(sub)
	cam3d = Camera3D.new()
	cam3d.near = 0.03
	cam3d.far = 90.0
	cam3d.current = true
	sub.add_child(cam3d)
	var layer := CanvasLayer.new()
	layer.layer = -10
	add_child(layer)
	view_tex = TextureRect.new()
	view_tex.texture = sub.get_texture()
	view_tex.set_anchors_preset(Control.PRESET_FULL_RECT)
	view_tex.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	view_tex.stretch_mode = TextureRect.STRETCH_SCALE
	view_tex.texture_filter = CanvasItem.TEXTURE_FILTER_LINEAR
	view_tex.mouse_filter = Control.MOUSE_FILTER_IGNORE
	layer.add_child(view_tex)


func _res_size(i: int) -> Vector2i:
	return RES_STEPS_43[i] if aspect_43 else RES_STEPS[i]


func _load_settings() -> void:
	var cfg := ConfigFile.new()
	if cfg.load(SETTINGS_PATH) == OK:
		aspect_43 = str(cfg.get_value("display", "aspect", "16:9")) == "4:3"
		left_hand = bool(cfg.get_value("controls", "left_hand", false))


func _save_settings() -> void:
	var cfg := ConfigFile.new()
	cfg.set_value("display", "aspect", "4:3" if aspect_43 else "16:9")
	cfg.set_value("controls", "left_hand", left_hand)
	cfg.save(SETTINGS_PATH)


## 16:9 = giữ nguyên tỉ lệ. 4:3 = vẽ ở 4:3 rồi KÉO GIÃN ra đầy màn hình (kiểu "stretched" của CS:GO:
## nhân vật và vật thể bè ra, to ngang hơn). Cửa sổ vẫn giữ nguyên.
func _apply_aspect_mode() -> void:
	get_window().content_scale_aspect = Window.CONTENT_SCALE_ASPECT_IGNORE if aspect_43 else Window.CONTENT_SCALE_ASPECT_KEEP


func _set_aspect(v43: bool) -> void:
	if aspect_43 == v43:
		return
	aspect_43 = v43
	_save_settings()
	_apply_ui_scale()
	sub.size = _res_size(res_idx)
	_fit_ui()
	_refresh_settings()


func _set_left_hand(v: bool) -> void:
	if left_hand == v:
		return
	left_hand = v
	_save_settings()
	if player != null and is_instance_valid(player):
		player.set_left_hand(v)
	_refresh_settings()


func _build_settings() -> void:
	settings_layer = CanvasLayer.new()
	settings_layer.layer = 60
	settings_layer.visible = false
	add_child(settings_layer)
	var dim := ColorRect.new()
	dim.color = Color(0.043, 0.047, 0.055, 0.96)
	dim.set_anchors_preset(Control.PRESET_FULL_RECT)
	settings_layer.add_child(dim)
	var root := _ui_root(settings_layer)
	var center := CenterContainer.new()
	center.set_anchors_preset(Control.PRESET_FULL_RECT)
	center.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.add_child(center)
	var vb := VBoxContainer.new()
	vb.add_theme_constant_override("separation", 14)
	vb.mouse_filter = Control.MOUSE_FILTER_IGNORE
	center.add_child(vb)
	vb.add_child(_make_label("ASPECT RATIO", 12, UI.MUTED))
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 10)
	row.alignment = BoxContainer.ALIGNMENT_CENTER
	vb.add_child(row)
	aspect_btns = []
	for i in 2:
		var b := Button.new()
		b.text = "16:9" if i == 0 else "4:3"
		b.focus_mode = Control.FOCUS_NONE
		b.custom_minimum_size = Vector2(110, 52)
		b.pressed.connect(_set_aspect.bind(i == 1))
		row.add_child(b)
		aspect_btns.append(b)
	vb.add_child(_make_label("CẦM SÚNG TAY TRÁI", 12, UI.MUTED))
	var row2 := HBoxContainer.new()
	row2.add_theme_constant_override("separation", 10)
	row2.alignment = BoxContainer.ALIGNMENT_CENTER
	vb.add_child(row2)
	left_btns = []
	for i in 2:
		var lb := Button.new()
		lb.text = "TẮT" if i == 0 else "BẬT"
		lb.focus_mode = Control.FOCUS_NONE
		lb.custom_minimum_size = Vector2(110, 52)
		lb.pressed.connect(_set_left_hand.bind(i == 1))
		row2.add_child(lb)
		left_btns.append(lb)
	vb.add_child(_spacer(10))
	var back := Button.new()
	back.text = "BACK"
	back.theme_type_variation = "Ghost"
	back.focus_mode = Control.FOCUS_NONE
	back.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	back.pressed.connect(_close_settings)
	vb.add_child(back)
	_refresh_settings()


## Nút đang chọn: viền + chữ màu nhấn.
func _refresh_settings() -> void:
	for i in left_btns.size():
		var lb: Button = left_btns[i]
		if (i == 1) == left_hand:
			lb.add_theme_stylebox_override("normal", UI.box(UI.SURFACE_HI, UI.ACCENT, 1))
			lb.add_theme_color_override("font_color", UI.ACCENT)
		else:
			lb.remove_theme_stylebox_override("normal")
			lb.remove_theme_color_override("font_color")
	for i in aspect_btns.size():
		var b: Button = aspect_btns[i]
		var on := (i == 1) == aspect_43
		if on:
			b.add_theme_stylebox_override("normal", UI.box(UI.SURFACE_HI, UI.ACCENT, 1))
			b.add_theme_color_override("font_color", UI.ACCENT)
		else:
			b.remove_theme_stylebox_override("normal")
			b.remove_theme_color_override("font_color")


func _open_settings() -> void:
	settings_open = true
	_refresh_settings()
	settings_layer.visible = true


func _close_settings() -> void:
	settings_open = false
	settings_layer.visible = false


func _toggle_shop() -> void:
	if in_menu or paused_menu or player == null:
		return
	if not shop_open and not player.alive:
		return
	if bomb != null and bomb.active and not shop_open and not round_frozen:
		hud.show_info("Hết giờ mua", 1.5)
		return
	shop_open = not shop_open
	shop_layer.visible = shop_open
	if bomb == null or not bomb.active:
		get_tree().paused = shop_open   # chế độ ĐẶT BOM: không tạm dừng, đồng hồ round vẫn chạy như CS
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE if shop_open else Input.MOUSE_MODE_CAPTURED
	if shop_open:
		_refresh_shop()


func _buy_m4() -> void:
	if money < PRICE_M4:
		return
	money -= PRICE_M4
	hud.set_money(money)
	player.give_weapon("m4a1")
	hud.show_info("M4A1  [1]", 3.0)
	_toggle_shop()


func _buy_ak() -> void:
	if money < PRICE_AK:
		return
	money -= PRICE_AK
	hud.set_money(money)
	player.give_weapon("ak47")
	hud.show_info("AK-47  [5]", 3.0)
	_toggle_shop()


func _buy_deagle() -> void:
	if money < PRICE_DEAGLE:
		return
	money -= PRICE_DEAGLE
	hud.set_money(money)
	player.give_weapon("deagle")
	hud.show_info("Desert Eagle  [2]", 3.0)
	_toggle_shop()


func _buy_awp() -> void:
	if money < PRICE_AWP:
		return
	money -= PRICE_AWP
	hud.set_money(money)
	player.give_weapon("awp")
	hud.show_info("AWP  [1]   Chuột phải = ngắm (bấm thêm = zoom hơn)", 4.0)
	_toggle_shop()


func _buy_mp5() -> void:
	if money < PRICE_MP5:
		return
	money -= PRICE_MP5
	hud.set_money(money)
	player.give_weapon("mp5")
	hud.show_info("MP5-SD  [1]", 3.0)
	_toggle_shop()


func _buy_ammo() -> void:
	if money < PRICE_AMMO:
		return
	money -= PRICE_AMMO
	hud.set_money(money)
	player.refill_ammo()
	_refresh_shop()


func _set_progress(value: float, text: String) -> void:
	progress.value = value
	loading_label.text = text
	await get_tree().process_frame


## Chạy thử mọi hiệu ứng/hướng nhìn một lần khi còn ở màn hình loading,
## để shader được biên dịch trước, vào game không bị khựng.
func _lighten_materials(root: Node, seen: Dictionary) -> void:
	for ch in root.get_children():
		if ch is MeshInstance3D:
			var mat = (ch as MeshInstance3D).material_override
			if mat is BaseMaterial3D and not seen.has(mat):
				seen[mat] = true
				var bm := mat as BaseMaterial3D
				if bm.shading_mode == BaseMaterial3D.SHADING_MODE_PER_PIXEL:
					bm.shading_mode = BaseMaterial3D.SHADING_MODE_PER_VERTEX
					bm.specular_mode = BaseMaterial3D.SPECULAR_DISABLED
					bm.metallic = 0.0
		_lighten_materials(ch, seen)


func _warmup() -> void:
	await _set_progress(90.0, "Optimizing materials...")
	var seen := {}
	_lighten_materials(player, seen)
	for b in bots:
		_lighten_materials(b, seen)
	await _set_progress(92.0, "Preparing graphics...")
	var cam: Camera3D = player.camera
	var temp: Array = []
	var mats: Array = [decal_mat, tracer_mat, spark_mat, blood_mat]
	for bm in Bot._mat_cache.values():
		mats.append(bm)
	for mat in mats:
		var mi := MeshInstance3D.new()
		var qm := QuadMesh.new()
		qm.size = Vector2(0.1, 0.1)
		mi.mesh = qm
		mi.material_override = mat
		cam.add_child(mi)
		mi.position = Vector3(randf_range(-0.3, 0.3), randf_range(-0.2, 0.2), -1.0)
		temp.append(mi)
	for v in player.viewmodels.values():
		v.visible = true
		v.flash.visible = true
	var y0: float = player.rotation.y
	for i in 5:
		player.rotation.y = y0 + float(i) * PI * 0.5   # quay quanh để nạp toàn bộ map vào GPU
		await get_tree().process_frame
		await get_tree().process_frame
	player.rotation.y = y0
	for v in player.viewmodels.values():
		v.flash.visible = false
		if v != player.vm:
			v.visible = false
	for mi in temp:
		(mi as Node).queue_free()
	await _set_progress(100.0, "Ready!")
	# trong lúc ở menu, thế giới game đứng yên
	world.process_mode = Node.PROCESS_MODE_DISABLED


func _show_menu() -> void:
	load_box.visible = false
	load_center.visible = false
	menu_box.visible = true
	_lobby_set_tab(0, false)   # mới vào sảnh: CHƠI được chọn nhưng chưa mở danh sách chế độ
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE


func _on_play() -> void:
	in_menu = false
	ui_layer.visible = false
	world.process_mode = Node.PROCESS_MODE_PAUSABLE
	hud.visible = true
	team_score = [0, 0]
	hud.set_score(0, 0)
	money = START_MONEY
	hud.set_money(money)
	player.reset_loadout()
	pickups.clear_all()
	_respawn_player()
	for b in bots:
		b.respawn(_pick_spawn(b.team))
	if not nav_ok:
		hud.show_info("Warning: navmesh failed - bots will move in straight lines", 6.0)
	elif OS.has_feature("editor"):
		hud.show_info("You are running inside the Godot editor (slow!). Close it and use CHOI_GAME.bat", 10.0)
	else:
		hud.show_info("Team Deathmatch - first to %d kills  |  Press B for the Buy Menu" % KILL_LIMIT, 6.0)
	Input.mouse_mode = Input.MOUSE_MODE_CAPTURED
	res_cooldown = 5.0


## Chế độ ĐẶT BOM: side = 0 (CT, gỡ bom) hoặc 1 (T, đặt bom). Luật xem scripts/bomb.gd.
func _on_bomb(side: int) -> void:
	in_menu = false
	ui_layer.visible = false
	world.process_mode = Node.PROCESS_MODE_PAUSABLE
	hud.visible = true
	hud.score_label.visible = true
	hud.kill_feed_on = true
	match_over = false
	if bomb != null and is_instance_valid(bomb):
		(bomb as Node).queue_free()
	bomb = BombScript.new()
	bomb.main = self
	add_child(bomb)
	bomb.start_match(side)
	Input.mouse_mode = Input.MOUSE_MODE_CAPTURED
	res_cooldown = 5.0


## Tạo lại toàn bộ bot cho chế độ ĐẶT BOM: đồng đội cùng phe người chơi + địch (3 đấu 3 ở bản đồ nhỏ, 5 đấu 5 ở bản đồ MIRAGE; số bot lấy từ MAP_CFG).
func _rebuild_bots(player_team: int) -> void:
	for ob in bots:
		if is_instance_valid(ob):
			ob.alive = false
			ob.collision_layer = 0
			ob.remove_from_group("combatants")
			ob.queue_free()
	bots.clear()
	var plan: Array = []
	for i in bots_ct:
		plan.append(player_team)
	for i in bots_t:
		plan.append(1 - player_team)
	for i in plan.size():
		var nb := Bot.new()
		nb.team = int(plan[i])
		nb.display_name = BOT_NAMES[i]
		nb.skill = randf_range(0.35, 0.75)
		nb.main = self
		world.add_child(nb)
		bots.append(nb)
		nb.respawn(_pick_spawn(nb.team))


# =====================================================================
#  THIẾT LẬP
# =====================================================================
func _add_key(action: String, keycode: Key) -> void:
	if not InputMap.has_action(action):
		InputMap.add_action(action)
	var ev := InputEventKey.new()
	ev.physical_keycode = keycode
	InputMap.action_add_event(action, ev)


func _add_mouse(action: String, button: MouseButton) -> void:
	if not InputMap.has_action(action):
		InputMap.add_action(action)
	var ev := InputEventMouseButton.new()
	ev.button_index = button
	InputMap.action_add_event(action, ev)


func _setup_input() -> void:
	_add_key("move_forward", KEY_W)
	_add_key("move_back", KEY_S)
	_add_key("move_left", KEY_A)
	_add_key("move_right", KEY_D)
	_add_key("jump", KEY_SPACE)
	_add_key("crouch", KEY_SHIFT)
	_add_key("walk", KEY_CTRL)
	_add_key("reload", KEY_R)
	_add_key("inspect", KEY_F)
	_add_key("drop", KEY_G)          # vứt món đang cầm (không vứt được dao)
	_add_key("scoreboard", KEY_TAB)
	_add_key("slot1", KEY_1)
	_add_key("slot2", KEY_2)
	_add_key("slot3", KEY_3)
	_add_key("slot5", KEY_5)
	_add_key("last_weapon", KEY_Q)
	_add_key("slot6", KEY_6)   # cầm bom C4
	_add_key("use", KEY_E)     # nhìn vào súng dưới đất bấm E: nhặt; giữ E gần bom đang đặt: gỡ bom (CT)
	_add_mouse("fire", MOUSE_BUTTON_LEFT)
	_add_mouse("aim", MOUSE_BUTTON_RIGHT)
	Input.use_accumulated_input = true


## Nút cảm ứng cho điện thoại. Trên máy tính script này tự tắt (trừ khi chạy với tham số "touch").
func _setup_touch() -> void:
	touch = preload("res://scripts/touch_controls.gd").new()
	touch.main = self
	add_child(touch)


func _setup_environment() -> void:
	# Cấu hình nhẹ cho laptop yếu: nền màu phẳng, ánh sáng môi trường, KHÔNG bóng đổ
	env = Environment.new()
	env.background_mode = Environment.BG_COLOR
	env.background_color = Color(0.45, 0.62, 0.85)
	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.ambient_light_color = Color(0.62, 0.66, 0.74)
	env.ambient_light_energy = 0.9
	var we := WorldEnvironment.new()
	we.environment = env
	add_child(we)
	sun = DirectionalLight3D.new()
	sun.rotation = Vector3(deg_to_rad(-52.0), deg_to_rad(-38.0), 0.0)
	sun.light_energy = 1.1
	sun.light_color = Color(1.0, 0.96, 0.88)
	sun.shadow_enabled = false
	add_child(sun)


func _make_fx_resources() -> void:
	var img := Image.create(32, 32, false, Image.FORMAT_RGBA8)
	for y in 32:
		for x in 32:
			var dx := (x - 15.5) / 15.5
			var dy := (y - 15.5) / 15.5
			var r := sqrt(dx * dx + dy * dy)
			var a := clampf(1.0 - r, 0.0, 1.0)
			a = clampf(a * 2.2, 0.0, 0.85)
			img.set_pixel(x, y, Color(0.02, 0.02, 0.02, a))
	hole_tex = ImageTexture.create_from_image(img)
	decal_mat = StandardMaterial3D.new()
	decal_mat.albedo_texture = hole_tex
	decal_mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	decal_mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	decal_mat.cull_mode = BaseMaterial3D.CULL_DISABLED
	tracer_mat = StandardMaterial3D.new()
	tracer_mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	tracer_mat.albedo_color = Color(1.0, 0.86, 0.5, 0.9)
	tracer_mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	spark_mat = StandardMaterial3D.new()
	spark_mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	spark_mat.albedo_color = Color(1.0, 0.8, 0.35)
	blood_mat = StandardMaterial3D.new()
	blood_mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	blood_mat.albedo_color = Color(0.7, 0.05, 0.05)
	# pool hạt (tia lửa / máu)
	burst_pools[spark_mat.get_instance_id()] = _make_burst_pool(spark_mat, 3, 0.2, 3.5)
	burst_pools[blood_mat.get_instance_id()] = _make_burst_pool(blood_mat, 4, 0.3, 3.0)
	burst_idx[spark_mat.get_instance_id()] = 0
	burst_idx[blood_mat.get_instance_id()] = 0
	# pool tia đạn
	for i in 12:
		var t := MeshInstance3D.new()
		var tb := BoxMesh.new()
		tb.size = Vector3.ONE
		t.mesh = tb
		t.material_override = tracer_mat
		t.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		t.visible = false
		fx_root.add_child(t)
		tracer_pool.append(t)
		tracer_time.append(0.0)


func _make_burst_pool(mat: Material, count: int, life: float, speed: float) -> Array:
	var arr: Array = []
	for i in 8:
		var p := CPUParticles3D.new()
		var bm := BoxMesh.new()
		bm.size = Vector3(0.025, 0.025, 0.025)
		p.mesh = bm
		p.material_override = mat
		p.amount = count
		p.lifetime = life
		p.one_shot = true
		p.explosiveness = 1.0
		p.spread = 50.0
		p.initial_velocity_min = speed * 0.5
		p.initial_velocity_max = speed
		p.gravity = Vector3(0.0, -9.8, 0.0)
		p.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		p.emitting = false
		fx_root.add_child(p)
		arr.append(p)
	return arr


## Phát âm thanh 3D tại một vị trí bằng pool; bỏ qua nếu quá xa hoặc hết "kênh".
func play_at(_sound_name: String = "", _pos: Vector3 = Vector3.ZERO, _vol_db: float = 0.0, _pitch: float = 1.0, _max_d: float = 60.0) -> void:
	pass   # đã xoá toàn bộ âm thanh trong game (giữ hàm rỗng để các chỗ gọi cũ không lỗi)


func _find_meshes(n: Node, out: Array) -> void:
	if n is MeshInstance3D:
		out.append(n)
	for c in n.get_children():
		_find_meshes(c, out)


func _start_game() -> bool:
	await _set_progress(5.0, "Loading...")

	# ---------- nạp map ----------
	var map_ok: bool = await _build_classic_map("default")
	if not map_ok:
		return false
	await _set_progress(80.0, "Spawning player & bots...")

	# ---------- HUD ----------
	hud = Hud.new()
	add_child(hud)
	hud.visible = false
	hud.sensitivity_changed.connect(func(v: float): player.sensitivity = v)
	hud.fov_changed.connect(func(v: float): player.fov_base = v)
	hud.resume_pressed.connect(_toggle_pause)
	hud.settings_pressed.connect(_open_settings)
	hud.quit_pressed.connect(func(): get_tree().quit())
	AudioServer.set_bus_mute(0, false)   # loa BẬT: game không còn tiếng nào ngoài MP5-SD (mp5.gd tự phát tiếng bắn / nạp đạn); các súng khác vẫn im lặng

	# ---------- người chơi + bot ----------
	player = Player.new()
	player.main = self
	player.hud = hud
	player.render_cam = cam3d
	player.team = 0
	world.add_child(player)
	pickups = PickupsScript.new()
	pickups.main = self
	world.add_child(pickups)
	_respawn_player()
	_spawn_classic_bots()
	hud.set_score(0, 0)
	return true


## Dựng bản đồ ĐẤU ĐỘI / ĐẶT BOM (id trong MAP_CFG): nạp .glb, tạo va chạm, bake navmesh, rải điểm tuần tra + điểm xuất phát.
func _build_classic_map(id: String) -> bool:
	var cfg: Dictionary = MAP_CFG[id]
	var file: String = str(cfg["file"])
	await _set_progress(15.0, "Loading map...")
	var scene = load(file)
	if scene == null:
		load_box.visible = true
		loading_label.text = "Cannot load %s\nRun CHOI_GAME.bat once so the map gets imported." % file
		return false
	loaded_map = id
	bots_ct = int(cfg["bots_ct"])
	bots_t = int(cfg["bots_t"])
	site_want = (cfg["site_want"] as Array).duplicate()
	site_ymax = float(cfg.get("site_ymax", 0.6))
	nav_region = NavigationRegion3D.new()
	var nm := NavigationMesh.new()
	# bán kính / chiều cao đặt đúng bội số của ô lưới (0.25) nên engine không còn cảnh báo "ceiled" (kết quả y hệt trước)
	nm.agent_radius = 0.5
	nm.agent_height = 2.0
	nm.agent_max_climb = 0.5
	nm.agent_max_slope = 40.0
	# đọc hình học từ collision (đã tạo trimesh cho cả map) thay vì mesh hiển thị -> hết cảnh báo "RenderingServer meshes"
	nm.geometry_parsed_geometry_type = NavigationMesh.PARSED_GEOMETRY_STATIC_COLLIDERS
	if cfg.has("nav_aabb"):
		nm.filter_baking_aabb = cfg["nav_aabb"]   # bản đồ lớn: chỉ bake vùng chơi cho nhanh
	nav_region.navigation_mesh = nm
	world.add_child(nav_region)
	map_root = scene.instantiate()
	nav_region.add_child(map_root)
	var meshes: Array = []
	_find_meshes(map_root, meshes)
	for mi in meshes:
		var inst := mi as MeshInstance3D
		inst.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		if inst.mesh != null:
			for si in inst.mesh.get_surface_count():
				var smat = inst.mesh.surface_get_material(si)
				if smat is BaseMaterial3D:
					# đèn tính theo đỉnh thay vì từng điểm ảnh: nhẹ hơn nhiều cho card đồ họa tích hợp
					# (map đã nướng sẵn ánh sáng vào màu đỉnh thì không cần đèn: vẽ thẳng, nhanh nhất)
					if bool(cfg.get("unshaded", false)):
						(smat as BaseMaterial3D).shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
					else:
						(smat as BaseMaterial3D).shading_mode = BaseMaterial3D.SHADING_MODE_PER_VERTEX
					(smat as BaseMaterial3D).specular_mode = BaseMaterial3D.SPECULAR_DISABLED
		if not String(inst.name).ends_with("_nocol"):
			inst.create_trimesh_collision()   # mesh nhìn (_nocol) không va chạm: va chạm nằm ở mesh col_*_hide riêng
		if String(inst.name).ends_with("_hide"):
			inst.visible = false   # vật cản vô hình (trần trời, tường chắn): chỉ giữ va chạm
	if cfg.has("half"):
		_add_map_barrier(float(cfg["half"]))
	await _set_progress(35.0, "Building collision & navigation...")

	# ---------- navmesh ----------
	var pa: Vector3 = cfg["probe_a"]
	var pb: Vector3 = cfg["probe_b"]
	nav_region.bake_navigation_mesh(false)
	await get_tree().physics_frame
	await get_tree().physics_frame
	nav_map = nav_region.get_navigation_map()
	var test_path := NavigationServer3D.map_get_path(nav_map, pa, pb, true)
	nav_ok = test_path.size() > 2
	if not nav_ok:
		# dự phòng: nếu cách đọc collision không ra navmesh thì quay về cách cũ (đọc mesh hiển thị)
		nm.geometry_parsed_geometry_type = NavigationMesh.PARSED_GEOMETRY_MESH_INSTANCES
		nav_region.bake_navigation_mesh(false)
		await get_tree().physics_frame
		await get_tree().physics_frame
		test_path = NavigationServer3D.map_get_path(nav_map, pa, pb, true)
		nav_ok = test_path.size() > 2
	await _set_progress(65.0, "Finding bot routes...")
	_build_waypoints_and_spawns()
	return true


## Tường vô hình bao quanh khu chơi của bản đồ lớn (bản đồ gốc bị cắt từ một thành phố rất rộng, không cho đi ra ngoài rồi rơi xuống).
func _add_map_barrier(half: float) -> void:
	var body := StaticBody3D.new()
	body.collision_layer = 1
	body.collision_mask = 0
	var t := 1.0
	var h := 90.0
	var c := half + t * 0.5
	var specs: Array = [
		[Vector3(t, h, 2.0 * (half + t)), Vector3(c, h * 0.5 - 10.0, 0.0)],
		[Vector3(t, h, 2.0 * (half + t)), Vector3(-c, h * 0.5 - 10.0, 0.0)],
		[Vector3(2.0 * (half + t), h, t), Vector3(0.0, h * 0.5 - 10.0, c)],
		[Vector3(2.0 * (half + t), h, t), Vector3(0.0, h * 0.5 - 10.0, -c)],
	]
	for sp in specs:
		var cs := CollisionShape3D.new()
		var bs := BoxShape3D.new()
		bs.size = sp[0]
		cs.shape = bs
		cs.position = sp[1]
		body.add_child(cs)
	nav_region.add_child(body)


## Tạo bot cho chế độ ĐẤU ĐỘI theo cấu hình bản đồ hiện tại (người chơi ở phe 0).
func _spawn_classic_bots() -> void:
	for i in bots_ct + bots_t:
		var b := Bot.new()
		b.team = 0 if i < bots_ct else 1
		b.display_name = BOT_NAMES[i]
		b.skill = randf_range(0.35, 0.75)
		b.main = self
		world.add_child(b)
		bots.append(b)
		b.respawn(_pick_spawn(b.team))


## Đổi sang bản đồ khác (từ sảnh chờ): gỡ map + bot cũ, dựng map mới, tạo lại bot theo số người của map đó.
func _switch_classic_map(id: String) -> bool:
	var file: String = str((MAP_CFG[id] as Dictionary)["file"])
	menu_box.visible = false
	load_center.visible = true
	load_box.visible = true
	await _set_progress(3.0, "Loading map...")
	if not ResourceLoader.exists(file):
		loading_label.text = "Cannot load %s\nRun CHOI_GAME.bat once so the map gets imported." % file
		await get_tree().create_timer(4.0).timeout
		load_box.visible = false
		load_center.visible = false
		menu_box.visible = true
		return false
	# bật thế giới lên để vật lý/navmesh chạy khi dựng map; tạm khoá người chơi để khỏi rơi xuyên đất
	player.process_mode = Node.PROCESS_MODE_DISABLED
	world.process_mode = Node.PROCESS_MODE_PAUSABLE
	await _set_progress(8.0, "Removing old map...")
	var old_bots: Array = bots
	bots = []
	nav_ok = false
	for b in old_bots:
		if is_instance_valid(b):
			(b as Node).remove_from_group("combatants")
			if (b as Node).get_parent() != null:
				(b as Node).get_parent().remove_child(b as Node)
			(b as Node).queue_free()
	if nav_region != null and is_instance_valid(nav_region):
		if nav_region.get_parent() != null:
			nav_region.get_parent().remove_child(nav_region)
		nav_region.queue_free()
		nav_region = null
		map_root = null
	waypoints = []
	await get_tree().physics_frame
	var ok: bool = await _build_classic_map(id)
	if not ok:
		player.process_mode = Node.PROCESS_MODE_INHERIT
		await get_tree().create_timer(4.0).timeout
		load_box.visible = false
		load_center.visible = false
		menu_box.visible = true
		return false
	await _set_progress(80.0, "Spawning player & bots...")
	_respawn_player()
	_spawn_classic_bots()
	var seen := {}
	for b in bots:
		_lighten_materials(b, seen)
	await _set_progress(92.0, "Preparing graphics...")
	var y0: float = player.rotation.y
	for i in 4:
		player.rotation.y = y0 + float(i) * PI * 0.5   # quay quanh để nạp map mới vào GPU
		await get_tree().process_frame
		await get_tree().process_frame
	player.rotation.y = y0
	player.process_mode = Node.PROCESS_MODE_INHERIT
	await _set_progress(100.0, "Ready!")
	world.process_mode = Node.PROCESS_MODE_DISABLED   # đang ở sảnh: thế giới đứng yên
	load_box.visible = false
	load_center.visible = false
	menu_box.visible = true
	return true


func _build_waypoints_and_spawns() -> void:
	waypoints = []
	spawns = [[], []]
	var cfg: Dictionary = MAP_CFG[loaded_map]
	var base: Vector3 = cfg["probe_a"]
	if nav_ok:
		var rng := RandomNumberGenerator.new()
		rng.seed = 12345
		var wx: float = float(cfg.get("wp_x", 11.5))
		var wz: float = float(cfg.get("wp_z", 23.5))
		var tries: int = int(cfg.get("wp_tries", 300))
		var gap: float = float(cfg.get("wp_gap", 3.5))
		var wmax: int = int(cfg.get("wp_max", 140))
		for i in tries:
			var py := 0.5
			if cfg.has("wp_y"):
				var wy: Vector2 = cfg["wp_y"]
				py = rng.randf_range(wy.x, wy.y)   # map nhiều tầng: thử nhiều độ cao
			var p := Vector3(rng.randf_range(-wx, wx), py, rng.randf_range(-wz, wz))
			var c := NavigationServer3D.map_get_closest_point(nav_map, p)
			if Vector2(c.x - p.x, c.z - p.z).length() > 0.6:
				continue
			var path := NavigationServer3D.map_get_path(nav_map, base, c, true)
			if path.size() < 2 or path[path.size() - 1].distance_to(c) > 1.0:
				continue
			var ok := true
			for w in waypoints:
				if (w as Vector3).distance_to(c) < gap:
					ok = false
					break
			if ok:
				waypoints.append(c)
			if waypoints.size() >= wmax:
				break
		if cfg.has("spawn_ct"):
			for t in 2:
				for sp in (cfg["spawn_ct"] if t == 0 else cfg["spawn_t"]):
					var p := _spawn_point(sp)
					var c := NavigationServer3D.map_get_closest_point(nav_map, p)
					if Vector2(c.x - p.x, c.z - p.z).length() < 1.5 and c.y < float(cfg.get("spawn_ymax", 0.7)) and absf(c.y - (p.y - 0.3)) < 1.2:
						spawns[t].append(c + Vector3(0.0, 0.05, 0.0))
		else:
			for sx in [-9.0, -6.0, -3.0, 0.0, 3.0, 6.0, 9.0]:
				for t in 2:
					var z := -21.0 if t == 0 else 21.0
					var p := Vector3(sx, 0.3, z)
					var c := NavigationServer3D.map_get_closest_point(nav_map, p)
					if Vector2(c.x - p.x, c.z - p.z).length() < 0.8 and c.y < 0.6:
						spawns[t].append(c + Vector3(0.0, 0.05, 0.0))
	for t in 2:
		if spawns[t].is_empty():
			if cfg.has("spawn_ct"):
				for sp in (cfg["spawn_ct"] if t == 0 else cfg["spawn_t"]):
					spawns[t].append(_spawn_point(sp))
			else:
				for sx in [-8.0, -4.0, 0.0, 4.0, 8.0]:
					spawns[t].append(Vector3(sx, 0.2, -21.0 if t == 0 else 21.0))


## Điểm xuất phát trong cấu hình: Vector2 (x, z) hoặc Vector3 (x, độ cao mặt sàn, z) -> vị trí đứng (cao hơn sàn 0.3 m).
func _spawn_point(sp) -> Vector3:
	if sp is Vector3:
		var v: Vector3 = sp
		return Vector3(v.x, v.y + 0.3, v.z)
	var sv: Vector2 = sp
	return Vector3(sv.x, 0.3, sv.y)


func _pick_spawn(team: int) -> Vector3:
	var list: Array = spawns[team]
	var best: Vector3 = list[randi() % list.size()]
	var best_d := -1.0
	for i in 5:
		var c: Vector3 = list[randi() % list.size()]
		var dmin := 1.0e9
		for n in get_tree().get_nodes_in_group("combatants"):
			if not n.alive:
				continue
			var dd := (n.global_position as Vector3).distance_to(c)
			if n.team != team:
				dmin = minf(dmin, dd)
			elif dd < 1.6:
				dmin = -1000.0   # đã có đồng đội đứng ở điểm này
				break
		if dmin > best_d:
			best_d = dmin
			best = c
	return best


func _respawn_player() -> void:
	var p := _pick_spawn(0)
	var dir := Vector3(-p.x, 0.0, -p.z).normalized()
	player.respawn(p, atan2(-dir.x, -dir.z))


# =====================================================================
#  GAMEPLAY
# =====================================================================
## Bắn một tia: kiểm tra tường (vật lý) và thân người (tính trực tiếp, không phụ thuộc layer).
func trace_shot(from: Vector3, dir: Vector3, max_dist: float, shooter) -> Dictionary:
	var out := {"kind": "none", "pos": from + dir * max_dist, "normal": Vector3.UP, "node": null, "dist": max_dist}
	var space := get_world_3d().direct_space_state
	var q := PhysicsRayQueryParameters3D.create(from, from + dir * max_dist, 1)
	var res := space.intersect_ray(q)
	if not res.is_empty():
		out["kind"] = "world"
		out["pos"] = res["position"]
		out["normal"] = res["normal"]
		out["dist"] = from.distance_to(res["position"])
	for c in get_tree().get_nodes_in_group("combatants"):
		if c == shooter or not c.alive:
			continue
		var body_pos: Vector3 = c.global_position
		if c.has_method("peek_offset"):
			body_pos += c.peek_offset()
		var t := _ray_vs_body(from, dir, body_pos)
		if t >= 0.0 and t < float(out["dist"]):
			out["kind"] = "combatant"
			out["node"] = c
			out["dist"] = t
			out["pos"] = from + dir * t
			out["normal"] = -dir
	return out


func _ray_vs_body(from: Vector3, dir: Vector3, base: Vector3) -> float:
	var r := 0.42
	var px := from.x - base.x
	var pz := from.z - base.z
	var a := dir.x * dir.x + dir.z * dir.z
	if a < 0.000001:
		return -1.0
	var b := 2.0 * (px * dir.x + pz * dir.z)
	var cc := px * px + pz * pz - r * r
	var disc := b * b - 4.0 * a * cc
	if disc < 0.0:
		return -1.0
	var t := (-b - sqrt(disc)) / (2.0 * a)
	if t < 0.0:
		return -1.0
	var y := from.y + dir.y * t
	if y < base.y - 0.05 or y > base.y + 1.85:
		return -1.0
	return t


## Mỗi khung hình chỉ cho 1 bot tìm đường (tránh dồn nhiều lần tìm đường cùng lúc gây khựng).
func can_path() -> bool:
	var f := Engine.get_process_frames()
	if f == path_budget_frame:
		return false
	path_budget_frame = f
	return true


func noise(pos: Vector3, radius: float, from_team: int) -> void:
	for b in bots:
		if b.alive and b.team != from_team and b.global_position.distance_to(pos) < radius:
			b.hear(pos)


func register_kill(killer, victim, headshot: bool) -> void:
	if bomb != null and bomb.active:
		bomb.on_kill(killer, victim, headshot)   # chế độ ĐẶT BOM: không hồi sinh giữa round, luật tiền/round nằm trong bomb.gd
		return
	if killer != null and is_instance_valid(killer) and killer != victim:
		killer.kills += 1
		team_score[killer.team] += 1
		hud.add_kill(str(killer.display_name), str(victim.display_name), headshot, int(killer.team))
		if killer == player:
			hud.kill_flash(headshot)
			money += (MP5_KILL_REWARD if player.cur_w == "mp5" else KILL_REWARD) + (HEADSHOT_BONUS if headshot else 0)
		elif killer is Bot:
			(killer as Bot).money = mini((killer as Bot).money + KILL_REWARD + (HEADSHOT_BONUS if headshot else 0), 16000)
			hud.set_money(money)
	else:
		hud.add_kill("World", str(victim.display_name), false, 1)
		if victim.team >= 0:
			team_score[1 - victim.team] += 1
	hud.set_score(team_score[0], team_score[1])
	if not match_over and (team_score[0] >= KILL_LIMIT or team_score[1] >= KILL_LIMIT):
		_end_match()
		return
	if not match_over:
		get_tree().create_timer(3.0, false).timeout.connect(_do_respawn.bind(victim))


func _do_respawn(who) -> void:
	if match_over or not is_instance_valid(who):
		return
	if who == player:
		_respawn_player()
	else:
		who.respawn(_pick_spawn(who.team))


func _end_match() -> void:
	match_over = true
	var win := "CT" if team_score[0] >= KILL_LIMIT else "T"
	hud.show_center("%s WIN!" % win, 6.0)
	hud.show_info("New match starting...", 6.0)
	get_tree().create_timer(6.0, false).timeout.connect(_restart_match)


func _restart_match() -> void:
	team_score = [0, 0]
	match_over = false
	hud.set_score(0, 0)
	money = START_MONEY
	hud.set_money(money)
	player.reset_loadout()
	pickups.clear_all()
	for n in get_tree().get_nodes_in_group("combatants"):
		n.kills = 0
		n.deaths = 0
	_respawn_player()
	for b in bots:
		b.respawn(_pick_spawn(b.team))


func _score_text() -> String:
	if bomb != null and bomb.active:
		return bomb.score_text()
	var all: Array = get_tree().get_nodes_in_group("combatants")
	all.sort_custom(func(a, b): return a.kills > b.kills)
	var s := "SCOREBOARD        CT %d : %d T\n\n" % [team_score[0], team_score[1]]
	for n in all:
		s += "[%s]  %s   K %d   D %d\n" % ["CT" if n.team == 0 else "T", str(n.display_name).rpad(10), n.kills, n.deaths]
	return s


# =====================================================================
#  HIỆU ỨNG
# =====================================================================
func spawn_impact(pos: Vector3, normal: Vector3) -> void:
	var q: MeshInstance3D
	if decals.size() >= 40:
		q = decals.pop_front()
	else:
		q = MeshInstance3D.new()
		var qm := QuadMesh.new()
		qm.size = Vector2(0.12, 0.12)
		q.mesh = qm
		q.material_override = decal_mat
		q.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		fx_root.add_child(q)
	var up := Vector3.UP if absf(normal.y) < 0.95 else Vector3.RIGHT
	q.global_transform = Transform3D(Basis.looking_at(-normal, up), pos + normal * 0.012)
	decals.append(q)
	_burst(pos, normal, spark_mat, 3, 0.2, 3.5)


func spawn_blood(pos: Vector3, normal: Vector3) -> void:
	_burst(pos, normal, blood_mat, 4, 0.3, 3.0)


func _burst(pos: Vector3, normal: Vector3, mat: Material, _count: int, _life: float, _speed: float) -> void:
	var key := mat.get_instance_id()
	var arr: Array = burst_pools[key]
	var i: int = burst_idx[key]
	burst_idx[key] = (i + 1) % arr.size()
	var p: CPUParticles3D = arr[i]
	p.global_position = pos + normal * 0.03
	p.direction = normal
	p.restart()
	p.emitting = true


func spawn_tracer(from: Vector3, to: Vector3) -> void:
	var length := from.distance_to(to)
	if length < 1.5:
		return
	var mi: MeshInstance3D = tracer_pool[tracer_i]
	tracer_time[tracer_i] = 0.05
	tracer_i = (tracer_i + 1) % tracer_pool.size()
	var up := Vector3.UP if absf((to - from).normalized().y) < 0.95 else Vector3.RIGHT
	var tb_basis := Basis.looking_at(to - from, up) * Basis.from_scale(Vector3(0.012, 0.012, length))
	mi.global_transform = Transform3D(tb_basis, (from + to) * 0.5)
	mi.visible = true


# =====================================================================
#  INPUT TOÀN CỤC
# =====================================================================
func _toggle_pause() -> void:
	paused_menu = not paused_menu
	get_tree().paused = paused_menu
	hud.set_paused(paused_menu)
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE if paused_menu else Input.MOUSE_MODE_CAPTURED


## Alt + Enter: bật/tắt toàn màn hình (dùng được cả ở menu lẫn trong game).
func _input(event: InputEvent) -> void:
	if event is InputEventKey:
		var k := event as InputEventKey
		if k.pressed and not k.echo and k.alt_pressed and (k.keycode == KEY_ENTER or k.keycode == KEY_KP_ENTER):
			if DisplayServer.window_get_mode() == DisplayServer.WINDOW_MODE_FULLSCREEN:
				DisplayServer.window_set_mode(DisplayServer.WINDOW_MODE_WINDOWED)
			else:
				DisplayServer.window_set_mode(DisplayServer.WINDOW_MODE_FULLSCREEN)
			get_viewport().set_input_as_handled()


func _unhandled_input(event: InputEvent) -> void:
	if settings_open and event is InputEventKey and (event as InputEventKey).pressed and (event as InputEventKey).keycode == KEY_ESCAPE:
		_close_settings()
		get_viewport().set_input_as_handled()
		return
	if hud == null or in_menu:
		return
	if event is InputEventKey:
		var k := event as InputEventKey
		if not k.pressed or k.echo:
			return
		if k.keycode == KEY_ESCAPE:
			if shop_open:
				_toggle_shop()
			else:
				_toggle_pause()
		elif k.keycode == KEY_B:
			_toggle_shop()
		elif k.keycode == KEY_1 and shop_open:
			_buy_m4()
		elif k.keycode == KEY_2 and shop_open:
			_buy_ak()
		elif k.keycode == KEY_3 and shop_open:
			_buy_deagle()
		elif k.keycode == KEY_4 and shop_open:
			_buy_ammo()
		elif k.keycode == KEY_5 and shop_open:
			_buy_awp()
		elif k.keycode == KEY_6 and shop_open:
			_buy_mp5()
		elif k.keycode == KEY_F3:
			debug_on = not debug_on
			if not debug_on:
				hud.set_debug("")
		elif k.keycode == KEY_F4:
			auto_res = false
			_set_res((res_idx + 1) % RES_STEPS.size())
		elif k.keycode == KEY_F11:
			var full := DisplayServer.window_get_mode() == DisplayServer.WINDOW_MODE_FULLSCREEN
			DisplayServer.window_set_mode(DisplayServer.WINDOW_MODE_WINDOWED if full else DisplayServer.WINDOW_MODE_FULLSCREEN)
	elif event is InputEventMouseButton:
		var mb := event as InputEventMouseButton
		if mb.pressed and not paused_menu and not shop_open and Input.mouse_mode != Input.MOUSE_MODE_CAPTURED:
			Input.mouse_mode = Input.MOUSE_MODE_CAPTURED


func _set_res(i: int) -> void:
	res_idx = clampi(i, 0, RES_STEPS.size() - 1)
	var r: Vector2i = _res_size(res_idx)
	sub.size = r   # chỉ đổi độ phân giải 3D, chữ và giao diện giữ nguyên
	_fit_ui()
	res_cooldown = 2.5
	fps_acc = 0.0
	fps_frames = 0
	if hud != null:
		hud.show_info("3D resolution: %dx%d  (F4 to change)" % [r.x, r.y], 2.5)


func _process(delta: float) -> void:
	if hud == null:
		return
	for ti in tracer_pool.size():
		if tracer_time[ti] > 0.0:
			tracer_time[ti] -= delta
			if tracer_time[ti] <= 0.0:
				(tracer_pool[ti] as MeshInstance3D).visible = false
	# tự giảm độ phân giải nếu FPS thấp hơn 45 liên tục trong 2 giây
	if auto_res and not paused_menu and not in_menu:
		if res_cooldown > 0.0:
			res_cooldown -= delta
			fps_acc = 0.0
			fps_frames = 0
		else:
			fps_acc += delta
			fps_frames += 1
			if fps_acc >= 1.5:
				var avg := float(fps_frames) / fps_acc
				fps_acc = 0.0
				fps_frames = 0
				if res_check_pending:
					# vừa hạ độ phân giải ở cửa sổ trước: nếu FPS gần như không khá hơn thì nghẽn ở CPU chứ không phải card đồ họa -> trả lại độ nét, thôi không tự hạ nữa
					res_check_pending = false
					if avg < res_prev_avg * 1.10:
						_set_res(res_prev_idx)
						auto_res = false
				elif avg < 50.0 and res_idx < RES_STEPS.size() - 1:   # mục tiêu ~60 FPS (trước đây 40)
					res_prev_avg = avg
					res_prev_idx = res_idx
					res_check_pending = true
					_set_res(res_idx + 1)
				elif avg < 34.0 and not cpu_saver:
					# đã ở độ phân giải thấp nhất mà vẫn chậm => máy nghẽn ở CPU: giảm tần số vật lý
					cpu_saver = true
					Engine.physics_ticks_per_second = 30
					hud.show_info("Power-saving mode ON (physics 30 Hz)", 3.0)
	if debug_on:
		var t := "FPS %d | script %.1f ms | physics %.1f ms | draw calls %d | tris %d | 3D res %s | editor=%s\n" % [
			Engine.get_frames_per_second(),
			Performance.get_monitor(Performance.TIME_PROCESS) * 1000.0,
			Performance.get_monitor(Performance.TIME_PHYSICS_PROCESS) * 1000.0,
			int(Performance.get_monitor(Performance.RENDER_TOTAL_DRAW_CALLS_IN_FRAME)),
			int(Performance.get_monitor(Performance.RENDER_TOTAL_PRIMITIVES_IN_FRAME)),
			str(_res_size(res_idx)), str(OS.has_feature("editor"))]
		t += "nav_ok=%s  waypoints=%d  spawnsCT=%d spawnsT=%d\n" % [str(nav_ok), waypoints.size(), spawns[0].size(), spawns[1].size()]
		t += "player pos=(%.1f, %.1f, %.1f)\n" % [player.global_position.x, player.global_position.y, player.global_position.z]
		for b in bots:
			t += b.debug_text() + "\n"
		hud.set_debug(t)
	var show := Input.is_action_pressed("scoreboard") and not paused_menu
	if show:
		score_timer -= delta
		if score_timer <= 0.0:
			score_timer = 0.2
			hud.set_scoreboard(true, _score_text())
	else:
		hud.set_scoreboard(false, "")
