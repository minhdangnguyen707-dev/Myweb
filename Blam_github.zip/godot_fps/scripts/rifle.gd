extends Node3D
## Súng trường M4A1 góc nhìn thứ nhất (dựng hoàn toàn bằng code) + hai tay + animation.
## Có cùng giao diện (API) với Viewmodel của Glock để Player dùng thay thế qua lại.
##
## Hệ trục của súng: +X phải, +Y lên, -Z là hướng nòng. Gốc = phía sau thân trên (upper receiver).
## Kiểu M4A1 CAR cổ điển (như CS 1.6): quai xách, ốp tay tròn có gân, đầu giảm giật A2, báng vai trượt, băng STANAG.
## Toàn bộ chi tiết nhỏ được GỘP vào vài khối lưới (lớp MB lấy từ ak47.gd) nên chỉ tốn ~6 lệnh vẽ.
## Quai xách tự hạ xuống khi ngắm (chuột phải) để không che tầm nhìn; chấu ngắm trước và thước ngắm sau giữ đúng y = 0.060.

signal sound(sound_name: String)
signal reload_inserted()
signal action_finished(action_name: String)

const D2R := 0.0174533
const Hands := preload("res://scripts/hands.gd")
const AK := preload("res://scripts/mesh_builder.gd")   # lớp dựng lưới AK.MB (tách ra từ ak47.gd cũ)

const HIP_POS := Vector3(0.12, -0.155, -0.36)
const HIP_ROT := Vector3(0.0, 0.06, 0.0)
const ADS_POS := Vector3(0.0, -0.062, -0.22)

const MAG_CENTER := Vector3(0.0, -0.125, -0.115)
const MAG_TRAVEL := 0.14
const LH_HOLD := Vector3(0.0, -0.050, -0.36)
const LH_MAG_OFF := Vector3(-0.034, 0.0, -0.004)   # vị trí tay so với tâm băng đạn khi cầm băng
const BELT := Vector3(-0.14, -0.28, 0.05)
const CHARGE_POS := Vector3(-0.025, 0.050, 0.035)
const LH_WRIST_LOCAL := Vector3(-0.004, -0.010, 0.050)
const RH_WRIST := Vector3(0.028, -0.165, 0.040)
const ELBOW_L := Vector3(-0.22, -0.30, 0.15)
const ELBOW_R := Vector3(0.22, -0.34, 0.20)
const MUZZLE := Vector3(0.0, 0.002, -0.665)

const DRAW_TIME := 0.9
const RELOAD_TAC := 2.4
const RELOAD_EMPTY := 3.0
const INSPECT_TIME := 3.8

enum Mode { NONE, DRAW, RELOAD, INSPECT }
enum MagMode { AXIS, HAND, HIDDEN }

static var _tex_cache: Dictionary = {}

# ---------------- trạng thái nhận từ Player ----------------
var move_amount := 0.0
var run_amount := 0.0
var grounded := true
var ads := false
var crouched := false
var mouse_delta := Vector2.ZERO
var wall_push := 0.0
var _wall_s := 0.0
const WALL_BACK := 0.12   # hạ súng khi sát tường: lùi tay (mét) - khớp bảng WALL_DIMS trong player.gd
const WALL_RX := 1.45     # hạ súng khi sát tường: góc chúc nòng xuống (rad)
var ads_t := 0.0

# ---------------- node ----------------
var rig: Node3D
var gun: Node3D
var mag: Node3D
var lh: Node3D
var charge: MeshInstance3D
var handle: MeshInstance3D       # quai xách (hạ xuống khi ngắm)
var flash: Node3D
var smoke: MeshInstance3D
var smoke_mat: StandardMaterial3D
var lh_fingers: Array[Node3D] = []
var limb_l
var limb_r
var rh_node: Node3D

var m_metal: StandardMaterial3D
var m_poly: StandardMaterial3D
var m_glove: StandardMaterial3D
var m_sleeve: StandardMaterial3D
var m_brass: StandardMaterial3D

# ---------------- animation ----------------
var mode: int = Mode.NONE
var mode_t := 0.0
var mode_len := 1.0
var reload_is_empty := false
var cues: Array = []

var a_pos := Vector3.ZERO
var a_rot := Vector3.ZERO
var lh_pos := Vector3.ZERO
var lh_curl := 0.0
var ch_off := 0.0
var mag_mode: int = MagMode.AXIS
var mag_out := 0.0
var mag_basis := Basis.IDENTITY

var flash_t := 0.0
var smoke_amt := 0.0
var _time := 0.0
var bob_phase := 0.0
var bob_smooth := 0.0
var run_t := 0.0
var air_t := 0.0
var sway := Vector2.ZERO
var kick_pos := Vector3.ZERO
var kick_pos_v := Vector3.ZERO
var kick_rot := Vector3.ZERO
var kick_rot_v := Vector3.ZERO
var shells: Array = []
var drops: Array = []

var k_draw_pos: Array
var k_draw_rot: Array
var k_tac_pos: Array
var k_tac_rot: Array
var k_tac_lh: Array
var k_tac_curl: Array
var k_emp_pos: Array
var k_emp_rot: Array
var k_emp_lh: Array
var k_emp_curl: Array
var k_emp_charge: Array
var k_magout: Array
var k_insp_pos: Array
var k_insp_rot: Array
var k_insp_lh: Array


func _ready() -> void:
	rig = Node3D.new()
	add_child(rig)
	gun = Node3D.new()
	rig.add_child(gun)
	mag_basis = Basis.from_euler(Vector3(8.0 * D2R, 0.0, 0.0))
	_make_materials()
	_build_gun()
	_build_hands()
	_build_flash()
	_build_keys()
	lh_pos = LH_HOLD
	limb_l = Hands.Arm.new(rig, true)
	limb_r = Hands.Arm.new(rig)
	limb_r.attach(rh_node, Basis(Vector3.RIGHT, -20.0 * D2R), Vector3.ZERO, Vector3(0.0, -1.0, 0.0), 0.0, 0)
	limb_l.mag_extra = Vector3(0.034, 0.0, 0.004)
	limb_l.attach(lh, Basis.IDENTITY, Vector3.ZERO, Vector3(0.0, -1.0, 0.0), 0.0, 1, Vector3(0.0, 0.050, 0.0))


# =====================================================================
#  DỰNG MÔ HÌNH
# =====================================================================
func _mat(color: Color, rough: float, metal: float) -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.albedo_color = color
	m.roughness = rough
	m.metallic = metal
	return m


func _make_materials() -> void:
	# kim loại anod đen (có vân hạt + vài vết xước), nhựa polymer nhám: màu theo đỉnh nhân với ảnh vân
	m_metal = _mat(Color(1, 1, 1), 0.52, 0.30)
	m_metal.albedo_texture = _tex_anod()
	m_metal.vertex_color_use_as_albedo = true
	m_metal.vertex_color_is_srgb = true
	m_poly = _mat(Color(1, 1, 1), 0.90, 0.0)
	m_poly.albedo_texture = _tex_poly()
	m_poly.vertex_color_use_as_albedo = true
	m_poly.vertex_color_is_srgb = true
	m_glove = Hands.material()   # tay dùng chung mọi súng (scripts/hands.gd)
	m_sleeve = Hands.material()
	m_brass = _mat(Color(0.85, 0.62, 0.22), 0.35, 0.9)


# =====================================================================
#  ẢNH TỰ SINH (kim loại anod, nhựa nhám) - lặp liền mạch, không cần file ảnh
# =====================================================================
static func _h(ix: int, iy: int, seed_v: int) -> float:
	var h: int = ix * 374761393 + iy * 668265263 + seed_v * 1442695041
	h = (h ^ (h >> 13)) * 1274126177
	h = h ^ (h >> 16)
	return float(h & 0xffff) / 65535.0


## Nhiễu giá trị lặp theo chu kỳ px x py ô (để ảnh nối liền không thấy đường nối).
static func _vn(x: float, y: float, px: int, py: int, seed_v: int) -> float:
	var x0 := floori(x)
	var y0 := floori(y)
	var fx := x - float(x0)
	var fy := y - float(y0)
	fx = fx * fx * (3.0 - 2.0 * fx)
	fy = fy * fy * (3.0 - 2.0 * fy)
	var a := _h(posmod(x0, px), posmod(y0, py), seed_v)
	var b := _h(posmod(x0 + 1, px), posmod(y0, py), seed_v)
	var c := _h(posmod(x0, px), posmod(y0 + 1, py), seed_v)
	var d := _h(posmod(x0 + 1, px), posmod(y0 + 1, py), seed_v)
	return lerpf(lerpf(a, b, fx), lerpf(c, d, fx), fy)


static func _tex_anod() -> ImageTexture:
	if _tex_cache.has("anod"):
		return _tex_cache["anod"]
	var n := 64
	var img := Image.create(n, n, false, Image.FORMAT_RGBA8)
	for y in n:
		for x in n:
			var u := float(x) / float(n)
			var v := float(y) / float(n)
			var a := _vn(u * 32.0, v * 32.0, 32, 32, 3)
			var b := _vn(u * 4.0, v * 40.0, 4, 40, 9)
			var g := 0.80 + 0.13 * a + 0.07 * b
			img.set_pixel(x, y, Color(g, g, g * 1.02))
	# vài vết xước sáng chạy dọc thân súng
	var rng := RandomNumberGenerator.new()
	rng.seed = 5656
	for k in 14:
		var sx := rng.randi_range(0, n - 1)
		var sy := rng.randi_range(0, n - 1)
		var ln := rng.randi_range(8, 24)
		var drift := rng.randf_range(-0.12, 0.12)
		for i in ln:
			var px := (sx + i) % n
			var py := posmod(int(round(float(sy) + drift * float(i))), n)
			var c := img.get_pixel(px, py)
			img.set_pixel(px, py, Color(minf(c.r + 0.12, 1.0), minf(c.g + 0.12, 1.0), minf(c.b + 0.13, 1.0)))
	img.generate_mipmaps()
	var tex := ImageTexture.create_from_image(img)
	_tex_cache["anod"] = tex
	return tex


static func _tex_poly() -> ImageTexture:
	if _tex_cache.has("poly"):
		return _tex_cache["poly"]
	var n := 64
	var img := Image.create(n, n, false, Image.FORMAT_RGBA8)
	for y in n:
		for x in n:
			var u := float(x) / float(n)
			var v := float(y) / float(n)
			var g := 0.84 + 0.10 * _h(x, y, 21) + 0.06 * _vn(u * 6.0, v * 6.0, 6, 6, 17)
			img.set_pixel(x, y, Color(g, g, g))
	img.generate_mipmaps()
	var tex := ImageTexture.create_from_image(img)
	_tex_cache["poly"] = tex
	return tex


func _inst(parent: Node, mb, mat: Material) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	mi.mesh = mb.make_mesh()
	mi.material_override = mat
	mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	parent.add_child(mi)
	return mi


func _build_gun() -> void:
	_inst(gun, _geo_metal(), m_metal)
	_inst(gun, _geo_poly(), m_poly)
	handle = _inst(gun, _geo_handle(), m_metal)
	# tay kéo thượng đạn: một node riêng (animation thay đạn hết đạn kéo nó ra sau)
	charge = _inst(gun, _geo_charge(), m_metal)
	charge.position = Vector3(0.0, 0.038, 0.035)

	# băng đạn STANAG 30 viên: vẫn là một Node3D con của gun (animation dịch chuyển/xoay/ẩn node này)
	mag = Node3D.new()
	gun.add_child(mag)
	_inst(mag, _geo_mag(), m_metal)
	_inst(mag, _geo_mag_tips(), m_brass)
	mag.transform = Transform3D(mag_basis, MAG_CENTER)


# ---------------- bảng màu đỉnh (nhân với ảnh vân) ----------------
const C_ANO := Color(0.118, 0.121, 0.132)       # nhôm anod đen (thân súng)
const C_ANO_L := Color(0.165, 0.170, 0.185)     # mặt / cạnh sáng hơn một chút
const C_ANO_X := Color(0.250, 0.255, 0.270)     # chỗ sờn lộ kim loại
const C_STEEL := Color(0.200, 0.205, 0.220)     # thép (vòng, chốt)
const C_BRIGHT := Color(0.330, 0.340, 0.360)    # thép sáng bóng
const C_BARREL := Color(0.100, 0.103, 0.112)    # nòng phốt phát hoá
const C_POLY := Color(0.085, 0.088, 0.094)      # nhựa polymer
const C_POLY_L := Color(0.120, 0.124, 0.132)
const C_RUBBER := Color(0.036, 0.036, 0.040)    # đế báng cao su
const C_DARK := Color(0.045, 0.045, 0.050)
const C_BLACK := Color(0.020, 0.020, 0.023)
const C_MAG := Color(0.125, 0.123, 0.120)
const C_MAG_RIB := Color(0.068, 0.066, 0.064)
const C_WHITE := Color(1.0, 1.0, 1.0)


# =====================================================================
#  HÀM HÌNH HỌC NHỎ
# =====================================================================
static func _T(x: float, y: float, z: float) -> Transform3D:
	return Transform3D(Basis.IDENTITY, Vector3(x, y, z))


## Xoay quanh trục X (độ), đặt tại (x, y, z).
static func _TX(x: float, y: float, z: float, deg: float) -> Transform3D:
	return Transform3D(Basis(Vector3.RIGHT, deg * 0.0174533), Vector3(x, y, z))


## Xoay quanh trục Y (độ). Hình trụ dựng dọc Z sẽ nằm ngang theo X: góc +90 hướng ra bên phải, -90 hướng ra bên trái.
static func _TY(x: float, y: float, z: float, deg: float) -> Transform3D:
	return Transform3D(Basis(Vector3.UP, deg * 0.0174533), Vector3(x, y, z))


## Xoay quanh trục Z (độ).
## Mặt cắt hình chữ nhật bo góc. rt = bo góc trên, rb = bo góc dưới.
static func _rrect(w: float, h: float, rt: float, rb: float, seg: int = 3) -> PackedVector2Array:
	var pts := PackedVector2Array()
	var hw := w * 0.5
	var hh := h * 0.5
	var corners := [
		[Vector2(hw - rb, -hh + rb), rb, -90.0],
		[Vector2(hw - rt, hh - rt), rt, 0.0],
		[Vector2(-hw + rt, hh - rt), rt, 90.0],
		[Vector2(-hw + rb, -hh + rb), rb, 180.0],
	]
	for c in corners:
		var ctr: Vector2 = c[0]
		var r: float = c[1]
		var a0: float = c[2]
		if r < 0.0004:
			pts.append(ctr)
		else:
			for s in range(seg + 1):
				var ang := deg_to_rad(a0 + 90.0 * float(s) / float(seg))
				pts.append(ctr + Vector2(cos(ang), sin(ang)) * r)
	return pts


## Bo tròn các góc của một đa giác: mỗi đỉnh có bán kính riêng (0 = giữ góc nhọn).
static func _round_poly(pts: PackedVector2Array, radii: PackedFloat32Array, seg: int) -> PackedVector2Array:
	var out := PackedVector2Array()
	var n := pts.size()
	for i in range(n):
		var p := pts[i]
		var a := pts[(i + n - 1) % n]
		var b := pts[(i + 1) % n]
		var r := radii[i]
		if r <= 0.0001:
			out.append(p)
			continue
		var la := p.distance_to(a)
		var lb := p.distance_to(b)
		r = minf(r, minf(0.45 * la, 0.45 * lb))
		var p0 := p + (a - p) / la * r
		var p1 := p + (b - p) / lb * r
		for k in range(seg + 1):
			var t := float(k) / float(seg)
			out.append(p0 * ((1.0 - t) * (1.0 - t)) + p * (2.0 * (1.0 - t) * t) + p1 * (t * t))
	return out


## Đùn một hình nhìn NGANG (toạ độ (z, y) của súng) theo bề ngang X từ x0 đến x1.
## pre = phép biến đổi thêm (ví dụ nghiêng báng cầm).
static func _side(m, pts: PackedVector2Array, x0: float, x1: float, col: Color, pre: Transform3D = Transform3D.IDENTITY) -> void:
	var q := PackedVector2Array()
	for p in pts:
		q.append(Vector2(-p.x, p.y))
	m.add_prism(q, x0, x1, pre * Transform3D(Basis(Vector3.UP, PI * 0.5), Vector3.ZERO), col)


## Mặt cắt tròn có gân dọc (ốp tay M4). Rãnh nằm ở góc 0 và 180 độ (hai bên hông).
static func _fins(r_out: float, r_in: float, n: int, duty: float) -> PackedVector2Array:
	var pts := PackedVector2Array()
	var step := TAU / float(n)
	var half := step * duty * 0.5
	for k in range(n):
		var c := step * (float(k) + 0.5)
		pts.append(Vector2(cos(c - half), sin(c - half)) * r_out)
		pts.append(Vector2(cos(c + half), sin(c + half)) * r_out)
		pts.append(Vector2(cos(c + half), sin(c + half)) * r_in)
		pts.append(Vector2(cos(c + step - half), sin(c + step - half)) * r_in)
	return pts


# =====================================================================
#  KHỐI KIM LOẠI: thân, ray, nòng, ngắm, chốt, vòng cò, ống đệm
# =====================================================================
static func _geo_metal() -> Variant:
	var m = AK.MB.new()
	m.uv_scale = Vector2(8.0, 8.0)

	# ================= THÂN TRÊN =================
	m.add_prism(_rrect(0.0455, 0.0505, 0.006, 0.0035, 3), 0.040, -0.232, _T(0.0, 0.0015, 0.0), C_ANO)

	# ================= THÂN DƯỚI + HỐC BĂNG ĐẠN (nhìn ngang, đùn theo bề ngang) =================
	var lo_ctrl := PackedVector2Array([
		Vector2(-0.174, -0.0232), Vector2(-0.174, -0.060), Vector2(-0.152, -0.068), Vector2(-0.082, -0.068),
		Vector2(-0.050, -0.071), Vector2(-0.014, -0.074), Vector2(0.020, -0.068), Vector2(0.040, -0.052),
		Vector2(0.040, -0.0232),
	])
	var lo_rad := PackedFloat32Array([0.0, 0.006, 0.006, 0.0, 0.012, 0.012, 0.012, 0.010, 0.0])
	_side(m, _round_poly(lo_ctrl, lo_rad, 3), -0.0215, 0.0215, C_ANO)
	m.add_prism(_rrect(0.0425, 0.034, 0.002, 0.004, 2), -0.150, -0.080, _T(0.0, -0.0775, 0.0), C_ANO)
	m.add_prism(_rrect(0.0455, 0.006, 0.001, 0.003, 2), -0.156, -0.074, _T(0.0, -0.0915, 0.0), C_ANO_L)
	# khe tách giữa thân trên và thân dưới
	m.add_box(Vector3(0.0462, 0.0016, 0.2140), _T(0.0, -0.0238, -0.067), C_BLACK)

	# ================= RAY PICATINNY TRÊN THÂN (đáy rãnh + các gờ ngang đều nhau) =================
	m.add_prism(_rrect(0.0205, 0.0040, 0.0, 0.0, 1), 0.030, -0.228, _T(0.0, 0.0280, 0.0), C_DARK)
	for i in range(26):
		var zz := 0.0255 - 0.0100 * float(i)
		m.add_prism(_rrect(0.0215, 0.0040, 0.001, 0.0, 1), zz + 0.0029, zz - 0.0029, _T(0.0, 0.0320, 0.0), C_ANO_L)

	# ================= THƯỚC NGẮM SAU (đỉnh hai tai y = 0.060, giữ như bản cũ) =================
	m.add_prism(_rrect(0.026, 0.016, 0.003, 0.0, 2), -0.031, -0.059, _T(0.0, 0.040, 0.0), C_ANO)
	for sx in [-1.0, 1.0]:
		m.add_box(Vector3(0.0042, 0.0200, 0.0140), _T(sx * 0.0085, 0.0500, -0.045), C_ANO_L)
	m.add_box(Vector3(0.0130, 0.0040, 0.0140), _T(0.0, 0.0470, -0.045), C_DARK)
	m.add_cyl(0.0040, 0.0040, -0.0004, _TY(0.0132, 0.0400, -0.045, 90.0), C_STEEL, 8)

	# ================= NÒNG + KHỐI KHÍ + CHẤU NGẮM TRƯỚC (đỉnh chấu y = 0.060) =================
	m.add_cyl(0.0085, -0.226, -0.472, _T(0.0, 0.002, 0.0), C_BARREL, 10)
	m.add_cyl(0.0072, -0.498, -0.606, _T(0.0, 0.002, 0.0), C_BARREL, 10)
	m.add_cyl(0.0108, -0.472, -0.500, _T(0.0, 0.002, 0.0), C_ANO, 12)
	var tower := PackedVector2Array([Vector2(-0.0062, 0.007), Vector2(0.0062, 0.007), Vector2(0.0032, 0.0425), Vector2(-0.0032, 0.0425)])
	m.add_prism(tower, -0.4775, -0.4925, _T(0.0, 0.0, 0.0), C_ANO)
	m.add_box(Vector3(0.0036, 0.0200, 0.0036), _T(0.0, 0.0500, -0.485), C_BLACK)
	for sx in [-1.0, 1.0]:
		m.add_box(Vector3(0.0022, 0.0100, 0.0120), _T(sx * 0.0050, 0.0440, -0.485), C_ANO)
	# ngàm lê + vòng đeo dây dưới khối khí
	m.add_box(Vector3(0.0070, 0.0080, 0.0140), _T(0.0, -0.0105, -0.486), C_ANO)
	m.add_rod(Vector3(0.0, -0.0100, -0.494), Vector3(0.0, -0.0220, -0.494), 0.0030, 0.0040, C_BRIGHT, 0.001)
	m.add_rod(Vector3(0.0, -0.0220, -0.494), Vector3(0.0, -0.0220, -0.480), 0.0030, 0.0040, C_BRIGHT, 0.001)
	m.add_rod(Vector3(0.0, -0.0220, -0.480), Vector3(0.0, -0.0100, -0.480), 0.0030, 0.0040, C_BRIGHT, 0.001)

	# ================= ĐẦU GIẢM GIẬT A2 (có khe) =================
	m.add_cyl(0.0090, -0.600, -0.608, _T(0.0, 0.002, 0.0), C_STEEL, 12)
	m.add_cyl(0.0107, -0.608, -0.652, _T(0.0, 0.002, 0.0), C_DARK, 14)
	m.add_cyl(0.0113, -0.646, -0.653, _T(0.0, 0.002, 0.0), C_STEEL, 14)
	for k in range(5):
		var ang := float(k) * 45.0 * D2R
		var sl := Transform3D(Basis(Vector3(0.0, 0.0, 1.0), ang), Vector3(cos(ang) * 0.0106, 0.002 + sin(ang) * 0.0106, -0.627))
		m.add_box(Vector3(0.0030, 0.0030, 0.0220), sl, C_BLACK)

	# ================= VÒNG DELTA + NẮP ĐẦU ỐP TAY =================
	m.add_cyl(0.0300, -0.230, -0.240, _T(0.0, -0.004, 0.0), C_STEEL, 16)
	m.add_cyl(0.0285, -0.240, -0.244, _T(0.0, -0.004, 0.0), C_DARK, 16)
	m.add_cyl(0.0276, -0.456, -0.467, _T(0.0, -0.004, 0.0), C_ANO_L, 16)

	# ================= NẮP CỬA THOÁT VỎ + NÚT ĐẨY TRỢ LỰC (bên phải) =================
	m.add_box(Vector3(0.0014, 0.0230, 0.0560), _T(0.0231, 0.0045, -0.068), C_BLACK)
	m.add_box(Vector3(0.0018, 0.0200, 0.0520), _T(0.0236, 0.0045, -0.068), C_ANO_L)
	m.add_cyl(0.0020, -0.044, -0.092, _T(0.0242, -0.0075, 0.0), C_BRIGHT, 6)
	m.add_cyl(0.0058, 0.012, 0.034, _T(0.0268, -0.0030, 0.0), C_ANO, 8)
	m.add_cyl(0.0044, 0.034, 0.041, _T(0.0268, -0.0030, 0.0), C_STEEL, 8)

	# ================= CẦN CHỌN CHẾ ĐỘ BẮN + NÚT KHOÁ NÒNG (bên trái) =================
	m.add_cyl(0.0068, 0.0040, -0.0005, _TY(-0.0215, -0.0400, -0.0020, -90.0), C_STEEL, 10)
	m.add_rod(Vector3(-0.0252, -0.0400, -0.0020), Vector3(-0.0252, -0.0305, -0.0185), 0.0030, 0.0042, C_BRIGHT, 0.001)
	m.add_rod(Vector3(-0.0225, -0.0300, -0.1030), Vector3(-0.0225, -0.0460, -0.0950), 0.0034, 0.0070, C_ANO_L, 0.001)
	m.add_cyl(0.0040, 0.0030, -0.0005, _TY(-0.0215, -0.0270, -0.0560, -90.0), C_BRIGHT, 8)

	# ================= NÚT NHẢ BĂNG ĐẠN (phải) + CHỐT BẢN LỀ / CHỐT THÁO (hai bên) =================
	m.add_cyl(0.0046, 0.0050, -0.0005, _TY(0.0215, -0.0630, -0.0840, 90.0), C_BRIGHT, 10)
	for sx in [-1.0, 1.0]:
		m.add_cyl(0.0042, 0.0020, -0.0004, _TY(sx * 0.0215, -0.0415, -0.1585, sx * 90.0), C_BRIGHT, 8)
		m.add_cyl(0.0042, 0.0020, -0.0004, _TY(sx * 0.0215, -0.0415, 0.0245, sx * 90.0), C_BRIGHT, 8)
		m.add_cyl(0.0030, 0.0016, -0.0004, _TY(sx * 0.0228, 0.0100, 0.0300, sx * 90.0), C_BRIGHT, 6)

	# ================= VÒNG BẢO VỆ CÒ + CÒ =================
	var tg := [
		Vector3(0.0, -0.067, -0.078), Vector3(0.0, -0.080, -0.074), Vector3(0.0, -0.090, -0.058),
		Vector3(0.0, -0.094, -0.038), Vector3(0.0, -0.088, -0.018), Vector3(0.0, -0.078, -0.010),
	]
	for i in range(tg.size() - 1):
		m.add_rod(tg[i], tg[i + 1], 0.0040, 0.0056, C_ANO, 0.0012)
	m.add_rod(Vector3(0.0, -0.068, -0.046), Vector3(0.0, -0.087, -0.038), 0.0042, 0.0045, C_BRIGHT, 0.0012)

	# ================= ỐNG ĐỆM (ống trượt báng) =================
	m.add_cyl(0.0155, 0.036, 0.150, _T(0.0, -0.004, 0.0), C_ANO, 12)
	m.add_cyl(0.0188, 0.040, 0.0485, _T(0.0, -0.004, 0.0), C_STEEL, 14)
	# vòng đeo dây dưới báng
	m.add_rod(Vector3(0.0, -0.069, 0.195), Vector3(0.0, -0.081, 0.195), 0.0025, 0.0040, C_BRIGHT, 0.0008)
	m.add_rod(Vector3(0.0, -0.081, 0.195), Vector3(0.0, -0.081, 0.207), 0.0025, 0.0040, C_BRIGHT, 0.0008)
	m.add_rod(Vector3(0.0, -0.081, 0.207), Vector3(0.0, -0.071, 0.207), 0.0025, 0.0040, C_BRIGHT, 0.0008)
	return m


# =====================================================================
#  KHỐI NHỰA: ốp tay, báng cầm, báng vai
# =====================================================================
static func _geo_poly() -> Variant:
	var p = AK.MB.new()
	p.uv_scale = Vector2(10.0, 10.0)

	# ================= ỐP TAY M4 CAR (tròn, nhiều gân dọc, hơi thon về phía trước) =================
	var fins := _fins(0.0272, 0.0253, 20, 0.58)
	p.add_prism(fins, -0.244, -0.352, _T(0.0, -0.004, 0.0), C_POLY)
	p.add_prism(fins, -0.352, -0.456, _T(0.0, -0.004, 0.0), C_POLY, 0.93)
	for sx in [-1.0, 1.0]:
		p.add_rod(Vector3(sx * 0.0262, -0.004, -0.246), Vector3(sx * 0.0262, -0.004, -0.352), 0.0016, 0.0016, C_BLACK, 0.0004)
		p.add_rod(Vector3(sx * 0.0262, -0.004, -0.352), Vector3(sx * 0.0244, -0.004, -0.454), 0.0016, 0.0016, C_BLACK, 0.0004)

	# ================= BÁNG CẦM (nghiêng 20 độ, đúng chỗ bàn tay phải) =================
	var gx := Transform3D(Basis(Vector3.RIGHT, -20.0 * D2R), Vector3(0.0, -0.105, 0.0))
	var grip_ctrl := PackedVector2Array([
		Vector2(-0.019, 0.0475), Vector2(-0.021, 0.026), Vector2(-0.016, 0.014), Vector2(-0.021, 0.004),
		Vector2(-0.016, -0.008), Vector2(-0.021, -0.018), Vector2(-0.019, -0.0475), Vector2(0.024, -0.0475),
		Vector2(0.021, -0.030), Vector2(0.019, -0.005), Vector2(0.023, 0.025), Vector2(0.028, 0.0475),
	])
	var grip_rad := PackedFloat32Array([0.003, 0.004, 0.004, 0.004, 0.004, 0.004, 0.003, 0.003, 0.012, 0.016, 0.014, 0.003])
	_side(p, _round_poly(grip_ctrl, grip_rad, 3), -0.0158, 0.0158, C_POLY, gx)

	# ================= BÁNG VAI TRƯỢT (M4), thon và nằm thấp để không che tầm ngắm =================
	var st_ctrl := PackedVector2Array([
		Vector2(0.092, 0.0125), Vector2(0.232, 0.0098), Vector2(0.238, 0.004), Vector2(0.240, -0.072),
		Vector2(0.231, -0.080), Vector2(0.200, -0.072), Vector2(0.150, -0.056), Vector2(0.110, -0.040),
		Vector2(0.092, -0.035),
	])
	var st_rad := PackedFloat32Array([0.004, 0.006, 0.004, 0.004, 0.006, 0.020, 0.030, 0.012, 0.003])
	_side(p, _round_poly(st_ctrl, st_rad, 4), -0.0180, 0.0180, C_POLY)
	var pad_ctrl := PackedVector2Array([
		Vector2(0.236, 0.0075), Vector2(0.2475, 0.0040), Vector2(0.2495, -0.0740), Vector2(0.2405, -0.0830), Vector2(0.232, -0.0810),
	])
	var pad_rad := PackedFloat32Array([0.002, 0.003, 0.003, 0.004, 0.002])
	_side(p, _round_poly(pad_ctrl, pad_rad, 2), -0.0190, 0.0190, C_RUBBER)
	# cần nhả nấc báng (dưới ống đệm) + hai rãnh dập bên hông báng
	p.add_rod(Vector3(0.0, -0.038, 0.100), Vector3(0.0, -0.047, 0.130), 0.0160, 0.0060, C_POLY_L, 0.002)
	for sx in [-1.0, 1.0]:
		p.add_box(Vector3(0.0012, 0.0260, 0.0040), _T(sx * 0.0181, -0.028, 0.130), C_BLACK)
		p.add_box(Vector3(0.0012, 0.0260, 0.0040), _T(sx * 0.0181, -0.028, 0.170), C_BLACK)
	return p


# =====================================================================
#  QUAI XÁCH (carry handle) - hạ xuống khi ngắm để không che tầm nhìn
# =====================================================================
static func _geo_handle() -> Variant:
	var h = AK.MB.new()
	h.uv_scale = Vector2(8.0, 8.0)
	var ctrl := PackedVector2Array([
		Vector2(-0.198, 0.0300), Vector2(-0.198, 0.062), Vector2(-0.186, 0.086), Vector2(-0.080, 0.088),
		Vector2(-0.062, 0.068), Vector2(-0.060, 0.0300), Vector2(-0.084, 0.0300), Vector2(-0.088, 0.058),
		Vector2(-0.094, 0.070), Vector2(-0.172, 0.071), Vector2(-0.178, 0.060), Vector2(-0.178, 0.0300),
	])
	var rad := PackedFloat32Array([0.0, 0.004, 0.010, 0.010, 0.006, 0.0, 0.0, 0.004, 0.004, 0.004, 0.003, 0.0])
	_side(h, _round_poly(ctrl, rad, 3), -0.0105, 0.0105, C_ANO)
	h.add_prism(_rrect(0.0270, 0.0100, 0.0045, 0.0015, 3), -0.080, -0.186, _T(0.0, 0.0822, 0.0), C_ANO_L)
	h.add_cyl(0.0046, 0.0045, -0.0004, _TY(0.0135, 0.0760, -0.071, 90.0), C_STEEL, 8)
	h.add_cyl(0.0030, 0.0016, -0.0004, _TY(-0.0107, 0.0600, -0.190, -90.0), C_BRIGHT, 6)
	h.add_cyl(0.0030, 0.0016, -0.0004, _TY(0.0107, 0.0600, -0.190, 90.0), C_BRIGHT, 6)
	return h


# =====================================================================
#  TAY KÉO THƯỢNG ĐẠN (dạng chữ T) - gốc node nằm ở giữa tay kéo
# =====================================================================
static func _geo_charge() -> Variant:
	var c = AK.MB.new()
	c.uv_scale = Vector2(8.0, 8.0)
	c.add_prism(_rrect(0.0150, 0.0110, 0.003, 0.001, 2), 0.0150, -0.0130, _T(0.0, 0.0, 0.0), C_ANO_L)
	c.add_box(Vector3(0.0105, 0.0075, 0.0300), _T(-0.0125, -0.0005, 0.0010), C_ANO_L)
	c.add_box(Vector3(0.0060, 0.0075, 0.0240), _T(0.0105, -0.0005, 0.0030), C_ANO_L)
	c.add_box(Vector3(0.0090, 0.0040, 0.0060), _T(0.0, 0.0055, 0.0120), C_ANO_X)
	c.add_box(Vector3(0.0100, 0.0050, 0.0180), _T(0.0, -0.0070, -0.0020), C_DARK)
	return c


# =====================================================================
#  BĂNG ĐẠN STANAG 30 viên: 4 khúc cong nhẹ, gân dập nổi, đế băng. Gốc node = tâm băng đạn.
# =====================================================================
static func _geo_mag() -> Variant:
	var mb = AK.MB.new()
	mb.uv_scale = Vector2(10.0, 10.0)
	var p := Vector3(0.0, 0.0560, 0.002)
	var seg := 0.0285
	var dir := Vector3.ZERO
	var rear := Vector3.ZERO
	for i in range(4):
		var a := (float(i) * 3.4 + 1.4) * D2R
		dir = Vector3(0.0, -cos(a), -sin(a))
		rear = Vector3(0.0, -sin(a), cos(a))
		var q := p + dir * seg
		mb.add_rod(p - dir * 0.0008, q + dir * 0.0008, 0.0255, 0.0400, C_MAG, 0.0035)
		for t in [0.25, 0.75]:
			var c: Vector3 = p.lerp(q, t)
			mb.add_rod(c - dir * 0.0014, c + dir * 0.0014, 0.0268, 0.0414, C_MAG_RIB, 0.0035)
		mb.add_rod(p + rear * 0.0205, q + rear * 0.0205, 0.0060, 0.0030, C_MAG_RIB, 0.001)
		mb.add_rod(p - rear * 0.0205, q - rear * 0.0205, 0.0060, 0.0030, C_MAG_RIB, 0.001)
		var mid := p.lerp(q, 0.5)
		mb.add_cyl(0.0021, 0.0008, -0.0002, _TY(-0.0128, mid.y, mid.z, -90.0), C_BLACK, 8)
		p = q
	# đế băng đạn
	mb.add_rod(p - dir * 0.0020, p + dir * 0.0085, 0.0300, 0.0440, C_BLACK, 0.003)
	mb.add_rod(p + dir * 0.0035, p + dir * 0.0060, 0.0190, 0.0480, C_MAG_RIB, 0.002)
	# môi tiếp đạn + ngàm khoá băng
	mb.add_box(Vector3(0.0262, 0.0050, 0.0410), _T(0.0, 0.0565, 0.0), C_STEEL)
	mb.add_box(Vector3(0.0016, 0.0070, 0.0140), _T(0.0128, 0.0390, 0.0050), C_BLACK)
	return mb


## Hai đầu đạn lấp ló ở miệng băng đạn (chỉ thấy khi băng rời khỏi súng).
static func _geo_mag_tips() -> Variant:
	var tb = AK.MB.new()
	tb.uv_scale = Vector2(10.0, 10.0)
	tb.add_rod(Vector3(-0.0045, 0.050, 0.003), Vector3(-0.0045, 0.066, 0.0), 0.0085, 0.0085, C_WHITE, 0.0033, 0.55)
	tb.add_rod(Vector3(0.0045, 0.050, -0.004), Vector3(0.0045, 0.064, -0.006), 0.0085, 0.0085, C_WHITE, 0.0033, 0.55)
	return tb


func _build_hands() -> void:
	# Tay giống AK-47 / mọi súng khác: mỗi bàn tay là MỘT khối hộp xanh quân đội (scripts/hands.gd)
	# ----- tay trái (đỡ ốp tay) -----
	lh = Node3D.new()
	gun.add_child(lh)
	Hands.add_hand(lh, Vector3(0.056, 0.050, 0.070))

	# ----- tay phải (cầm báng) -----
	var rh := Node3D.new()
	rh_node = rh
	rh.position = Vector3(0.0, -0.105, 0.0)
	rh.rotation = Vector3(-20.0 * D2R, 0.0, 0.0)
	gun.add_child(rh)
	Hands.add_hand(rh, Vector3(0.042, 0.070, 0.050))


## Tia lửa đầu nòng: sao 3 cánh (luôn quay mặt về camera) + 2 tia lửa chéo nhau phun dọc nòng + khói nhẹ.
func _build_flash() -> void:
	flash = Node3D.new()
	flash.position = MUZZLE
	flash.visible = false
	gun.add_child(flash)

	var img := Image.create(64, 64, false, Image.FORMAT_RGBA8)
	for y in 64:
		for x in 64:
			var dx := (x - 31.5) / 31.5
			var dy := (y - 31.5) / 31.5
			var r := sqrt(dx * dx + dy * dy)
			var star := maxf(0.0, 1.0 - r) * (0.50 + 0.50 * pow(absf(cos(atan2(dy, dx) * 3.0)), 3.0))
			var a := clampf(star * 1.7, 0.0, 1.0)
			img.set_pixel(x, y, Color(1.0, 0.88 - 0.3 * r, 0.48 - 0.33 * r, a))
	var star_tex := ImageTexture.create_from_image(img)

	var jet := Image.create(64, 24, false, Image.FORMAT_RGBA8)
	for y in 24:
		for x in 64:
			var u := float(x) / 63.0
			var v := absf(float(y) - 11.5) / 11.5
			var a := pow(maxf(0.0, 1.0 - u), 1.4) * pow(maxf(0.0, 1.0 - v), 1.2)
			jet.set_pixel(x, y, Color(1.0, 0.80 - 0.35 * u, 0.40 - 0.3 * u, clampf(a * 1.5, 0.0, 1.0)))
	var jet_tex := ImageTexture.create_from_image(jet)

	var fm := StandardMaterial3D.new()
	fm.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	fm.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	fm.blend_mode = BaseMaterial3D.BLEND_MODE_ADD
	fm.albedo_texture = star_tex
	fm.billboard_mode = BaseMaterial3D.BILLBOARD_ENABLED
	fm.billboard_keep_scale = true
	fm.cull_mode = BaseMaterial3D.CULL_DISABLED
	var q := QuadMesh.new()
	q.size = Vector2(0.17, 0.17)
	var mi := MeshInstance3D.new()
	mi.mesh = q
	mi.material_override = fm
	mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	flash.add_child(mi)

	var jm := StandardMaterial3D.new()
	jm.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	jm.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	jm.blend_mode = BaseMaterial3D.BLEND_MODE_ADD
	jm.albedo_texture = jet_tex
	jm.cull_mode = BaseMaterial3D.CULL_DISABLED
	var jq := QuadMesh.new()
	jq.size = Vector2(0.20, 0.060)
	for k in 2:
		var j := MeshInstance3D.new()
		j.mesh = jq
		j.material_override = jm
		j.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		j.position = Vector3(0.0, 0.0, -0.09)
		j.rotation = Vector3(0.0, PI * 0.5, float(k) * PI * 0.5)
		flash.add_child(j)

	# ---- khói nòng: một đám khói mềm bay lên, đặc dần khi bắn liên tục ----
	var simg := Image.create(32, 32, false, Image.FORMAT_RGBA8)
	for y in 32:
		for x in 32:
			var dx := (x - 15.5) / 15.5
			var dy := (y - 15.5) / 15.5
			var r := sqrt(dx * dx + dy * dy)
			var a := pow(maxf(0.0, 1.0 - r), 2.0)
			simg.set_pixel(x, y, Color(0.78, 0.78, 0.8, a))
	smoke_mat = StandardMaterial3D.new()
	smoke_mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	smoke_mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	smoke_mat.albedo_texture = ImageTexture.create_from_image(simg)
	smoke_mat.billboard_mode = BaseMaterial3D.BILLBOARD_ENABLED
	smoke_mat.billboard_keep_scale = true
	smoke_mat.cull_mode = BaseMaterial3D.CULL_DISABLED
	smoke_mat.albedo_color = Color(1.0, 1.0, 1.0, 0.0)
	var sq := QuadMesh.new()
	sq.size = Vector2(0.09, 0.09)
	smoke = MeshInstance3D.new()
	smoke.mesh = sq
	smoke.material_override = smoke_mat
	smoke.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	smoke.visible = false
	smoke.position = MUZZLE + Vector3(0.0, 0.02, -0.05)
	gun.add_child(smoke)


# =====================================================================
#  KEYFRAME
# =====================================================================
func _d(x: float, y: float, z: float) -> Vector3:
	return Vector3(x, y, z) * D2R


func _build_keys() -> void:
	var z3 := Vector3.ZERO
	var mc: Vector3 = MAG_CENTER + LH_MAG_OFF
	var dn := Vector3(0.0, -MAG_TRAVEL, 0.0)
	# =================== NẠP ĐẠN kiểu CS (làm lại) ===================
	# 0.00-0.35 nghiêng súng, tay trái trượt từ ốp tay xuống băng đạn
	# 0.50      bấm chốt, băng cũ tụt xuống (0.50-0.68), tay kéo ra, 0.80 vứt băng cũ
	# 0.80-1.10 tay thò xuống thắt lưng lấy băng mới
	# 1.10-1.40 đưa băng mới lên, canh vào hộc đạn
	# 1.40-1.52 đẩy băng vào mạnh (súng giật nhẹ khi băng vào chốt), 1.52-1.72 vỗ đáy băng
	# 1.72-2.10 trả súng về tư thế bắn (nạp khi hết đạn: thêm kéo cần thượng đạn rồi mới trả súng)
	var rp := Vector3(-0.05, 0.030, 0.060)
	var rr := _d(14.0, 18.0, -32.0)
	var toss := Vector3(-0.060, -0.030, 0.020)

	k_draw_pos = [[0.0, Vector3(0.05, -0.30, 0.10)], [0.55, Vector3(0.0, 0.012, -0.004)], [DRAW_TIME, z3]]
	k_draw_rot = [[0.0, _d(-55.0, -20.0, -18.0)], [0.55, _d(4.0, 0.0, 0.0)], [DRAW_TIME, z3]]

	var lh_a := [
		[0.0, LH_HOLD], [0.35, mc], [0.50, mc], [0.68, mc + dn], [0.80, mc + dn + toss],
		[1.02, BELT], [1.10, BELT], [1.40, mc + dn], [1.52, mc], [1.72, mc],
	]
	var curl_a := [
		[0.0, 0.0], [0.25, 0.9], [0.35, 0.9], [0.50, 0.5], [0.80, 0.5], [1.02, 0.8], [1.10, 0.8],
		[1.40, 0.5], [1.72, 0.5],
	]
	var pos_a := [
		[0.0, z3], [0.35, rp], [0.52, rp + Vector3(0.0, -0.010, 0.012)], [0.70, rp], [1.40, rp],
		[1.50, rp + Vector3(0.0, 0.008, 0.022)], [1.70, rp],
	]
	var rot_a := [
		[0.0, z3], [0.35, rr], [0.52, rr + _d(-3.0, 0.0, 0.0)], [0.70, rr], [1.40, rr],
		[1.50, rr + _d(4.0, 0.0, 2.0)], [1.70, rr],
	]
	k_magout = [[0.0, 0.0], [0.50, 0.0], [0.68, 1.0], [1.40, 1.0], [1.52, 0.0], [RELOAD_EMPTY, 0.0]]

	# ---- thay đạn khi còn đạn ----
	k_tac_pos = pos_a.duplicate()
	k_tac_pos.append_array([[2.10, z3], [RELOAD_TAC, z3]])
	k_tac_rot = rot_a.duplicate()
	k_tac_rot.append_array([[2.10, z3], [RELOAD_TAC, z3]])
	k_tac_lh = lh_a.duplicate()
	k_tac_lh.append_array([[2.10, LH_HOLD], [RELOAD_TAC, LH_HOLD]])
	k_tac_curl = curl_a.duplicate()
	k_tac_curl.append_array([[2.0, 0.0], [RELOAD_TAC, 0.0]])

	# ---- thay đạn khi hết đạn (kéo cần thượng đạn) ----
	var ch := CHARGE_POS
	var chb := CHARGE_POS + Vector3(0.0, 0.0, 0.05)
	var cp := Vector3(-0.020, 0.012, 0.025)
	var cr := _d(4.0, 4.0, -8.0)
	k_emp_pos = pos_a.duplicate()
	k_emp_pos.append_array([[1.95, cp], [2.60, cp], [RELOAD_EMPTY, z3]])
	k_emp_rot = rot_a.duplicate()
	k_emp_rot.append_array([[1.95, cr], [2.60, cr], [RELOAD_EMPTY, z3]])
	k_emp_lh = lh_a.duplicate()
	k_emp_lh.append_array([
		[1.95, ch], [2.10, ch], [2.22, chb], [2.30, chb], [2.38, ch],
		[2.55, ch + Vector3(0.0, 0.012, 0.0)], [RELOAD_EMPTY, LH_HOLD],
	])
	k_emp_curl = curl_a.duplicate()
	k_emp_curl.append_array([[1.95, 0.3], [2.55, 0.3], [2.80, 0.0], [RELOAD_EMPTY, 0.0]])
	k_emp_charge = [[0.0, 0.0], [2.10, 0.0], [2.22, 0.045], [2.30, 0.045], [2.38, 0.0], [RELOAD_EMPTY, 0.0]]

	# =================== XEM SÚNG (inspect, làm lại) ===================
	# 0.0-0.6 đưa súng sát mắt và xoay cho thấy một bên thân súng, 1.3 giữ lại ngắm nghía,
	# 1.3-2.1 lật sang bên kia, 2.1-3.0 ngóc nòng lên xem hộc đạn và băng đạn, 3.0-3.8 trả súng về, 3.8 xong.
	k_insp_pos = [
		[0.0, z3], [0.6, Vector3(-0.060, 0.040, 0.070)], [1.3, Vector3(-0.065, 0.045, 0.080)],
		[2.1, Vector3(-0.030, 0.030, 0.060)], [2.7, Vector3(-0.035, 0.035, 0.065)],
		[3.1, Vector3(-0.030, 0.030, 0.070)], [3.5, Vector3(-0.010, 0.010, 0.020)], [INSPECT_TIME, z3],
	]
	k_insp_rot = [
		[0.0, z3], [0.6, _d(8.0, 50.0, -30.0)], [1.3, _d(10.0, 56.0, -34.0)],
		[2.1, _d(6.0, -48.0, 28.0)], [2.7, _d(8.0, -54.0, 32.0)],
		[3.1, _d(38.0, 6.0, -6.0)], [3.5, _d(4.0, 4.0, -4.0)], [INSPECT_TIME, z3],
	]
	k_insp_lh = [
		[0.0, LH_HOLD], [0.5, LH_HOLD + Vector3(0.0, -0.010, 0.020)], [2.9, LH_HOLD + Vector3(0.0, -0.010, 0.020)],
		[3.1, LH_HOLD + Vector3(0.0, -0.020, 0.030)], [3.5, LH_HOLD], [INSPECT_TIME, LH_HOLD],
	]


func _kf(t: float, keys: Array) -> Variant:
	if t <= keys[0][0]:
		return keys[0][1]
	for i in range(1, keys.size()):
		if t <= keys[i][0]:
			var t0: float = keys[i - 1][0]
			var t1: float = keys[i][0]
			var w := (t - t0) / maxf(t1 - t0, 0.0001)
			w = w * w * (3.0 - 2.0 * w)
			return lerp(keys[i - 1][1], keys[i][1], w)
	return keys[keys.size() - 1][1]


# =====================================================================
#  API CHO PLAYER (giống Viewmodel)
# =====================================================================
func is_busy() -> bool:
	return mode != Mode.NONE


func current_mode() -> int:
	return mode


func play_draw() -> void:
	_start_mode(Mode.DRAW, DRAW_TIME)
	cues = [[0.10, "sfx", "rustle"], [0.55, "sfx", "slide_fwd"]]


func play_reload(empty: bool) -> float:
	reload_is_empty = empty
	var length := RELOAD_EMPTY if empty else RELOAD_TAC
	_start_mode(Mode.RELOAD, length)
	cues = [[0.50, "sfx", "mag_out"], [0.80, "drop", ""], [1.04, "sfx", "rustle"], [1.50, "sfx", "mag_in"], [1.50, "inserted", ""]]
	if empty:
		cues.append([2.22, "sfx", "slide_back"])
		cues.append([2.38, "sfx", "slide_fwd"])
	return length


func play_inspect() -> void:
	_start_mode(Mode.INSPECT, INSPECT_TIME)
	cues = [[0.10, "sfx", "rustle"], [1.55, "sfx", "rustle"], [3.00, "sfx", "rustle"], [3.50, "sfx", "slide_fwd"]]


func cancel() -> void:
	mode = Mode.NONE
	mode_t = 0.0
	cues = []


func set_slide_locked(_locked: bool) -> void:
	pass


func land(strength: float) -> void:
	kick_pos_v.y -= 0.35 * strength
	kick_rot_v.x -= 0.6 * strength


## Vị trí đầu nòng (toạ độ thế giới) để vẽ tia đạn xuất phát đúng từ nòng súng.
func muzzle_global() -> Vector3:
	return flash.global_position


func fire(_last_round: bool) -> void:
	# Giật kiểu CS: cả khẩu súng thụt mạnh về phía vai rồi bật lại ngay (kịp trước phát kế tiếp), nòng ngóc nhẹ.
	# (Độ giật của CAMERA và độ tỏa đạn nằm trong player.gd, theo bảng "cs" của M4A1.)
	var k := 0.6 if ads_t > 0.5 else 1.0
	kick_pos_v += Vector3(randf_range(-0.010, 0.010), randf_range(0.004, 0.012), 1.40) * k
	kick_rot_v += Vector3(0.90 + randf_range(0.0, 0.30), randf_range(-0.25, 0.25), randf_range(-0.35, 0.35)) * k
	flash_t = 0.045
	flash.visible = true
	flash.rotation = Vector3(0.0, 0.0, randf() * TAU)
	flash.scale = Vector3.ONE * randf_range(0.85, 1.3)
	smoke_amt = minf(smoke_amt + 0.22, 1.0)
	_spawn_shell()


func dry_fire() -> void:
	kick_pos_v.z += 0.05
	kick_rot_v.x += 0.2


# =====================================================================
#  NỘI BỘ
# =====================================================================
func _start_mode(m: int, length: float) -> void:
	mode = m
	mode_t = 0.0
	mode_len = length


func _do_cue(kind: String, arg: String) -> void:
	match kind:
		"sfx":
			sound.emit(arg)
		"drop":
			_spawn_dropped_mag()
		"inserted":
			reload_inserted.emit()


func _advance_mode(delta: float) -> void:
	if mode == Mode.NONE:
		return
	var prev := mode_t
	mode_t += delta
	for c in cues:
		var ct: float = c[0]
		if prev < ct and mode_t >= ct:
			_do_cue(c[1], c[2])
	if mode_t >= mode_len:
		var finished := mode
		mode = Mode.NONE
		mode_t = 0.0
		cues = []
		var nm := "draw"
		if finished == Mode.RELOAD:
			nm = "reload"
		elif finished == Mode.INSPECT:
			nm = "inspect"
		action_finished.emit(nm)


func _eval_anim() -> void:
	a_pos = Vector3.ZERO
	a_rot = Vector3.ZERO
	lh_pos = LH_HOLD
	lh_curl = 0.0
	ch_off = 0.0
	mag_mode = MagMode.AXIS
	mag_out = 0.0
	if mode == Mode.NONE:
		return
	var t := mode_t
	match mode:
		Mode.DRAW:
			a_pos = _kf(t, k_draw_pos)
			a_rot = _kf(t, k_draw_rot)
		Mode.RELOAD:
			var e := reload_is_empty
			a_pos = _kf(t, k_emp_pos if e else k_tac_pos)
			a_rot = _kf(t, k_emp_rot if e else k_tac_rot)
			lh_pos = _kf(t, k_emp_lh if e else k_tac_lh)
			lh_curl = _kf(t, k_emp_curl if e else k_tac_curl)
			mag_out = _kf(t, k_magout)
			if e:
				ch_off = _kf(t, k_emp_charge)
			if t >= 0.68 and t < 0.80:
				mag_mode = MagMode.HAND
			elif t >= 0.80 and t < 1.10:
				mag_mode = MagMode.HIDDEN
			elif t >= 1.10 and t < 1.40:
				mag_mode = MagMode.HAND
			else:
				mag_mode = MagMode.AXIS
		Mode.INSPECT:
			a_pos = _kf(t, k_insp_pos)
			a_rot = _kf(t, k_insp_rot)
			lh_pos = _kf(t, k_insp_lh)


func _spring(delta: float) -> void:
	# lò xo cứng và nhanh: mỗi phát bắn là một cú "thụt rồi bật lại" riêng biệt (kiểu CS), chia bước nhỏ để ổn định ở mọi FPS
	var steps := maxi(1, int(ceil(delta / 0.005)))
	var h := delta / float(steps)
	var kp := 520.0
	var cp := 30.0
	var kr := 380.0
	var cr := 26.0
	for i in range(steps):
		kick_pos_v += (-kp * kick_pos - cp * kick_pos_v) * h
		kick_pos += kick_pos_v * h
		kick_rot_v += (-kr * kick_rot - cr * kick_rot_v) * h
		kick_rot += kick_rot_v * h
	# chặn khi bắn liên thanh: súng không thụt quá sâu và không ngóc quá cao
	kick_pos.z = minf(kick_pos.z, 0.055)
	kick_rot.x = clampf(kick_rot.x, -0.2, 0.06)


func _process(delta: float) -> void:
	delta = minf(delta, 0.05)
	_time += delta
	_advance_mode(delta)
	_eval_anim()

	# --- ADS ---
	var ads_target := 1.0 if (ads and mode == Mode.NONE) else 0.0
	ads_t = move_toward(ads_t, ads_target, delta * 7.0)
	var ae := ads_t * ads_t * (3.0 - 2.0 * ads_t)
	var pos := HIP_POS.lerp(ADS_POS, ae)
	var rot := HIP_ROT.lerp(Vector3.ZERO, ae)

	# --- bob khi di chuyển ---
	if move_amount > 0.05 and grounded:
		bob_phase += delta * (5.5 + 5.5 * move_amount)
	var bob_amp := move_amount * (1.0 - 0.85 * ae) * (0.6 if crouched else 1.0)
	if not grounded:
		bob_amp = 0.0
	bob_smooth = lerpf(bob_smooth, bob_amp, 1.0 - exp(-10.0 * delta))
	pos += Vector3(cos(bob_phase) * 0.0060, sin(bob_phase * 2.0) * 0.0050, 0.0) * bob_smooth
	rot += Vector3(sin(bob_phase * 2.0) * 0.010, cos(bob_phase) * 0.014, cos(bob_phase) * 0.020) * bob_smooth

	# --- thở ---
	var br := sin(_time * 1.7)
	pos.y += br * 0.0008 * (1.0 - 0.6 * ae)
	rot.x += br * 0.0025 * (1.0 - 0.6 * ae)

	# --- tư thế chạy ---
	var run_target := run_amount if mode == Mode.NONE else 0.0
	run_t = lerpf(run_t, run_target, 1.0 - exp(-8.0 * delta))
	pos += Vector3(0.015, -0.035, 0.050) * run_t
	rot += Vector3(-0.12, 0.35, -0.25) * run_t

	# --- sway theo chuột ---
	var sway_target := (mouse_delta * 0.0009).limit_length(0.06)
	mouse_delta = Vector2.ZERO
	sway = sway.lerp(sway_target, 1.0 - exp(-14.0 * delta))
	rot.y += sway.x * (1.0 - 0.7 * ae)
	rot.x += sway.y * (1.0 - 0.7 * ae)
	pos.x -= sway.x * 0.10

	# --- trên không ---
	air_t = move_toward(air_t, 0.0 if grounded else 1.0, delta * 5.0)
	pos.y += 0.007 * air_t
	rot.x += 0.03 * air_t

	# --- gần tường: hạ súng, tránh xuyên tường ---
	_wall_s = lerpf(_wall_s, wall_push, 1.0 - exp(-(28.0 if wall_push > _wall_s else 9.0) * delta))
	pos += Vector3(0.03, -0.04, WALL_BACK) * _wall_s
	rot += Vector3(-WALL_RX, 0.35, -0.2) * _wall_s

	# --- lò xo giật ---
	_spring(delta)
	pos += kick_pos
	rot += kick_rot

	# --- animation (draw / reload / inspect) ---
	pos += a_pos
	rot += a_rot
	rig.position = pos
	rig.rotation = rot

	# --- tay kéo thượng đạn ---
	charge.position = Vector3(0.0, 0.038, 0.035 + ch_off)

	# --- quai xách hạ xuống khi ngắm (khỏi che tầm nhìn dọc nòng) ---
	var hs := clampf(1.0 - ads_t * 2.2, 0.0, 1.0)
	handle.visible = hs > 0.03
	handle.scale = Vector3(1.0, maxf(hs, 0.01), 1.0)

	# --- tay trái ---
	lh.position = lh_pos
	for f in lh_fingers:
		f.rotation = Vector3(0.0, 0.0, -lh_curl * 0.9)

	# --- băng đạn ---
	match mag_mode:
		MagMode.AXIS:
			mag.visible = true
			mag.transform = Transform3D(mag_basis, MAG_CENTER + Vector3(0.0, -MAG_TRAVEL * mag_out, 0.0))
		MagMode.HAND:
			mag.visible = true
			mag.transform = Transform3D(mag_basis, lh_pos - LH_MAG_OFF)
		MagMode.HIDDEN:
			mag.visible = false

	# --- cánh tay ---
	limb_l.mag_target = 1.0 if mag_mode == MagMode.HAND else 0.0
	limb_l.rest_k = clampf(1.0 - lh_pos.distance_to(LH_HOLD) / 0.05, 0.0, 1.0)
	limb_l.update(rig.basis, lh.transform * LH_WRIST_LOCAL, ELBOW_L, delta)
	limb_r.update(rig.basis, RH_WRIST, ELBOW_R, delta)

	# --- tia lửa đầu nòng ---
	if flash_t > 0.0:
		flash_t -= delta
		if flash_t <= 0.0:
			flash.visible = false

	# --- khói nòng ---
	if smoke_amt > 0.0:
		smoke_amt = maxf(smoke_amt - delta * 1.1, 0.0)
		smoke.visible = smoke_amt > 0.04
		var grow := 0.9 + (1.0 - smoke_amt) * 1.6
		smoke.scale = Vector3.ONE * grow
		smoke.position = MUZZLE + Vector3(0.0, 0.02 + (1.0 - smoke_amt) * 0.07, -0.05)
		smoke_mat.albedo_color.a = smoke_amt * 0.28 * (1.0 - 0.75 * ads_t)
	elif smoke.visible:
		smoke.visible = false

	_update_shells(delta)
	_update_drops(delta)


# ---------------- vỏ đạn & băng đạn rơi ----------------
func _spawn_shell() -> void:
	var sm := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = Vector3(0.006, 0.006, 0.020)
	sm.mesh = bm
	sm.material_override = m_brass
	sm.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(sm)
	sm.position = rig.transform * (gun.transform * Vector3(0.030, 0.005, -0.07))
	var v := rig.transform.basis * Vector3(randf_range(0.9, 1.5), randf_range(0.8, 1.4), randf_range(0.2, 0.8))
	shells.append({"node": sm, "vel": v, "spin": Vector3(randf_range(-20, 20), randf_range(-20, 20), randf_range(-20, 20)), "t": 0.0})


func _spawn_dropped_mag() -> void:
	var m := mag.duplicate() as Node3D
	add_child(m)
	m.visible = true
	m.global_transform = mag.global_transform
	var v := rig.transform.basis * Vector3(-0.6, -0.4, 0.5)
	drops.append({"node": m, "vel": v, "spin": Vector3(randf_range(-5, 5), randf_range(-5, 5), randf_range(-5, 5)), "t": 0.0})


func _update_shells(delta: float) -> void:
	for i in range(shells.size() - 1, -1, -1):
		var s: Dictionary = shells[i]
		var n: Node3D = s["node"]
		s["t"] = float(s["t"]) + delta
		var vel: Vector3 = s["vel"]
		vel.y -= 9.8 * delta
		s["vel"] = vel
		n.position += vel * delta
		n.rotation += (s["spin"] as Vector3) * delta
		if float(s["t"]) > 0.7:
			n.queue_free()
			shells.remove_at(i)


func _update_drops(delta: float) -> void:
	for i in range(drops.size() - 1, -1, -1):
		var s: Dictionary = drops[i]
		var n: Node3D = s["node"]
		s["t"] = float(s["t"]) + delta
		var vel: Vector3 = s["vel"]
		vel.y -= 9.8 * delta
		s["vel"] = vel
		n.position += vel * delta
		n.rotation += (s["spin"] as Vector3) * delta
		if float(s["t"]) > 0.7:
			n.queue_free()
			drops.remove_at(i)
