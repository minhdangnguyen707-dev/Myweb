extends Node3D
## AWP góc nhìn thứ nhất (người dùng yêu cầu: NHÚNG THẲNG model CS vào game).
## Súng + hai bàn tay + mọi animation (rút súng, bắn kéo bolt, nạp đạn, inspect) đều lấy từ MỘT file: assets/awp/v_awp.glb,
## đổi từ v_awp.mdl (CS 1.6, bản gốc để cạnh đó: assets/awp/v_awp.mdl) bằng `python3 tools/mdl2glb.py v_awp.mdl v_awp.glb --vm`.
## NGOẠI LỆ so với quy tắc "súng mới phải dùng Hands.Arm": AWP dùng tay CÓ SẴN trong model (người dùng yêu cầu), KHÔNG dùng hands.gd.
## Cùng giao diện (API) với Viewmodel / Rifle để Player dùng thay thế qua lại.
## Âm thanh (gói cs_10_beta_awp, người dùng yêu cầu thêm): assets/awp/sounds/ = tiếng bắn awp1 + 3 tiếng kéo khoá boltup / boltpull1 / boltdown phát đúng các mốc
## 0.429 / 0.543 / 0.914 s của animation bắn (sự kiện 5004 trong v_awp.mdl). Gói không có tiếng nạp đạn / rút súng nên hai hành động đó vẫn im lặng.
##
## Ngắm (scope) do player.gd lo (chuột phải: zoom 1 -> zoom 2 -> tắt). Khi đang ngắm player ẩn viewmodel này đi như CS.
## Hệ trục model (glTF, giống GoldSrc xoay): +X trái, +Y lên, +Z phía trước. Ta xoay 180 độ quanh Y để nòng súng chĩa về -Z (hướng nhìn camera).

signal sound(sound_name: String)
signal reload_inserted()
signal action_finished(action_name: String)

const MODEL_PATH := "res://assets/awp/v_awp.glb"
# Model GoldSrc đặt súng lệch TRÁI mắt ~15 cm (gốc toạ độ = mắt): dời sang phải cho giống cách cầm súng của CS. (x phải, y lên, z trước = -z)
const VM_OFFSET := Vector3(0.25, 0.01, 0.0)
const MUZZLE_BONE := "Bone50"
const MUZZLE_LOCAL := Vector3(-0.5588, 0.0, 0.0)   # attachment 0 của model (22 đơn vị GoldSrc dọc nòng), toạ độ trong xương Bone50

const SND_DIR := "res://assets/awp/sounds/"
const SND_NAMES := ["awp1", "boltup", "boltpull1", "boltdown"]
# Sự kiện âm thanh của animation bắn (giây tính từ lúc bắn, lấy từ sự kiện 5004 của v_awp.mdl): [thời điểm, tên file wav bỏ đuôi]
const BOLT_EVENTS := [[0.429, "boltup"], [0.543, "boltpull1"], [0.914, "boltdown"]]

enum Mode { NONE, DRAW, RELOAD, INSPECT }

# thời điểm (giây) trong animation reload khi băng đạn mới vào súng (sự kiện awp_clipin của model: frame 53 / 30 fps)
const RELOAD_INSERT_AT := 1.77

# ---------------- trạng thái nhận từ Player ----------------
var move_amount := 0.0
var run_amount := 0.0
var grounded := true
var crouched := false
var ads := 0.0           # luôn 0 (ngắm do player.gd xử lý bằng scope, không phải ADS của viewmodel)
var ads_t := 0.0
var wall_push := 0.0
var mouse_delta := Vector2.ZERO
var planting := false    # bomb.gd gán biến này cho viewmodel đang cầm; AWP không dùng

var rig: Node3D = null            # gốc model (đã xoay 180 độ + dời vị trí)
var anim: AnimationPlayer = null
var skel: Skeleton3D = null
var muzzle_bone := -1
var flash: MeshInstance3D = null
var flash_t := 0.0

var mode: int = Mode.NONE
var mode_t := 0.0
var mode_len := 0.0
var insert_sent := false
var fire_t := 0.0                 # còn đang chạy animation bắn (kéo bolt)
var shoot_i := 0

var snd := {}
var bolt_players: Array = []
var bolt_i := 0
var shot_players: Array = []
var shot_i := 0
var bolt_t := -1.0                # >= 0: đang tính giờ cho các tiếng kéo khoá sau phát bắn
var bolt_n := 0                   # đã phát bao nhiêu tiếng kéo khoá

var idle_hold_t := 0.0           # sau khi về tư thế nghỉ ~0.3 s thì DỪNG animation (không cập nhật xương mỗi khung hình khi súng đứng yên)
var sway := Vector2.ZERO
var bob_t := 0.0
var land_off := 0.0


func _ready() -> void:
	rig = Node3D.new()
	rig.rotation.y = PI
	rig.position = VM_OFFSET
	add_child(rig)
	_build_flash()   # main._warmup() đụng tới `flash` của mọi viewmodel nên luôn phải có
	_build_audio()
	var scene = load(MODEL_PATH)
	if scene == null:
		push_warning("Không nạp được " + MODEL_PATH + " (chạy CHOI_GAME.bat để Godot import lại)")
		return
	var model: Node3D = (scene as PackedScene).instantiate()
	rig.add_child(model)
	skel = _find_skeleton(model)
	anim = _find_anim(model)
	if skel != null:
		muzzle_bone = skel.find_bone(MUZZLE_BONE)
	_fix_meshes(model)
	if anim != null:
		_complete_tracks()
		anim.playback_default_blend_time = 0.05
		for nm in ["idle1"]:
			if anim.has_animation(nm):
				(anim.get_animation(nm) as Animation).loop_mode = Animation.LOOP_LINEAR
		_play("idle1")
	visibility_changed.connect(_on_visibility_changed)


## Khi import, Godot có thể bỏ các track xương "bất biến" (bằng tư thế nghỉ). Nếu animation sau không còn track của xương đó thì xương giữ nguyên
## tư thế của animation trước (tay / bolt không quay về chỗ cũ). Thêm lại các track thiếu bằng đúng tư thế nghỉ để animation nào cũng ghi đè đủ mọi xương.
func _complete_tracks() -> void:
	if skel == null:
		return
	var base: Node = anim.get_node_or_null(anim.root_node)
	if base == null:
		return
	var sp := str(base.get_path_to(skel))
	for an in anim.get_animation_list():
		var a: Animation = anim.get_animation(an)
		for b in skel.get_bone_count():
			var path := NodePath(sp + ":" + skel.get_bone_name(b))
			var rest := skel.get_bone_rest(b)
			if a.find_track(path, Animation.TYPE_POSITION_3D) < 0:
				var tp_i := a.add_track(Animation.TYPE_POSITION_3D)
				a.track_set_path(tp_i, path)
				a.position_track_insert_key(tp_i, 0.0, rest.origin)
			if a.find_track(path, Animation.TYPE_ROTATION_3D) < 0:
				var tr_i := a.add_track(Animation.TYPE_ROTATION_3D)
				a.track_set_path(tr_i, path)
				a.rotation_track_insert_key(tr_i, 0.0, rest.basis.get_rotation_quaternion())


func _find_skeleton(n: Node) -> Skeleton3D:
	if n is Skeleton3D:
		return n
	for c in n.get_children():
		var r := _find_skeleton(c)
		if r != null:
			return r
	return null


func _find_anim(n: Node) -> AnimationPlayer:
	if n is AnimationPlayer:
		return n
	for c in n.get_children():
		var r := _find_anim(c)
		if r != null:
			return r
	return null


## Texture CS vẽ không đổ bóng (giống các súng khác + nhẹ cho máy yếu); mesh có xương nên nới hộp cắt hình để không bị mất khi animation đưa súng ra xa.
func _fix_meshes(n: Node) -> void:
	if n is MeshInstance3D:
		var mi := n as MeshInstance3D
		mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		mi.custom_aabb = AABB(Vector3(-3.0, -3.0, -3.0), Vector3(6.0, 6.0, 6.0))
		if mi.mesh != null:
			for i in mi.mesh.get_surface_count():
				var m = mi.mesh.surface_get_material(i)
				if m is BaseMaterial3D:
					var d := (m as BaseMaterial3D).duplicate() as BaseMaterial3D
					d.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
					d.cull_mode = BaseMaterial3D.CULL_DISABLED
					mi.set_surface_override_material(i, d)
	for c in n.get_children():
		_fix_meshes(c)


func _build_flash() -> void:
	var g := Gradient.new()
	g.set_color(0, Color(1.0, 0.95, 0.7, 1.0))
	g.set_color(1, Color(1.0, 0.5, 0.1, 0.0))
	var gt := GradientTexture2D.new()
	gt.gradient = g
	gt.fill = GradientTexture2D.FILL_RADIAL
	gt.fill_from = Vector2(0.5, 0.5)
	gt.fill_to = Vector2(1.0, 0.5)
	gt.width = 64
	gt.height = 64
	var q := QuadMesh.new()
	q.size = Vector2(0.55, 0.55)
	var mat := StandardMaterial3D.new()
	mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	mat.blend_mode = BaseMaterial3D.BLEND_MODE_ADD
	mat.billboard_mode = BaseMaterial3D.BILLBOARD_ENABLED
	mat.albedo_texture = gt
	mat.no_depth_test = true
	flash = MeshInstance3D.new()
	flash.mesh = q
	flash.material_override = mat
	flash.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	flash.visible = false
	add_child(flash)


## Nạp các file wav (thiếu file / chưa import thì im lặng bỏ qua, súng vẫn chạy bình thường) và dựng các kênh phát.
func _build_audio() -> void:
	for n in SND_NAMES:
		var p: String = SND_DIR + n + ".wav"
		if ResourceLoader.exists(p):
			var st = load(p)
			if st != null:
				snd[n] = st
	for i in 2:
		var ap := AudioStreamPlayer.new()
		ap.volume_db = 0.0   # tiếng bắn AWP to nhất
		add_child(ap)
		shot_players.append(ap)
	for i in 3:
		var ap := AudioStreamPlayer.new()
		ap.volume_db = -3.0
		add_child(ap)
		bolt_players.append(ap)


func _play_shot() -> void:
	if not snd.has("awp1"):
		return
	var ap: AudioStreamPlayer = shot_players[shot_i % shot_players.size()]
	shot_i += 1
	ap.stream = snd["awp1"]
	ap.play()


func _play_bolt(sname: String) -> void:
	if not snd.has(sname):
		return
	var ap: AudioStreamPlayer = bolt_players[bolt_i % bolt_players.size()]
	bolt_i += 1
	ap.stream = snd[sname]
	ap.play()


## Tắt hết tiếng + huỷ lịch kéo khoá. KHÔNG gọi khi ẩn viewmodel vì đang ngắm (bắn lúc ngắm thì viewmodel đang ẩn mà tiếng vẫn phải phát).
func _stop_snd() -> void:
	bolt_t = -1.0
	for ap in shot_players:
		(ap as AudioStreamPlayer).stop()
	for ap in bolt_players:
		(ap as AudioStreamPlayer).stop()


## Ẩn viewmodel (đổi súng / đang ngắm) thì tắt luôn animation cho nhẹ máy.
func _on_visibility_changed() -> void:
	if anim != null:
		anim.active = is_visible_in_tree()


func _play(anim_name: String, blend: float = -1.0) -> void:
	if anim == null or not anim.has_animation(anim_name):
		return
	idle_hold_t = 0.3 if anim_name == "idle1" else 0.0
	if blend >= 0.0:
		anim.play(anim_name, blend)
	else:
		anim.play(anim_name)


func _anim_len(anim_name: String, fallback: float) -> float:
	if anim != null and anim.has_animation(anim_name):
		return anim.get_animation(anim_name).length
	return fallback


# =====================================================================
#  API CHO PLAYER
# =====================================================================
func is_busy() -> bool:
	return mode != Mode.NONE or fire_t > 0.0


func current_mode() -> int:
	return mode


func play_draw() -> void:
	_start_mode(Mode.DRAW, "draw", 1.03)


func play_reload(_empty: bool) -> float:
	_start_mode(Mode.RELOAD, "reload", 2.93)
	return mode_len


func play_inspect() -> void:
	_start_mode(Mode.INSPECT, "inspect", 5.0)


func cancel() -> void:
	mode = Mode.NONE
	mode_t = 0.0
	fire_t = 0.0
	flash_t = 0.0
	if flash != null:
		flash.visible = false
	_stop_snd()   # đổi súng giữa chừng thì tắt tiếng bắn / tiếng kéo khoá
	_play("idle1", 0.05)


func set_slide_locked(_locked: bool) -> void:
	pass


func is_slide_locked() -> bool:
	return false


func land(strength: float) -> void:
	land_off = minf(land_off - 0.035 * strength, 0.0)


func dry_fire() -> void:
	pass


## Bắn: chạy animation bắn + kéo bolt (3 kiểu như model gốc) và loé lửa đầu nòng.
func fire(_last_round: bool) -> void:
	if mode == Mode.INSPECT:
		cancel()
	shoot_i = (shoot_i + 1) % 3
	var nm := "shoot%d" % (shoot_i + 1)
	_play(nm, 0.0)
	fire_t = _anim_len(nm, 1.17)
	flash_t = 0.055
	if flash != null:
		flash.visible = true
		flash.global_position = muzzle_global()
	bolt_t = 0.0   # lịch các tiếng kéo khoá (boltup / boltpull1 / boltdown) tính từ phát bắn
	bolt_n = 0
	_play_shot()
	sound.emit("shot_awp")


## Vị trí đầu nòng trong thế giới (theo xương nòng đang chuyển động) cho vạch đạn.
func muzzle_global() -> Vector3:
	if skel != null and muzzle_bone >= 0:
		var t: Transform3D = skel.global_transform * skel.get_bone_global_pose(muzzle_bone)
		return t * MUZZLE_LOCAL
	return global_transform * Vector3(0.1, -0.05, -0.8)


# =====================================================================
#  NỘI BỘ
# =====================================================================
func _start_mode(m: int, anim_name: String, fallback_len: float) -> void:
	mode = m
	mode_t = 0.0
	fire_t = 0.0
	insert_sent = false
	bolt_t = -1.0   # animation bị thay nên các sự kiện kéo khoá chưa tới cũng bỏ
	mode_len = _anim_len(anim_name, fallback_len)
	_play(anim_name, 0.03)


func _process(delta: float) -> void:
	delta = minf(delta, 0.05)
	# đồng hồ của hành động (rút súng / nạp đạn / inspect) chạy song song với animation của model
	if mode != Mode.NONE:
		mode_t += delta
		if mode == Mode.RELOAD and not insert_sent and mode_t >= RELOAD_INSERT_AT:
			insert_sent = true
			reload_inserted.emit()
		if mode_t >= mode_len:
			var finished := mode
			mode = Mode.NONE
			mode_t = 0.0
			_play("idle1", 0.08)
			var nm := "draw"
			if finished == Mode.RELOAD:
				nm = "reload"
				if not insert_sent:
					insert_sent = true
					reload_inserted.emit()
			elif finished == Mode.INSPECT:
				nm = "inspect"
			action_finished.emit(nm)
	elif fire_t > 0.0:
		fire_t -= delta
		if fire_t <= 0.0:
			fire_t = 0.0
			_play("idle1", 0.08)
	if idle_hold_t > 0.0:
		idle_hold_t -= delta
		if idle_hold_t <= 0.0 and anim != null and mode == Mode.NONE and fire_t <= 0.0:
			anim.pause()   # súng đứng yên: không cần cập nhật bộ xương mỗi khung hình (đỡ tốn máy yếu)
	if bolt_t >= 0.0:
		bolt_t += delta
		while bolt_n < BOLT_EVENTS.size() and bolt_t >= float((BOLT_EVENTS[bolt_n] as Array)[0]):
			_play_bolt(str((BOLT_EVENTS[bolt_n] as Array)[1]))
			bolt_n += 1
		if bolt_n >= BOLT_EVENTS.size():
			bolt_t = -1.0
	if flash_t > 0.0:
		flash_t -= delta
		if flash != null:
			flash.global_position = muzzle_global()
			if flash_t <= 0.0:
				flash.visible = false

	# lắc nhẹ theo chuột + nhún khi đi + dội khi tiếp đất (cộng lên trên animation của model)
	var target := Vector2(clampf(-mouse_delta.x * 0.0005, -0.018, 0.018), clampf(mouse_delta.y * 0.0005, -0.018, 0.018))
	mouse_delta = Vector2.ZERO
	sway = sway.lerp(target, 1.0 - exp(-9.0 * delta))
	bob_t += delta * (3.0 + move_amount * 7.0)
	var bob := Vector3(sin(bob_t) * 0.004, -absf(cos(bob_t)) * 0.005, 0.0) * move_amount
	land_off = lerpf(land_off, 0.0, 1.0 - exp(-10.0 * delta))
	if rig != null:
		rig.position = VM_OFFSET + Vector3(sway.x, sway.y + land_off, 0.0) + bob
