extends Node3D
## DAO BƯỚM kiểu CS:GO (người dùng yêu cầu: NHÚNG THẲNG model + tay + animation + âm thanh trong file gửi kèm, thay cho nắm đấm tay không).
## Dao + hai bàn tay (găng) + mọi animation (rút dao 2 kiểu, chém trái / chém phải xen kẽ, đâm mạnh chuột phải, đâm sau lưng, múa dao F 3 kiểu, đứng yên)
## lấy từ MỘT file: assets/knife/v_knife_ct.glb (phe CT: tay áo xanh FBI) hoặc v_knife_t.glb (phe T: tay trần găng hở ngón), đổi từ CT/v_knife.mdl và T/v_knife.mdl
## của gói butterfly_knife bằng `python3 tools/mdl2glb.py v_knife.mdl v_knife_ct.glb --vm --atlas --jpeg`.
## Chỉ lấy MỘT con dao (dao bướm, skin mặc định đã nhúng sẵn trong model); 24 skin sơn khác trong thư mục Textures của gói KHÔNG dùng.
## Âm thanh: assets/knife/sounds/*.wav, phát ĐÚNG thời điểm sự kiện ghi trong model (rút dao, múa dao, đâm sau lưng). Gói không có tiếng chém / trúng nên không thêm.
## NGOẠI LỆ so với quy tắc "súng mới phải dùng Hands.Arm": dao dùng tay CÓ SẴN trong model (giống AWP / MP5 / AK-47), KHÔNG dùng hands.gd.
## Cùng giao diện (API) với Viewmodel / Rifle / Mp5 + signal melee_hit để Player dùng thay thế qua lại. File giữ tên knife.gd / id "knife" để player.gd, phím 3 không phải đổi.
## Nắm đấm cũ (dựng bằng code + Hands.Arm) đã bị XOÁ theo yêu cầu.
##
## Hệ trục model (glTF, đổi từ GoldSrc): +X trái, +Y lên, +Z phía trước. Xoay 180 độ quanh Y cho nòng chĩa -Z. KHÁC AK-47: model dao này vẽ đúng cho tay phải
## (dao nằm ở tay phải, bên phải màn hình) nên KHÔNG lật gương. Chế độ tay trái của game lật gương cả viewmodel như mọi súng khác.

signal sound(sound_name: String)
signal reload_inserted()
signal action_finished(action_name: String)
signal melee_hit(kind: String)   # phát ra đúng khoảnh khắc lưỡi dao chạm mục tiêu (từ animation)

# Phe CT (team 0) = tay áo xanh, phe T (team 1) = tay trần. Đổi phe giữa trận (bomb.gd) thì dao tự đổi model.
const MODEL_CT := "res://assets/knife/v_knife_ct.glb"
const MODEL_T := "res://assets/knife/v_knife_t.glb"
const SND_DIR := "res://assets/knife/sounds/"
const SND_NAMES := ["backstab", "draw1", "draw2", "insp1a", "insp1b", "insp1c", "insp2a", "insp2b", "insp2c"]

# Thu nhỏ đều quanh mắt (hình trên màn hình không đổi). Dao + tay nằm gần mắt sẵn nên để 1.0 (thu nhỏ nữa thì tay sát mắt bị near plane cắt).
const GUN_SCALE := 1.0
const VM_OFFSET := Vector3(0.0, 0.0, 0.0)

enum Mode { NONE, DRAW, RELOAD, INSPECT, ATTACK }

# Thời điểm lưỡi dao chạm (giây trong animation), đo từ chuyển động của lưỡi dao trong model.
const HIT_SLASH := 0.17     # chém (chuột trái): slash1 / slash2
const HIT_HEAVY := 0.38     # đâm mạnh (chuột phải): heavy_miss
const HIT_BACKSTAB := 0.5   # đâm sau lưng: backstab (đúng chỗ model đặt tiếng đâm)

# Sự kiện âm thanh ghi trong model: [giây, tên file wav bỏ đuôi]
const EVENTS := {
	"draw": [[0.043, "draw2"]],
	"draw2": [[0.043, "draw1"]],
	"backstab": [[0.5, "backstab"]],
	"inspect": [[0.261, "insp1a"], [3.652, "insp2a"]],
	"inspect2": [[0.261, "insp1c"], [3.261, "insp2c"]],
	"inspect3": [[0.304, "insp1b"], [3.087, "insp2b"]],
}

# ---------------- trạng thái nhận từ Player ----------------
var move_amount := 0.0
var run_amount := 0.0
var grounded := true
var crouched := false
var ads := 0.0           # luôn 0 (game không có ngắm)
var ads_t := 0.0
var wall_push := 0.0
var mouse_delta := Vector2.ZERO
var planting := false    # bomb.gd gán biến này cho viewmodel đang cầm; dao không dùng

var rig: Node3D = null            # gốc model (đã xoay 180 độ quanh Y)
var model: Node3D = null          # model đang dùng (CT hoặc T)
var model_team := -1              # phe của model đang dựng (-1 = chưa dựng)
var owner_player: Node = null     # Player đang cầm dao (để đọc phe + hỏi có đang ở sau lưng địch không)
var anim: AnimationPlayer = null
var skel: Skeleton3D = null
var flash: Node3D = null          # không dùng, nhưng main._warmup() đọc `flash.visible` của MỌI viewmodel nên phải là một Node3D thật (không được để null)

var mode: int = Mode.NONE
var mode_t := 0.0
var mode_len := 0.0
var cur_anim := ""                # animation của hành động hiện tại
var attack_kind := "slash"
var hit_at := 0.0                 # giây (trong hành động) lưỡi dao chạm
var hit_sent := true
var slash_i := 0                  # chém xen kẽ slash1 / slash2
var draw_i := 0                   # rút dao xen kẽ draw / draw2
var insp_i := 0                   # múa dao xen kẽ inspect / inspect2 / inspect3
var ev_list: Array = []           # sự kiện âm thanh của hành động hiện tại
var ev_i := 0

var snd := {}                     # tên file -> AudioStream
var foley_players: Array = []
var foley_i := 0

var sway := Vector2.ZERO
var bob_t := 0.0
var land_off := 0.0


func _ready() -> void:
	rig = Node3D.new()
	rig.rotation.y = PI
	rig.scale = Vector3(GUN_SCALE, GUN_SCALE, GUN_SCALE)
	rig.position = VM_OFFSET
	add_child(rig)
	flash = Node3D.new()
	flash.visible = false
	add_child(flash)
	_build_audio()
	# tìm Player (tổ tiên có biến `team` và `viewmodels`) để biết đang chơi phe nào
	var n: Node = get_parent()
	while n != null:
		if "team" in n and "viewmodels" in n:
			owner_player = n
			break
		n = n.get_parent()
	_set_team(_player_team())
	visibility_changed.connect(_on_visibility_changed)


## Nạp các file wav (thiếu file / chưa import thì im lặng bỏ qua, dao vẫn chạy bình thường) và dựng các kênh phát.
func _build_audio() -> void:
	for n in SND_NAMES:
		var p: String = SND_DIR + n + ".wav"
		if ResourceLoader.exists(p):
			var s = load(p)
			if s != null:
				snd[n] = s
	for i in 2:
		var ap := AudioStreamPlayer.new()
		ap.volume_db = -3.0
		add_child(ap)
		foley_players.append(ap)


func _play_snd(sname: String) -> void:
	if not snd.has(sname):
		return
	var ap: AudioStreamPlayer = foley_players[foley_i % foley_players.size()]
	foley_i += 1
	ap.stream = snd[sname]
	ap.play()


func _stop_snd() -> void:
	for ap in foley_players:
		(ap as AudioStreamPlayer).stop()


## Phe của người chơi đang cầm dao: 0 = CT (tay áo xanh), 1 = T (tay trần). Không tìm thấy Player thì coi như CT.
func _player_team() -> int:
	if owner_player != null and is_instance_valid(owner_player):
		return 1 if int(owner_player.team) == 1 else 0
	return 0


## Đổi phe thì dựng lại model cho đúng tay áo, giữ nguyên animation đang chạy.
func _sync_team() -> void:
	var t := _player_team()
	if t != model_team:
		_set_team(t)


func _set_team(t: int) -> void:
	var cur_name := ""
	var cur_pos := 0.0
	if anim != null:
		cur_name = anim.current_animation
		cur_pos = anim.current_animation_position
	if model != null:
		rig.remove_child(model)
		model.queue_free()
		model = null
		skel = null
		anim = null
	model_team = t
	var path := MODEL_T if t == 1 else MODEL_CT
	var scene = load(path)
	if scene == null:
		push_warning("Không nạp được " + path + " (chạy CHOI_GAME.bat để Godot import lại)")
		return
	model = (scene as PackedScene).instantiate()
	rig.add_child(model)
	skel = _find_skeleton(model)
	anim = _find_anim(model)
	_fix_meshes(model)
	if anim != null:
		_complete_tracks()
		anim.playback_default_blend_time = 0.05
		anim.active = is_visible_in_tree()
		if cur_name != "" and anim.has_animation(cur_name):
			_play(cur_name, 0.0)
			anim.seek(cur_pos, true)
		else:
			_play("idle")


## Khi import, Godot có thể bỏ các track xương "bất biến" (bằng tư thế nghỉ). Nếu animation sau không còn track của xương đó thì xương giữ nguyên
## tư thế của animation trước (tay không quay về chỗ cũ). Thêm lại các track thiếu bằng đúng tư thế nghỉ để animation nào cũng ghi đè đủ mọi xương.
func _complete_tracks() -> void:
	if skel == null:
		return
	var base: Node = anim.get_node_or_null(anim.root_node)
	if base == null:
		return
	var sp := str(base.get_path_to(skel))
	for an in anim.get_animation_list():
		var a: Animation = anim.get_animation(an)
		for b in skel.get_bone_count():
			var path := NodePath(sp + ":" + skel.get_bone_name(b))
			var rest := skel.get_bone_rest(b)
			if a.find_track(path, Animation.TYPE_POSITION_3D) < 0:
				var tp_i := a.add_track(Animation.TYPE_POSITION_3D)
				a.track_set_path(tp_i, path)
				a.position_track_insert_key(tp_i, 0.0, rest.origin)
			if a.find_track(path, Animation.TYPE_ROTATION_3D) < 0:
				var tr_i := a.add_track(Animation.TYPE_ROTATION_3D)
				a.track_set_path(tr_i, path)
				a.rotation_track_insert_key(tr_i, 0.0, rest.basis.get_rotation_quaternion())


func _find_skeleton(n: Node) -> Skeleton3D:
	if n is Skeleton3D:
		return n
	for c in n.get_children():
		var r := _find_skeleton(c)
		if r != null:
			return r
	return null


func _find_anim(n: Node) -> AnimationPlayer:
	if n is AnimationPlayer:
		return n
	for c in n.get_children():
		var r := _find_anim(c)
		if r != null:
			return r
	return null


## Texture CS vẽ không đổ bóng (giống các súng khác + nhẹ cho máy yếu); mesh có xương nên nới hộp cắt hình để không bị mất khi animation đưa dao ra xa.
func _fix_meshes(n: Node) -> void:
	if n is MeshInstance3D:
		var mi := n as MeshInstance3D
		mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		mi.custom_aabb = AABB(Vector3(-3.0, -3.0, -3.0), Vector3(6.0, 6.0, 6.0))
		if mi.mesh != null:
			for i in mi.mesh.get_surface_count():
				var m = mi.mesh.surface_get_material(i)
				if m is BaseMaterial3D:
					var d := (m as BaseMaterial3D).duplicate() as BaseMaterial3D
					d.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
					d.cull_mode = BaseMaterial3D.CULL_DISABLED   # lưỡi dao mỏng, nhìn thấy cả hai mặt
					mi.set_surface_override_material(i, d)
	for c in n.get_children():
		_fix_meshes(c)


## Ẩn viewmodel (đổi súng) thì tắt luôn animation + tiếng cho nhẹ máy.
func _on_visibility_changed() -> void:
	if anim != null:
		anim.active = is_visible_in_tree()
	if not is_visible_in_tree():
		_stop_snd()


func _play(anim_name: String, blend: float = -1.0, speed: float = 1.0) -> void:
	if anim == null or not anim.has_animation(anim_name):
		return
	anim.play(anim_name, blend, speed)


func _anim_len(anim_name: String, fallback: float) -> float:
	if anim != null and anim.has_animation(anim_name):
		return anim.get_animation(anim_name).length
	return fallback


# =====================================================================
#  API CHO PLAYER
# =====================================================================
func is_busy() -> bool:
	return mode != Mode.NONE


func current_mode() -> int:
	return mode


func play_draw() -> void:
	_sync_team()
	draw_i = (draw_i + 1) % 2
	var nm := "draw" if draw_i == 0 else "draw2"
	_start_mode(Mode.DRAW, nm, 1.2)


func play_reload(_empty: bool) -> float:
	return 0.0   # dao không có nạp đạn


## F: múa dao, xen kẽ 3 kiểu của model.
func play_inspect() -> void:
	_sync_team()
	insp_i = (insp_i + 1) % 3
	var nm := "inspect" if insp_i == 0 else ("inspect2" if insp_i == 1 else "inspect3")
	_start_mode(Mode.INSPECT, nm, 4.5)


## kind = "slash" (chém, chuột trái: slash1 / slash2 xen kẽ) hoặc "stab" (đâm mạnh, chuột phải: heavy_miss; địch đang quay lưng thì đâm sau lưng: backstab)
func play_attack(kind: String) -> void:
	_sync_team()
	attack_kind = kind
	if kind == "stab":
		if owner_player != null and owner_player.has_method("melee_backstab_ready") and bool(owner_player.melee_backstab_ready()):
			_start_mode(Mode.ATTACK, "backstab", 0.97)
			hit_at = HIT_BACKSTAB
		else:
			_start_mode(Mode.ATTACK, "heavy_miss", 0.9)
			hit_at = HIT_HEAVY
	else:
		slash_i = (slash_i + 1) % 2
		_start_mode(Mode.ATTACK, "slash1" if slash_i == 0 else "slash2", 0.9)
		hit_at = HIT_SLASH
	hit_sent = false


func cancel() -> void:
	mode = Mode.NONE
	mode_t = 0.0
	hit_sent = true
	ev_list = []
	_stop_snd()   # đổi súng giữa chừng thì tắt tiếng múa dao
	_play("idle", 0.05)


func set_slide_locked(_locked: bool) -> void:
	pass


func is_slide_locked() -> bool:
	return false


func land(strength: float) -> void:
	land_off = minf(land_off - 0.035 * strength, 0.0)


func fire(_last_round: bool) -> void:
	pass


func dry_fire() -> void:
	pass


# =====================================================================
#  NỘI BỘ
# =====================================================================
func _start_mode(m: int, anim_name: String, fallback_len: float) -> void:
	mode = m
	mode_t = 0.0
	hit_sent = true
	cur_anim = anim_name
	mode_len = _anim_len(anim_name, fallback_len)
	ev_list = EVENTS.get(anim_name, [])
	ev_i = 0
	_play(anim_name, 0.03)


func _process(delta: float) -> void:
	delta = minf(delta, 0.05)
	_sync_team()   # đổi phe giữa trận (bomb.gd) thì đổi tay áo
	# đồng hồ của hành động chạy song song với animation của model
	if mode != Mode.NONE:
		mode_t += delta
		# tiếng động theo đúng thời điểm sự kiện của model
		while ev_i < ev_list.size() and mode_t >= float((ev_list[ev_i] as Array)[0]):
			_play_snd(str((ev_list[ev_i] as Array)[1]))
			ev_i += 1
		# lưỡi dao chạm: báo cho Player tính sát thương
		if mode == Mode.ATTACK and not hit_sent and mode_t >= hit_at:
			hit_sent = true
			melee_hit.emit(attack_kind)
		if mode_t >= mode_len:
			var finished := mode
			mode = Mode.NONE
			mode_t = 0.0
			ev_list = []
			hit_sent = true
			_play("idle", 0.08)
			var nm := "draw"
			if finished == Mode.INSPECT:
				nm = "inspect"
			elif finished == Mode.ATTACK:
				nm = "attack"
			action_finished.emit(nm)

	# lắc nhẹ theo chuột + nhún khi đi + dội khi tiếp đất (cộng lên trên animation của model)
	var target := Vector2(clampf(-mouse_delta.x * 0.0005, -0.018, 0.018), clampf(mouse_delta.y * 0.0005, -0.018, 0.018))
	mouse_delta = Vector2.ZERO
	sway = sway.lerp(target, 1.0 - exp(-9.0 * delta))
	bob_t += delta * (3.0 + move_amount * 7.0)
	var bob := Vector3(sin(bob_t) * 0.004, -absf(cos(bob_t)) * 0.005, 0.0) * move_amount
	land_off = lerpf(land_off, 0.0, 1.0 - exp(-10.0 * delta))
	if rig != null:
		rig.position = VM_OFFSET + Vector3(sway.x, sway.y + land_off, 0.0) + bob
