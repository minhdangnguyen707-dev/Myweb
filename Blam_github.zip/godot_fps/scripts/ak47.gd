extends Node3D
## AK-47 góc nhìn thứ nhất kiểu CS:GO / CS2 (người dùng yêu cầu: NHÚNG THẲNG model + tay + animation trong file gửi kèm; không có âm thanh nên không làm tiếng).
## Súng + hai bàn tay (găng đen) + mọi animation (rút súng, bắn 3 kiểu, nạp đạn, inspect, móc khoá cú mèo đung đưa) lấy từ MỘT file: assets/ak47/v_ak47.glb,
## đổi từ cstrike/models/v_ak47.mdl (gói cs2ak47_cfrigs) bằng `python3 tools/mdl2glb.py v_ak47.mdl v_ak47.glb --vm --atlas --atlas-scale=0.5 --jpeg`.
## Phe CT dùng bản tay áo xanh: assets/ak47/v_ak47_ct.glb đổi từ alt/v_ak47.mdl bằng cùng lệnh trên (phe T dùng v_ak47.glb, tay trần). Súng tự đổi model theo Player.team.
## NGOẠI LỆ so với quy tắc "súng mới phải dùng Hands.Arm": AK-47 dùng tay CÓ SẴN trong model (giống AWP / MP5), KHÔNG dùng hands.gd.
## Cùng giao diện (API) với Viewmodel / Rifle / Awp / Mp5 để Player dùng thay thế qua lại. KHÔNG có ngắm (ADS).
## Model AK-47 cũ dựng bằng code (khối hộp + tay hộp) đã bị XOÁ theo yêu cầu; lớp dựng lưới MB của nó được tách sang scripts/mesh_builder.gd (M4A1 còn dùng).
##
## Hệ trục model (glTF, đổi từ GoldSrc): +X trái, +Y lên, +Z phía trước. Model CS 1.6 được vẽ cho tay TRÁI (engine lật gương khi chơi tay phải),
## nên ta xoay 180 độ quanh Y (nòng chĩa về -Z) RỒI lật gương X: x_game = +x_model, z_game = -z_model -> tay phải cầm báng, tay trái đỡ ốp tay.
## Model GoldSrc dài ~2.2 m (viewmodel nhìn từ mắt): thu nhỏ đều quanh mắt (GUN_SCALE) thì hình trên màn hình Y NGUYÊN nhưng súng ngắn lại ~1.2 m, đỡ xuyên tường.

signal sound(sound_name: String)
signal reload_inserted()
signal action_finished(action_name: String)

# Phe CT (team 0) = tay áo xanh (alt/v_ak47.mdl), phe T (team 1) = tay trần găng đen (v_ak47.mdl). Đổi phe giữa trận (bomb.gd) thì súng tự đổi model.
const MODEL_CT := "res://assets/ak47/v_ak47_ct.glb"
const MODEL_T := "res://assets/ak47/v_ak47.glb"
# Thu nhỏ đều quanh mắt: hình trên màn hình không đổi (phép chiếu), chỉ đỡ dài. Gần quá thì bị near plane (0.03) cắt mất báng / cánh tay sát mắt.
const GUN_SCALE := 0.55
# Dời cả súng + tay (x phải, y lên, z trước = -z), tính theo mét ngoài đời (đã nhân GUN_SCALE rồi). Model đã đặt súng đúng chỗ kiểu CS nên để 0.
const VM_OFFSET := Vector3(0.0, 0.0, 0.0)
# Đầu nòng = attachment 0 của model, gắn vào xương "Box001", lệch (x trước 0.4, y trái 1.6, z lên 6.4) đơn vị GoldSrc (1 đơn vị = 2.54 cm), đổi sang hệ glTF (trái, lên, trước)
const MUZZLE_BONE := "Box001"
const MUZZLE_LOCAL := Vector3(0.0406, 0.1626, 0.0102)
# Dự phòng khi không tìm thấy xương: vị trí đầu nòng lúc nghỉ trong hệ model
const MUZZLE_FALLBACK := Vector3(0.304, -0.271, 2.255)

enum Mode { NONE, DRAW, RELOAD, INSPECT }

# CS2: nạp đạn AK-47 = 2.43 s; animation gốc của model dài ~2.467 s nên chạy nhanh hơn một chút cho vừa (xem play_reload).
const RELOAD_TIME := 2.43
# Băng đạn mới vào súng ngay sau cú "clipin" của model (giây TRONG animation gốc: clipin ở 1.133 s, kéo khoá ở 1.7 s)
const RELOAD_INSERT_AT := 1.2
# true = DỪNG animation khi súng đứng yên (đỡ tốn máy yếu nhưng mất hiệu ứng thở / móc khoá đung đưa của CS). Mặc định false: model chỉ 1 mảnh, 1 vật liệu nên rất nhẹ.
const FREEZE_IDLE := false

# ---------------- trạng thái nhận từ Player ----------------
var move_amount := 0.0
var run_amount := 0.0
var grounded := true
var crouched := false
var ads := 0.0           # luôn 0 (game không có ngắm)
var ads_t := 0.0
var wall_push := 0.0
var mouse_delta := Vector2.ZERO
var planting := false    # bomb.gd gán biến này cho viewmodel đang cầm; AK-47 không dùng

var rig: Node3D = null            # gốc model (đã xoay 180 độ + lật gương + thu nhỏ + dời vị trí)
var model: Node3D = null          # model đang dùng (CT hoặc T)
var model_team := -1              # phe của model đang dựng (-1 = chưa dựng)
var owner_player: Node = null     # Player đang cầm súng (để đọc phe)
var anim: AnimationPlayer = null
var skel: Skeleton3D = null
var muzzle_bone := -1
var flash: MeshInstance3D = null
var flash_t := 0.0

var mode: int = Mode.NONE
var mode_t := 0.0
var mode_len := 0.0
var mode_speed := 1.0             # tốc độ chạy animation của hành động hiện tại (nạp đạn chạy hơi nhanh cho đúng 2.43 s)
var insert_at := 1.2              # giây (đã tính tốc độ) băng đạn mới vào súng
var insert_sent := false
var fire_t := 0.0                 # còn đang chạy animation bắn
var shoot_i := 0

var idle_hold_t := 0.0            # chỉ dùng khi FREEZE_IDLE = true
var sway := Vector2.ZERO
var bob_t := 0.0
var land_off := 0.0


func _ready() -> void:
	rig = Node3D.new()
	rig.rotation.y = PI
	rig.scale = Vector3(-GUN_SCALE, GUN_SCALE, GUN_SCALE)   # xoay 180 độ + lật gương X = lật gương Z: x_game = +x_model * s, z_game = -z_model * s
	rig.position = VM_OFFSET
	add_child(rig)
	_build_flash()   # main._warmup() đụng tới `flash` của mọi viewmodel nên luôn phải có
	# tìm Player (tổ tiên có biến `team` và `viewmodels`) để biết đang chơi phe nào
	var n: Node = get_parent()
	while n != null:
		if "team" in n and "viewmodels" in n:
			owner_player = n
			break
		n = n.get_parent()
	_set_team(_player_team())
	visibility_changed.connect(_on_visibility_changed)


## Phe của người chơi đang cầm súng: 0 = CT (tay áo xanh), 1 = T (tay trần). Không tìm thấy Player thì coi như CT.
func _player_team() -> int:
	if owner_player != null and is_instance_valid(owner_player):
		return 1 if int(owner_player.team) == 1 else 0
	return 0


## Đổi phe thì dựng lại model cho đúng tay áo, giữ nguyên animation đang chạy (rút súng / nạp đạn / bắn dở).
func _sync_team() -> void:
	var t := _player_team()
	if t != model_team:
		_set_team(t)


func _set_team(t: int) -> void:
	var cur_name := ""
	var cur_pos := 0.0
	if anim != null:
		cur_name = anim.current_animation
		cur_pos = anim.current_animation_position
	if model != null:
		rig.remove_child(model)
		model.queue_free()
		model = null
		skel = null
		anim = null
		muzzle_bone = -1
	model_team = t
	var path := MODEL_T if t == 1 else MODEL_CT
	var scene = load(path)
	if scene == null:
		push_warning("Không nạp được " + path + " (chạy CHOI_GAME.bat để Godot import lại)")
		return
	model = (scene as PackedScene).instantiate()
	rig.add_child(model)
	skel = _find_skeleton(model)
	anim = _find_anim(model)
	if skel != null:
		muzzle_bone = skel.find_bone(MUZZLE_BONE)
		if muzzle_bone < 0:
			muzzle_bone = _find_bone_by_suffix(MUZZLE_BONE.to_lower())
	_fix_meshes(model)
	if anim != null:
		_complete_tracks()
		anim.playback_default_blend_time = 0.05
		anim.active = is_visible_in_tree()
		if cur_name != "" and anim.has_animation(cur_name):
			var sp := mode_speed if mode != Mode.NONE else 1.0
			_play(cur_name, 0.0, sp)
			anim.seek(cur_pos, true)
		else:
			_play("idle")


## Khi import, Godot có thể bỏ các track xương "bất biến" (bằng tư thế nghỉ). Nếu animation sau không còn track của xương đó thì xương giữ nguyên
## tư thế của animation trước (tay / băng đạn không quay về chỗ cũ). Thêm lại các track thiếu bằng đúng tư thế nghỉ để animation nào cũng ghi đè đủ mọi xương.
func _complete_tracks() -> void:
	if skel == null:
		return
	var base: Node = anim.get_node_or_null(anim.root_node)
	if base == null:
		return
	var sp := str(base.get_path_to(skel))
	for an in anim.get_animation_list():
		var a: Animation = anim.get_animation(an)
		for b in skel.get_bone_count():
			var path := NodePath(sp + ":" + skel.get_bone_name(b))
			var rest := skel.get_bone_rest(b)
			if a.find_track(path, Animation.TYPE_POSITION_3D) < 0:
				var tp_i := a.add_track(Animation.TYPE_POSITION_3D)
				a.track_set_path(tp_i, path)
				a.position_track_insert_key(tp_i, 0.0, rest.origin)
			if a.find_track(path, Animation.TYPE_ROTATION_3D) < 0:
				var tr_i := a.add_track(Animation.TYPE_ROTATION_3D)
				a.track_set_path(tr_i, path)
				a.rotation_track_insert_key(tr_i, 0.0, rest.basis.get_rotation_quaternion())


func _find_skeleton(n: Node) -> Skeleton3D:
	if n is Skeleton3D:
		return n
	for c in n.get_children():
		var r := _find_skeleton(c)
		if r != null:
			return r
	return null


func _find_anim(n: Node) -> AnimationPlayer:
	if n is AnimationPlayer:
		return n
	for c in n.get_children():
		var r := _find_anim(c)
		if r != null:
			return r
	return null


## Tìm xương theo đuôi tên (không phân biệt hoa thường), phòng khi Godot đổi dấu trong tên xương.
func _find_bone_by_suffix(suffix: String) -> int:
	for i in skel.get_bone_count():
		if skel.get_bone_name(i).to_lower().ends_with(suffix):
			return i
	return -1


## Texture CS vẽ không đổ bóng (giống các súng khác + nhẹ cho máy yếu); mesh có xương nên nới hộp cắt hình để không bị mất khi animation đưa súng ra xa.
func _fix_meshes(n: Node) -> void:
	if n is MeshInstance3D:
		var mi := n as MeshInstance3D
		mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		mi.custom_aabb = AABB(Vector3(-3.0, -3.0, -3.0), Vector3(6.0, 6.0, 6.0))
		if mi.mesh != null:
			for i in mi.mesh.get_surface_count():
				var m = mi.mesh.surface_get_material(i)
				if m is BaseMaterial3D:
					var d := (m as BaseMaterial3D).duplicate() as BaseMaterial3D
					d.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
					d.cull_mode = BaseMaterial3D.CULL_DISABLED   # model bị lật gương nên chiều mặt đảo: tắt cắt mặt sau cho chắc
					mi.set_surface_override_material(i, d)
	for c in n.get_children():
		_fix_meshes(c)


## Tia lửa đầu nòng: AK-47 không có ống giảm thanh nên loé to và sáng.
func _build_flash() -> void:
	var g := Gradient.new()
	g.set_color(0, Color(1.0, 0.95, 0.7, 0.95))
	g.set_color(1, Color(1.0, 0.5, 0.1, 0.0))
	var gt := GradientTexture2D.new()
	gt.gradient = g
	gt.fill = GradientTexture2D.FILL_RADIAL
	gt.fill_from = Vector2(0.5, 0.5)
	gt.fill_to = Vector2(1.0, 0.5)
	gt.width = 64
	gt.height = 64
	var q := QuadMesh.new()
	q.size = Vector2(0.22, 0.22)
	var mat := StandardMaterial3D.new()
	mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	mat.blend_mode = BaseMaterial3D.BLEND_MODE_ADD
	mat.billboard_mode = BaseMaterial3D.BILLBOARD_ENABLED
	mat.albedo_texture = gt
	mat.no_depth_test = true
	flash = MeshInstance3D.new()
	flash.mesh = q
	flash.material_override = mat
	flash.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	flash.visible = false
	add_child(flash)


## Ẩn viewmodel (đổi súng) thì tắt luôn animation cho nhẹ máy.
func _on_visibility_changed() -> void:
	if anim != null:
		anim.active = is_visible_in_tree()


func _play(anim_name: String, blend: float = -1.0, speed: float = 1.0) -> void:
	if anim == null or not anim.has_animation(anim_name):
		return
	idle_hold_t = 0.3 if (anim_name == "idle" and FREEZE_IDLE) else 0.0
	anim.play(anim_name, blend, speed)


func _anim_len(anim_name: String, fallback: float) -> float:
	if anim != null and anim.has_animation(anim_name):
		return anim.get_animation(anim_name).length
	return fallback


# =====================================================================
#  API CHO PLAYER
# =====================================================================
func is_busy() -> bool:
	return mode != Mode.NONE or fire_t > 0.0


func current_mode() -> int:
	return mode


func play_draw() -> void:
	_sync_team()
	_start_mode(Mode.DRAW, "draw", _anim_len("draw", 1.0), 1.0)


func play_reload(_empty: bool) -> float:
	_sync_team()
	var a_len := _anim_len("reload", 2.467)
	_start_mode(Mode.RELOAD, "reload", RELOAD_TIME, a_len / RELOAD_TIME)
	return mode_len


func play_inspect() -> void:
	_sync_team()
	_start_mode(Mode.INSPECT, "inspect", _anim_len("inspect", 4.45), 1.0)


func cancel() -> void:
	mode = Mode.NONE
	mode_t = 0.0
	fire_t = 0.0
	flash_t = 0.0
	if flash != null:
		flash.visible = false
	_play("idle", 0.05)


func set_slide_locked(_locked: bool) -> void:
	pass


func is_slide_locked() -> bool:
	return false


func land(strength: float) -> void:
	land_off = minf(land_off - 0.035 * strength, 0.0)


func dry_fire() -> void:
	pass   # model không có animation bắn rỗng


## Bắn: chạy animation bắn (3 kiểu như model gốc) + loé lửa đầu nòng.
func fire(_last_round: bool) -> void:
	_sync_team()
	if mode == Mode.INSPECT:
		cancel()
	shoot_i = (shoot_i + 1) % 3
	var nm := "shoot%d" % (shoot_i + 1)
	_play(nm, 0.0)
	fire_t = _anim_len(nm, 0.55)
	flash_t = 0.04
	if flash != null:
		flash.visible = true
		flash.global_position = muzzle_global()
	sound.emit("shot_ak")


## Vị trí đầu nòng trong thế giới (theo xương "Box001" đang chuyển động) cho vạch đạn / loé lửa.
func muzzle_global() -> Vector3:
	if skel != null and muzzle_bone >= 0:
		var t: Transform3D = skel.global_transform * skel.get_bone_global_pose(muzzle_bone)
		return t * MUZZLE_LOCAL
	if rig != null:
		return rig.to_global(MUZZLE_FALLBACK)
	return global_transform * Vector3(0.12, -0.12, -0.9)


# =====================================================================
#  NỘI BỘ
# =====================================================================
func _start_mode(m: int, anim_name: String, total_len: float, speed: float) -> void:
	mode = m
	mode_t = 0.0
	fire_t = 0.0
	insert_sent = false
	mode_speed = maxf(speed, 0.01)
	mode_len = total_len
	insert_at = RELOAD_INSERT_AT / mode_speed
	_play(anim_name, 0.03, speed)


func _process(delta: float) -> void:
	delta = minf(delta, 0.05)
	_sync_team()   # đổi phe giữa trận (bomb.gd) thì đổi tay áo
	# đồng hồ của hành động (rút súng / nạp đạn / inspect) chạy song song với animation của model
	if mode != Mode.NONE:
		mode_t += delta
		if mode == Mode.RELOAD and not insert_sent and mode_t >= insert_at:
			insert_sent = true
			reload_inserted.emit()
		if mode_t >= mode_len:
			var finished := mode
			mode = Mode.NONE
			mode_t = 0.0
			_play("idle", 0.08)
			var nm := "draw"
			if finished == Mode.RELOAD:
				nm = "reload"
				if not insert_sent:
					insert_sent = true
					reload_inserted.emit()
			elif finished == Mode.INSPECT:
				nm = "inspect"
			action_finished.emit(nm)
	elif fire_t > 0.0:
		fire_t -= delta
		if fire_t <= 0.0:
			fire_t = 0.0
			_play("idle", 0.08)
	if idle_hold_t > 0.0:
		idle_hold_t -= delta
		if idle_hold_t <= 0.0 and anim != null and mode == Mode.NONE and fire_t <= 0.0:
			anim.pause()   # chỉ khi FREEZE_IDLE = true
	if flash_t > 0.0:
		flash_t -= delta
		if flash != null:
			flash.global_position = muzzle_global()
			if flash_t <= 0.0:
				flash.visible = false

	# lắc nhẹ theo chuột + nhún khi đi + dội khi tiếp đất (cộng lên trên animation của model)
	var target := Vector2(clampf(-mouse_delta.x * 0.0005, -0.018, 0.018), clampf(mouse_delta.y * 0.0005, -0.018, 0.018))
	mouse_delta = Vector2.ZERO
	sway = sway.lerp(target, 1.0 - exp(-9.0 * delta))
	bob_t += delta * (3.0 + move_amount * 7.0)
	var bob := Vector3(sin(bob_t) * 0.004, -absf(cos(bob_t)) * 0.005, 0.0) * move_amount
	land_off = lerpf(land_off, 0.0, 1.0 - exp(-10.0 * delta))
	if rig != null:
		rig.position = VM_OFFSET + Vector3(sway.x, sway.y + land_off, 0.0) + bob
