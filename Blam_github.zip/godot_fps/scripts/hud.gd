class_name Hud
extends CanvasLayer
## HUD: tâm ngắm động kiểu CS2, máu, đạn, hit marker, kill feed, điểm số, bảng điểm, menu tạm dừng.

signal sensitivity_changed(value: float)
signal fov_changed(value: float)
signal resume_pressed()
signal quit_pressed()
signal settings_pressed()


class Crosshair:
	extends Control
	var gap := 2.0
	var length := 3.0       # cỡ "Very Small" như CS 1.6
	var thick := 1.0
	var col := Color(1.0, 1.0, 1.0, 1.0)
	var hit_t := 0.0
	var hit_head := false
	var dim := 1.0
	var hide_cross := false

	func _draw() -> void:
		# Vẽ bằng ĐIỂM ẢNH THẬT của màn hình (không bị phóng to làm mờ): đổi hệ toạ độ về điểm ảnh thật.
		var k := get_viewport().get_final_transform().get_scale().x
		if k < 0.1:
			k = 1.0
		draw_set_transform(Vector2.ZERO, 0.0, Vector2(1.0 / k, 1.0 / k))
		var u := k / 1.7778   # 1.0 khi cửa sổ cao 720
		var c := (size * k * 0.5).floor()
		if not hide_cross:
			_draw_cross(c, u)
		_draw_hit(c, u)

	func _draw_cross(c: Vector2, u: float) -> void:
		# Hình chữ nhật nằm trọn trên lưới điểm ảnh, đối xứng quanh tâm (c): bốn nhánh luôn bằng nhau.
		var cc := Color(col.r, col.g, col.b, col.a * dim)
		var ol := Color(0, 0, 0, 0.35 * dim)
		var g := roundf(gap * 1.5 * u)
		var l := roundf(4.0 * u)
		var t := 2.0 if u < 2.2 else 4.0
		var o := t * 0.5
		var e_out := maxf(1.0, roundf(u))
		for pass_i in 2:
			var e := e_out if pass_i == 0 else 0.0
			var colr := ol if pass_i == 0 else cc
			var x0 := c.x - o
			var y0 := c.y - o
			# trái, phải
			draw_rect(Rect2(x0 - g - l - e, y0 - e, l + 2.0 * e, t + 2.0 * e), colr)
			draw_rect(Rect2(x0 + t + g - e, y0 - e, l + 2.0 * e, t + 2.0 * e), colr)
			# trên, dưới
			draw_rect(Rect2(x0 - e, y0 - g - l - e, t + 2.0 * e, l + 2.0 * e), colr)
			draw_rect(Rect2(x0 - e, y0 + t + g - e, t + 2.0 * e, l + 2.0 * e), colr)

	func _draw_hit(c: Vector2, u: float) -> void:
		if hit_t > 0.0:
			var a := clampf(hit_t / 0.25, 0.0, 1.0)
			var hc := Color(1.0, 0.15, 0.15, a) if hit_head else Color(1, 1, 1, a)
			var d := 10.0 * u
			var e := 22.0 * u
			var w := 3.0 * u
			draw_line(c + Vector2(-d, -d), c + Vector2(-e, -e), hc, w)
			draw_line(c + Vector2(d, -d), c + Vector2(e, -e), hc, w)
			draw_line(c + Vector2(-d, d), c + Vector2(-e, e), hc, w)
			draw_line(c + Vector2(d, d), c + Vector2(e, e), hc, w)


## Thanh máu/đạn dưới giữa màn hình kiểu CS2: số máu (gạch chân) - đường kẻ - huy hiệu tròn - đường kẻ - đạn trong băng | đạn dự trữ.
## Hạ được địch thì huy hiệu sáng rực, có tia sáng + lá bài đầu lâu hiện lên vài giây rồi tắt.
class BottomBar:
	extends Control
	const KILL_TIME := 3.2
	var hp := 100
	var mag := 0
	var reserve := 0
	var melee := false
	var kill_t := 0.0
	var kill_head := false
	var streak := 0
	var font: Font
	const KS := 0.78   # hệ số thu nhỏ cả thanh

	func _init() -> void:
		var fv := FontVariation.new()
		fv.base_font = ThemeDB.fallback_font
		fv.variation_embolden = 0.55
		font = fv

	func kill(head: bool) -> void:
		streak = (streak + 1) if kill_t > 0.0 else 1
		kill_t = KILL_TIME
		kill_head = head
		queue_redraw()

	func _text(pos: Vector2, s: String, fs: int, col: Color) -> void:
		draw_string_outline(font, pos, s, HORIZONTAL_ALIGNMENT_LEFT, -1, fs, 5, Color(0, 0, 0, 0.75))
		draw_string(font, pos, s, HORIZONTAL_ALIGNMENT_LEFT, -1, fs, col)

	func _hline(x0: float, x1: float, y: float, col: Color) -> void:
		if x1 <= x0:
			return
		draw_line(Vector2(x0, y + 1.0), Vector2(x1, y + 1.0), Color(0, 0, 0, 0.4), 1.5)
		draw_line(Vector2(x0, y), Vector2(x1, y), col, 1.5)

	func _draw() -> void:
		var w := size.x / KS
		var h := size.y / KS
		draw_set_transform(Vector2.ZERO, 0.0, Vector2(KS, KS))
		var ly := h - 30.0
		var cx := w * 0.5
		var c := Vector2(cx, ly)
		var r := 20.0
		var low_hp := hp <= 30
		var white := Color(1, 1, 1, 0.95)
		var accent := Color(1.0, 0.32, 0.27, 1.0) if low_hp else white
		var line_col := Color(1, 1, 1, 0.7)

		# --- máu (trái) ---
		var hs := 30
		var htxt := str(maxi(hp, 0))
		var hsz := font.get_string_size(htxt, HORIZONTAL_ALIGNMENT_LEFT, -1, hs)
		var hbase := ly + float(hs) * 0.36
		_text(Vector2(0.0, hbase), htxt, hs, accent)
		draw_line(Vector2(0.0, hbase + 5.0), Vector2(hsz.x, hbase + 5.0), accent, 2.0)
		_hline(hsz.x + 14.0, cx - r - 6.0, ly, line_col)

		# --- đạn (phải) ---
		var line_end := w
		if not melee:
			# viên đạn nhỏ ở mép phải
			draw_set_transform(Vector2(w - 7.0, ly) * KS, PI * 0.25, Vector2(KS, KS))
			draw_rect(Rect2(-2.5, -1.0, 5.0, 8.0), white)
			draw_circle(Vector2(0.0, -1.0), 2.5, white)
			draw_set_transform(Vector2.ZERO, 0.0, Vector2(KS, KS))
			var rs := 15
			var rtxt := str(reserve)
			var rsz := font.get_string_size(rtxt, HORIZONTAL_ALIGNMENT_LEFT, -1, rs)
			var rx := w - 20.0 - rsz.x
			_text(Vector2(rx, ly + float(rs) * 0.36), rtxt, rs, Color(1, 1, 1, 0.9))
			draw_line(Vector2(rx - 8.0, ly - 9.0), Vector2(rx - 8.0, ly + 9.0), Color(1, 1, 1, 0.8), 1.5)
			var ms := 30
			var mtxt := str(mag)
			var msz := font.get_string_size(mtxt, HORIZONTAL_ALIGNMENT_LEFT, -1, ms)
			var mx := rx - 8.0 - 12.0 - msz.x
			line_end = mx - 12.0
			_text(Vector2(mx, ly + float(ms) * 0.36), mtxt, ms, white)
		_hline(cx + r + 6.0, line_end, ly, line_col)

		# --- hiệu ứng hạ gục ---
		var inten := 0.0
		var gc := Color(1.0, 0.8, 0.35) if kill_head else Color(0.72, 0.88, 1.0)
		if kill_t > 0.0:
			var k_in := clampf((KILL_TIME - kill_t) / 0.15, 0.0, 1.0)
			var k_out := clampf(kill_t / 1.3, 0.0, 1.0)
			inten = k_in * k_out
			var pulse := 0.88 + 0.12 * sin(float(Time.get_ticks_msec()) * 0.014)
			inten *= pulse
			# quầng sáng
			for i in 9:
				var rr := r * (1.0 + float(i) * 0.4)
				draw_circle(c, rr, Color(gc.r, gc.g, gc.b, 0.15 * inten * (1.0 - float(i) / 9.0)))
			# tia sáng bay lên
			var pts := PackedVector2Array([Vector2(cx - 10.0, ly - 6.0), Vector2(cx + 10.0, ly - 6.0), Vector2(cx + 26.0, ly - 110.0), Vector2(cx + 8.0, ly - 110.0)])
			var cols := PackedColorArray([Color(gc.r, gc.g, gc.b, 0.6 * inten), Color(gc.r, gc.g, gc.b, 0.6 * inten), Color(gc.r, gc.g, gc.b, 0.0), Color(gc.r, gc.g, gc.b, 0.0)])
			draw_polygon(pts, cols)

		# --- huy hiệu NGÔI SAO (sáng lên khi hạ địch) ---
		var sfill := Color(0.07, 0.09, 0.13, 0.7)
		if low_hp:
			sfill = Color(0.28, 0.05, 0.05, 0.75)
		var ring := Color(0.78, 0.9, 1.0, 0.95).lerp(Color(1, 1, 1, 1), inten)
		if low_hp:
			ring = Color(1.0, 0.5, 0.45, 0.95)
		var star := PackedVector2Array()
		for i in 10:
			var rad := r * 1.12 * (1.0 if i % 2 == 0 else 0.42)
			var ang := -PI * 0.5 + float(i) * PI / 5.0
			star.append(c + Vector2(cos(ang), sin(ang)) * rad)
		draw_colored_polygon(star, sfill)
		if inten > 0.0:
			draw_colored_polygon(star, Color(gc.r, gc.g, gc.b, 0.6 * inten))
		var outline := star.duplicate()
		outline.append(star[0])
		draw_polyline(outline, ring, 2.0, true)

		# --- lá bài đầu lâu (số lá = số kill liên tiếp, tối đa 3) ---
		if kill_t > 0.0:
			var n := mini(streak, 3)
			var rise := (1.0 - clampf((KILL_TIME - kill_t) / 0.2, 0.0, 1.0)) * 16.0
			for i in n:
				var off := float(i) - float(n - 1) * 0.5
				var pos := Vector2(cx + off * 15.0, ly - 54.0 + rise)
				draw_set_transform(pos * KS, off * 0.2, Vector2(KS, KS))
				var front := (i == n - 1)
				var fill := Color(0.93, 0.97, 1.0, 0.95 * inten) if front else Color(0.55, 0.65, 0.8, 0.85 * inten)
				draw_rect(Rect2(-9.0, -13.0, 18.0, 26.0), fill)
				draw_rect(Rect2(-9.0, -13.0, 18.0, 26.0), Color(gc.r, gc.g, gc.b, 0.9 * inten), false, 1.5)
				var ink := Color(0.1, 0.12, 0.18, 0.95 * inten)
				draw_circle(Vector2(0.0, -3.0), 5.0, ink)
				draw_rect(Rect2(-2.8, 0.5, 5.6, 5.0), ink)
				draw_circle(Vector2(-2.0, -3.0), 1.3, fill)
				draw_circle(Vector2(2.0, -3.0), 1.3, fill)
			draw_set_transform(Vector2.ZERO, 0.0, Vector2(KS, KS))


## Ống ngắm AWP kiểu CS:GO: hai bên đen, vòng tròn nhìn xuyên vừa khít chiều cao màn hình, hai vạch chữ thập mảnh xuyên suốt màn hình.
class Scope:
	extends Control

	func _init() -> void:
		resized.connect(queue_redraw)

	func _draw() -> void:
		var w := size.x
		var h := size.y
		var c := size * 0.5
		var r := h * 0.5
		var black := Color(0.0, 0.0, 0.0, 1.0)
		draw_rect(Rect2(-2.0, -2.0, c.x - r + 2.0, h + 4.0), black)
		draw_rect(Rect2(c.x + r, -2.0, w - c.x - r + 2.0, h + 4.0), black)
		# bốn góc giữa hình vuông và vòng tròn
		for q in 4:
			var sx := -1.0 if (q == 0 or q == 3) else 1.0
			var sy := -1.0 if q < 2 else 1.0
			var pts := PackedVector2Array()
			pts.append(c + Vector2(sx * (r + 1.0), sy * (r + 1.0)))
			pts.append(c + Vector2(sx * (r + 1.0), 0.0))
			var n := 36
			for i in range(n + 1):
				var a := float(i) / float(n) * PI * 0.5
				pts.append(c + Vector2(sx * r * cos(a), sy * r * sin(a)))
			pts.append(c + Vector2(0.0, sy * (r + 1.0)))
			draw_colored_polygon(pts, black)
		# chữ thập mảnh xuyên suốt
		var lc := Color(0.0, 0.0, 0.0, 0.92)
		draw_rect(Rect2(c.x - r, c.y - 0.6, r * 2.0, 1.2), lc)
		draw_rect(Rect2(c.x - 0.6, 0.0, 1.2, h), lc)


var crosshair: Crosshair
var scope_overlay: Scope
var bar: BottomBar
var kill_feed_on := true
var score_label: Label
var info_label: Label
var center_label: Label
var kill_box: VBoxContainer
var damage_flash: ColorRect
var scoreboard: PanelContainer
var score_text: Label
var pause_panel: PanelContainer
var fps_label: Label
var weapon_label: Label
var money_label: Label
var round_label: Label        # đồng hồ round (chế độ ĐẶT BOM)
var prompt_label: Label       # "Giữ E để đặt bom / gỡ bom"
var act_bg: ColorRect         # thanh tiến độ đặt / gỡ bom
var act_fill: ColorRect
var quit_btn: Button
var _fps_t := 0.0
var debug_label: Label

var _kill_items: Array = []
var _flash_a := 0.0
var _center_t := 0.0
var _info_t := 0.0


func _ready() -> void:
	layer = 10
	var root := Control.new()
	root.set_anchors_preset(Control.PRESET_FULL_RECT)
	root.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(root)

	damage_flash = ColorRect.new()
	damage_flash.set_anchors_preset(Control.PRESET_FULL_RECT)
	damage_flash.color = Color(0.8, 0.0, 0.0, 0.0)
	damage_flash.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.add_child(damage_flash)

	scope_overlay = Scope.new()
	scope_overlay.set_anchors_preset(Control.PRESET_FULL_RECT)
	scope_overlay.mouse_filter = Control.MOUSE_FILTER_IGNORE
	scope_overlay.visible = false
	root.add_child(scope_overlay)

	crosshair = Crosshair.new()
	crosshair.set_anchors_preset(Control.PRESET_FULL_RECT)
	crosshair.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.add_child(crosshair)

	# --- thanh máu / đạn dưới giữa (kiểu CS2) ---
	bar = BottomBar.new()
	bar.anchor_left = 0.26
	bar.anchor_right = 0.74
	bar.anchor_top = 1.0
	bar.anchor_bottom = 1.0
	bar.offset_left = 0.0
	bar.offset_right = 0.0
	bar.offset_top = -170.0
	bar.offset_bottom = -12.0
	bar.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.add_child(bar)
	weapon_label = _label("GLOCK 17", 11, Color(0.85, 0.9, 1.0, 0.8))
	weapon_label.add_theme_constant_override("outline_size", 3)
	weapon_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	_anchor(weapon_label, 1.0, 1.0, -180.0, -15.0, 180.0, 14.0)
	bar.add_child(weapon_label)

	# --- điểm số (trên giữa) ---
	score_label = _label("CT 0  :  0 T", 28, Color(1, 1, 1))
	_anchor(score_label, 0.5, 0.0, -110.0, 14.0, 220.0, 40.0)
	score_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	root.add_child(score_label)

	# --- đồng hồ round + gợi ý hành động (chế độ ĐẶT BOM) ---
	round_label = _label("", 22, Color(1, 1, 1))
	round_label.add_theme_constant_override("outline_size", 4)
	_anchor(round_label, 0.5, 0.0, -110.0, 52.0, 220.0, 60.0)
	round_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	round_label.visible = false
	root.add_child(round_label)
	prompt_label = _label("", 22, Color(1.0, 0.9, 0.5))
	prompt_label.add_theme_constant_override("outline_size", 4)
	_anchor(prompt_label, 0.5, 0.5, -250.0, 70.0, 500.0, 34.0)
	prompt_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	root.add_child(prompt_label)
	act_bg = ColorRect.new()
	act_bg.color = Color(0, 0, 0, 0.6)
	_anchor(act_bg, 0.5, 0.5, -110.0, 108.0, 220.0, 12.0)
	act_bg.visible = false
	act_bg.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.add_child(act_bg)
	act_fill = ColorRect.new()
	act_fill.color = Color(1.0, 0.85, 0.3)
	act_fill.position = Vector2(2.0, 2.0)
	act_fill.size = Vector2(0.0, 8.0)
	act_fill.mouse_filter = Control.MOUSE_FILTER_IGNORE
	act_bg.add_child(act_fill)

	# --- kill feed (trên phải) ---
	kill_box = VBoxContainer.new()
	_anchor(kill_box, 1.0, 0.0, -370.0, 16.0, 350.0, 20.0)
	kill_box.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.add_child(kill_box)

	# --- thông báo giữa màn hình ---
	center_label = _label("", 40, Color(1, 1, 1))
	_anchor(center_label, 0.5, 0.5, -300.0, -30.0, 600.0, 60.0)
	center_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	root.add_child(center_label)

	info_label = _label("", 20, Color(1, 0.9, 0.5))
	_anchor(info_label, 0.5, 0.5, -300.0, 110.0, 600.0, 40.0)
	info_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	root.add_child(info_label)

	fps_label = _label("", 14, Color(0.7, 1, 0.7))
	_anchor(fps_label, 0.0, 0.0, 8.0, 4.0, 100.0, 20.0)
	root.add_child(fps_label)

	money_label = _label("$0", 24, Color(0.55, 1.0, 0.55))
	_anchor(money_label, 0.0, 0.5, 14.0, -14.0, 200.0, 30.0)
	root.add_child(money_label)

	debug_label = _label("", 13, Color(1, 1, 0.6))
	_anchor(debug_label, 0.0, 0.0, 8.0, 40.0, 600.0, 200.0)
	debug_label.visible = false
	root.add_child(debug_label)

	# --- bảng điểm (giữ TAB) ---
	scoreboard = PanelContainer.new()
	_anchor(scoreboard, 0.5, 0.5, -260.0, -200.0, 520.0, 300.0)
	scoreboard.visible = false
	scoreboard.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.add_child(scoreboard)
	score_text = _label("", 18, Color(1, 1, 1))
	scoreboard.add_child(score_text)

	_build_pause(root)


func _anchor(c: Control, ax: float, ay: float, ox: float, oy: float, w: float, h: float) -> void:
	c.anchor_left = ax
	c.anchor_right = ax
	c.anchor_top = ay
	c.anchor_bottom = ay
	c.offset_left = ox
	c.offset_right = ox + w
	c.offset_top = oy
	c.offset_bottom = oy + h


func _label(text: String, font_size: int, color: Color) -> Label:
	var l := Label.new()
	l.text = text
	l.add_theme_font_size_override("font_size", font_size)
	l.add_theme_color_override("font_color", color)
	l.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.85))
	l.add_theme_constant_override("outline_size", 5)
	l.mouse_filter = Control.MOUSE_FILTER_IGNORE
	return l


func _build_pause(root: Control) -> void:
	pause_panel = PanelContainer.new()
	_anchor(pause_panel, 0.5, 0.5, -300.0, -235.0, 600.0, 470.0)
	# nếu nội dung rộng hơn khung thì nở đều ra hai phía, không bị lệch sang phải/xuống dưới
	pause_panel.grow_horizontal = Control.GROW_DIRECTION_BOTH
	pause_panel.grow_vertical = Control.GROW_DIRECTION_BOTH
	pause_panel.visible = false
	root.add_child(pause_panel)
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 10)
	pause_panel.add_child(v)
	var title := Label.new()
	title.text = "PAUSED"
	title.add_theme_font_size_override("font_size", 32)
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	v.add_child(title)
	v.add_child(_slider_row("Mouse sensitivity", 0.02, 0.6, 0.12, 0.01, "sens"))
	v.add_child(_slider_row("Field of view", 60.0, 105.0, 80.0, 1.0, "fov"))
	var help := Label.new()
	help.text = "WASD move | Space jump | Shift crouch | Ctrl walk\nLMB fire | RMB aim | R reload | F inspect | Tab scoreboard\nB buy menu | 1 M4A1 | 2 Pistol (Glock / Desert Eagle) | 3 Knife | 5 AK-47 | Q last weapon\nKnife: LMB slash | RMB stab (backstab = instant kill) | F flourish"
	help.add_theme_font_size_override("font_size", 14)
	help.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	v.add_child(help)
	var b1 := Button.new()
	b1.text = "Resume"
	b1.pressed.connect(func(): resume_pressed.emit())
	v.add_child(b1)
	var bset := Button.new()
	bset.text = "Settings"
	bset.pressed.connect(func(): settings_pressed.emit())
	v.add_child(bset)
	quit_btn = Button.new()
	quit_btn.text = "Quit"
	quit_btn.pressed.connect(func(): quit_pressed.emit())
	v.add_child(quit_btn)


func _slider_row(caption: String, mn: float, mx: float, val: float, step: float, kind: String) -> Control:
	var h := HBoxContainer.new()
	var l := Label.new()
	l.text = caption
	l.custom_minimum_size = Vector2(170, 0)
	h.add_child(l)
	var s := HSlider.new()
	s.min_value = mn
	s.max_value = mx
	s.step = step
	s.value = val
	s.custom_minimum_size = Vector2(160, 0)
	s.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	h.add_child(s)
	var vl := Label.new()
	vl.text = str(val)
	vl.custom_minimum_size = Vector2(50, 0)
	h.add_child(vl)
	s.value_changed.connect(_on_slider.bind(kind, vl))
	return h


func _on_slider(x: float, kind: String, vl: Label) -> void:
	vl.text = str(snappedf(x, 0.01))
	match kind:
		"sens":
			sensitivity_changed.emit(x)
		"fov":
			fov_changed.emit(x)


# ---------------- cập nhật ----------------
func set_health(hp: int) -> void:
	bar.hp = hp
	bar.queue_redraw()


func set_ammo(mag: int, reserve: int) -> void:
	bar.mag = mag
	bar.reserve = reserve
	bar.melee = false
	bar.queue_redraw()


func set_melee_ammo() -> void:
	bar.melee = true
	bar.queue_redraw()


## Hạ được địch: ngôi sao sáng rực + tia sáng + lá bài đầu lâu vài giây.
func kill_flash(head: bool) -> void:
	bar.kill(head)


func set_weapon(weapon_name: String) -> void:
	weapon_label.text = weapon_name


func set_money(amount: int) -> void:
	money_label.text = "$%d" % amount


## Chế độ ĐẶT BOM: dòng đồng hồ + số round dưới tỉ số (text rỗng = ẩn).
func set_round_text(text: String, col: Color) -> void:
	round_label.visible = text != ""
	round_label.text = text
	round_label.add_theme_color_override("font_color", col)


func set_prompt(text: String) -> void:
	prompt_label.text = text


## frac < 0 = ẩn thanh tiến độ; 0..1 = đang đặt / gỡ bom.
func set_action_progress(frac: float) -> void:
	act_bg.visible = frac >= 0.0
	if frac >= 0.0:
		act_fill.size.x = 216.0 * clampf(frac, 0.0, 1.0)


func set_score(ct: int, t: int) -> void:
	score_label.text = "CT %d  :  %d T" % [ct, t]


func set_crosshair_gap(gap: float, aiming: bool) -> void:
	crosshair.gap = maxf(2.0, 2.0 + (gap - 4.0) * 0.5)   # co giãn nhẹ khi di chuyển/bắn
	crosshair.dim = 0.35 if aiming else 1.0
	crosshair.hide_cross = aiming
	crosshair.queue_redraw()


## Bật / tắt ống ngắm AWP (viền đen + chữ thập). Tâm ngắm thường do player.gd ẩn bằng set_crosshair_gap(..., true).
func set_scope(on: bool) -> void:
	scope_overlay.visible = on
	if on:
		scope_overlay.queue_redraw()


func hit_marker(head: bool) -> void:
	crosshair.hit_t = 0.25
	crosshair.hit_head = head


func damage_indicator(strength: float) -> void:
	_flash_a = clampf(0.25 + strength * 0.5, 0.0, 0.7)


func show_center(text: String, seconds: float) -> void:
	center_label.text = text
	_center_t = seconds


func show_info(text: String, seconds: float) -> void:
	info_label.text = text
	_info_t = seconds


func add_kill(killer: String, victim: String, headshot: bool, killer_team: int) -> void:
	if not kill_feed_on:
		return
	var l := _label("%s  >  %s%s" % [killer, victim, "  [HS]" if headshot else ""], 18, Color(0.4, 0.7, 1.0) if killer_team == 0 else Color(1.0, 0.75, 0.35))
	l.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	kill_box.add_child(l)
	_kill_items.append({"node": l, "t": 5.0})
	while _kill_items.size() > 6:
		var it: Dictionary = _kill_items.pop_front()
		(it["node"] as Node).queue_free()


func set_scoreboard(visible_now: bool, text: String) -> void:
	scoreboard.visible = visible_now
	if visible_now:
		score_text.text = text


func set_debug(text: String) -> void:
	debug_label.visible = text != ""
	debug_label.text = text


func set_paused(p: bool) -> void:
	pause_panel.visible = p


func _process(delta: float) -> void:
	if bar.kill_t > 0.0:
		bar.kill_t -= delta
		bar.queue_redraw()
	if crosshair.hit_t > 0.0:
		crosshair.hit_t -= delta
		crosshair.queue_redraw()
	_flash_a = maxf(_flash_a - delta * 1.6, 0.0)
	damage_flash.color.a = _flash_a
	if _center_t > 0.0:
		_center_t -= delta
		if _center_t <= 0.0:
			center_label.text = ""
	if _info_t > 0.0:
		_info_t -= delta
		if _info_t <= 0.0:
			info_label.text = ""
	for i in range(_kill_items.size() - 1, -1, -1):
		var it: Dictionary = _kill_items[i]
		it["t"] = float(it["t"]) - delta
		if float(it["t"]) <= 0.0:
			(it["node"] as Node).queue_free()
			_kill_items.remove_at(i)
	_fps_t -= delta
	if _fps_t <= 0.0:
		_fps_t = 0.25
		fps_label.text = "%d FPS" % Engine.get_frames_per_second()
