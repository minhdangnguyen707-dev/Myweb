class_name Player
extends CharacterBody3D
## Người chơi góc nhìn thứ nhất: di chuyển kiểu CS, súng Glock 17 (bắn bán tự động),
## độ lệch đạn thay đổi theo chuyển động, ADS, reload, inspect.

const D2R := 0.0174533
const CorpseScript := preload("res://scripts/corpse.gd")
const DEATH_CAM_TIME := 0.9    # thời gian camera lùi ra góc thứ 3
const DEATH_CAM_DIST := 2.7    # khoảng cách camera tới xác (mét)

const WALK_SPEED := 3.3
const RUN_SPEED := 6.0
const CROUCH_SPEED := 2.2
const GRAVITY := 22.0
const JUMP_VEL := 7.4
const ACCEL := 45.0
const AIR_ACCEL := 9.0
const FRICTION := 38.0
const STAND_H := 1.8
const CROUCH_H := 1.35
const EYE_STAND := 1.62
const EYE_CROUCH := 1.2

const WEAPONS := {
	"glock": {
		"name": "GLOCK 17", "mag": 17, "reserve": 85, "interval": 0.12, "auto": false, "slot": "pistol",
		"damage": 28.0, "falloff": 0.93, "base_spread": 0.15, "inacc_add": 0.6, "inacc_max": 2.5,
		"recoil": 0.40, "sound": "shot", "move": 1.0, "muzzle": Vector3(0.13, -0.12, -0.5),
	},
	"deagle": {
		# DESERT EAGLE kiểu CS2: 7 viên / dự trữ 35, nhát rất mạnh (63 sát thương, bắn đầu = 252), mỗi phát cách nhau 0.33 s (nặng, phải chờ), giá $700.
		# Mỗi phát giật CAMERA lên cao (~6.5° + một cú nảy của súng), bắn liên tiếp là hất thẳng lên trời, tâm ngắm hạ về RẤT chậm (rec_base/rec_mul).
		# Bảng "cs" của súng lục (có "semi"): độ tỏa đạn = đứng yên (stand) -> chạy (move_full) theo tốc độ, trên không = air,
		# cộng thêm độ lệch tích luỹ do bắn liền nhau (mỗi phát + fire_add, tối đa fire_cap, tự hồi fire_decay mỗi giây). Sau reset_time giây không bắn thì tính lại từ phát đầu.
		# Giật camera: bảng kick_* giống M4A1/AK-47 (xem chú thích ở M4A1). snap = cú nảy lò xo thêm mỗi phát (càng lớn càng "đá").
		"name": "DESERT EAGLE", "mag": 7, "reserve": 35, "interval": 0.33, "auto": false, "slot": "pistol",
		"damage": 63.0, "falloff": 0.81, "base_spread": 0.0, "inacc_add": 0.0, "inacc_max": 0.0,
		"recoil": 0.0, "sound": "shot_deagle", "move": 0.96, "muzzle": Vector3(0.13, -0.12, -0.62),
		"cs": {
			"semi": true, "snap": 1.2, "rec_base": 6.0, "rec_mul": 0.6,
			"stand": 0.0035, "move_min": 1.9, "move_speed": 5.2, "move_full": 0.17, "air": 0.30,
			"fire_add": 0.07, "fire_cap": 0.14, "fire_decay": 0.10, "reset_time": 0.55,
			"crouch_spread": 0.70, "ads_spread": 0.65, "ads_kick": 0.85,
			"kick_stand": [6.5, 0.9, 0.9, 0.05, 28.0, 3.5, 3],
			"kick_duck": [6.0, 0.8, 0.8, 0.04, 26.0, 3.0, 3],
			"kick_move": [7.5, 1.3, 1.0, 0.10, 30.0, 5.0, 3],
			"kick_air": [8.5, 1.8, 1.1, 0.15, 32.0, 6.0, 3],
		},
	},
	"knife": {
		"name": "BUTTERFLY", "mag": 0, "reserve": 0, "interval": 0.55, "auto": false, "melee": true,
		"damage": 40.0, "falloff": 1.0, "base_spread": 0.0, "inacc_add": 0.0, "inacc_max": 0.0,
		"recoil": 0.0, "sound": "knife_swing", "move": 1.18, "muzzle": Vector3.ZERO,
	},
	"c4": {
		"name": "C4", "mag": 0, "reserve": 0, "interval": 0.5, "auto": false, "melee": true,
		"damage": 0.0, "falloff": 1.0, "base_spread": 0.0, "inacc_add": 0.0, "inacc_max": 0.0,
		"recoil": 0.0, "sound": "", "move": 1.1, "muzzle": Vector3.ZERO,
	},
	"m4a1": {
		"name": "M4A1", "mag": 30, "reserve": 90, "interval": 0.0875, "auto": true,
		"damage": 33.0, "falloff": 0.97, "base_spread": 0.10, "inacc_add": 0.32, "inacc_max": 3.2,
		"recoil": 0.34, "sound": "shot_m4", "move": 0.92, "muzzle": Vector3(0.12, -0.12, -0.85),
		# Giật + tỏa đạn kiểu Counter-Strike 1.6 (chỉ M4A1 có bảng "cs"; các súng khác giữ cách cũ).
		# Độ chính xác: acc = n^3 / acc_div + acc_base (n = số phát bắn liên tiếp, thả chuột là về 0), tối đa acc_max.
		# Tỏa đạn (tan góc): đứng yên = stand * acc | đang chạy (> move_speed m/s) = move_base + move_acc * acc | trên không = air_base + air_acc * acc.
		# Giật camera (độ): [lên_đầu, ngang_đầu, lên_mỗi_phát, ngang_mỗi_phát, lên_tối_đa, ngang_tối_đa, cứ ~N phát đổi hướng ngang].
		"cs": {
			"acc_div": 220.0, "acc_base": 0.30, "acc_max": 1.0,
			"stand": 0.020, "move_base": 0.070, "move_acc": 0.120, "air_base": 0.080, "air_acc": 0.40,
			"move_speed": 4.5, "crouch_spread": 0.80, "ads_spread": 0.60, "ads_kick": 0.80,
			"kick_stand": [0.65, 0.35, 0.25, 0.015, 3.5, 2.25, 7],
			"kick_duck": [0.60, 0.30, 0.20, 0.0125, 3.25, 2.0, 7],
			"kick_move": [1.00, 0.45, 0.28, 0.045, 3.75, 3.0, 7],
			"kick_air": [1.20, 0.50, 0.23, 0.15, 5.5, 3.5, 6],
		},
	},
	"ak47": {
		# AK-47 kiểu CS2 / CS:GO (người dùng yêu cầu chỉ số y như CS): 30 viên / dự trữ 90, bắn tự động 600 phát/phút (cách nhau 0.1 s), giá $2700, thưởng hạ gục $300.
		# Sát thương 36 (thân), đầu x4 = 144 (chết 1 phát khi không giáp), chân x0.75 = 27; hao dần theo khoảng cách 0.98 mỗi 12.7 m (500 đơn vị CS) như "range modifier" của CS2.
		# Tốc độ chạy 215 / 250 = 0.86 so với dao. Nạp đạn 2.43 s. Game chưa có giáp nên không dùng "xuyên giáp 77.5%" của CS2.
		"name": "AK-47", "mag": 30, "reserve": 90, "interval": 0.1, "auto": true, "slot": "primary",
		"damage": 36.0, "falloff": 0.98, "base_spread": 0.14, "inacc_add": 0.45, "inacc_max": 4.2,
		"recoil": 0.40, "sound": "shot_ak", "move": 0.86, "muzzle": Vector3(0.12, -0.12, -0.85),
		# Giật + tỏa đạn kiểu CS 1.6 cho AK-47 (cách đọc bảng: xem chú thích ở M4A1). AK giật mạnh và lệch hơn M4A1, đổi lại sát thương cao.
		"cs": {
			"acc_div": 200.0, "acc_base": 0.35, "acc_max": 1.25,
			"stand": 0.0275, "move_base": 0.080, "move_acc": 0.130, "air_base": 0.090, "air_acc": 0.40,
			"move_speed": 4.5, "crouch_spread": 0.80, "ads_spread": 0.60, "ads_kick": 0.80,
			"kick_stand": [1.0, 0.375, 0.175, 0.0375, 4.0, 1.25, 8],
			"kick_duck": [0.9, 0.35, 0.15, 0.025, 5.5, 1.5, 9],
			"kick_move": [1.5, 0.45, 0.225, 0.05, 6.5, 2.5, 7],
			"kick_air": [2.0, 1.0, 0.5, 0.35, 9.0, 6.0, 5],
		},
	},
	"awp": {
		# AWP kiểu CS:GO / CS2 (người dùng yêu cầu): 5 viên / dự trữ 30, 115 sát thương (thân = chết 1 phát, đầu = chết chắc, chân 86), giá $4750.
		# Bolt-action: mỗi phát cách nhau 1.45 s. Chuột PHẢI = ngắm: zoom 1 (~2.7x) -> bấm nữa zoom 2 (~11x) -> bấm nữa tắt ngắm. Bắn xong tự thoát ngắm (phải bấm ngắm lại).
		# Tỏa đạn (tan góc, bảng "cs" có "sniper"): đang ngắm + đứng yên = gần như tuyệt đối chính xác; đang ngắm mà đi/chạy = lệch rất lớn;
		# bắn khi KHÔNG ngắm = lệch rộng (cố ý, như CS); nhảy = lệch cực lớn. Đang ngắm đi chậm một nửa (scope.move_mul). "no_chamber": nạp đạn không +1 viên trong nòng.
		# scope.zoom = hệ số tan(FOV/2) so với FOV gốc (CS: FOV 40 và 10 trên nền 90) -> số càng nhỏ càng zoom.
		"name": "AWP", "mag": 5, "reserve": 30, "interval": 1.45, "auto": false, "slot": "primary", "no_chamber": true, "range": 250.0,
		"damage": 115.0, "falloff": 0.99, "base_spread": 0.0, "inacc_add": 0.0, "inacc_max": 0.0,
		"recoil": 0.0, "sound": "shot_awp", "move": 0.80, "muzzle": Vector3(0.13, -0.12, -0.9),
		"scope": {"zoom": [0.364, 0.0875], "move_mul": 0.5},
		"cs": {
			"sniper": true, "snap": 0.9, "rec_base": 5.0, "rec_mul": 0.6,
			"scoped_stand": 0.0003, "scoped_move": 0.07, "unscoped_stand": 0.075, "unscoped_move": 0.12,
			"move_min": 0.8, "move_speed": 3.0, "air": 0.25, "crouch_spread": 1.0,
			"kick_stand": [2.2, 0.3, 0.0, 0.0, 4.0, 1.0, 1],
			"kick_duck": [2.0, 0.3, 0.0, 0.0, 4.0, 1.0, 1],
			"kick_move": [2.6, 0.5, 0.0, 0.0, 5.0, 1.5, 1],
			"kick_air": [3.2, 0.8, 0.0, 0.0, 6.0, 2.0, 1],
		},
	},
	"mp5": {
		# MP5-SD kiểu CS2 / CS:GO (người dùng yêu cầu chỉ số y như CS): 30 viên / dự trữ 120, bắn tự động 750 phát/phút (cách nhau 0.08 s), giá $1400, thưởng hạ gục $600.
		# Sát thương 28 (thân), đầu x4 = 112 (chết 1 phát khi không giáp), chân x0.75 = 21; hao dần theo khoảng cách 0.87 mỗi 12.7 m (500 đơn vị CS) như "range modifier" của CS2.
		# Tốc độ chạy 235 / 250 = 0.94 so với dao. Nạp đạn 2.97 s. Có ống giảm thanh: tiếng súng chỉ vang ~20 m (bot nghe ít hơn các súng khác, xem "noise").
		# Giật + tỏa đạn: cách đọc bảng "cs" xem chú thích ở M4A1. SMG nên tỏa rộng hơn súng trường một chút và giật nhẹ hơn (độ chính xác tốt nhất ~15 m).
		# Game chưa có giáp nên không dùng "xuyên giáp 62.5%" của CS2. Không có ngắm (ADS) như mọi súng khác (trừ AWP).
		"name": "MP5-SD", "mag": 30, "reserve": 120, "interval": 0.08, "auto": true, "slot": "primary", "noise": 20.0,
		"damage": 28.0, "falloff": 0.87, "base_spread": 0.12, "inacc_add": 0.30, "inacc_max": 3.0,
		"recoil": 0.28, "sound": "shot_mp5", "move": 0.94, "muzzle": Vector3(0.12, -0.12, -0.80),
		"cs": {
			"acc_div": 200.0, "acc_base": 0.30, "acc_max": 1.10,
			"stand": 0.022, "move_base": 0.075, "move_acc": 0.120, "air_base": 0.085, "air_acc": 0.40,
			"move_speed": 4.5, "crouch_spread": 0.80, "ads_spread": 0.60, "ads_kick": 0.80,
			"kick_stand": [0.55, 0.30, 0.22, 0.012, 3.2, 2.0, 8],
			"kick_duck": [0.50, 0.25, 0.18, 0.010, 3.0, 1.8, 8],
			"kick_move": [0.85, 0.40, 0.25, 0.040, 3.5, 2.8, 7],
			"kick_air": [1.10, 0.50, 0.22, 0.120, 5.0, 3.2, 6],
		},
	},
}
# Loại vũ khí: mỗi loại chỉ cầm được MỘT khẩu (1 súng chính + 1 súng lục + 1 dao). Mua / nhặt khẩu cùng loại thì khẩu cũ rơi xuống đất.
const SLOT_OF := {"m4a1": "primary", "ak47": "primary", "awp": "primary", "mp5": "primary", "glock": "pistol", "deagle": "pistol", "knife": "melee", "c4": "bomb"}
const HEAD_MULT := 4.0
const LEG_MULT := 0.75
const SHOT_RANGE := 120.0


var sensitivity := 0.12   # độ trên mỗi pixel
var fov_base := 80.0

var team := 0
var display_name := "YOU"
var hp := 100
var alive := true
var kills := 0
var deaths := 0
var main = null
var hud: Hud = null

var yaw := 0.0
var pitch := 0.0
var head: Node3D
var camera: Camera3D
var col_shape: CollisionShape3D
var capsule: CapsuleShape3D
var vm   # viewmodel của súng đang cầm (Viewmodel hoặc Rifle)
var viewmodels := {}
var left_hand := false   # cầm súng tay trái: lật gương cả mô hình súng + tay góc nhìn thứ nhất (cài đặt trong main)
var owned := {"glock": true, "deagle": false, "m4a1": false, "ak47": false, "awp": false, "mp5": false, "knife": true, "c4": false}
var w_mag := {"glock": 17, "deagle": 7, "m4a1": 30, "ak47": 30, "awp": 5, "mp5": 30, "knife": 0, "c4": 0}
var w_res := {"glock": 85, "deagle": 35, "m4a1": 90, "ak47": 90, "awp": 30, "mp5": 120, "knife": 0, "c4": 0}
var cur_w := "glock"
var last_w := "knife"
var W: Dictionary = WEAPONS["glock"]

var crouching := false
var eye_y := EYE_STAND
var land_dip := 0.0
var was_on_floor := true
var step_dist := 0.0
var fire_cd := 0.0
var fire_queue := 0.0
var switching := false             # đang chạy animation cất súng trước khi đổi sang súng khác (chỉ Desert Eagle có)
var inaccuracy := 0.0
var since_shot := 10.0
var mag := 17
var reserve := 85
var reloading := false
var scope_level := 0              # AWP: 0 = không ngắm, 1 = zoom 1, 2 = zoom 2 (chuột phải)
var zoom_k := 1.0                 # tan(FOV/2) hiện tại so với FOV gốc (1 = không zoom), chạy mượt về zoom_target
var zoom_target := 1.0
var punch := Vector2.ZERO
var punch_v := Vector2.ZERO
var shots_fired := 0              # số phát bắn liên tiếp (kiểu CS: thả chuột là về 0; súng lục bán tự động: im tay đủ lâu mới về 0)
var pistol_inacc := 0.0           # độ lệch tích luỹ của súng lục kiểu CS (Desert Eagle): bắn nhanh liên tục thì tăng, nghỉ tay thì hồi
var cs_punch := Vector2.ZERO      # giật camera kiểu CS (độ): x = ngóc lên, y = lệch trái
var cs_dir := true                # hướng lệch ngang hiện tại của giật CS
var roll := 0.0
var lean := 0.0
var cur_spread := 0.0
var render_cam: Camera3D = null        # camera thật sự vẽ 3D (main tạo), bám theo camera này
var interp_off := Vector3.ZERO
var corpse: Node3D = null              # thân người hiện ra khi chết
var death_t := 0.0
var prev_pos := Vector3.ZERO           # nội suy vị trí giữa 2 nhịp vật lý -> camera mượt dù FPS không đúng 60
var curr_pos := Vector3.ZERO
var death_cam_from := Transform3D.IDENTITY
var death_az := 0.0                    # góc quay quanh xác (radian)


func _ready() -> void:
	add_to_group("combatants")
	collision_layer = 2
	collision_mask = 1 | 4
	floor_snap_length = 0.4
	floor_max_angle = deg_to_rad(46.0)

	capsule = CapsuleShape3D.new()
	capsule.radius = 0.35
	capsule.height = STAND_H
	col_shape = CollisionShape3D.new()
	col_shape.shape = capsule
	col_shape.position.y = STAND_H * 0.5
	add_child(col_shape)

	head = Node3D.new()
	head.position.y = EYE_STAND
	add_child(head)
	camera = Camera3D.new()
	camera.fov = fov_base
	camera.near = 0.03
	camera.far = 90.0
	head.add_child(camera)
	# camera này chỉ để tính hướng nhìn; hình 3D do camera trong SubViewport của main vẽ (xem render_cam)
	camera.clear_current(false)

	_build_viewmodel()
	set_left_hand(bool(main.left_hand) if main != null else false)


## Bật / tắt cầm súng tay trái. Lật gương (scale.x = -1) từng mô hình súng đang gắn vào camera:
## súng + bàn tay phải thành súng + bàn tay trái, đạn / vỏ đạn / băng đạn rơi cũng lật theo vì là con của mô hình.
func set_left_hand(v: bool) -> void:
	left_hand = v
	for id in viewmodels:
		(viewmodels[id] as Node3D).scale = Vector3(-1.0 if v else 1.0, 1.0, 1.0)


func _build_viewmodel() -> void:
	viewmodels["glock"] = Viewmodel.new()
	viewmodels["deagle"] = preload("res://scripts/deagle.gd").new()
	viewmodels["m4a1"] = preload("res://scripts/rifle.gd").new()
	viewmodels["ak47"] = preload("res://scripts/ak47.gd").new()
	viewmodels["awp"] = preload("res://scripts/awp.gd").new()   # model + tay + animation lấy thẳng từ v_awp.mdl
	viewmodels["mp5"] = preload("res://scripts/mp5.gd").new()   # model + tay + animation + âm thanh lấy thẳng từ v_mp5.mdl
	viewmodels["knife"] = preload("res://scripts/knife.gd").new()
	viewmodels["c4"] = preload("res://scripts/c4.gd").new()
	for id in viewmodels:
		var v = viewmodels[id]
		camera.add_child(v)
		v.sound.connect(_on_vm_sound)
		v.reload_inserted.connect(_on_reload_inserted)
		v.action_finished.connect(_on_action_finished)
		if v.has_signal("melee_hit"):
			v.melee_hit.connect(_on_melee_hit)
		if id != "glock":
			v.visible = false
			v.set_process(false)
	vm = viewmodels["glock"]


# =====================================================================
#  ÂM THANH (đã xoá hết, chỉ còn hàm rỗng)
# =====================================================================
func play(_sound_name: String = "", _vol_db: float = 0.0, _pitch: float = 1.0) -> void:
	pass   # đã xoá toàn bộ âm thanh trong game (giữ hàm rỗng để các chỗ gọi cũ không lỗi)


func _on_vm_sound(sound_name: String) -> void:
	play(sound_name, -3.0)


# =====================================================================
#  INPUT
# =====================================================================
func _unhandled_input(event: InputEvent) -> void:
	if not alive:
		return
	if event is InputEventKey and (event as InputEventKey).pressed and not (event as InputEventKey).echo:
		if event.is_action_pressed("slot1"):
			if primary_id() != "":
				request_switch(primary_id())   # phím 1 = súng chính đang cầm (M4A1 / AK-47)
		elif event.is_action_pressed("drop"):
			drop_current()   # G: vứt món đang cầm (không vứt được dao)
		elif event.is_action_pressed("slot2"):
			request_switch(pistol_id())   # phím 2 = súng lục đang có (Glock hoặc Desert Eagle, như CS2)
		elif event.is_action_pressed("slot3"):
			request_switch("knife")
		elif event.is_action_pressed("slot5"):
			request_switch("ak47")
		elif event.is_action_pressed("slot6"):
			request_switch("c4")   # cầm bom (chỉ khi đang mang bom)
		elif event.is_action_pressed("last_weapon"):
			request_switch(last_w)
	elif event is InputEventMouseButton and (event as InputEventMouseButton).pressed:
		var bi := (event as InputEventMouseButton).button_index
		if bi == MOUSE_BUTTON_WHEEL_UP:
			cycle_weapon(-1)
		elif bi == MOUSE_BUTTON_WHEEL_DOWN:
			cycle_weapon(1)
	if event is InputEventMouseMotion and Input.mouse_mode == Input.MOUSE_MODE_CAPTURED:
		var mm := event as InputEventMouseMotion
		var s := sensitivity * D2R * zoom_k   # đang zoom thì chuột chậm lại theo tỉ lệ (như CS: tâm quét cùng tốc độ trên màn hình)
		var rel := mm.screen_relative * 0.75   # không đổi độ nhạy khi độ phân giải 3D thay đổi
		yaw -= rel.x * s
		pitch = clampf(pitch - rel.y * s, -1.5, 1.5)
		rotation.y = yaw
		head.rotation.x = pitch
		vm.mouse_delta += (Vector2(-rel.x, rel.y) if left_hand else rel)   # tay trái: súng đã lật gương nên đảo chiều lắc theo chuột


## Xoay camera bằng ngón tay (điện thoại): touch_controls.gd gọi hàm này, giống nhánh InputEventMouseMotion ở trên nhưng không cần khóa chuột.
func touch_look(rel: Vector2) -> void:
	if not alive:
		return
	var s := sensitivity * D2R * zoom_k
	yaw -= rel.x * s
	pitch = clampf(pitch - rel.y * s, -1.5, 1.5)
	rotation.y = yaw
	head.rotation.x = pitch
	vm.mouse_delta += (Vector2(-rel.x, rel.y) if left_hand else rel)


# =====================================================================
#  VẬT LÝ / DI CHUYỂN
# =====================================================================
func _physics_process(delta: float) -> void:
	prev_pos = global_position
	_player_physics(delta)
	curr_pos = global_position


func _player_physics(delta: float) -> void:
	if alive and main != null and (main.round_frozen or main.player_locked):
		# chế độ ĐẶT BOM: đang chuẩn bị round, hoặc đang giữ E đặt/gỡ bom -> đứng yên (vẫn xoay nhìn được)
		velocity.x = move_toward(velocity.x, 0.0, 30.0 * delta)
		velocity.z = move_toward(velocity.z, 0.0, 30.0 * delta)
		if not is_on_floor():
			velocity.y -= GRAVITY * delta
		move_and_slide()
	elif alive:
		_move(delta)
		_combat(delta)
	else:
		velocity.x = move_toward(velocity.x, 0.0, 20.0 * delta)
		velocity.z = move_toward(velocity.z, 0.0, 20.0 * delta)
		if not is_on_floor():
			velocity.y -= GRAVITY * delta
		move_and_slide()
	if global_position.y < -30.0 and alive:
		take_damage(999.0, null, false)


func _set_crouch(c: bool) -> void:
	crouching = c
	capsule.height = CROUCH_H if c else STAND_H
	col_shape.position.y = capsule.height * 0.5


func _can_stand() -> bool:
	var space := get_world_3d().direct_space_state
	var q := PhysicsRayQueryParameters3D.create(
		global_position + Vector3(0.0, CROUCH_H - 0.05, 0.0),
		global_position + Vector3(0.0, STAND_H + 0.05, 0.0), 1)
	return space.intersect_ray(q).is_empty()



## Tự bước lên bậc thềm thấp (Godot không có sẵn): nếu bị chặn thì thử nhấc lên, tiến tới, hạ xuống.
const STEP_H := 0.55
const STEP_HEIGHTS := [0.24, 0.42, 0.6]      # thử từ thấp tới cao: bậc nhỏ thì nhấc ít cho khỏi đụng bậc kế
const STEP_FWD := [0.2, 0.3, 0.42, 0.55]    # độ dài bước tới sau khi nhấc (thử từ ngắn tới dài)
var floor_t := 1.0   # thời gian kể từ lần cuối đứng trên sàn (cho phép bước bậc ngay sau khi hụt chân)

func _slide_with_step(delta: float) -> void:
	var was_floor := is_on_floor()
	var start := global_position
	var vb := velocity
	move_and_slide()
	if vb.y > 3.0:
		return
	var hv := Vector3(vb.x, 0.0, vb.z)
	if hv.length() < 0.3:
		return
	var dir := hv.normalized()
	if not (was_floor or is_on_floor() or floor_t < 0.12):
		return
	# bị chặn bởi bức tường / mép bậc thềm đúng hướng đang đi?
	var blocked := false
	for i in get_slide_collision_count():
		var cn := get_slide_collision(i).get_normal()
		if cn.y < 0.3 and (-cn).dot(dir) > 0.2:
			blocked = true
	var moved := Vector3(global_position.x - start.x, 0.0, global_position.z - start.z)
	if (not blocked) and moved.length() > hv.length() * delta * 0.6:
		return
	var from := Transform3D(global_transform.basis, start)
	# thử nhiều độ cao và nhiều độ dài bước tới (bậc thang liên tiếp: bước tới quá xa sẽ đụng bậc kế tiếp)
	for h in STEP_HEIGHTS:
		var hh: float = h
		if test_move(from, Vector3.UP * hh):
			break   # đụng trần: nhấc cao hơn cũng không được
		var up_t := from.translated(Vector3.UP * hh)
		for f in STEP_FWD:
			var ff: float = f
			var fwd: Vector3 = dir * ff
			if test_move(up_t, fwd):
				continue
			var fwd_t := up_t.translated(fwd)
			var col := KinematicCollision3D.new()
			if not test_move(fwd_t, Vector3.DOWN * (hh + 0.08), col):
				continue
			if col.get_normal().y < 0.6:
				continue
			var new_y := start.y + hh + col.get_travel().y
			if new_y - start.y < 0.004:
				continue
			global_position = Vector3(start.x + fwd.x, new_y, start.z + fwd.z)
			velocity.x = vb.x
			velocity.z = vb.z
			velocity.y = 0.0
			floor_t = 0.0
			return


func _move(delta: float) -> void:
	var inp := Input.get_vector("move_left", "move_right", "move_forward", "move_back")
	var wish := transform.basis * Vector3(inp.x, 0.0, inp.y)
	if wish.length() > 1.0:
		wish = wish.normalized()

	var want_crouch := Input.is_action_pressed("crouch")
	if want_crouch and not crouching:
		_set_crouch(true)
	elif (not want_crouch) and crouching and _can_stand():
		_set_crouch(false)

	var walking := Input.is_action_pressed("walk")
	var max_speed := RUN_SPEED
	if crouching:
		max_speed = CROUCH_SPEED
	elif walking:
		max_speed = WALK_SPEED
	max_speed *= float(W["move"])
	if scope_level > 0:
		max_speed *= float((W["scope"] as Dictionary)["move_mul"])   # đang ngắm đi chậm một nửa

	var hv := Vector3(velocity.x, 0.0, velocity.z)
	var prev_speed := hv.length()
	var on_floor := is_on_floor()
	var fall_speed := -velocity.y
	if on_floor:
		if wish.length() > 0.05:
			hv = hv.move_toward(wish * max_speed, ACCEL * delta)
		else:
			hv = hv.move_toward(Vector3.ZERO, FRICTION * delta)
		if velocity.y < 0.0:
			velocity.y = 0.0
		if Input.is_action_pressed("jump"):
			velocity.y = JUMP_VEL
	else:
		velocity.y -= GRAVITY * delta
		if wish.length() > 0.05:
			hv += wish * AIR_ACCEL * delta
			var lim := maxf(prev_speed, RUN_SPEED)
			if hv.length() > lim:
				hv = hv.normalized() * lim
	velocity.x = hv.x
	velocity.z = hv.z
	floor_t = 0.0 if is_on_floor() else floor_t + delta
	_slide_with_step(delta)

	# tiếp đất
	var now_floor := is_on_floor()
	if now_floor and not was_on_floor and fall_speed > 4.5:
		var st := clampf((fall_speed - 4.5) / 9.0, 0.15, 1.0)
		vm.land(st)
		land_dip = -0.07 * st
		play("step", -2.0 + 4.0 * st, 0.85)
		if main:
			main.noise(global_position, 14.0, team)
	was_on_floor = now_floor

	# tiếng bước chân (chạy thường mới có tiếng, đi bộ Ctrl / ngồi thì im lặng)
	var speed := Vector2(velocity.x, velocity.z).length()
	if now_floor and speed > RUN_SPEED * 0.8 and not crouching and not walking:
		step_dist += speed * delta
		if step_dist > 2.5:
			step_dist = 0.0
			play("step", -9.0, randf_range(0.9, 1.1))
			if main:
				main.noise(global_position, 13.0, team)
	elif speed < 0.5:
		step_dist = 0.0


# =====================================================================
#  CHIẾN ĐẤU
# =====================================================================
func _combat(delta: float) -> void:
	fire_cd = maxf(fire_cd - delta, 0.0)
	fire_queue = maxf(fire_queue - delta, 0.0)
	since_shot += delta
	inaccuracy = maxf(inaccuracy - 2.4 * delta, 0.0)
	if switching:
		return
	if W.has("cs") and (W["cs"] as Dictionary).has("semi"):
		pistol_inacc = maxf(pistol_inacc - float((W["cs"] as Dictionary)["fire_decay"]) * delta, 0.0)
		if since_shot > float((W["cs"] as Dictionary)["reset_time"]):
			shots_fired = 0   # nghỉ tay đủ lâu: phát kế tiếp lại là "phát đầu" (chính xác, giật như mới)
	if cur_w == "c4":
		return
	var is_melee := bool(W.get("melee", false))

	if is_melee:
		# dao: chuột trái = chém, chuột phải = đâm (mạnh hơn, chậm hơn), F = múa dao
		if fire_cd <= 0.0 and vm.current_mode() != Viewmodel.Mode.DRAW:
			if Input.is_action_pressed("fire"):
				_melee_attack("slash")
			elif Input.is_action_pressed("aim"):
				_melee_attack("stab")
		if Input.is_action_just_pressed("inspect") and not vm.is_busy():
			vm.play_inspect()
		return

	if W.has("scope"):
		_scope_input()

	if W.has("cs") and not (W["cs"] as Dictionary).has("semi") and not Input.is_action_pressed("fire"):
		shots_fired = 0   # kiểu CS: thả chuột là độ chính xác và độ giật tích luỹ về lại từ đầu

	if Input.is_action_just_pressed("fire"):
		fire_queue = 0.15
	elif bool(W["auto"]) and Input.is_action_pressed("fire") and mag > 0:
		fire_queue = maxf(fire_queue, 0.05)
	if fire_queue > 0.0 and fire_cd <= 0.0:
		if _try_fire():
			fire_queue = 0.0
	if Input.is_action_just_pressed("reload"):
		start_reload()
	if Input.is_action_just_pressed("inspect"):
		if (not vm.is_busy()) and mag > 0 and scope_level == 0:
			vm.play_inspect()


func _try_fire() -> bool:
	var m: int = vm.current_mode()
	if m == Viewmodel.Mode.RELOAD or m == Viewmodel.Mode.DRAW:
		return false
	if m == Viewmodel.Mode.INSPECT:
		vm.cancel()
	if mag <= 0:
		fire_cd = 0.25
		vm.dry_fire()
		play("dry", -4.0)
		if reserve > 0:
			start_reload()
		return true
	_shoot()
	return true


## Độ tỏa đạn kiểu CS (đơn vị: tan góc, như biến flSpread của CS 1.6). shots = số phát bắn liên tiếp tính cả phát này.
func _cs_spread(shots: int) -> float:
	var cs: Dictionary = W["cs"]
	if cs.has("sniper"):
		return _cs_spread_sniper(cs)
	if cs.has("semi"):
		return _cs_spread_pistol(cs)
	var speed := Vector2(velocity.x, velocity.z).length()
	var acc := minf(float(shots * shots * shots) / float(cs["acc_div"]) + float(cs["acc_base"]), float(cs["acc_max"]))
	var s := 0.0
	if not is_on_floor():
		s = float(cs["air_base"]) + float(cs["air_acc"]) * acc
	else:
		# càng đi nhanh càng tỏa: đứng yên = chụm, đi bộ = tỏa vừa, chạy (move_speed trở lên) = tỏa rất rộng
		var t := clampf((speed - 0.4) / (float(cs["move_speed"]) - 0.4), 0.0, 1.0)
		var still := float(cs["stand"]) * acc
		s = lerpf(still, float(cs["move_base"]) + float(cs["move_acc"]) * acc, t)
	if crouching:
		s *= float(cs["crouch_spread"])
	return s


## Độ tỏa đạn súng lục bán tự động kiểu CS2 (Desert Eagle): đứng yên và bắn chậm = chính xác tuyệt đối,
## đi/chạy hoặc nhảy = tỏa rất rộng, bắn liên tiếp nhanh = lệch dần (tích luỹ rồi tự hồi lại khi nghỉ tay).
func _cs_spread_pistol(cs: Dictionary) -> float:
	var speed := Vector2(velocity.x, velocity.z).length()
	var s := 0.0
	if not is_on_floor():
		s = float(cs["air"])
	else:
		var t := clampf((speed - float(cs["move_min"])) / (float(cs["move_speed"]) - float(cs["move_min"])), 0.0, 1.0)
		s = lerpf(float(cs["stand"]), float(cs["move_full"]), t)
	s += pistol_inacc
	if crouching:
		s *= float(cs["crouch_spread"])
	return s


## Độ tỏa đạn AWP kiểu CS:GO: ngắm + đứng yên = gần như tuyệt đối chính xác; ngắm mà đang đi = lệch rất lớn (phải dừng lại mới bắn trúng);
## không ngắm = lệch rộng; trên không = lệch cực lớn.
func _cs_spread_sniper(cs: Dictionary) -> float:
	if not is_on_floor():
		return float(cs["air"])
	var speed := Vector2(velocity.x, velocity.z).length()
	var t := clampf((speed - float(cs["move_min"])) / (float(cs["move_speed"]) - float(cs["move_min"])), 0.0, 1.0)
	if scope_level > 0:
		return lerpf(float(cs["scoped_stand"]), float(cs["scoped_move"]), t)
	return lerpf(float(cs["unscoped_stand"]), float(cs["unscoped_move"]), t)


## Chuột phải với súng có ống ngắm: tắt -> zoom 1 -> zoom 2 -> tắt. Không ngắm được khi đang rút súng / nạp đạn; nạp đạn / đổi súng thì tự thoát ngắm.
func _scope_input() -> void:
	var m: int = vm.current_mode()
	var busy := reloading or m == Viewmodel.Mode.RELOAD or m == Viewmodel.Mode.DRAW
	if scope_level > 0 and busy:
		_set_scope(0)
		return
	if Input.is_action_just_pressed("aim") and not busy:
		if m == Viewmodel.Mode.INSPECT:
			vm.cancel()
		var levels: int = ((W["scope"] as Dictionary)["zoom"] as Array).size()
		_set_scope((scope_level + 1) % (levels + 1))


func _set_scope(lv: int) -> void:
	if lv == scope_level:
		return
	scope_level = lv
	var scoped := lv > 0
	zoom_target = 1.0
	if scoped and W.has("scope"):
		zoom_target = float((((W["scope"] as Dictionary)["zoom"]) as Array)[lv - 1])
	vm.visible = not scoped   # CS: đang ngắm thì không thấy súng + tay, chỉ thấy ống ngắm
	if hud:
		hud.set_scope(scoped)


func _zoomed_fov() -> float:
	return rad_to_deg(2.0 * atan(tan(deg_to_rad(fov_base) * 0.5) * zoom_k))


## AWP nạp đạn không có viên trong nòng (các súng khác nạp thêm +1).
func _chamber() -> int:
	return 0 if bool(W.get("no_chamber", false)) else 1


## Giật camera kiểu CS: mỗi phát đẩy góc nhìn lên (tăng theo số phát liên tiếp, có trần) và lệch ngang trái/phải ngẫu nhiên.
func _cs_kick() -> void:
	var cs: Dictionary = W["cs"]
	var speed := Vector2(velocity.x, velocity.z).length()
	var kb: Array = cs["kick_stand"]
	if not is_on_floor():
		kb = cs["kick_air"]
	elif speed > 1.5:
		kb = cs["kick_move"]
	elif crouching:
		kb = cs["kick_duck"]
	var n := shots_fired
	var up := float(kb[0])
	var lat := float(kb[1])
	if n > 1:
		up = float(n) * float(kb[2]) + float(kb[0])
		lat = float(n) * float(kb[3]) + float(kb[1])
	var k := 1.0
	cs_punch.x = minf(cs_punch.x + up * k, float(kb[4]))
	if cs_dir:
		cs_punch.y = minf(cs_punch.y + lat * k, float(kb[5]))
	else:
		cs_punch.y = maxf(cs_punch.y - lat * k, -float(kb[5]))
	if randi() % (int(kb[6]) + 1) == 0:
		cs_dir = not cs_dir
	if cs.has("snap"):
		punch_v += Vector2(float(cs["snap"]), randf_range(-0.15, 0.15)) * k   # cú nảy của súng: hất lên rồi dội về


func current_spread_deg() -> float:
	if W.has("cs"):
		# phát kế tiếp sẽ là phát thứ shots_fired + 1 -> tâm ngắm nở ra theo độ tỏa đạn thật
		return rad_to_deg(atan(_cs_spread(shots_fired + 1)))
	var speed := Vector2(velocity.x, velocity.z).length()
	# đi/chạy là tỏa đạn mạnh (kiểu CS/Valorant): đứng yên mới chụm
	var sf := clampf((speed - 0.4) / (RUN_SPEED * 0.75 - 0.4), 0.0, 1.0)
	var s := float(W["base_spread"]) + inaccuracy + sf * 5.5
	if not is_on_floor():
		s += 6.0
	if crouching:
		s *= 0.75
	return s


func _shoot() -> void:
	mag -= 1
	fire_cd = float(W["interval"])
	since_shot = 0.0
	# hướng bắn có độ lệch
	var cb := camera.global_transform.basis
	var dir := Vector3.ZERO
	if W.has("cs"):
		# tỏa đạn kiểu CS: lệch ngang/dọc độc lập, dồn nhiều về giữa (tổng hai số ngẫu nhiên)
		shots_fired += 1
		var sp := _cs_spread(shots_fired)
		var ox := (randf() + randf() - 1.0) * sp
		var oy := (randf() + randf() - 1.0) * sp
		dir = (-cb.z + cb.x * ox + cb.y * oy).normalized()
		if (W["cs"] as Dictionary).has("semi"):
			pistol_inacc = minf(pistol_inacc + float((W["cs"] as Dictionary)["fire_add"]), float((W["cs"] as Dictionary)["fire_cap"]))
	else:
		var spread := current_spread_deg()
		inaccuracy = minf(inaccuracy + float(W["inacc_add"]), float(W["inacc_max"]))
		var ang := randf() * TAU
		var rr := sqrt(randf()) * spread * D2R
		dir = (-cb.z + cb.x * cos(ang) * tan(rr) + cb.y * sin(ang) * tan(rr)).normalized()
	var rng := float(W.get("range", SHOT_RANGE))
	var from := camera.global_position
	var to := from + dir * rng

	var muzzle := camera.global_transform * (W["muzzle"] as Vector3)
	if vm.has_method("muzzle_global"):
		muzzle = vm.muzzle_global()
	var hit_pos := to
	if main:
		var hit: Dictionary = main.trace_shot(from, dir, rng, self)
		hit_pos = hit["pos"]
		if hit["kind"] == "combatant":
			var victim = hit["node"]
			if int(victim.team) != team:
				var hs := 1.0
				if "hit_height" in victim:
					hs = float(victim.hit_height) / 1.85   # kẻ địch nhỏ (chó) thì vùng đầu/chân thu nhỏ theo
				var rel_y: float = (hit_pos.y - float(victim.global_position.y)) / hs
				var mult := 1.0
				var is_head := false
				if rel_y > 1.5:
					mult = HEAD_MULT
					is_head = true
				elif rel_y < 0.7:
					mult = LEG_MULT
				var dist := from.distance_to(hit_pos)
				var dmg := float(W["damage"]) * mult * pow(float(W["falloff"]), dist / 12.7)
				victim.take_damage(dmg, self, is_head)
				if hud:
					hud.hit_marker(is_head)
				play("headshot" if is_head else "hit", -5.0)
				main.spawn_blood(hit_pos, hit["normal"])
		elif hit["kind"] == "world":
			main.spawn_impact(hit_pos, hit["normal"])
		main.spawn_tracer(muzzle, hit_pos)
		main.noise(global_position, float(W.get("noise", 42.0)), team)

	if scope_level > 0:
		_set_scope(0)   # CS:GO: bắn xong là thoát ngắm, muốn ngắm tiếp phải bấm chuột phải lại
	vm.fire(mag == 0)
	play(str(W["sound"]), -1.0, randf_range(0.96, 1.04))
	if W.has("cs"):
		_cs_kick()
	else:
		var k := 1.0
		punch_v += Vector2(float(W["recoil"]) * k, randf_range(-0.12, 0.12) * k)
	_update_hud()


func _melee_attack(kind: String) -> void:
	fire_cd = 1.0 if kind == "stab" else float(W["interval"])
	vm.play_attack(kind)
	if main:
		main.noise(global_position, 9.0, team)


## Dao hỏi trước khi đâm mạnh (chuột phải): có địch đang QUAY LƯNG trong tầm đâm không? Có thì dao chạy animation đâm sau lưng (backstab) thay vì đâm thường.
## Dùng đúng cách tìm mục tiêu và điều kiện quay lưng của _on_melee_hit (tầm 2.0 m, ba tia lệch 0.14 rad).
func melee_backstab_ready() -> bool:
	if not alive or main == null:
		return false
	var from := camera.global_position
	var fwd := -camera.global_transform.basis.z
	for off in [0.0, 0.14, -0.14]:
		var dir: Vector3 = fwd.rotated(Vector3.UP, off)
		var hit: Dictionary = main.trace_shot(from, dir, 2.0, self)
		if hit["kind"] == "combatant" and int(hit["node"].team) != team:
			var victim = hit["node"]
			if "face_yaw" in victim:
				var vf := Vector3(-sin(float(victim.face_yaw)), 0.0, -cos(float(victim.face_yaw)))
				var to_v: Vector3 = victim.global_position - global_position
				to_v.y = 0.0
				if to_v.length() > 0.01 and vf.dot(to_v.normalized()) > 0.35:
					return true
	return false


## Được gọi đúng khoảnh khắc lưỡi dao chạm (từ animation của dao).
func _on_melee_hit(kind: String) -> void:
	if not alive or main == null or not bool(W.get("melee", false)):
		return
	var stab := kind == "stab"
	var reach := 2.0 if stab else 2.3
	var from := camera.global_position
	var fwd := -camera.global_transform.basis.z
	var best: Dictionary = {}
	var best_d := 1.0e9
	var world_hit: Dictionary = {}
	for off in [0.0, 0.14, -0.14]:
		var dir: Vector3 = fwd.rotated(Vector3.UP, off)
		var hit: Dictionary = main.trace_shot(from, dir, reach, self)
		if hit["kind"] == "combatant":
			if int(hit["node"].team) != team and float(hit["dist"]) < best_d:
				best = hit
				best_d = float(hit["dist"])
		elif hit["kind"] == "world" and world_hit.is_empty():
			world_hit = hit
	if not best.is_empty():
		var victim = best["node"]
		var dmg := 65.0 if stab else 40.0
		var backstab := false
		if "face_yaw" in victim:
			# đâm sau lưng (địch đang quay lưng lại) = hạ gục ngay
			var vf := Vector3(-sin(float(victim.face_yaw)), 0.0, -cos(float(victim.face_yaw)))
			var to_v: Vector3 = victim.global_position - global_position
			to_v.y = 0.0
			if to_v.length() > 0.01 and vf.dot(to_v.normalized()) > 0.35:
				dmg = 195.0
				backstab = true
		victim.take_damage(dmg, self, false)
		if hud:
			hud.hit_marker(backstab)
		play("knife_hit", 0.0)
		main.spawn_blood(best["pos"], best["normal"])
	elif not world_hit.is_empty():
		play("knife_wall", -2.0)
		main.spawn_impact(world_hit["pos"], world_hit["normal"])


func start_reload() -> void:
	if reloading or reserve <= 0 or mag >= int(W["mag"]) + _chamber():
		return
	var m: int = vm.current_mode()
	if m == Viewmodel.Mode.RELOAD or m == Viewmodel.Mode.DRAW:
		return
	if m == Viewmodel.Mode.INSPECT:
		vm.cancel()
	reloading = true
	_set_scope(0)
	vm.play_reload(mag == 0)


func _on_reload_inserted() -> void:
	var cap := int(W["mag"]) + (_chamber() if mag > 0 else 0)
	var take := mini(cap - mag, reserve)
	mag += take
	reserve -= take
	_update_hud()


func _on_action_finished(action_name: String) -> void:
	if action_name == "reload":
		reloading = false
		vm.set_slide_locked(false)


## Lăn chuột: duyệt qua các vũ khí đang có theo thứ tự M4A1 -> AK-47 -> AWP -> MP5-SD -> Desert Eagle -> Glock -> Dao -> Bom (khi đang mang bom).
func cycle_weapon(step: int) -> void:
	var list: Array = []
	for id in ["m4a1", "ak47", "awp", "mp5", "deagle", "glock", "knife", "c4"]:
		if bool(owned.get(id, false)):
			list.append(id)
	var i := list.find(cur_w)
	if i < 0 or list.size() < 2:
		return
	request_switch(str(list[(i + step + list.size()) % list.size()]))


## Đổi súng do người chơi bấm phím / lăn chuột: nếu súng đang cầm có animation cất súng (Desert Eagle) thì chạy xong rồi mới đổi.
## Các chỗ khác (mua súng, đầu vòng, cứ điểm bom) vẫn gọi switch_weapon() để đổi ngay.
func request_switch(id: String) -> void:
	if switching or id == cur_w or not alive or not bool(owned.get(id, false)):
		return
	if not vm.has_method("play_holster"):
		switch_weapon(id)
		return
	switching = true
	reloading = false
	var old_vm = vm
	var t: float = vm.play_holster()
	await get_tree().create_timer(t).timeout
	switching = false
	if alive and vm == old_vm and cur_w != id and bool(owned.get(id, false)):
		switch_weapon(id)


## Đổi sang súng khác (nếu đã sở hữu).
func switch_weapon(id: String) -> void:
	if id == cur_w or not alive or not bool(owned.get(id, false)):
		return
	_set_scope(0)
	w_mag[cur_w] = mag
	w_res[cur_w] = reserve
	reloading = false
	vm.cancel()
	vm.visible = false
	vm.set_process(false)
	last_w = cur_w
	cur_w = id
	W = WEAPONS[id]
	mag = int(w_mag[id])
	reserve = int(w_res[id])
	vm = viewmodels[id]
	vm.set_process(true)
	vm.visible = true
	vm.cancel()
	vm.play_draw()
	fire_queue = 0.0
	fire_cd = 0.0
	shots_fired = 0
	pistol_inacc = 0.0
	_update_hud()


## Loại của một vũ khí: "primary" (súng chính), "pistol" (súng lục), "melee" (dao), "bomb" (C4).
static func slot_of(id: String) -> String:
	return str(SLOT_OF.get(id, ""))


## Nhận súng (mua ở cửa hàng hoặc nhặt dưới đất) và cầm luôn. Mỗi loại chỉ cầm được một khẩu:
## đang có khẩu cùng loại thì khẩu đó rơi xuống đất (kèm số đạn hiện tại), không bị khóa món nào cả.
## Mua mới: đạn đầy (keep_mag / keep_res = -1). Nhặt từ đất: giữ nguyên số đạn lúc bị vứt.
func give_weapon(id: String, keep_mag: int = -1, keep_res: int = -1) -> void:
	var slot := slot_of(id)
	for wid in WEAPONS:
		if slot_of(str(wid)) == slot and bool(owned.get(wid, false)):
			_drop_weapon_item(str(wid), 1.8)
	owned[id] = true
	w_mag[id] = int(WEAPONS[id]["mag"]) if keep_mag < 0 else keep_mag
	w_res[id] = int(WEAPONS[id]["reserve"]) if keep_res < 0 else keep_res
	if id != cur_w:
		switch_weapon(id)
	else:
		mag = int(w_mag[id])
		reserve = int(w_res[id])
		_update_hud()
	if not bool(owned.get(last_w, false)):
		last_w = "knife"


## Thả một khẩu súng đang sở hữu xuống đất, phía trước mặt (kèm số đạn của nó). Không đổi súng cầm tay (chỗ gọi tự lo).
func _drop_weapon_item(id: String, speed: float) -> void:
	var m: int = mag if id == cur_w else int(w_mag[id])
	var r: int = reserve if id == cur_w else int(w_res[id])
	owned[id] = false
	if main == null or main.pickups == null:
		return
	var fwd: Vector3 = -(camera.global_transform.basis.z)
	fwd.y = 0.0
	fwd = fwd.normalized() if fwd.length() > 0.01 else Vector3.FORWARD
	var start: Vector3 = camera.global_position + fwd * 0.5 + Vector3(0.0, -0.35, 0.0)
	main.pickups.drop_weapon(id, m, r, start, fwd * speed + Vector3(0.0, 1.2, 0.0), yaw)


## Phím G: vứt món đang cầm. Dao không vứt được. Bom C4 do bomb.gd vứt (nằm tại chỗ, phe T đi tới là nhặt lại).
func drop_current() -> void:
	if not alive or switching or main == null:
		return
	if main.shop_open or main.player_locked:
		return
	var id := cur_w
	if id == "knife":
		if hud:
			hud.show_info("Không thể vứt dao", 1.5)
		return
	if id == "c4":
		if main.bomb != null and main.bomb.active:
			main.bomb.player_drop_c4()
		return
	if not bool(owned.get(id, false)):
		return
	reloading = false
	vm.cancel()
	_drop_weapon_item(id, 2.8)
	switch_weapon(best_weapon())
	if not bool(owned.get(last_w, false)):
		last_w = "knife"


## Súng chính đang cầm trong túi (M4A1 / AK-47 / AWP / MP5-SD), "" nếu không có.
func primary_id() -> String:
	for id in ["m4a1", "ak47", "awp", "mp5"]:
		if bool(owned.get(id, false)):
			return id
	return ""


## Món nên cầm tiếp sau khi vứt: súng chính > súng lục > dao.
func best_weapon() -> String:
	var pid := primary_id()
	return pid if pid != "" else pistol_id()


## Mua đạn: đầy đạn dự trữ cho mọi súng đang có.
func refill_ammo() -> void:
	for wid in WEAPONS:
		if bool(owned[wid]):
			w_res[wid] = int(WEAPONS[wid]["reserve"])
	reserve = int(w_res[cur_w])
	_update_hud()


## Về trạng thái đầu trận: chỉ còn Glock.
func reset_loadout() -> void:
	owned = {"glock": true, "deagle": false, "m4a1": false, "ak47": false, "awp": false, "mp5": false, "knife": true, "c4": false}
	if cur_w != "glock":
		owned["glock"] = true
		switch_weapon("glock")
	last_w = "knife"


## Súng lục đang sở hữu (Desert Eagle hoặc Glock); không còn khẩu nào (đã vứt) thì trả về "knife". Dùng cho phím 2 và khi cần quay về súng lục.
func pistol_id() -> String:
	if bool(owned.get("deagle", false)):
		return "deagle"
	if bool(owned.get("glock", false)):
		return "glock"
	return "knife"   # đã vứt hết súng lục thì quay về dao


func _update_hud() -> void:
	if hud:
		hud.set_weapon(str(W["name"]))
		if bool(W.get("melee", false)):
			hud.set_melee_ammo()
		else:
			hud.set_ammo(mag, reserve)
		hud.set_health(hp)


# =====================================================================
#  SÁT THƯƠNG / CHẾT / HỒI SINH
# =====================================================================
func take_damage(amount: float, attacker, headshot: bool = false) -> bool:
	if not alive:
		return false
	hp -= int(round(amount))
	punch_v += Vector2(randf_range(-0.2, 0.2), randf_range(-0.3, 0.3))
	roll += randf_range(-0.04, 0.04)
	play("hurt", -3.0)
	if hud:
		hud.set_health(hp)
		hud.damage_indicator(amount / 100.0)
	if hp <= 0:
		hp = 0
		_die(attacker, headshot)
		return true
	return false


func _die(attacker, headshot: bool) -> void:
	_set_scope(0)
	zoom_k = 1.0
	zoom_target = 1.0
	alive = false
	deaths += 1
	reloading = false
	vm.cancel()
	vm.visible = false
	play("die", 0.0)
	if hud:
		hud.set_health(0)
		hud.set_crosshair_gap(4.0, true)   # ẩn tâm ngắm khi chết
	_start_death_cam(attacker, headshot)
	if main:
		main.register_kill(attacker, self, headshot)


func _start_death_cam(attacker, headshot: bool) -> void:
	death_t = 0.0
	death_cam_from = camera.global_transform
	camera.top_level = true
	camera.global_transform = death_cam_from
	# ngã theo hướng đạn bay tới (ngược lại với kẻ bắn); không rõ thì ngã ngửa
	var d := Vector3(0.0, 0.0, 1.0)
	if attacker != null and is_instance_valid(attacker) and attacker is Node3D:
		var away: Vector3 = global_position - (attacker as Node3D).global_position
		away.y = 0.0
		if away.length() > 0.1:
			d = away.normalized().rotated(Vector3.UP, -yaw)
	if corpse != null and is_instance_valid(corpse):
		corpse.queue_free()
	corpse = CorpseScript.new()
	add_child(corpse)
	if main != null and main.get("skins") != null:
		corpse.kind = str(main.skins.model_for_player(team))   # skin người chơi đã chọn cho phe đang chơi (skins.gd)
	corpse.setup(team == 0, d, velocity, headshot)
	# súng văng ra khỏi tay phải là khẩu đang cầm (không dùng khẩu súng hộp mặc định)
	if main != null and main.pickups != null and cur_w != "knife" and cur_w != "c4" and WEAPONS.has(cur_w):
		corpse.set_gun_model(main.pickups._build_model(cur_w))
	else:
		corpse.set_gun_model(null)
	# camera đứng phía sau lưng, lệch sang vai phải một chút
	death_az = yaw + 0.55


func _death_cam(delta: float) -> void:
	death_t += delta
	var k := clampf(death_t / DEATH_CAM_TIME, 0.0, 1.0)
	var e := 1.0 - pow(1.0 - k, 3.0)   # lùi ra nhanh rồi chậm dần
	var fall := clampf((death_t - 0.08) / 0.55, 0.0, 1.0)
	var focus := global_position + Vector3(0.0, lerpf(1.05, 0.45, fall), 0.0)
	var az := death_az + death_t * 0.10   # trôi chậm quanh xác
	var target := focus + Vector3(sin(az), 0.0, cos(az)) * DEATH_CAM_DIST + Vector3(0.0, 1.0, 0.0)
	# không cho camera xuyên tường: gặp tường thì kéo lại gần xác
	var q := PhysicsRayQueryParameters3D.create(focus, target, 1)
	var hit := get_world_3d().direct_space_state.intersect_ray(q)
	if not hit.is_empty():
		target = (hit["position"] as Vector3) + (focus - target).normalized() * 0.25
	var pos := death_cam_from.origin.lerp(target, e)
	var look := Transform3D(Basis.IDENTITY, pos).looking_at(focus, Vector3.UP)
	var b := death_cam_from.basis.orthonormalized().slerp(look.basis.orthonormalized(), e)
	camera.global_transform = Transform3D(b, pos)
	camera.fov = lerpf(fov_base, fov_base + 8.0, e)


func respawn(pos: Vector3, face_yaw: float) -> void:
	_set_scope(0)
	zoom_k = 1.0
	zoom_target = 1.0
	global_position = pos
	prev_pos = pos
	curr_pos = pos
	velocity = Vector3.ZERO
	hp = 100
	for wid in WEAPONS:
		w_mag[wid] = int(WEAPONS[wid]["mag"])
		w_res[wid] = int(WEAPONS[wid]["reserve"])
	mag = int(w_mag[cur_w])
	reserve = int(w_res[cur_w])
	alive = true
	reloading = false
	switching = false
	fire_cd = 0.0
	fire_queue = 0.0
	inaccuracy = 0.0
	_set_crouch(false)
	yaw = face_yaw
	pitch = 0.0
	rotation.y = yaw
	head.rotation.x = 0.0
	roll = 0.0
	punch = Vector2.ZERO
	punch_v = Vector2.ZERO
	cs_punch = Vector2.ZERO
	shots_fired = 0
	pistol_inacc = 0.0
	eye_y = EYE_STAND
	head.position.y = EYE_STAND
	camera.top_level = false
	camera.position = Vector3.ZERO
	camera.rotation = Vector3.ZERO
	camera.fov = fov_base
	if corpse != null and is_instance_valid(corpse):
		corpse.queue_free()
	corpse = null
	vm.visible = true
	vm.cancel()
	vm.set_slide_locked(false)
	vm.play_draw()
	if hud:
		hud.show_center("", 0.1)
		hud.show_info("", 0.1)
	_update_hud()


# =====================================================================
#  HIỆU ỨNG CAMERA / HUD MỖI KHUNG HÌNH
# =====================================================================
func _process(delta: float) -> void:
	delta = minf(delta, 0.05)
	var speed := Vector2(velocity.x, velocity.z).length()
	var sf := clampf(speed / RUN_SPEED, 0.0, 1.0)

	if alive:
		var target_eye := EYE_CROUCH if crouching else EYE_STAND
		eye_y = lerpf(eye_y, target_eye, 1.0 - exp(-14.0 * delta))
		land_dip = lerpf(land_dip, 0.0, 1.0 - exp(-9.0 * delta))
		interp_off = transform.basis.inverse() * ((prev_pos - curr_pos) * (1.0 - Engine.get_physics_interpolation_fraction()))
		head.position.y = eye_y + land_dip + interp_off.y
		head.position.z = interp_off.z
		roll = lerpf(roll, 0.0, 1.0 - exp(-8.0 * delta))
	else:
		_death_cam(delta)

	# nghiêng nhẹ khi đi ngang
	var local_v := transform.basis.inverse() * velocity
	var lean_target := -clampf(local_v.x / RUN_SPEED, -1.0, 1.0) * 0.018
	lean = lerpf(lean, lean_target, 1.0 - exp(-8.0 * delta))

	# lò xo giật camera
	punch_v += (-120.0 * punch - 14.0 * punch_v) * delta
	punch += punch_v * delta
	# giật kiểu CS: tự hồi về 0 với tốc độ (10 + 0.5 * độ lớn) độ mỗi giây, nên khi bắn liên tục góc nhìn dừng ở mức trần rồi chỉ lắc ngang
	if cs_punch != Vector2.ZERO:
		var plen := cs_punch.length()
		var rb := 10.0
		var rm := 0.5
		if W.has("cs"):
			rb = float((W["cs"] as Dictionary).get("rec_base", 10.0))
			rm = float((W["cs"] as Dictionary).get("rec_mul", 0.5))
		var nlen := maxf(plen - (rb + plen * rm) * delta, 0.0)
		cs_punch = cs_punch * (nlen / plen)
	# tự động nghiêng: kiểm tra ~14 lần/giây cho nhẹ máy
	head.position.x = interp_off.x if alive else 0.0
	if alive:
		camera.rotation = Vector3(punch.x + cs_punch.x * D2R, punch.y + cs_punch.y * D2R, roll + lean)
		zoom_k = lerpf(zoom_k, zoom_target, 1.0 - exp(-24.0 * delta))
		if absf(zoom_k - zoom_target) < 0.0005:
			zoom_k = zoom_target
		camera.fov = _zoomed_fov()
	if render_cam != null:
		var want_far := 90.0 if zoom_k > 0.9 else 200.0   # đang zoom thì nhìn xa hơn (chỉ gán khi đổi, đỡ cập nhật camera mỗi khung hình)
		if not is_equal_approx(render_cam.far, want_far):
			render_cam.far = want_far
		render_cam.global_transform = camera.global_transform
		render_cam.fov = camera.fov

	# truyền trạng thái cho viewmodel
	vm.move_amount = sf
	vm.grounded = is_on_floor()
	vm.crouched = crouching
	var running := (speed > RUN_SPEED * 0.9 and Input.is_action_pressed("move_forward")
		and not crouching and not Input.is_action_pressed("walk") and since_shot > 0.45)
	vm.run_amount = 0.0   # đã bỏ: chạy nước rút không cụp súng, súng luôn ở tư thế sẵn sàng như CS2

	# tâm ngắm động
	if hud and alive:
		cur_spread = lerpf(cur_spread, current_spread_deg(), 1.0 - exp(-18.0 * delta))
		hud.set_crosshair_gap(4.0 + cur_spread * 4.0, scope_level > 0)
