extends Node3D
## Đồ rơi dưới đất: súng bị vứt (bấm G) hoặc bị thay ra khi mua / nhặt súng cùng loại.
## Nhìn vào món đồ (trong vòng PICK_RANGE mét) rồi bấm E để nhặt. Đồ nằm đó đến hết round
## (đầu round mới / trận mới thì dọn sạch bằng clear_all()). Bom C4 do bomb.gd lo (phe T đi tới là tự nhặt).
## Không dùng class_name; main.gd nạp bằng preload("res://scripts/pickups.gd").

const PICK_RANGE := 2.6      # nhìn món đồ gần hơn bấy nhiêu mét mới nhặt được
const PICK_RADIUS := 0.55    # tâm ngắm lệch món đồ tối đa bấy nhiêu mét thì vẫn tính là "đang nhìn"
const MAX_ITEMS := 36        # quá nhiều thì xoá món cũ nhất (giữ game nhẹ)
const FALL_GRAVITY := 18.0
const LIE_H := 0.045         # súng nằm nghiêng nên tâm cao hơn mặt đất chừng này

var main = null
var items: Array = []        # mỗi món: {id, mag, res, node, vel, landed, age}
var prompt := ""             # dòng nhắc "Bấm E để nhặt ..." (rỗng nếu không nhìn món nào)
var _shown_prompt := ""
var _target = null
var _mats := {}


func _ready() -> void:
	add_to_group("pickups")


# =====================================================================
#  THẢ ĐỒ XUỐNG ĐẤT
# =====================================================================
## Thả một khẩu súng: id, đạn trong băng, đạn dự trữ, vị trí xuất phát, vận tốc ném, hướng quay (yaw).
func drop_weapon(id: String, mag: int, res: int, pos: Vector3, vel: Vector3, yaw: float) -> void:
	var root := _build_model(id)
	root.rotation.y = yaw
	add_child(root)
	root.global_position = pos
	items.append({"id": id, "mag": mag, "res": res, "node": root, "vel": vel, "landed": false, "age": 0.0})
	while items.size() > MAX_ITEMS:
		_remove(items[0])


func clear_all() -> void:
	for it in items:
		var n = it["node"]
		if n != null and is_instance_valid(n):
			(n as Node).queue_free()
	items.clear()
	_target = null
	prompt = ""


func _remove(it: Dictionary) -> void:
	var n = it["node"]
	if n != null and is_instance_valid(n):
		(n as Node).queue_free()
	items.erase(it)
	if _target == it:
		_target = null


# =====================================================================
#  RƠI XUỐNG ĐẤT + TÌM MÓN ĐANG NHÌN (mỗi nhịp vật lý)
# =====================================================================
func _physics_process(delta: float) -> void:
	if items.is_empty():
		_target = null
		return
	var space := get_world_3d().direct_space_state
	for it in items.duplicate():
		if bool(it["landed"]):
			continue
		var node := it["node"] as Node3D
		var vel: Vector3 = it["vel"]
		it["age"] = float(it["age"]) + delta
		vel.y -= FALL_GRAVITY * delta
		var from := node.global_position
		var to := from + vel * delta
		var q := PhysicsRayQueryParameters3D.create(from, to + Vector3(0.0, -LIE_H, 0.0), 1)
		var hit := space.intersect_ray(q)
		if hit.is_empty():
			node.global_position = to
		else:
			var n: Vector3 = hit["normal"]
			if n.y > 0.5:
				node.global_position = (hit["position"] as Vector3) + Vector3(0.0, LIE_H, 0.0)
				it["landed"] = true
				vel = Vector3.ZERO
				if main != null and main.has_method("play_at"):
					main.play_at("mag_in", node.global_position, -2.0, 0.8, 40.0)
			else:
				# đập vào tường: mất vận tốc ngang, chỉ rơi thẳng xuống
				vel.x = 0.0
				vel.z = 0.0
				node.global_position = from + Vector3(0.0, vel.y * delta, 0.0)
		it["vel"] = vel
		if node.global_position.y < -40.0 or float(it["age"]) > 8.0:
			_remove(it)
	_find_target(space)


func _find_target(space: PhysicsDirectSpaceState3D) -> void:
	_target = null
	var p = main.player if main != null else null
	if p == null or not p.alive:
		return
	var eye: Vector3 = p.camera.global_position
	var fwd: Vector3 = -(p.camera.global_transform.basis.z)
	var best = null
	var best_perp := 1.0e9
	for it in items:
		if not bool(it["landed"]):
			continue
		var c: Vector3 = (it["node"] as Node3D).global_position + Vector3(0.0, 0.08, 0.0)
		var d := c - eye
		var dist := d.length()
		if dist > PICK_RANGE or dist < 0.01:
			continue
		var cosv := fwd.dot(d / dist)
		if cosv <= 0.0:
			continue
		var perp := dist * sqrt(maxf(0.0, 1.0 - cosv * cosv))
		if perp > PICK_RADIUS or perp >= best_perp:
			continue
		best = it
		best_perp = perp
	if best == null:
		return
	# có tường chắn giữa mắt và món đồ thì không nhặt được
	var bp: Vector3 = ((best["node"] as Node3D).global_position) + Vector3(0.0, 0.08, 0.0)
	var q := PhysicsRayQueryParameters3D.create(eye, bp, 1)
	var hit := space.intersect_ray(q)
	if not hit.is_empty() and eye.distance_to(hit["position"]) < eye.distance_to(bp) - 0.2:
		return
	_target = best


# =====================================================================
#  NHẶT (phím E) + DÒNG NHẮC
# =====================================================================
func _process(_delta: float) -> void:
	prompt = ""
	var p = main.player if main != null else null
	var can: bool = p != null and p.alive and not main.in_menu and not main.shop_open and not main.paused_menu
	# đang có việc khác với phím E (đặt / gỡ bom) thì không nhặt, để khỏi vừa gỡ bom vừa nhặt súng
	var b = main.bomb if main != null else null
	if can and b != null and is_instance_valid(b) and b.active and str(b.busy_prompt) != "":
		can = false
	if not can or _target == null or not is_instance_valid((_target as Dictionary)["node"]):
		_publish()
		return
	var it: Dictionary = _target
	var id: String = it["id"]
	var slot := Player.slot_of(id)
	prompt = "Bấm E để nhặt " + str(Player.WEAPONS[id]["name"])
	for wid in Player.WEAPONS:
		if Player.slot_of(str(wid)) == slot and bool(p.owned.get(wid, false)):
			prompt += "  (đổi với " + str(Player.WEAPONS[wid]["name"]) + ")"
			break
	_publish()
	if Input.is_action_just_pressed("use") and not main.player_locked:
		_remove(it)
		p.give_weapon(id, int(it["mag"]), int(it["res"]))
		main.hud.show_info(str(Player.WEAPONS[id]["name"]), 2.0)


## Đưa dòng nhắc lên màn hình. Trong chế độ ĐẶT BOM lúc đang đánh (LIVE / PLANTED) thì bomb.gd tự ghép dòng này vào dòng nhắc của nó.
func _publish() -> void:
	var b = main.bomb if main != null else null
	if b != null and is_instance_valid(b) and b.active and (int(b.state) == 1 or int(b.state) == 2):
		_shown_prompt = ""
		return
	if prompt != _shown_prompt:
		_shown_prompt = prompt
		main.hud.set_prompt(prompt)


# =====================================================================
#  MÔ HÌNH SÚNG DƯỚI ĐẤT (ghép từ vài khối hộp, nòng súng hướng -Z, súng nằm nghiêng một bên)
# =====================================================================
func _mat(color: Color, emissive: bool = false, alpha: float = 1.0) -> StandardMaterial3D:
	var key := color.to_html() + ("e" if emissive else "") + str(alpha)
	if not _mats.has(key):
		var m := StandardMaterial3D.new()
		m.albedo_color = Color(color.r, color.g, color.b, alpha)
		m.roughness = 0.9
		m.shading_mode = BaseMaterial3D.SHADING_MODE_PER_VERTEX
		m.specular_mode = BaseMaterial3D.SPECULAR_DISABLED
		if emissive:
			m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
		if alpha < 1.0:
			m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
		_mats[key] = m
	return _mats[key]


func _box(parent: Node3D, size: Vector3, pos: Vector3, color: Color, rot: Vector3 = Vector3.ZERO) -> void:
	var mi := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = size
	mi.mesh = bm
	mi.material_override = _mat(color)
	mi.position = pos
	mi.rotation = rot
	mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	parent.add_child(mi)


func _build_model(id: String) -> Node3D:
	var root := Node3D.new()
	var m := Node3D.new()
	m.rotation.z = PI * 0.5   # súng nằm nghiêng một bên
	root.add_child(m)
	var black := Color(0.09, 0.09, 0.10)
	var gray := Color(0.27, 0.28, 0.30)
	var silver := Color(0.62, 0.63, 0.67)
	var wood := Color(0.42, 0.25, 0.10)
	match id:
		"glock":
			_box(m, Vector3(0.032, 0.038, 0.19), Vector3(0, 0.03, -0.02), gray)
			_box(m, Vector3(0.030, 0.025, 0.17), Vector3(0, 0.0, -0.01), black)
			_box(m, Vector3(0.030, 0.09, 0.045), Vector3(0, -0.05, 0.06), black, Vector3(0.2, 0, 0))
		"deagle":
			_box(m, Vector3(0.04, 0.05, 0.27), Vector3(0, 0.03, -0.03), silver)
			_box(m, Vector3(0.036, 0.03, 0.24), Vector3(0, 0.0, -0.02), black)
			_box(m, Vector3(0.036, 0.11, 0.055), Vector3(0, -0.06, 0.08), black, Vector3(0.2, 0, 0))
		"m4a1":
			_box(m, Vector3(0.05, 0.075, 0.32), Vector3(0, 0, 0), black)
			_box(m, Vector3(0.05, 0.055, 0.26), Vector3(0, -0.005, -0.29), gray)
			_box(m, Vector3(0.016, 0.016, 0.2), Vector3(0, 0.008, -0.52), black)
			_box(m, Vector3(0.045, 0.07, 0.2), Vector3(0, -0.01, 0.27), black)
			_box(m, Vector3(0.034, 0.14, 0.055), Vector3(0, -0.1, 0.0), gray, Vector3(-0.15, 0, 0))
			_box(m, Vector3(0.035, 0.09, 0.04), Vector3(0, -0.08, 0.13), black, Vector3(0.35, 0, 0))
			_box(m, Vector3(0.02, 0.03, 0.2), Vector3(0, 0.05, -0.02), gray)
		"ak47":
			_box(m, Vector3(0.05, 0.07, 0.32), Vector3(0, 0, 0), gray)
			_box(m, Vector3(0.05, 0.055, 0.25), Vector3(0, -0.005, -0.285), wood)
			_box(m, Vector3(0.016, 0.016, 0.24), Vector3(0, 0.008, -0.54), black)
			_box(m, Vector3(0.045, 0.075, 0.22), Vector3(0, -0.015, 0.28), wood)
			_box(m, Vector3(0.036, 0.15, 0.055), Vector3(0, -0.1, -0.04), black, Vector3(0.3, 0, 0))
			_box(m, Vector3(0.035, 0.09, 0.04), Vector3(0, -0.08, 0.13), wood, Vector3(0.35, 0, 0))
		"awp":
			var od := Color(0.17, 0.23, 0.15)
			_box(m, Vector3(0.05, 0.08, 0.5), Vector3(0, 0, 0.0), od)
			_box(m, Vector3(0.045, 0.09, 0.32), Vector3(0, -0.01, 0.40), od)
			_box(m, Vector3(0.022, 0.022, 0.5), Vector3(0, 0.012, -0.5), black)
			_box(m, Vector3(0.045, 0.045, 0.3), Vector3(0, 0.07, -0.02), black)
			_box(m, Vector3(0.06, 0.06, 0.09), Vector3(0, 0.07, -0.2), black)
			_box(m, Vector3(0.032, 0.09, 0.06), Vector3(0, -0.07, 0.05), gray)
			_box(m, Vector3(0.034, 0.1, 0.05), Vector3(0, -0.07, 0.22), od, Vector3(0.3, 0, 0))
		"mp5":
			_box(m, Vector3(0.045, 0.065, 0.30), Vector3(0, 0, 0.0), black)
			_box(m, Vector3(0.05, 0.05, 0.26), Vector3(0, 0.0, -0.28), gray)
			_box(m, Vector3(0.016, 0.02, 0.2), Vector3(0, 0.005, 0.3), gray)
			_box(m, Vector3(0.03, 0.07, 0.03), Vector3(0, 0.0, 0.41), black)
			_box(m, Vector3(0.03, 0.14, 0.04), Vector3(0, -0.10, -0.02), black, Vector3(-0.15, 0, 0))
			_box(m, Vector3(0.032, 0.09, 0.04), Vector3(0, -0.075, 0.12), black, Vector3(0.3, 0, 0))
		_:
			_box(m, Vector3(0.05, 0.05, 0.3), Vector3.ZERO, gray)
	return root
