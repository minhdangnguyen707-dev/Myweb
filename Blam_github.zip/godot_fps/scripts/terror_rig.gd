extends RefCounted
## Nhân vật có animation thật của CS 1.6: PHE T = "Faithful Terror" (assets/terror/terror.glb, 55 xương, 100 animation),
## PHE CT = "Yuri Classic" của CS Online (assets/yuri/yuri.glb, 97 xương, 108 animation). Cùng một script, khác cấu hình (configure()).
## Giao diện: setup(frame, team) -> bool, drive(bot, hip_y, arm_l2), on_death(bot, headshot) / on_respawn() / free_model().
## Cách điều khiển:
##   - CHÂN + HÔNG: chạy animation thật của model (idle1 / walk / run / jump), tốc độ phát theo tốc độ thật của bot
##     nên bước chân khớp với quãng đường đi; hông xoay theo hướng đi (như CS 1.6).
##   - THÂN TRÊN + ĐẦU: lấy animation làm gốc rồi cộng thêm góc xoay / ngẩng của bộ xương hộp ẩn của Bot (ngắm, giật, nghiêng).
##   - HAI TAY: IK để bàn tay chạm đúng chỗ khối tay chạm (cầm súng), giống SkinRig.
##   - CHẾT: phát animation chết thật (head / back / forward / left / right / death1-3 / gutshot / crouch_die) tuỳ hướng đạn.
## Không dựng được model / thiếu xương / thiếu animation thì setup() trả về false và Bot quay về các khối hộp.

const YAW_OFF := PI        # model quay mặt về +Z; xoay PI để mặt hướng -Z (hướng tiến của Bot)
const FADE := 0.18         # thời gian chuyển mượt giữa hai animation (giây)
const LOOPS := ["idle1", "idle", "walk", "run", "crouch_idle", "crouchrun"]
const NEED_ANIMS := ["walk", "run", "jump", "head", "back", "forward", "left", "right", "death1", "death2", "death3", "gutshot", "crouch_die"]
## Cấu hình từng model (đổi bằng configure()). Mặc định = model phe T "Faithful Terror".
const CONFIGS := {
	"terror": {"path": "res://assets/terror/terror.glb", "idle": "idle1", "walk_mps": 1.68, "run_mps": 7.03, "run_from": 2.3, "walk_max": 2.4},
	"yuri": {"path": "res://assets/yuri/yuri.glb", "idle": "idle", "walk_mps": 0.965, "run_mps": 6.31, "run_from": 2.4, "walk_max": 2.5},
	"miho": {"path": "res://assets/miho/miho.glb", "idle": "idle", "walk_mps": 0.938, "run_mps": 6.29, "run_from": 2.4, "walk_max": 2.5},
	"abia": {"path": "res://assets/abia/abia.glb", "idle": "idle", "walk_mps": 0.994, "run_mps": 6.658, "run_from": 2.4, "walk_max": 2.5},
	"neko_gign": {"path": "res://assets/neko_gign/neko_gign.glb", "idle": "idle1", "walk_mps": 0.82, "run_mps": 5.092, "run_from": 2.4, "walk_max": 2.5},
	"kratos": {"path": "res://assets/kratos/kratos.glb", "idle": "idle1", "walk_mps": 1.577, "run_mps": 6.595, "run_from": 2.3, "walk_max": 2.4},
	"neko_gsg9": {"path": "res://assets/neko_gsg9/neko_gsg9.glb", "idle": "idle1", "walk_mps": 0.875, "run_mps": 5.495, "run_from": 2.4, "walk_max": 2.5},
}

# tên xương: so khớp phần đuôi của tên đã bỏ dấu cách / gạch
const BONE_KEYS := {
	"pelvis": "bip01pelvis", "spine": "bip01spine", "spine1": "bip01spine1", "spine2": "bip01spine2", "spine3": "bip01spine3",
	"head": "bip01head",
	"ruarm": "bip01rupperarm", "rfore": "bip01rforearm", "rhand": "bip01rhand",
	"luarm": "bip01lupperarm", "lfore": "bip01lforearm", "lhand": "bip01lhand",
}
const BONE_NEED := ["pelvis", "spine", "spine1", "spine2", "spine3", "head", "ruarm", "rfore", "rhand", "luarm", "lfore", "lhand"]
const SPINE_W := {"spine": 0.25, "spine1": 0.5, "spine2": 0.75, "spine3": 1.0}

var model_path := "res://assets/terror/terror.glb"
var idle_name := "idle1"
var walk_mps := 1.68       # tốc độ đi của animation "walk" (m/s)
var run_mps := 7.03        # tốc độ chạy của animation "run" (m/s)
var run_from := 2.3        # bot nhanh hơn mức này (m/s) thì dùng animation chạy
var walk_max := 2.4        # tốc độ phát tối đa của animation đi bộ
var ok := false
var frame: Node3D = null      # khung toạ độ = thân của Bot (nơi bộ xương hộp nằm)
var root: Node3D = null
var model: Node3D = null
var skel: Skeleton3D = null
var ap: AnimationPlayer = null
var b: Dictionary = {}
var s2f := Transform3D.IDENTITY   # xương -> khung
var s2f_b := Basis.IDENTITY
var f2s_b := Basis.IDENTITY
var arm_len_r := Vector2(0.3, 0.3)
var arm_len_l := Vector2(0.3, 0.3)
var cur_anim := ""
var air_t := 0.0
var dead := false


## Chọn model: "terror" (phe T, mặc định) hoặc "yuri" (phe CT). Gọi TRƯỚC setup().
func configure(kind: String) -> void:
	if not CONFIGS.has(kind):
		return
	var c: Dictionary = CONFIGS[kind]
	model_path = String(c["path"])
	idle_name = String(c["idle"])
	walk_mps = float(c["walk_mps"])
	run_mps = float(c["run_mps"])
	run_from = float(c["run_from"])
	walk_max = float(c["walk_max"])


func setup(frame_node: Node3D, _team_id: int) -> bool:
	frame = frame_node
	if not ResourceLoader.exists(model_path):
		return false
	var scene = load(model_path)
	if not (scene is PackedScene):
		return false
	root = Node3D.new()
	frame.add_child(root)
	model = (scene as PackedScene).instantiate() as Node3D
	if model == null:
		_discard()
		return false
	root.add_child(model)
	skel = _find_skeleton(model)
	ap = _find_player(model)
	if skel == null or skel.get_bone_count() == 0 or ap == null:
		push_warning("TerrorRig: thieu skeleton / AnimationPlayer")
		_discard()
		return false
	_index_bones()
	for k in BONE_NEED:
		if not b.has(k):
			push_warning("TerrorRig: thieu xuong " + str(k))
			_discard()
			return false
	if not ap.has_animation(idle_name):
		push_warning("TerrorRig: thieu animation " + idle_name)
		_discard()
		return false
	for a in NEED_ANIMS:
		if not ap.has_animation(a):
			push_warning("TerrorRig: thieu animation " + str(a))
			_discard()
			return false
	for a in LOOPS:
		if ap.has_animation(a):
			ap.get_animation(a).loop_mode = Animation.LOOP_LINEAR
	# animation do mình tự cho chạy (advance) trong drive(), để chỉnh xương SAU khi animation đã chạy trong cùng khung hình
	ap.callback_mode_process = AnimationMixer.ANIMATION_CALLBACK_MODE_PROCESS_MANUAL
	_fix_materials(model)
	root.transform = Transform3D(Basis(Vector3.UP, YAW_OFF), Vector3.ZERO)
	ap.play(idle_name, 0.0)
	cur_anim = idle_name
	ap.advance(0.0)
	_calibrate()
	ok = true
	return true


## Gỡ model ra khỏi nhân vật (dùng khi đổi skin giữa chừng).
func free_model() -> void:
	ok = false
	_discard()


func _discard() -> void:
	if root != null:
		if root.get_parent() != null:
			root.get_parent().remove_child(root)
		root.free()
	root = null
	model = null
	skel = null
	ap = null


func _find_skeleton(n: Node) -> Skeleton3D:
	if n is Skeleton3D:
		return n as Skeleton3D
	for c in n.get_children():
		var r := _find_skeleton(c)
		if r != null:
			return r
	return null


func _find_player(n: Node) -> AnimationPlayer:
	if n is AnimationPlayer:
		return n as AnimationPlayer
	for c in n.get_children():
		var r := _find_player(c)
		if r != null:
			return r
	return null


static func _norm(s: String) -> String:
	var out := ""
	for ch in s.to_lower():
		if (ch >= "a" and ch <= "z") or (ch >= "0" and ch <= "9"):
			out += ch
	return out


func _index_bones() -> void:
	b.clear()
	for i in skel.get_bone_count():
		var n := _norm(skel.get_bone_name(i))
		for k in BONE_KEYS:
			if not b.has(k) and n.ends_with(String(BONE_KEYS[k])):
				b[k] = i


func _calibrate() -> void:
	s2f = frame.global_transform.affine_inverse() * skel.global_transform
	s2f_b = s2f.basis.orthonormalized()
	f2s_b = s2f_b.inverse()
	arm_len_r = _arm_lens(b["ruarm"], b["rfore"], b["rhand"])
	arm_len_l = _arm_lens(b["luarm"], b["lfore"], b["lhand"])


func _arm_lens(ua: int, fo: int, ha: int) -> Vector2:
	var pu: Vector3 = skel.get_bone_global_rest(ua).origin
	var pf: Vector3 = skel.get_bone_global_rest(fo).origin
	var ph: Vector3 = skel.get_bone_global_rest(ha).origin
	return Vector2(pu.distance_to(pf), pf.distance_to(ph))


## Model chỉ có sẵn ảnh trong file; chỉnh vật liệu cho nhẹ máy (tô theo đỉnh, không bóng loáng, không đổ bóng).
func _fix_materials(n: Node) -> void:
	if n is MeshInstance3D:
		var mi := n as MeshInstance3D
		mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		if mi.mesh != null:
			for i in mi.mesh.get_surface_count():
				var m = mi.mesh.surface_get_material(i)
				if m is StandardMaterial3D:
					var sm := m as StandardMaterial3D
					sm.shading_mode = BaseMaterial3D.SHADING_MODE_PER_VERTEX
					sm.specular_mode = BaseMaterial3D.SPECULAR_DISABLED
					sm.metallic = 0.0
					sm.roughness = 1.0
					sm.cull_mode = BaseMaterial3D.CULL_DISABLED
	for c in n.get_children():
		_fix_materials(c)


# =====================================================================
#  SỰ KIỆN TỪ BOT
# =====================================================================
## Gọi ngay khi bot chết (sau khi bot đã tính death_dir = hướng ngã, toạ độ của visual: -Z phía trước, +X bên phải).
func on_death(bot, headshot: bool) -> void:
	if not ok:
		return
	var d: Vector3 = bot.death_dir
	var nm := ""
	if headshot:
		nm = "head"
	elif float(bot.aim_t) > 0.85 and randf() < 0.5:
		nm = "crouch_die"          # đang giao tranh (người đã hạ thấp)
	else:
		var r := randf()
		if r < 0.4:
			nm = ["death1", "death2", "death3", "gutshot"][randi() % 4]   # ngã theo kiểu ngẫu nhiên cho đỡ giống nhau
		elif d.z > 0.55:
			nm = "back"            # đạn từ phía trước: ngã ngửa ra sau
		elif d.z < -0.55:
			nm = "forward"         # đạn từ phía sau: ngã sấp
		elif d.x > 0.55:
			nm = "right"
		elif d.x < -0.55:
			nm = "left"
		else:
			nm = ["death1", "death2", "death3"][randi() % 3]
	dead = true
	cur_anim = nm
	ap.play(nm, 0.12)


## Dùng cho xác của người chơi (corpse.gd): chỉ chạy tiếp animation chết, không lái xương theo khối hộp.
func drive_corpse(dt: float) -> void:
	if ok:
		ap.advance(dt)


func on_respawn() -> void:
	dead = false
	cur_anim = ""
	air_t = 0.0


# =====================================================================
#  LÁI XƯƠNG (gọi mỗi khung hình, SAU khi Bot đã cập nhật bộ xương hộp)
# =====================================================================
func drive(bot, _hip_y: float, arm_l2: float) -> void:
	if not ok:
		return
	var dt: float = minf(bot.get_process_delta_time(), 0.05)
	if bot.alive:
		if dead:
			on_respawn()
		_drive_alive(bot, dt, arm_l2)
	else:
		if not dead:
			on_death(bot, false)
		_drive_dead(bot, dt)


func _play(nm: String, rate: float, dt: float) -> void:
	if nm != cur_anim:
		ap.play(nm, FADE)
		cur_anim = nm
	ap.advance(dt * rate)


func _drive_dead(bot, dt: float) -> void:
	# xác nằm yên tại chỗ: không đi theo khối hộp đang đổ, chỉ theo vị trí + hướng của bot lúc chết
	var vis: Node3D = bot.visual
	root.global_transform = Transform3D(vis.global_transform.basis.orthonormalized() * Basis(Vector3.UP, YAW_OFF), vis.global_position)
	ap.advance(dt)


func _drive_alive(bot, dt: float, arm_l2: float) -> void:
	root.transform = Transform3D(Basis(Vector3.UP, YAW_OFF), Vector3.ZERO)
	# ---- chọn animation + tốc độ phát theo tốc độ thật ----
	var speed: float = (bot.anim_vel as Vector3).length()
	if bot.is_on_floor():
		air_t = 0.0
	else:
		air_t += dt
	var nm := idle_name
	var rate := 1.0
	if air_t > 0.3:
		nm = "jump"
	elif speed > 0.35:
		if speed < run_from:
			nm = "walk"
			rate = clampf(speed / walk_mps, 0.5, walk_max)
		else:
			nm = "run"
			rate = clampf(speed / run_mps, 0.72, 1.4)
	_play(nm, rate, dt)

	# ---- tư thế gốc từ animation (hướng toàn cục trong toạ độ xương), trước khi cộng góc của bộ xương hộp ----
	var ag := {}
	for k in ["pelvis", "spine", "spine1", "spine2", "spine3"]:
		ag[k] = _g_basis(b[k])
	var fg := frame.global_transform
	var finv := fg.basis.orthonormalized().inverse()
	var fo_inv := fg.affine_inverse()

	# hông: xoay theo hướng đi (chân quay theo hướng chạy, thân trên vẫn nhìn về phía ngắm)
	var bh: Basis = (finv * (bot.hips as Node3D).global_transform.basis).orthonormalized()
	_set_global(b["pelvis"], _rot_s(bh) * (ag["pelvis"] as Basis))

	# cột sống: chia đều phần xoay của thân trên (so với hông) cho các đốt
	var bt: Basis = (finv * (bot.torso as Node3D).global_transform.basis).orthonormalized()
	var lq: Quaternion = (bh.inverse() * bt).get_rotation_quaternion()
	for k in SPINE_W:
		var q := Quaternion.IDENTITY.slerp(lq, float(SPINE_W[k]))
		_set_global(b[k], _rot_s(bh * Basis(q)) * (ag[k] as Basis))

	# đầu: cộng thêm góc ngẩng / liếc của khối đầu so với thân
	var hq := Basis((bot.head as Node3D).quaternion)
	_set_global(b["head"], _rot_s(bt * hq * bt.inverse()) * _g_basis(b["head"]))

	# tay: bàn tay chạm đúng chỗ khối tay chạm, khuỷu hướng giống khối
	var arms := [["luarm", "lfore", "lhand"], ["ruarm", "rfore", "rhand"]]
	for i in 2:
		var up: Node3D = bot.up_arm[i]
		var fo: Node3D = bot.fore_arm[i]
		var sh_f: Vector3 = fo_inv * up.global_position
		var el_f: Vector3 = fo_inv * fo.global_position
		var wr_f: Vector3 = fo_inv * (fo.global_transform * Vector3(0.0, -arm_l2, 0.0))
		var pole: Vector3 = el_f - (sh_f + wr_f) * 0.5
		var lens: Vector2 = arm_len_l if i == 0 else arm_len_r
		_arm_ik(b[arms[i][0]], b[arms[i][1]], b[arms[i][2]], lens, wr_f, pole)


func _rot_s(rf: Basis) -> Basis:
	return f2s_b * rf * s2f_b


func _g_basis(i: int) -> Basis:
	return skel.get_bone_global_pose(i).basis.orthonormalized()


## Đặt hướng toàn cục cho xương i (tính lại góc cục bộ theo xương cha hiện tại). Gọi cha trước con.
func _set_global(i: int, target_b: Basis) -> void:
	var p := skel.get_bone_parent(i)
	var pb := Basis.IDENTITY
	if p >= 0:
		pb = _g_basis(p)
	var q := (pb.inverse() * target_b).orthonormalized().get_rotation_quaternion()
	skel.set_bone_pose_rotation(i, q)


## Quay xương i sao cho xương con child chỉ về tgt (toạ độ xương).
func _aim_bone(i: int, child: int, tgt: Vector3) -> void:
	var g: Transform3D = skel.get_bone_global_pose(i)
	var off: Vector3 = skel.get_bone_rest(child).origin
	var cur := g.basis * off
	var des := tgt - g.origin
	if cur.length() < 0.00001 or des.length() < 0.00001:
		return
	var q := Quaternion(cur.normalized(), des.normalized())
	_set_global(i, Basis(q) * g.basis.orthonormalized())


## IK 2 xương cho tay: vai -> khuỷu -> cổ tay chạm target (toạ độ khung), khuỷu hướng về pole.
## Xuất phát từ tư thế animation (không reset về tư thế chữ T) nên cổ tay / bàn tay không bị vặn.
func _arm_ik(ua: int, fo: int, ha: int, lens: Vector2, target_f: Vector3, pole_f: Vector3) -> void:
	var sh: Vector3 = skel.get_bone_global_pose(ua).origin
	var t: Vector3 = s2f.affine_inverse() * target_f
	var pole: Vector3 = f2s_b * pole_f
	var d := t - sh
	var dist := d.length()
	if dist < 0.0001:
		return
	var dir := d / dist
	var l1 := lens.x
	var l2 := lens.y
	var eps := (l1 + l2) * 0.02
	dist = clampf(dist, absf(l1 - l2) + eps, l1 + l2 - eps)
	var a := (l1 * l1 - l2 * l2 + dist * dist) / (2.0 * dist)
	var h := sqrt(maxf(l1 * l1 - a * a, 0.0))
	var pp := pole - dir * pole.dot(dir)
	if pp.length() < 0.0001:
		pp = f2s_b * Vector3.DOWN
		pp = pp - dir * pp.dot(dir)
	pp = pp.normalized()
	var elbow := sh + dir * a + pp * h
	var wrist := sh + dir * dist
	_aim_bone(ua, fo, elbow)
	_aim_bone(fo, ha, wrist)
