class_name Bot
extends CharacterBody3D

const TerrorRig := preload("res://scripts/terror_rig.gd")   # model có animation thật: phe T = Faithful Terror, phe CT = Yuri (CS 1.6 / CS Online)
## Bot đơn giản: tuần tra theo navmesh, nhìn thấy địch thì dừng lại bắn (có thời gian phản xạ,
## độ lệch đạn theo khoảng cách), nghe tiếng súng/bước chân thì đi tới kiểm tra.

const SPEED_PATROL := 3.4
const SPEED_COMBAT := 2.7
const GRAVITY := 22.0

var team := 1
var display_name := "Bot"
var hp := 100
var alive := true
var kills := 0
var deaths := 0
var skill := 0.5
var main = null

var enemy = null          # địch đang nhìn thấy
var last_seen := Vector3.ZERO
var has_last_seen := false
var lost_t := 99.0
var react_t := 0.0
var fire_cd := 0.0
var scan_t := 0.0

var path := PackedVector3Array()
var path_i := 0
var goal := Vector3.ZERO
var has_goal := false
var repath_t := 0.0
var path_pending := false
var wait_t := 0.0
var anim_acc := 0.0         # dt cộng dồn trong lúc bỏ qua animation (xem _process / _needs_anim)
var jam_n := 0              # số khoảng 0.5 s liên tiếp bot muốn đi mà không nhích (xem _jam_check)
var jam_win_t := 0.0
var sep_acc := 0.0
var jam_pos := Vector3.ZERO
var want_move_t := 0.0      # thời gian trong khoảng hiện tại bot thật sự đang muốn đi
var side_t := 0.0           # đang né sang bên để gỡ kẹt
var side_dir := 1.0
var strafe_dir := 1.0
var pace := 1.0             # nhịp riêng mỗi bot (tốc độ đi hơi khác nhau, không đi đều như robot)
var cphase := 0             # giao tranh: 0 = đi ngang (strafe), 1 = đứng lại bắn
var cphase_t := 0.0
var had_enemy := false      # tick trước còn thấy địch -> vừa mất dấu thì khựng lại nhìn về chỗ cũ
var freeze_t := 0.0
var walk_mode := false      # đi bộ chậm (thay vì chạy) khi tuần tra
var look_yaw := 0.0         # hướng đang nhìn quanh lúc đứng chờ
var look_t := 0.0

# --- mô hình + animation (bộ xương dựng bằng code) ---
const HIP_Y := 0.88
const ARM_L1 := 0.30        # chiều dài cánh tay trên
const ARM_L2 := 0.33        # cẳng tay + bàn tay
const SHOULDER_X := 0.29
const SHOULDER_Y := 0.54
const POLE_R := Vector3(0.55, -1.0, 0.35)           # hướng khuỷu tay (hơi hướng ra ngoài + xuống)
const POLE_L := Vector3(-0.55, -1.0, 0.35)

var visual: Node3D      # xoay theo hướng nhìn
var body: Node3D        # gốc ở chân, dùng để ngã khi chết
var hips: Node3D
var torso: Node3D
var head: Node3D
var gun: Node3D
var flash: Node3D
var thigh: Array = []   # [trái, phải]
var shin: Array = []
var foot: Array = []    # bàn chân (xoay riêng để luôn bám mặt đất)
var prev_pos := Vector3.ZERO   # vị trí 2 lần cập nhật vật lý gần nhất, để nội suy hình ảnh cho mượt
var curr_pos := Vector3.ZERO
var up_arm: Array = []
var fore_arm: Array = []
var walk_phase := 0.0
var step_dist := 0.0
var death_t := 0.0
var face_yaw := 0.0
var anim_time := 0.0
var look_seed := 0.0
var gait_amp := 0.0
var anim_vel := Vector3.ZERO   # vận tốc đã làm mượt, chỉ dùng cho animation (không ảnh hưởng di chuyển thật)
var leg_yaw := 0.0            # hông/chân quay theo HƯỚNG ĐI, thân trên vẫn hướng về chỗ ngắm (như CS 1.6)
var leg_back := false         # đang đi lùi (chân hướng tới trước, bước ngược)
var step_dir := 1.0           # +1 tiến, -1 lùi (đã làm mượt)
var yaw_rate := 0.0           # tốc độ xoay thân (rad/s) -> bước chân tại chỗ khi quay người
var prev_yaw := 0.0
var aim_t := 0.0          # 0 = cầm súng thấp, 1 = ngắm bắn
var aim_pitch := 0.0
var aim_err := 0.0        # lệch giữa hướng thân và hướng địch (để xoay thân trên)
var aim_err_s := 0.0
var recoil := 0.0
var flinch := 0.0
var flinch_side := 1.0
var death_dir := Vector3(0.0, 0.0, 1.0)   # hướng ngã (toạ độ của visual)
var death_q: Array = []
var death_seed := 1.0
var death_hip_yaw := 0.0      # góc hông/thân lúc trúng đạn: giữ liền mạch khi chuyển sang ngã
var death_torso_yaw := 0.0
var gun_vel := Vector3.ZERO
var gun_spin := Vector3.ZERO
var gun_dropped := false
var gun_floor := 0.0
var rig = null          # TerrorRig: mô hình người thật (null = vẫn dùng các khối hộp)
# --- hành vi giống người chơi thật ---
const FOV_HALF := 1.05      # nửa góc nhìn (rad): ~60 độ mỗi bên = tầm nhìn 120 độ, KHÔNG nhìn được sau lưng
const PRICE_RIFLE_T := 2700    # AK-47 (giá giống cửa hàng của người chơi: $2700 như CS2)
const PRICE_RIFLE_CT := 2700   # M4A1
const PRICE_DEAGLE := 700
const MAX_MONEY := 16000
# Cách bot dùng từng khẩu súng (thông số sát thương / băng đạn / tiếng súng lấy từ Player.WEAPONS = đúng súng của người chơi)
#  gap = khoảng cách giữa 2 phát trong một loạt | pause = nghỉ giữa hai loạt | burst_* = số phát mỗi loạt (xa / vừa / gần)
#  spread = độ lệch nhân thêm | kick = độ lệch tăng thêm mỗi phát liền nhau | reload = giây nạp đạn | muzzle = vị trí đầu nòng | grip = chỗ hai tay bám
const WEAPON_AI := {
	"glock": {"gap": [0.18, 0.30], "pause": [0.30, 0.70], "burst_far": [1, 2], "burst_mid": [2, 3], "burst_near": [2, 4], "spread": 1.0, "kick": 0.5, "reload": 2.2, "muzzle": -0.15,
		"ready_pos": Vector3(0.12, 0.30, -0.30), "ready_rot": Vector3(-0.30, 0.25, 0.0), "aim_pos": Vector3(0.04, 0.46, -0.46),
		"grip_r": Vector3(0.0, -0.075, 0.06), "grip_l": Vector3(-0.012, -0.085, 0.02)},
	"deagle": {"gap": [0.42, 0.62], "pause": [0.05, 0.25], "burst_far": [1, 1], "burst_mid": [1, 1], "burst_near": [1, 2], "spread": 0.75, "kick": 1.8, "reload": 2.4, "muzzle": -0.20,
		"ready_pos": Vector3(0.12, 0.30, -0.30), "ready_rot": Vector3(-0.30, 0.25, 0.0), "aim_pos": Vector3(0.04, 0.46, -0.46),
		"grip_r": Vector3(0.0, -0.085, 0.08), "grip_l": Vector3(-0.012, -0.095, 0.03)},
	"m4a1": {"gap": [0.095, 0.12], "pause": [0.28, 0.65], "burst_far": [2, 4], "burst_mid": [3, 6], "burst_near": [5, 9], "spread": 0.85, "kick": 0.40, "reload": 3.0, "muzzle": -0.66,
		"ready_pos": Vector3(0.09, 0.40, -0.20), "ready_rot": Vector3(-0.42, 0.30, 0.0), "aim_pos": Vector3(0.11, 0.50, -0.27),
		"grip_r": Vector3(0.0, -0.09, 0.07), "grip_l": Vector3(0.0, -0.085, -0.22)},
	"ak47": {"gap": [0.105, 0.13], "pause": [0.30, 0.70], "burst_far": [2, 3], "burst_mid": [3, 5], "burst_near": [4, 8], "spread": 1.0, "kick": 0.55, "reload": 2.5, "muzzle": -0.70,
		"ready_pos": Vector3(0.09, 0.40, -0.20), "ready_rot": Vector3(-0.42, 0.30, 0.0), "aim_pos": Vector3(0.11, 0.50, -0.27),
		"grip_r": Vector3(0.0, -0.09, 0.07), "grip_l": Vector3(0.0, -0.085, -0.22)},
}
var weapon := "glock"       # súng đang cầm (id trong Player.WEAPONS): bot mua súng theo tiền từng round
var money := 800            # tiền của bot (đầu trận / hiệp 2 là $800 như người chơi)
var res := 85               # đạn dự trữ
var grip_r := Vector3(0.0, -0.075, 0.06)
var grip_l := Vector3(-0.012, -0.085, 0.02)
var pose_ready_pos := Vector3(0.12, 0.30, -0.30)   # tư thế cầm súng thay đổi theo khẩu (súng lục: hai tay duỗi thẳng trước ngực; súng trường: tì vai)
var pose_ready_rot := Vector3(-0.30, 0.25, 0.0)
var pose_aim_pos := Vector3(0.04, 0.46, -0.46)
var aggr := 0.5             # tính cách: 0 = thủ chặt, 1 = hung hăng
var patience := 0.5         # kiên nhẫn: cao thì đứng canh lâu
var mag := 30               # số đạn còn trong băng (hết thì phải nạp, lúc nạp là điểm yếu)
var reload_t := 0.0
var spot_acc := 0.0         # nhận ra địch cần thời gian (xa / đứng yên thì lâu hơn)
var engage_t := 0.0         # thời gian đã giao tranh với địch hiện tại: càng lâu càng ngắm chuẩn
var burst_left := 0
var burst_n := 0
var last_seen_vel := Vector3.ZERO
var callout_t := -1.0       # đồng đội báo có địch: sau chừng này giây mới phản ứng
var callout_pos := Vector3.ZERO
var retreat_t := 0.0        # đang lùi về chỗ nấp (máu yếu / nạp đạn)
var has_cover := false
var cover_pos := Vector3.ZERO
var cover_cd := 0.0
var hold_t := 0.0           # đứng canh góc sau khi rút lui
var died_flag := false      # đã chết ở lượt trước (mất súng)
var visual_weapon := ""     # súng đang hiện trên người (để dựng lại mô hình khi khác)
static var _mat_cache: Dictionary = {}


func _ready() -> void:
	add_to_group("combatants")
	collision_layer = 4
	collision_mask = 1 | 2   # KHÔNG va cứng với bot khác (hai bot chặn nhau ở lối hẹp là kẹt vĩnh viễn); chỉ đẩy nhẹ nhau ở _separate()
	floor_snap_length = 0.4
	floor_max_angle = deg_to_rad(46.0)
	var cap := CapsuleShape3D.new()
	cap.radius = 0.35
	cap.height = 1.8
	var cs := CollisionShape3D.new()
	cs.shape = cap
	cs.position.y = 0.9
	add_child(cs)
	_build_visual()
	pace = randf_range(0.92, 1.08)
	aggr = randf_range(0.1, 0.95)
	patience = randf()
	scan_t = randf() * 0.2   # mỗi bot quét vào thời điểm khác nhau


func _get_mat(color: Color) -> StandardMaterial3D:
	var key := color.to_html()
	if not _mat_cache.has(key):
		var m := StandardMaterial3D.new()
		m.albedo_color = color
		m.roughness = 0.9
		m.shading_mode = BaseMaterial3D.SHADING_MODE_PER_VERTEX
		m.specular_mode = BaseMaterial3D.SPECULAR_DISABLED
		_mat_cache[key] = m
	return _mat_cache[key]


func _part(parent: Node3D, size: Vector3, pos: Vector3, color: Color, rot: Vector3 = Vector3.ZERO) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = size
	mi.mesh = bm
	mi.material_override = _get_mat(color)
	mi.position = pos
	mi.rotation = rot
	mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	parent.add_child(mi)
	return mi


func _get_flash_mat() -> StandardMaterial3D:
	if not _mat_cache.has("flash"):
		var m := StandardMaterial3D.new()
		m.albedo_color = Color(1.0, 0.85, 0.4)
		m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
		m.cull_mode = BaseMaterial3D.CULL_DISABLED
		_mat_cache["flash"] = m
	return _mat_cache["flash"]


func _build_visual() -> void:
	visual = Node3D.new()
	add_child(visual)
	body = Node3D.new()
	visual.add_child(body)
	look_seed = float(get_instance_id() % 97) * 0.37
	death_seed = 1.0 if (get_instance_id() % 2) == 0 else -1.0
	var ct := team == 0
	var cloth := Color(0.16, 0.29, 0.58) if ct else Color(0.58, 0.42, 0.22)
	var cloth_d := Color(0.09, 0.15, 0.32) if ct else Color(0.36, 0.26, 0.15)
	var pants := Color(0.12, 0.13, 0.17) if ct else Color(0.27, 0.22, 0.15)
	var dark := Color(0.07, 0.07, 0.08)
	var tones := [Color(0.84, 0.64, 0.52), Color(0.66, 0.47, 0.36), Color(0.45, 0.31, 0.23), Color(0.92, 0.76, 0.64)]
	var skin: Color = tones[get_instance_id() % 4]
	var helmet := Color(0.08, 0.11, 0.19) if ct else Color(0.30, 0.25, 0.15)

	# ---- hông + hai chân (đùi -> cẳng chân -> giày) ----
	hips = Node3D.new()
	hips.position = Vector3(0.0, HIP_Y, 0.0)
	body.add_child(hips)
	_part(hips, Vector3(0.39, 0.17, 0.24), Vector3.ZERO, pants)
	for i in 2:
		var sx := -1.0 if i == 0 else 1.0
		var th := Node3D.new()
		th.position = Vector3(0.105 * sx, 0.0, 0.0)
		hips.add_child(th)
		_part(th, Vector3(0.17, 0.46, 0.2), Vector3(0.0, -0.23, 0.0), pants)
		var sh := Node3D.new()
		sh.position = Vector3(0.0, -0.45, 0.0)
		th.add_child(sh)
		_part(sh, Vector3(0.15, 0.42, 0.17), Vector3(0.0, -0.21, 0.0), pants)
		var ft := Node3D.new()
		ft.position = Vector3(0.0, -0.385, 0.0)
		sh.add_child(ft)
		_part(ft, Vector3(0.155, 0.09, 0.27), Vector3(0.0, 0.0, -0.05), dark)
		foot.append(ft)
		thigh.append(th)
		shin.append(sh)

	# ---- thân trên ----
	torso = Node3D.new()
	torso.position = Vector3(0.0, 0.02, 0.0)
	hips.add_child(torso)
	_part(torso, Vector3(0.46, 0.54, 0.27), Vector3(0.0, 0.33, 0.0), cloth)
	_part(torso, Vector3(0.42, 0.36, 0.05), Vector3(0.0, 0.36, -0.155), cloth_d)     # áo giáp trước
	_part(torso, Vector3(0.30, 0.36, 0.14), Vector3(0.0, 0.34, 0.20), cloth_d)       # ba lô
	_part(torso, Vector3(0.47, 0.06, 0.285), Vector3(0.0, 0.07, 0.0), dark)          # thắt lưng
	_part(torso, Vector3(0.1, 0.1, 0.07), Vector3(-0.16, 0.12, -0.17), dark)         # túi đạn
	_part(torso, Vector3(0.1, 0.1, 0.07), Vector3(0.16, 0.12, -0.17), dark)
	_part(torso, Vector3(0.10, 0.10, 0.10), Vector3(0.0, 0.60, 0.0), skin)           # cổ

	# ---- đầu ----
	head = Node3D.new()
	head.position = Vector3(0.0, 0.62, 0.0)
	torso.add_child(head)
	_part(head, Vector3(0.22, 0.24, 0.23), Vector3(0.0, 0.10, 0.0), skin)
	_part(head, Vector3(0.20, 0.05, 0.02), Vector3(0.0, 0.13, -0.12), Color(0.04, 0.05, 0.07))   # kính
	if not ct:
		_part(head, Vector3(0.23, 0.10, 0.24), Vector3(0.0, 0.02, 0.0), cloth_d)               # khăn che mặt
	_part(head, Vector3(0.255, 0.10, 0.265), Vector3(0.0, 0.235, 0.0), helmet)                  # mũ
	_part(head, Vector3(0.255, 0.03, 0.08), Vector3(0.0, 0.195, -0.15), helmet)                 # lưỡi trai

	# ---- hai tay (cánh tay trên -> cẳng tay -> găng) ----
	for i in 2:
		var sx2 := -1.0 if i == 0 else 1.0
		var up := Node3D.new()
		up.position = Vector3(SHOULDER_X * sx2, SHOULDER_Y, 0.0)
		torso.add_child(up)
		_part(up, Vector3(0.13, 0.30, 0.13), Vector3(0.0, -0.15, 0.0), cloth)
		_part(up, Vector3(0.17, 0.09, 0.17), Vector3(0.0, 0.0, 0.0), cloth_d)          # vai
		var fo := Node3D.new()
		fo.position = Vector3(0.0, -ARM_L1, 0.0)
		up.add_child(fo)
		_part(fo, Vector3(0.115, 0.28, 0.115), Vector3(0.0, -0.14, 0.0), cloth)
		_part(fo, Vector3(0.10, 0.10, 0.11), Vector3(0.0, -0.30, 0.0), dark)           # găng tay
		up_arm.append(up)
		fore_arm.append(fo)

	# ---- súng trường (con của thân trên, nên bám theo mọi chuyển động) ----
	gun = Node3D.new()
	torso.add_child(gun)
	var gm := Color(0.09, 0.09, 0.10)
	_part(gun, Vector3(0.055, 0.085, 0.30), Vector3(0.0, 0.0, -0.02), gm)             # thân súng
	_part(gun, Vector3(0.06, 0.07, 0.24), Vector3(0.0, -0.005, -0.28), Color(0.13, 0.12, 0.11))   # ốp lót nòng
	_part(gun, Vector3(0.026, 0.026, 0.22), Vector3(0.0, 0.012, -0.52), gm)           # nòng
	_part(gun, Vector3(0.036, 0.036, 0.05), Vector3(0.0, 0.012, -0.64), dark)         # đầu nòng
	_part(gun, Vector3(0.045, 0.095, 0.20), Vector3(0.0, -0.01, 0.23), Color(0.14, 0.12, 0.10))   # báng
	_part(gun, Vector3(0.04, 0.11, 0.05), Vector3(0.0, -0.085, 0.07), gm, Vector3(0.25, 0.0, 0.0))  # tay cầm
	_part(gun, Vector3(0.045, 0.15, 0.07), Vector3(0.0, -0.11, -0.09), Color(0.12, 0.12, 0.13), Vector3(-0.15, 0.0, 0.0))  # băng đạn
	_part(gun, Vector3(0.025, 0.04, 0.09), Vector3(0.0, 0.062, -0.02), gm)            # điểm ngắm
	flash = Node3D.new()
	flash.position = Vector3(0.0, 0.012, -0.70)
	flash.visible = false
	gun.add_child(flash)
	var fm := _get_flash_mat()
	for fr in [Vector3(0.0, 0.0, 0.0), Vector3(0.0, 0.0, PI * 0.5), Vector3(0.0, PI * 0.5, 0.0)]:
		var fq := MeshInstance3D.new()
		var qm := QuadMesh.new()
		qm.size = Vector2(0.20, 0.07)
		fq.mesh = qm
		fq.material_override = fm
		fq.rotation = fr
		fq.position.z = -0.04
		fq.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		flash.add_child(fq)

	# ---- thay các khối hộp bằng nhân vật người thật (nếu dựng được); bộ xương hộp vẫn chạy ngầm để lái xương ----
	_build_rig()


## Dựng model người thật: phe T = Terror, phe CT = Yuri (hoặc skin người chơi đã chọn cho cả phe, xem skins.gd).
func _build_rig() -> void:
	rig = null
	var kind := "terror" if team == 1 else "yuri"
	if main != null and main.get("skins") != null:
		kind = str(main.skins.model_for_bot(team))   # skin đã chọn cho cả phe (T hoặc CT), không có thì mặc định
	var arig = TerrorRig.new()
	arig.configure(kind)
	if arig.setup(body, team):
		rig = arig
	if rig != null:
		_hide_boxes(hips)


## Đổi skin giữa chừng (gọi từ sảnh chờ): bỏ model cũ, dựng lại theo skin hiện tại.
func reload_rig() -> void:
	if rig != null:
		rig.free_model()
	_build_rig()
	if rig != null and not alive:
		rig.on_death(self, false)


## Ẩn các khối hộp (trừ khẩu súng và tia lửa) -- chúng vẫn chuyển động ngầm để lái bộ xương thật.
func _hide_boxes(n: Node) -> void:
	for c in n.get_children():
		if c == gun:
			continue
		if c is MeshInstance3D:
			(c as MeshInstance3D).visible = false
		_hide_boxes(c)


# =====================================================================
#  ĐIỀU KHIỂN
# =====================================================================
func respawn(pos: Vector3) -> void:
	global_position = pos
	prev_pos = pos
	curr_pos = pos
	velocity = Vector3.ZERO
	hp = 100
	alive = true
	if rig != null and rig.has_method("on_respawn"):
		rig.on_respawn()
	collision_layer = 4
	death_t = 0.0
	visual.rotation = Vector3.ZERO
	body.transform = Transform3D.IDENTITY
	if gun_dropped:
		gun.top_level = false
		gun_dropped = false
	flash.visible = false
	recoil = 0.0
	flinch = 0.0
	aim_t = 0.0
	aim_err = 0.0
	aim_err_s = 0.0
	gait_amp = 0.0
	anim_vel = Vector3.ZERO
	leg_yaw = 0.0
	leg_back = false
	step_dir = 1.0
	yaw_rate = 0.0
	freeze_t = 0.0
	had_enemy = false
	cphase = 0
	cphase_t = 0.0
	look_t = 0.0
	enemy = null
	has_last_seen = false
	lost_t = 99.0
	has_goal = false
	path = PackedVector3Array()
	fire_cd = 1.0
	reload_t = 0.0
	gun.visible = true
	if main == null or main.bomb == null or not main.bomb.active:
		round_start(false, died_flag)   # chế độ ĐẤU ĐỘI: chết rồi hồi sinh thì mất súng, mua lại theo tiền
	died_flag = false
	mag = _mag_size()
	if visual_weapon != weapon:
		_apply_weapon_visual()
	spot_acc = 0.0
	engage_t = 0.0
	burst_left = 0
	retreat_t = 0.0
	has_cover = false
	cover_cd = 0.0
	hold_t = 0.0
	callout_t = -1.0
	last_seen_vel = Vector3.ZERO
	wait_t = randf_range(0.2, 1.0)
	jam_n = 0
	jam_pos = pos
	want_move_t = 0.0
	side_t = 0.0
	face_yaw = randf() * TAU
	prev_yaw = face_yaw


func hear(pos: Vector3) -> void:
	if not alive or enemy != null:
		return
	var dh: float = Vector2(pos.x - global_position.x, pos.z - global_position.z).length()
	if main != null and main.bomb != null and main.bomb.active and dh > (22.0 if team == 0 else 30.0):
		return   # chế độ ĐẶT BOM: tiếng ở xa không làm bot bỏ vị trí đang giữ
	if randf() < 0.45:
		return
	last_seen = pos
	has_last_seen = true
	lost_t = 0.0
	if dh < 14.0:
		freeze_t = randf_range(0.3, 0.7)   # nghe thấy gần: đứng lại lắng nghe, quay về phía tiếng động
	_set_goal(pos)


func take_damage(amount: float, attacker, headshot: bool = false) -> bool:
	if not alive:
		return false
	hp -= int(round(amount))
	flinch = 1.5 if headshot else 1.0
	flinch_side = 1.0 if randf() < 0.5 else -1.0
	if main:
		main.play_at("hurt", global_position, 0.0, 1.0, 40.0)
	if attacker != null and is_instance_valid(attacker) and attacker.alive:
		last_seen = attacker.global_position
		has_last_seen = true
		lost_t = 0.0
		if enemy == null:
			react_t = 0.25
			freeze_t = 0.0
			_set_goal(last_seen)
			if hp < 40 and randf() < 0.7 and retreat_t <= 0.0:
				_start_retreat(last_seen, randf_range(2.0, 3.5))   # bị bắn từ chỗ không thấy + máu yếu: lùi về chỗ nấp
	if hp <= 0:
		hp = 0
		_die(attacker, headshot)
		return true
	return false


func _die(attacker, headshot: bool) -> void:
	alive = false
	died_flag = true
	if main != null and main.pickups != null and visual_weapon == weapon:
		# thả khẩu súng đang cầm xuống đất để người chơi nhặt được (như CS)
		gun.visible = false
		main.pickups.drop_weapon(weapon, mag, res, global_position + Vector3(0.0, 1.0, 0.0), Vector3(velocity.x * 0.4 + randf_range(-0.8, 0.8), 1.5, velocity.z * 0.4 + randf_range(-0.8, 0.8)), face_yaw)
	deaths += 1
	collision_layer = 0
	enemy = null
	_start_death_anim(attacker, headshot)
	if rig != null and rig.has_method("on_death"):
		rig.on_death(self, headshot)   # model phe T phát animation chết thật
	if main:
		main.play_at("die", global_position, 0.0, 1.0, 40.0)
	if main:
		main.register_kill(attacker, self, headshot)


func _set_goal(p: Vector3) -> void:
	goal = p
	has_goal = true
	path_pending = true   # tìm đường ở lần _nav_move kế tiếp (có giới hạn ngân sách)


func _repath() -> void:
	path_pending = false
	repath_t = 2.0
	if main == null or not main.nav_ok:
		path = PackedVector3Array()
		return
	path = NavigationServer3D.map_get_path(main.nav_map, global_position, goal, true)
	path_i = 0


## Đổi vận tốc ngang về target (theo vector, có quán tính: tăng tốc chậm hơn phanh).
func _steer(target: Vector3, delta: float, accel: float = 14.0, decel: float = 24.0) -> void:
	var cur := Vector3(velocity.x, 0.0, velocity.z)
	var tg := Vector3(target.x, 0.0, target.z)
	var a := decel if tg.length() < cur.length() else accel
	var nv := cur.move_toward(tg, a * delta)
	velocity.x = nv.x
	velocity.z = nv.z


## Xoay thân về target_yaw: mượt ở đầu/cuối, nhưng không quá nhanh (giới hạn tốc độ xoay như người).
func _turn_to(target_yaw: float, delta: float, rate: float = 10.0, max_speed: float = 8.0) -> void:
	var diff := angle_difference(face_yaw, target_yaw)
	var step := diff * (1.0 - exp(-rate * delta))
	var mx := max_speed * delta
	face_yaw += clampf(step, -mx, mx)


## Trả về true khi đã tới đích.
func _nav_move(speed: float, delta: float) -> bool:
	repath_t -= delta
	var flat_goal := Vector2(goal.x - global_position.x, goal.z - global_position.z)
	if flat_goal.length() < 0.7:
		return true
	var dir := Vector3.ZERO
	if main != null and main.nav_ok:
		if path_pending or repath_t <= 0.0:
			if main.can_path():
				_repath()
			elif path_pending:
				_steer(Vector3.ZERO, delta)
				return false   # chờ tới lượt tìm đường
		while path_i < path.size():
			var d2 := Vector2(path[path_i].x - global_position.x, path[path_i].z - global_position.z)
			var reach := 0.75 if path_i + 1 < path.size() else 0.55
			if d2.length() < reach:
				path_i += 1
			else:
				break
		if path_i >= path.size():
			return true
		dir = path[path_i] - global_position
		dir.y = 0.0
		# nhìn trước khúc cua: gần tới điểm rẽ thì bẻ lái dần sang đoạn kế tiếp (cua tròn, không gấp khúc)
		if path_i + 1 < path.size() and dir.length() > 0.01:
			var dn: Vector3 = path[path_i + 1] - global_position
			dn.y = 0.0
			if dn.length() > 0.01:
				var w := smoothstep(1.6, 0.4, dir.length()) * 0.65
				dir = dir.normalized().lerp(dn.normalized(), w)
	else:
		dir = goal - global_position
	dir.y = 0.0
	if dir.length() < 0.01:
		return false
	dir = dir.normalized()
	want_move_t += delta
	if side_t > 0.0:
		dir = dir.rotated(Vector3.UP, side_dir * 1.1)   # đang kẹt: né sang bên khoảng 60 độ
	# tốc độ: chậm dần khi gần tới đích, và giảm tốc khi phải đổi hướng gấp
	var sp := speed * pace * clampf(flat_goal.length() / 2.2, 0.45, 1.0)
	var cv := Vector3(velocity.x, 0.0, velocity.z)
	if cv.length() > 0.6:
		sp *= lerpf(0.5, 1.0, clampf(cv.normalized().dot(dir), 0.0, 1.0))
	_steer(dir * sp, delta)
	_turn_to(atan2(-dir.x, -dir.z), delta, 8.0, 7.0)
	return false


func _pick_waypoint() -> void:
	if main != null and main.bomb != null and main.bomb.active:
		_set_goal(main.bomb.pick_goal(self))   # chế độ ĐẶT BOM: đi quanh điểm bom của mình, không lang thang cả map
		return
	if main == null or main.waypoints.is_empty():
		var a := randf() * TAU
		_set_goal(global_position + Vector3(cos(a), 0.0, sin(a)) * 8.0)
		return
	var best: Vector3 = main.waypoints[randi() % main.waypoints.size()]
	for i in 2:
		var c: Vector3 = main.waypoints[randi() % main.waypoints.size()]
		if c.distance_to(global_position) > best.distance_to(global_position):
			best = c
	_set_goal(best)


func _scan() -> void:
	var prev = enemy
	enemy = null
	var best := 1.0e9
	var eye := global_position + Vector3(0.0, 1.55, 0.0)
	var space := get_world_3d().direct_space_state
	var fwd := Vector3(-sin(face_yaw), 0.0, -cos(face_yaw))
	var cand = null
	var heard := false
	var heard_pos := Vector3.ZERO
	for c in get_tree().get_nodes_in_group("combatants"):
		if c == self or (not c.alive) or c.team == team:
			continue
		var tp: Vector3 = c.global_position + Vector3(0.0, 1.2, 0.0)
		if c.has_method("peek_offset"):
			tp += c.peek_offset()
		var d := eye.distance_to(tp)
		# nghe tiếng bước chân khi địch chạy ở gần (đi bộ / ngồi thì không nghe)
		var csp: float = Vector2(c.velocity.x, c.velocity.z).length()
		if csp > 4.6 and d < 15.0 and not heard and randf() < 0.3:
			heard = true
			heard_pos = c.global_position + Vector3(randf_range(-2.5, 2.5), 0.0, randf_range(-2.5, 2.5))
		if d > 60.0 or d >= best:
			continue
		# tầm nhìn 120 độ: địch ở bên hông / sau lưng thì không thấy (trừ khi sát mặt hoặc đang theo dõi)
		var tf := Vector3(tp.x - eye.x, 0.0, tp.z - eye.z)
		var in_view := d < 3.5
		if (not in_view) and tf.length() > 0.01:
			var ang := acos(clampf(fwd.dot(tf.normalized()), -1.0, 1.0))
			in_view = ang < FOV_HALF + (0.9 if c == prev else 0.0)
		if not in_view:
			continue
		var q := PhysicsRayQueryParameters3D.create(eye, tp, 1)
		var q2 := PhysicsRayQueryParameters3D.create(eye, tp + Vector3(0.0, 0.5, 0.0), 1)
		if space.intersect_ray(q).is_empty() or space.intersect_ray(q2).is_empty():
			cand = c
			best = d
	if cand != null:
		# nhận ra địch cần một chút thời gian: xa thì lâu hơn, địch chạy thì dễ thấy hơn, đã theo dõi / vừa mất dấu thì thấy ngay
		var need := lerpf(0.42, 0.16, skill) + clampf(best / 60.0, 0.0, 1.0) * 0.3
		if Vector2(cand.velocity.x, cand.velocity.z).length() > 3.0:
			need -= 0.1
		if cand == prev or (has_last_seen and lost_t < 2.0):
			need = 0.0
		spot_acc += 0.2
		if spot_acc >= need:
			enemy = cand
	else:
		spot_acc = maxf(spot_acc - 0.4, 0.0)
	if enemy != null:
		if lost_t > 0.8:
			react_t = lerpf(0.6, 0.22, skill)
		if prev == null and lost_t > 0.8:
			_callout(enemy.global_position)   # hô cho đồng đội biết
		last_seen = enemy.global_position
		last_seen_vel = Vector3(enemy.velocity.x, 0.0, enemy.velocity.z)
		has_last_seen = true
		lost_t = 0.0
		if main != null and main.bomb != null and main.bomb.active and team == 0:
			main.bomb.report_enemy(team, enemy.global_position)
	elif heard:
		hear(heard_pos)


## Hô báo vị trí địch cho đồng đội ở gần (họ phản ứng sau chừng 1 giây, như người nghe callout).
func _callout(pos: Vector3) -> void:
	if main == null:
		return
	for b in main.bots:
		if b == self or (not is_instance_valid(b)) or (not b.alive) or int(b.team) != team or b.enemy != null:
			continue
		if b.global_position.distance_to(global_position) < 32.0:
			b.callout_pos = pos
			b.callout_t = randf_range(0.7, 1.6)


## Tìm chỗ nấp: điểm tuần tra gần đó mà địch (ở from_pos) KHÔNG nhìn thấy, không nằm gần địch hơn mình. Chạy tới đó.
func _start_retreat(from_pos: Vector3, dur: float) -> bool:
	if main == null or main.waypoints.is_empty():
		return false
	var space := get_world_3d().direct_space_state
	var eye_e := from_pos + Vector3(0.0, 1.5, 0.0)
	var my_d: float = Vector2(from_pos.x - global_position.x, from_pos.z - global_position.z).length()
	var best := Vector3.ZERO
	var best_s := 1.0e9
	var found := false
	for i in 24:
		var w: Vector3 = main.waypoints[randi() % main.waypoints.size()]
		var dme: float = Vector2(w.x - global_position.x, w.z - global_position.z).length()
		if dme < 3.0 or dme > 16.0:
			continue
		var de: float = Vector2(w.x - from_pos.x, w.z - from_pos.z).length()
		if de < my_d * 0.9:
			continue
		if absf(w.y - global_position.y) > 3.0:
			continue
		var q := PhysicsRayQueryParameters3D.create(eye_e, w + Vector3(0.0, 1.4, 0.0), 1)
		if space.intersect_ray(q).is_empty():
			continue
		var sc: float = dme - de * 0.2
		if sc < best_s:
			best_s = sc
			best = w
			found = true
	if not found:
		return false
	cover_pos = best
	has_cover = true
	retreat_t = dur
	_set_goal(best)
	return true


func _retreat_step(delta: float) -> void:
	retreat_t -= delta
	if (not has_goal) or goal.distance_to(cover_pos) > 1.0:
		_set_goal(cover_pos)
	var arrived := _nav_move(SPEED_PATROL * 1.15, delta)
	if arrived or retreat_t <= 0.0:
		retreat_t = 0.0
		has_cover = false
		has_goal = false
		hold_t = randf_range(2.5, 5.0) * (0.6 + patience * 0.8)   # tới chỗ nấp: đứng canh góc, không lao ra ngay


## Vật lý chạy 60 lần/giây nhưng hình vẽ có thể 43-58 FPS nên chuyển động bị "khựng" từng nhịp.
## Giải pháp: nhớ vị trí 2 nhịp vật lý gần nhất, rồi mỗi khung hình vẽ nhân vật ở vị trí nội suy giữa chúng (xem _process).
func _physics_process(delta: float) -> void:
	prev_pos = global_position
	_bot_physics(delta)
	curr_pos = global_position


func _bot_physics(delta: float) -> void:
	if not alive:
		velocity.x = move_toward(velocity.x, 0.0, 20.0 * delta)
		velocity.z = move_toward(velocity.z, 0.0, 20.0 * delta)
		if not is_on_floor():
			velocity.y -= GRAVITY * delta
		move_and_slide()
		return

	# chế độ ĐẶT BOM: đang thời gian chuẩn bị thì đứng yên tại chỗ xuất phát
	if main != null and main.round_frozen:
		velocity.x = 0.0
		velocity.z = 0.0
		if not is_on_floor():
			velocity.y -= GRAVITY * delta
		move_and_slide()
		return

	fire_cd = maxf(fire_cd - delta, 0.0)
	react_t = maxf(react_t - delta, 0.0)
	cover_cd = maxf(cover_cd - delta, 0.0)
	if reload_t > 0.0:
		reload_t -= delta
		if reload_t <= 0.0:
			_finish_reload()
			if main:
				main.play_at("mag_in", global_position, -4.0, 1.0, 30.0)
	if callout_t > 0.0:
		callout_t -= delta
		if callout_t <= 0.0 and enemy == null and not has_last_seen:
			last_seen = callout_pos
			has_last_seen = true
			lost_t = 0.0
	scan_t -= delta
	if scan_t <= 0.0:
		scan_t = 0.2
		_scan()

	if not is_on_floor():
		velocity.y -= GRAVITY * delta
	elif velocity.y < 0.0:
		velocity.y = 0.0

	if retreat_t > 0.0 and has_cover:
		_retreat_step(delta)
	elif enemy != null and is_instance_valid(enemy) and enemy.alive:
		had_enemy = true
		_combat(delta)
	else:
		enemy = null
		if had_enemy:
			had_enemy = false
			freeze_t = randf_range(0.4, 0.8)   # vừa mất dấu: khựng lại, nhìn về chỗ vừa thấy
			last_seen += last_seen_vel.limit_length(6.0) * 0.7   # đoán địch đang chạy tiếp theo hướng cũ
		engage_t = 0.0
		burst_left = 0
		if mag < int(float(_mag_size()) * 0.45) and reload_t <= 0.0:
			reload_t = _reload_time()   # rảnh thì nạp lại đạn
		lost_t += delta
		_roam(delta)
	floor_t = 0.0 if is_on_floor() else floor_t + delta
	_separate(delta)
	_slide_with_step(delta)
	if global_position.y < -8.0 and main:
		respawn(main._pick_spawn(team))
		return
	var moving_speed := Vector2(velocity.x, velocity.z).length()

	# bị kẹt: nhảy + né sang bên, đổi đích, cuối cùng đưa bot tới điểm kế tiếp trên đường đi
	_jam_check(delta)

	# tiếng bước chân (animation chân nằm ở _process)
	step_dist += moving_speed * delta
	if step_dist > 2.6 and moving_speed > 2.4:
		step_dist = 0.0
		if main:
			main.play_at("step", global_position, -4.0, randf_range(0.9, 1.1), 22.0)


## Hai bot đứng quá gần thì đẩy nhẹ ra xa nhau (bot không còn va cứng vào nhau nên không thể chặn nhau ở lối hẹp). Chỉ chạy 20 lần/giây cho nhẹ.
func _separate(delta: float) -> void:
	if main == null:
		return
	sep_acc += delta
	if sep_acc < 0.05:
		return
	var dtp := sep_acc
	sep_acc = 0.0
	var gp := global_position
	for o in main.bots:
		if o == self:
			continue
		var op: Vector3 = o.global_position
		var dx := gp.x - op.x
		var dz := gp.z - op.z
		if dx * dx + dz * dz >= 0.5625 or absf(gp.y - op.y) > 1.5 or not o.alive:   # 0.75 m
			continue
		var l := sqrt(dx * dx + dz * dz)
		var ax := dx / l if l > 0.01 else cos(float(get_instance_id() % 628) * 0.01)
		var az := dz / l if l > 0.01 else sin(float(get_instance_id() % 628) * 0.01)
		velocity.x += ax * (0.75 - l) * 30.0 * dtp
		velocity.z += az * (0.75 - l) * 30.0 * dtp


## Gỡ kẹt: cứ mỗi 0.5 s xét xem bot có đang muốn đi (không phải đứng chờ / canh góc) mà gần như không nhích không.
##  kẹt ~1 s: nhảy + né sang bên | ~2.5 s: đổi đích khác | ~3.5 s: đưa bot tới điểm kế tiếp trên đường đi
##  (lúc người chơi không nhìn thấy; kẹt quá 8 s thì đưa luôn). Đây là lớp bảo hiểm cho mọi loại kẹt (vật cản vô hình, góc hẹp, bậc cao...).
func _jam_check(delta: float) -> void:
	side_t = maxf(side_t - delta, 0.0)
	jam_win_t += delta
	if jam_win_t < 0.5:
		return
	var wanted := want_move_t
	want_move_t = 0.0
	jam_win_t = 0.0
	var moved := Vector2(global_position.x - jam_pos.x, global_position.z - jam_pos.z).length()
	jam_pos = global_position
	if wanted < 0.4 or moved > 0.12 or enemy != null or not alive:
		jam_n = 0
		return
	jam_n += 1
	if jam_n == 2 or jam_n == 3 or jam_n == 4:
		side_t = 0.7
		side_dir = 1.0 if randf() < 0.5 else -1.0
		if is_on_floor():
			velocity.y = 6.0   # nhảy được vật cản thấp (~0.8 m)
	elif jam_n == 5:
		_pick_waypoint()
	elif jam_n >= 7:
		if _unstick_hop():
			jam_n = 0
			side_t = 0.0


## Đưa bot tới điểm kế tiếp (cách >= 2 m) trên đường đi. Trả về false nếu chưa làm được (người chơi đang nhìn thấy bot).
func _unstick_hop() -> bool:
	if main == null or not main.nav_ok:
		return false
	var target := global_position
	if path_i < path.size():
		var k := path.size() - 1
		for j in range(path_i, path.size()):
			if Vector2(path[j].x - global_position.x, path[j].z - global_position.z).length() >= 2.0:
				k = j
				break
		target = path[k]
		path_i = k
	else:
		var fwd := Vector3(-sin(face_yaw), 0.0, -cos(face_yaw))
		target = NavigationServer3D.map_get_closest_point(main.nav_map, global_position + fwd * 2.0)
	if Vector2(target.x - global_position.x, target.z - global_position.z).length() < 0.5:
		_pick_waypoint()
		return false
	if jam_n < 16 and _seen_by_player():
		return false
	global_position = target + Vector3(0.0, 0.1, 0.0)
	velocity = Vector3.ZERO
	return true


## Người chơi đang nhìn thấy bot này (trong tầm nhìn phía trước và không bị tường che)?
func _seen_by_player() -> bool:
	var pl = main.player
	if pl == null or not is_instance_valid(pl) or not pl.is_inside_tree():
		return false
	var eye: Vector3 = pl.global_position + Vector3(0.0, 1.6, 0.0)
	var to := global_position + Vector3(0.0, 1.0, 0.0) - eye
	var flat := Vector3(to.x, 0.0, to.z)
	if flat.length() > 70.0:
		return false
	if flat.length() < 3.0:
		return true
	var fwd := Vector3(-sin(pl.rotation.y), 0.0, -cos(pl.rotation.y))
	if fwd.dot(flat.normalized()) < 0.2:
		return false
	var q := PhysicsRayQueryParameters3D.create(eye, global_position + Vector3(0.0, 1.0, 0.0), 1)
	return get_world_3d().direct_space_state.intersect_ray(q).is_empty()


func _roam(delta: float) -> void:
	# vừa mất dấu địch: khựng lại, nhìn về chỗ vừa thấy (người thật cũng vậy), rồi mới đi tới kiểm tra
	if freeze_t > 0.0:
		freeze_t -= delta
		_steer(Vector3.ZERO, delta)
		var tl := last_seen - global_position
		if Vector2(tl.x, tl.z).length() > 0.5:
			_turn_to(atan2(-tl.x, -tl.z), delta, 9.0, 8.0)
		return
	# vừa rút lui tới chỗ nấp: đứng canh góc, nhìn về phía địch vừa xuất hiện
	if hold_t > 0.0:
		hold_t -= delta
		_steer(Vector3.ZERO, delta)
		var hl := last_seen - global_position
		if Vector2(hl.x, hl.z).length() > 0.5:
			_turn_to(atan2(-hl.x, -hl.z), delta, 4.0, 3.0)
		return
	# chế độ ĐẶT BOM: nhiệm vụ riêng (đi đặt bom, đặt bom, nhặt bom, gỡ bom)
	if main != null and main.bomb != null and main.bomb.active and main.bomb.bot_special(self, delta):
		return
	# đi kiểm tra chỗ vừa thấy / nghe thấy địch (thận trọng, không chạy hết tốc độ)
	if has_last_seen and lost_t < 7.0:
		if (not has_goal) or goal.distance_to(last_seen) > 2.0:
			_set_goal(last_seen)
		# kiên nhẫn cao thì đi chậm dò từng góc, hung hăng thì áp sát nhanh
		if _nav_move(SPEED_PATROL * lerpf(0.65, 1.0, aggr), delta):
			has_last_seen = false
			has_goal = false
			wait_t = randf_range(0.6, 1.4)
		return
	has_last_seen = false
	if wait_t > 0.0:
		wait_t -= delta
		_steer(Vector3.ZERO, delta)
		# đứng chờ thì từ từ ngó quanh; chế độ ĐẶT BOM thì nhìn về hướng địch sẽ tới
		look_t -= delta
		if look_t <= 0.0:
			look_t = randf_range(0.9, 2.2)
			if main != null and main.bomb != null and main.bomb.active:
				var ad: Vector3 = main.bomb.approach_dir(self)
				if ad.length() > 0.5:
					look_yaw = atan2(-ad.x, -ad.z) + randf_range(-0.8, 0.8)
				else:
					look_yaw = face_yaw + randf_range(-1.5, 1.5)
			else:
				look_yaw = face_yaw + randf_range(-1.5, 1.5)
		_turn_to(look_yaw, delta, 3.0, 2.2)
		return
	if not has_goal:
		_pick_waypoint()
		walk_mode = randf() < 0.3   # thỉnh thoảng đi bộ chậm thay vì chạy
	var sp := SPEED_PATROL * (0.62 if walk_mode else 1.0)
	if _nav_move(sp, delta):
		has_goal = false
		if main != null and main.bomb != null and main.bomb.active:
			wait_t = float(main.bomb.hold_wait(self))   # giữ vị trí lâu hơn khi đang canh điểm bom
		else:
			wait_t = randf_range(0.6, 2.4)


func _combat(delta: float) -> void:
	var tpos: Vector3 = enemy.global_position
	var to_t := Vector3(tpos.x - global_position.x, 0.0, tpos.z - global_position.z)
	var dist := to_t.length()
	var dir_t := to_t.normalized()
	var want_yaw := atan2(-dir_t.x, -dir_t.z)
	aim_err = angle_difference(face_yaw, want_yaw)
	_turn_to(want_yaw, delta, 14.0, 10.0)
	engage_t += delta
	last_seen_vel = Vector3(enemy.velocity.x, 0.0, enemy.velocity.z)
	# mới thấy địch: giật mình khựng lại một nhịp, xoay người về phía địch rồi mới xử lý
	if react_t > 0.0:
		_steer(Vector3.ZERO, delta, 14.0, 26.0)
		return

	# máu yếu hoặc đang nạp đạn mà địch còn thấy mình: lùi về chỗ nấp thay vì đứng giữa trời (người thật không đứng chịu trận)
	if cover_cd <= 0.0 and dist > 4.0:
		if hp < 38:
			cover_cd = 6.0
			if randf() < 0.8 - aggr * 0.4:
				if _start_retreat(tpos, randf_range(2.0, 3.5)):
					return
		elif reload_t > 0.0:
			cover_cd = 5.0
			if randf() < 0.7:
				if _start_retreat(tpos, reload_t + 0.8):
					return

	if dist > 24.0 and aggr > 0.4 and engage_t > 1.0:
		# còn xa: kẻ hung hăng tiến lại gần theo đường đi (kẻ thủ thì đứng bắn từ xa)
		if (not has_goal) or goal.distance_to(tpos) > 4.0:
			_set_goal(tpos)
		_nav_move(SPEED_PATROL, delta)
	else:
		# nhịp giao tranh kiểu người chơi: đi ngang vài nhịp -> DỪNG HẲN để bắn -> đổi hướng
		cphase_t -= delta
		if cphase_t <= 0.0:
			if cphase == 0:
				cphase = 1
				cphase_t = randf_range(0.35, 0.9) * lerpf(1.2, 0.8, skill)
			else:
				cphase = 0
				cphase_t = randf_range(0.5, 1.1)
				if randf() < 0.7:
					strafe_dir = -strafe_dir
		var mv := Vector3.ZERO
		if cphase == 0:
			var perp := Vector3(-dir_t.z, 0.0, dir_t.x) * strafe_dir
			mv = perp * 0.9
			if dist < 6.0:
				mv -= dir_t * 0.8
			elif dist > 15.0:
				mv += dir_t * lerpf(-0.2, 0.6, aggr)
			mv = mv.normalized() * SPEED_COMBAT * pace
		elif dist < 5.0:
			mv = -dir_t * 1.2   # đứng bắn nhưng lùi nhẹ khi địch quá gần
		_steer(mv, delta, 16.0, 28.0)   # phanh gấp hơn tăng tốc (counter-strafe)

	if reload_t > 0.0:
		return   # đang nạp đạn: không bắn được
	if fire_cd <= 0.0:
		var spd: float = Vector2(velocity.x, velocity.z).length()
		if spd > 2.0 and dist > 9.0 and randf() < lerpf(0.75, 0.45, skill):
			fire_cd = randf_range(0.06, 0.16)   # đang chạy thì chờ dừng lại cho trúng
		elif engage_t > 0.12:
			_shoot(tpos, dist)


func _shoot(tpos: Vector3, dist: float) -> void:
	var wd: Dictionary = Player.WEAPONS[weapon]
	var wc: Dictionary = WEAPON_AI[weapon]
	# nhịp bắn như người: bắn từng loạt ngắn rồi nghỉ (xa = loạt ngắn, gần = xả dài); tốc độ bắn tuỳ khẩu súng
	if burst_left <= 0:
		var br: Array = wc["burst_far"] if dist > 20.0 else (wc["burst_mid"] if dist > 8.0 else wc["burst_near"])
		burst_left = randi_range(int(br[0]), int(br[1]))
		burst_n = 0
	burst_left -= 1
	burst_n += 1
	if burst_left <= 0:
		var pz: Array = wc["pause"]
		fire_cd = randf_range(float(pz[0]), float(pz[1])) * lerpf(1.2, 0.8, skill)
	else:
		var gp: Array = wc["gap"]
		fire_cd = maxf(randf_range(float(gp[0]), float(gp[1])) * lerpf(1.15, 0.9, skill), float(wd["interval"]))
	mag -= 1
	if mag <= 0:
		reload_t = _reload_time()
		burst_left = 0
	recoil = 1.0
	flash.rotation.z = randf() * TAU
	var fs := randf_range(0.8, 1.3)
	flash.scale = Vector3(fs, fs, fs)
	var from := global_position + Vector3(0.0, 1.5, 0.0)
	# thỉnh thoảng nhắm đầu, còn lại nhắm thân
	var head_aim := randf() < lerpf(0.06, 0.28, skill)
	var aim := tpos + Vector3(0.0, 1.62 if head_aim else randf_range(1.0, 1.35), 0.0)
	var dir := (aim - from).normalized()
	# độ lệch: mới bắt đầu giao tranh thì ngắm chưa chuẩn, càng lâu càng chuẩn; chạy / xả đạn dài / địch chạy ngang thì lệch thêm
	var acq := lerpf(2.3, 1.0, clampf(engage_t / lerpf(1.0, 0.45, skill), 0.0, 1.0))
	var spread := (lerpf(4.2, 1.2, skill) + dist * 0.05) * acq * float(wc["spread"])
	var own_v: float = Vector2(velocity.x, velocity.z).length()
	if own_v > 1.0:
		spread += 1.0 + own_v * 0.45
	spread += float(burst_n - 1) * float(wc["kick"])
	if enemy != null and is_instance_valid(enemy):
		var ev := Vector3(enemy.velocity.x, 0.0, enemy.velocity.z)
		var fl := Vector3(tpos.x - global_position.x, 0.0, tpos.z - global_position.z).normalized()
		spread += absf(ev.dot(Vector3(-fl.z, 0.0, fl.x))) * 0.35
	var right := dir.cross(Vector3.UP).normalized()
	var up := right.cross(dir).normalized()
	var ang := randf() * TAU
	var rr := sqrt(randf()) * spread * 0.0174533
	dir = (dir + right * cos(ang) * tan(rr) + up * sin(ang) * tan(rr)).normalized()
	var hit_pos := from + dir * 100.0
	if main:
		var hit: Dictionary = main.trace_shot(from, dir, 100.0, self)
		hit_pos = hit["pos"]
		if hit["kind"] == "combatant":
			var victim = hit["node"]
			if int(victim.team) != team:
				var rel_y: float = hit_pos.y - float(victim.global_position.y)
				var mult := 1.0
				var is_head := false
				if rel_y > 1.5:
					mult = Player.HEAD_MULT
					is_head = true
				elif rel_y < 0.7:
					mult = Player.LEG_MULT
				# sát thương + suy giảm theo khoảng cách đúng bảng súng của người chơi
				var dmg := float(wd["damage"]) * mult * pow(float(wd["falloff"]), from.distance_to(hit_pos) / 12.7)
				victim.take_damage(dmg, self, is_head)
				main.spawn_blood(hit_pos, hit["normal"])
		elif hit["kind"] == "world":
			main.spawn_impact(hit_pos, hit["normal"])
		main.spawn_tracer(from + dir * 0.6, hit_pos)
		main.noise(global_position, 45.0 if weapon != "glock" else 38.0, team)   # tiếng súng: địch gần đó nghe thấy
	if main:
		main.play_at(str(wd["sound"]), global_position, 2.0, randf_range(0.93, 1.07), 70.0)


# =====================================================================
#  ANIMATION
# =====================================================================
## Xoay 1 đoạn chi (hộp kéo dài theo trục -Y) để chỉ theo hướng dir.
func _limb_basis(dir: Vector3, hint: Vector3) -> Basis:
	var ya := -dir
	var xa := hint - ya * hint.dot(ya)
	if xa.length() < 0.001:
		xa = Vector3(0.0, 0.0, 1.0) - ya * ya.z
	xa = xa.normalized()
	var za := xa.cross(ya)
	return Basis(xa, ya, za)


## IK 2 khúc: đặt cánh tay sao cho bàn tay chạm điểm target (toạ độ thân trên).
func _solve_arm(up: Node3D, fore: Node3D, target: Vector3, pole: Vector3, side: float) -> void:
	var shoulder := up.position
	var to_t := target - shoulder
	var dist := to_t.length()
	if dist < 0.001:
		return
	var dir := to_t / dist
	var d := clampf(dist, 0.10, ARM_L1 + ARM_L2 - 0.005)
	var cos_a := (ARM_L1 * ARM_L1 + d * d - ARM_L2 * ARM_L2) / (2.0 * ARM_L1 * d)
	var ang := acos(clampf(cos_a, -1.0, 1.0))
	var pp := pole - dir * pole.dot(dir)
	if pp.length() < 0.001:
		pp = Vector3(side, 0.0, 0.0)
	pp = pp.normalized()
	var upper_dir := dir * cos(ang) + pp * sin(ang)
	var elbow := shoulder + upper_dir * ARM_L1
	var wrist := shoulder + dir * d
	var fore_dir := (wrist - elbow).normalized()
	var hint := Vector3(side, 0.0, 0.0)
	var ub := _limb_basis(upper_dir, hint)
	var fb := _limb_basis(fore_dir, hint)
	up.transform = Transform3D(ub, shoulder)
	fore.transform = Transform3D(ub.inverse() * fb, Vector3(0.0, -ARM_L1, 0.0))


func _process(delta: float) -> void:
	delta = minf(delta, 0.05)
	# TIẾT KIỆM CPU: bot đang sống mà người chơi không thấy (sau lưng / ngoài rìa màn hình) thì bỏ qua animation + IK tay (rất tốn trên máy yếu);
	# bot ở xa (> 45 m) cập nhật nửa số khung hình. Thời gian bỏ qua được cộng dồn để vào lại tầm nhìn không bị khựng.
	if alive and not _needs_anim():
		anim_acc = minf(anim_acc + delta, 0.2)
		visual.position = (prev_pos - curr_pos) * (1.0 - Engine.get_physics_interpolation_fraction())
		return
	var dt := minf(delta + anim_acc, 0.2)
	anim_acc = 0.0
	if alive:
		_animate_alive(dt)
	else:
		_animate_dead(delta)
	if rig != null:
		rig.drive(self, HIP_Y, ARM_L2)
	# vẽ nhân vật ở vị trí nội suy giữa 2 nhịp vật lý -> mượt dù FPS không đúng 60
	visual.position = (prev_pos - curr_pos) * (1.0 - Engine.get_physics_interpolation_fraction())


## Người chơi có đang thấy bot này không? (camera 3D của main; góc ~78 độ quanh hướng nhìn là rộng hơn hẳn nửa màn hình 16:9 = 56 độ)
func _needs_anim() -> bool:
	if main == null or main.cam3d == null:
		return true
	var cam: Camera3D = main.cam3d
	var to := global_position - cam.global_position
	var d := to.length()
	if d < 5.0:
		return true
	var fwd := -cam.global_transform.basis.z
	if fwd.dot(to / d) < 0.2:
		return false
	if d > 45.0:
		return (Engine.get_frames_drawn() + get_instance_id()) % 2 == 0
	return true


func _animate_alive(delta: float) -> void:
	anim_time += delta
	visual.rotation.y = face_yaw
	# vận tốc làm mượt: animation không bị giật khi bot đổi hướng / dừng đột ngột
	var vel := Vector3(velocity.x, 0.0, velocity.z)
	anim_vel = anim_vel.lerp(vel, 1.0 - exp(-9.0 * delta))
	var speed := anim_vel.length()
	var yr := angle_difference(prev_yaw, face_yaw) / maxf(delta, 0.0001)
	prev_yaw = face_yaw
	yaw_rate = lerpf(yaw_rate, clampf(yr, -8.0, 8.0), 1.0 - exp(-10.0 * delta))
	var dirn := Vector3.ZERO
	if speed > 0.15:
		dirn = (anim_vel / speed).rotated(Vector3.UP, -face_yaw)   # hướng đi theo toạ độ của thân (-Z = tiến)

	# --- hướng chân: chạy theo hướng di chuyển (ngang / chéo / lùi), thân trên vẫn nhìn về phía ngắm ---
	if speed > 0.35:
		var a := atan2(-dirn.x, -dirn.z)
		if leg_back and absf(a) < PI * 0.5 - 0.3:
			leg_back = false
		elif (not leg_back) and absf(a) > PI * 0.5 + 0.3:
			leg_back = true
		if leg_back:
			a -= signf(a) * PI
		leg_yaw = lerp_angle(leg_yaw, a, 1.0 - exp(-10.0 * delta))
	else:
		# đứng yên: chân từ từ xoay về hướng nhìn, hơi trễ so với thân khi quay người
		var lag := -clampf(yaw_rate * 0.10, -0.4, 0.4)
		leg_yaw = lerp_angle(leg_yaw, lag, 1.0 - exp(-4.0 * delta))
	step_dir = lerpf(step_dir, -1.0 if leg_back else 1.0, 1.0 - exp(-14.0 * delta))

	# --- cường độ bước đi, tư thế chiến đấu ---
	gait_amp = lerpf(gait_amp, clampf(speed / 3.2, 0.0, 1.0), 1.0 - exp(-10.0 * delta))
	var turn_amp := clampf(absf(yaw_rate) / 3.5, 0.0, 1.0) * (1.0 - gait_amp)
	walk_phase += speed * delta * 3.0 + absf(yaw_rate) * delta * 1.4 * (1.0 - gait_amp)   # quay người tại chỗ thì bước chân nhỏ
	var in_combat := enemy != null
	aim_t = move_toward(aim_t, 1.0 if in_combat else 0.0, delta * (7.0 if in_combat else 2.5))
	var aim_e := aim_t * aim_t * (3.0 - 2.0 * aim_t)   # vào/ra tư thế ngắm êm, không cứng
	recoil = maxf(recoil - delta * 14.0, 0.0)
	flinch = maxf(flinch - delta * 5.0, 0.0)
	var amp := maxf(gait_amp, turn_amp * 0.6)
	var cr := aim_e * 0.9   # hạ thấp người khi giao tranh (đùi +0.5*cr, cẳng chân -cr)

	# --- aim: góc ngẩng/chúi tới địch, lệch hướng thân ---
	var pitch_target := 0.0
	if in_combat and is_instance_valid(enemy):
		var eye := global_position + Vector3(0.0, 1.5, 0.0)
		var tgt: Vector3 = enemy.global_position + Vector3(0.0, 1.2, 0.0)
		var dd := tgt - eye
		var hd := Vector2(dd.x, dd.z).length()
		pitch_target = clampf(atan2(dd.y, maxf(hd, 0.5)), -0.6, 0.6)
	else:
		aim_err = 0.0
	aim_pitch = lerpf(aim_pitch, pitch_target, 1.0 - exp(-10.0 * delta))
	aim_err_s = lerpf(aim_err_s, aim_err, 1.0 - exp(-14.0 * delta))

	# --- chân: đùi đá tới/lui, gối gập (nhiều nhất lúc đưa chân), bàn chân luôn bám mặt đất ---
	for i in 2:
		var p := walk_phase + float(i) * PI
		var sx := -1.0 if i == 0 else 1.0
		var th: Node3D = thigh[i]
		var sh: Node3D = shin[i]
		var ft: Node3D = foot[i]
		var s2 := sin(p) * step_dir                  # >0: chân đang ở phía trước thân
		var fwd := cos(p) * step_dir                 # >0: chân đang đưa về phía trước
		var ph := fposmod(p, TAU)
		var load := 0.0                              # gối khuỵu nhẹ lúc chân vừa chạm đất nhận trọng lượng
		if ph > PI * 0.5 and ph < PI:
			load = sin((ph - PI * 0.5) * 2.0) * 0.2
		th.rotation = Vector3(
			s2 * 0.62 * amp + cr * 0.5,
			0.0,
			sx * (0.03 * amp + 0.07 * aim_t))
		sh.rotation = Vector3(-((maxf(0.0, fwd) * 0.9 + load) * amp + cr), 0.0, 0.0)
		# bù góc đùi + cẳng chân để bàn chân phẳng; nhón gót khi đẩy, hất mũi chân khi sắp chạm đất
		ft.rotation = Vector3(-(th.rotation.x + sh.rotation.x) + (-0.5 * maxf(0.0, -s2) + 0.22 * maxf(0.0, s2)) * amp, 0.0, 0.0)

	# --- hông: nhấp nhô, đảo hông nhẹ, xoay hông theo nhịp bước (dáng đi tự nhiên) ---
	var breathe := sin(anim_time * 1.8 + look_seed)
	var sp := sin(walk_phase)
	var idle := 1.0 - amp
	hips.position = Vector3(
		sp * 0.016 * amp + sin(anim_time * 0.5 + look_seed) * 0.008 * idle,
		HIP_Y - HIP_Y * (1.0 - cos(0.5 * cr)) - 0.045 * amp * sp * sp + breathe * 0.003,
		0.0)
	var twist := sp * 0.10 * amp
	hips.rotation = Vector3(0.0, leg_yaw + twist, sp * 0.035 * amp)

	# --- thân trên: giữ hướng ngắm (bù lại góc xoay của hông), nghiêng người theo hướng chạy ---
	var upper_yaw := clampf(aim_err_s, -0.6, 0.6) * 0.8 * aim_e + leg_yaw * 0.2 - twist * 0.5
	torso.rotation = Vector3(
		0.10 * gait_amp * dirn.z + 0.30 * flinch + 0.03 * recoil,
		upper_yaw - hips.rotation.y,
		flinch_side * 0.18 * flinch - hips.rotation.z * 0.8 - 0.05 * gait_amp * dirn.x + 0.03 * clampf(yaw_rate, -3.0, 3.0) * gait_amp)
	var look := 0.0
	if not in_combat and speed < 0.5:
		look = sin(anim_time * 0.6 + look_seed) * 0.6    # đứng yên thì nhìn quanh
	head.rotation = Vector3(
		aim_pitch * 0.8 - 0.5 * flinch - torso.rotation.x * 0.5,
		look - upper_yaw * 0.6,
		0.08 * aim_e - torso.rotation.z * 0.5)

	# --- súng: thấp khi đi tuần, tì vai khi ngắm; nảy nhẹ theo bước chạy; giật khi bắn ---
	var gp := pose_ready_pos.lerp(pose_aim_pos, aim_e)
	gp.y += breathe * 0.002 + sin(walk_phase * 2.0) * 0.010 * amp * (1.0 - aim_e * 0.6)
	gp.x += sp * 0.008 * amp * (1.0 - aim_e * 0.6)
	gp.z += 0.05 * recoil
	var gr := Vector3(
		lerpf(pose_ready_rot.x, aim_pitch, aim_e) + 0.06 * recoil + 0.15 * flinch,
		lerpf(pose_ready_rot.y, 0.0, aim_e),
		0.0)
	gun.transform = Transform3D(Basis.from_euler(gr), gp)
	flash.visible = recoil > 0.7

	# --- hai tay bám theo súng bằng IK ---
	var ph_r: Vector3 = gun.transform * grip_r
	var ph_l: Vector3 = gun.transform * grip_l
	_solve_arm(up_arm[1], fore_arm[1], ph_r, POLE_R, 1.0)
	_solve_arm(up_arm[0], fore_arm[0], ph_l, POLE_L, -1.0)


func _start_death_anim(attacker, headshot: bool) -> void:
	death_t = 0.0
	death_hip_yaw = hips.rotation.y
	death_torso_yaw = torso.rotation.y
	flash.visible = false
	var d := Vector3(0.0, 0.0, 1.0)   # mặc định ngã ngửa ra sau
	if attacker != null and is_instance_valid(attacker):
		var away: Vector3 = global_position - attacker.global_position
		away.y = 0.0
		if away.length() > 0.1:
			d = away.normalized().rotated(Vector3.UP, -face_yaw)
	death_dir = d
	death_q = [up_arm[0].quaternion, up_arm[1].quaternion, fore_arm[0].quaternion, fore_arm[1].quaternion]
	# súng văng ra khỏi tay
	var gt := gun.global_transform
	gun.top_level = true
	gun.global_transform = gt
	gun_dropped = true
	gun_floor = global_position.y + 0.04
	gun_vel = Vector3(velocity.x * 0.5 + randf_range(-0.8, 0.8), 1.6 if headshot else 1.2, velocity.z * 0.5 + randf_range(-0.8, 0.8))
	gun_spin = Vector3(randf_range(-6.0, 6.0), randf_range(-6.0, 6.0), randf_range(-6.0, 6.0))


func _animate_dead(delta: float) -> void:
	death_t += delta
	var buckle := clampf(death_t / 0.30, 0.0, 1.0)                 # gối khuỵu xuống
	var fall := clampf((death_t - 0.08) / 0.55, 0.0, 1.0)           # thân đổ
	var fall_ang := 1.52 * fall * fall
	# đổ theo hướng death_dir (quanh trục ngang đi qua chân), có nảy nhẹ khi chạm đất
	var axis := Vector3.UP.cross(death_dir)
	if axis.length() > 0.001:
		body.basis = Basis(axis.normalized(), fall_ang)
	var bounce := 0.0
	if death_t > 0.63 and death_t < 0.9:
		bounce = sin((death_t - 0.63) / 0.27 * PI) * 0.05
	body.position.y = 0.13 * fall + bounce

	# chân khuỵu rồi buông thõng
	var cr := buckle * 0.9
	for i in 2:
		var sx := -1.0 if i == 0 else 1.0
		var th: Node3D = thigh[i]
		var sh: Node3D = shin[i]
		var splay := fall * (0.15 + 0.12 * float(i) * death_seed)
		th.rotation = Vector3(cr * 0.5 + fall * 0.25 * (1.0 if i == 0 else -0.4), 0.0, sx * splay)
		sh.rotation = Vector3(-cr * (1.0 - 0.5 * fall), 0.0, 0.0)
		(foot[i] as Node3D).rotation = Vector3.ZERO
	var blend := 1.0 - clampf(death_t / 0.3, 0.0, 1.0)
	hips.position = Vector3(hips.position.x * blend, HIP_Y - HIP_Y * (1.0 - cos(0.5 * cr)), 0.0)
	hips.rotation = Vector3(0.0, death_hip_yaw * blend, 0.0)
	torso.rotation = Vector3(0.25 * fall, death_seed * 0.15 * fall + death_torso_yaw * blend, death_seed * 0.12 * fall)
	head.rotation = Vector3(0.35 * fall * (1.0 if death_dir.z > 0.0 else -1.0), death_seed * 0.3 * fall, 0.12 * fall * death_seed)

	# tay buông ra hai bên
	var k := clampf(death_t / 0.35, 0.0, 1.0)
	k = k * k * (3.0 - 2.0 * k)
	for i in 2:
		var sx2 := -1.0 if i == 0 else 1.0
		var tu := Quaternion(Basis.from_euler(Vector3(-0.25, 0.0, sx2 * (0.55 + 0.7 * fall))))
		var tf := Quaternion(Basis.from_euler(Vector3(-0.6 - 0.3 * fall, 0.0, 0.0)))
		var qu: Quaternion = death_q[i]
		var qf: Quaternion = death_q[2 + i]
		up_arm[i].quaternion = qu.slerp(tu, k)
		fore_arm[i].quaternion = qf.slerp(tf, k)
		up_arm[i].position = Vector3(SHOULDER_X * sx2, SHOULDER_Y, 0.0)
		fore_arm[i].position = Vector3(0.0, -ARM_L1, 0.0)

	# súng rơi xuống đất
	if gun_dropped:
		gun_vel.y -= 14.0 * delta
		var gpos := gun.global_position + gun_vel * delta
		if gpos.y < gun_floor:
			gpos.y = gun_floor
			gun_vel = gun_vel * exp(-8.0 * delta)
			gun_vel.y = 0.0
			gun_spin = gun_spin * exp(-10.0 * delta)
		gun.global_position = gpos
		gun.rotate_x(gun_spin.x * delta)
		gun.rotate_y(gun_spin.y * delta)
		gun.rotate_z(gun_spin.z * delta)


func debug_text() -> String:
	var st := "COMBAT" if enemy != null else ("INVESTIGATE" if (has_last_seen and lost_t < 7.0) else ("WAIT" if wait_t > 0.0 else ("MOVE" if has_goal else "IDLE")))
	return "%s T%d hp%d (%.0f, %.1f, %.0f) %s fire_cd=%.2f" % [display_name, team, hp, global_position.x, global_position.y, global_position.z, st, fire_cd]


## Bot tự bước lên bậc thềm thấp (giống người chơi): bị chặn thì nhấc lên, tiến tới, hạ xuống.
const STEP_H := 0.55
const STEP_HEIGHTS := [0.24, 0.42, 0.6]      # thử từ thấp tới cao: bậc nhỏ thì nhấc ít cho khỏi đụng bậc kế
const STEP_FWD := [0.2, 0.3, 0.42, 0.55]    # độ dài bước tới sau khi nhấc (thử từ ngắn tới dài)
var floor_t := 1.0   # thời gian kể từ lần cuối đứng trên sàn (cho phép bước bậc ngay sau khi hụt chân)
var step_cd := 0.0   # vừa tìm bậc thềm mà không được thì nghỉ một chút (mỗi lần tìm tốn tới ~27 test_move, bot cọ tường thì lặp mỗi nhịp rất nặng)

func _slide_with_step(delta: float) -> void:
	step_cd = maxf(step_cd - delta, 0.0)
	var was_floor := is_on_floor()
	var start := global_position
	var vb := velocity
	move_and_slide()
	if vb.y > 3.0:
		return
	var hv := Vector3(vb.x, 0.0, vb.z)
	if hv.length() < 0.3:
		return
	var dir := hv.normalized()
	if not (was_floor or is_on_floor() or floor_t < 0.12):
		return
	# bị chặn bởi bức tường / mép bậc thềm đúng hướng đang đi?
	var blocked := false
	for i in get_slide_collision_count():
		var cn := get_slide_collision(i).get_normal()
		if cn.y < 0.3 and (-cn).dot(dir) > 0.2:
			blocked = true
	var moved := Vector3(global_position.x - start.x, 0.0, global_position.z - start.z)
	if (not blocked) and moved.length() > hv.length() * delta * 0.6:
		return
	if step_cd > 0.0:
		return
	var from := Transform3D(global_transform.basis, start)
	# thử nhiều độ cao và nhiều độ dài bước tới (bậc thang liên tiếp: bước tới quá xa sẽ đụng bậc kế tiếp)
	for h in STEP_HEIGHTS:
		var hh: float = h
		if test_move(from, Vector3.UP * hh):
			break   # đụng trần: nhấc cao hơn cũng không được
		var up_t := from.translated(Vector3.UP * hh)
		for f in STEP_FWD:
			var ff: float = f
			var fwd: Vector3 = dir * ff
			if test_move(up_t, fwd):
				continue
			var fwd_t := up_t.translated(fwd)
			var col := KinematicCollision3D.new()
			if not test_move(fwd_t, Vector3.DOWN * (hh + 0.08), col):
				continue
			if col.get_normal().y < 0.6:
				continue
			var new_y := start.y + hh + col.get_travel().y
			if new_y - start.y < 0.004:
				continue
			global_position = Vector3(start.x + fwd.x, new_y, start.z + fwd.z)
			velocity.x = vb.x
			velocity.z = vb.z
			velocity.y = 0.0
			floor_t = 0.0
			return
	step_cd = 0.15   # không có bậc nào bước lên được: 0.15 s nữa mới thử lại


## Số đạn một băng của súng đang cầm (lấy từ bảng súng của người chơi).
func _mag_size() -> int:
	return int(Player.WEAPONS[weapon]["mag"])


func _reload_time() -> float:
	return float((WEAPON_AI[weapon] as Dictionary)["reload"]) * randf_range(0.95, 1.1)


func _finish_reload() -> void:
	var msz := _mag_size()
	var take := mini(msz - mag, res)
	mag += take
	res -= take
	if mag <= 0:
		if weapon != "glock":
			set_weapon("glock")   # hết sạch đạn súng chính: rút súng lục
		else:
			res = 51
			mag = mini(msz, res)
			res -= mag
	if main:
		main.play_at("mag_in", global_position, -4.0, 1.0, 30.0)


## Đổi súng cầm (thay mô hình, băng đạn, vị trí tay bám).
func set_weapon(id: String) -> void:
	if not Player.WEAPONS.has(id) or not WEAPON_AI.has(id):
		id = "glock"
	weapon = id
	var wd: Dictionary = Player.WEAPONS[id]
	mag = int(wd["mag"])
	res = int(wd["reserve"])
	reload_t = 0.0
	burst_left = 0
	_apply_weapon_visual()


## Dựng lại mô hình súng bot cầm theo khẩu đang dùng: dùng đúng mô hình súng rơi dưới đất của game (pickups.gd).
func _apply_weapon_visual() -> void:
	if gun == null:
		return
	var wc: Dictionary = WEAPON_AI[weapon]
	grip_r = wc["grip_r"]
	grip_l = wc["grip_l"]
	pose_ready_pos = wc["ready_pos"]
	pose_ready_rot = wc["ready_rot"]
	pose_aim_pos = wc["aim_pos"]
	if flash != null:
		flash.position = Vector3(0.0, 0.012, float(wc["muzzle"]))
	if main == null or main.pickups == null:
		return
	var root: Node3D = main.pickups._build_model(weapon)
	if root == null or root.get_child_count() == 0:
		return
	for c in gun.get_children():
		if c != flash:
			c.queue_free()
	var m: Node3D = root.get_child(0)
	root.remove_child(m)
	m.rotation = Vector3.ZERO   # trong game súng rơi nằm nghiêng; khi cầm thì dựng thẳng, nòng hướng -Z
	gun.add_child(m)
	root.queue_free()
	visual_weapon = weapon


## Đầu round (chế độ ĐẶT BOM) hoặc mỗi lần hồi sinh (ĐẤU ĐỘI): lost = mất súng cũ (chết / hết trận), full = đầu trận (về $800 + súng lục).
func round_start(full: bool, lost: bool) -> void:
	if full:
		money = 800
		lost = true
	if lost:
		set_weapon("glock")
	elif Player.SLOT_OF.get(weapon, "") == "primary":
		set_weapon(weapon)   # còn sống: giữ súng, nạp đầy
	_buy(full)


## Mua súng theo tiền như người chơi: đủ tiền thì mua súng trường (T = AK-47, CT = M4A1), thiếu tiền thì giữ súng lục / thỉnh thoảng mua Desert Eagle.
func _buy(pistol_round: bool) -> void:
	if Player.SLOT_OF.get(weapon, "") == "primary":
		return   # đã có súng trường (giữ từ round trước)
	var rifle := "ak47" if team == 1 else "m4a1"
	var price := PRICE_RIFLE_T if team == 1 else PRICE_RIFLE_CT
	if money >= price:
		money -= price
		set_weapon(rifle)
	elif weapon == "glock" and money >= PRICE_DEAGLE and randf() < (0.35 if pistol_round else 0.2):
		money -= PRICE_DEAGLE
		set_weapon("deagle")
