extends Node3D
const Hands := preload("res://scripts/hands.gd")
## Bom C4 cầm trên tay (góc nhìn thứ nhất). Chỉ dùng trong chế độ ĐẶT BOM: T mang bom bấm phím 6 để cầm,
## đứng trong vùng A/B và giữ chuột trái để đặt. Cùng giao diện (API) với Viewmodel / Rifle / Knife để Player dùng chung.

signal sound(sound_name: String)
signal reload_inserted()
signal action_finished(action_name: String)

const HIP_POS := Vector3(0.03, -0.17, -0.36)
const DRAW_TIME := 0.55

enum Mode { NONE, DRAW, RELOAD, INSPECT }

var move_amount := 0.0
var run_amount := 0.0
var grounded := true
var ads := false
var crouched := false
var mouse_delta := Vector2.ZERO
var wall_push := 0.0
var _wall_s := 0.0
const WALL_BACK := 0.10   # khớp bảng WALL_DIMS trong player.gd
const WALL_RX := 1.30
var ads_t := 0.0
var planting := false          # Player/bomb.gd bật khi đang giữ chuột trái đặt bom: hai tay ấn bom xuống, đèn nháy

var rig: Node3D
var flash: Node3D              # không dùng (giữ cho giống các súng)
var led: MeshInstance3D
var mode: int = Mode.NONE
var mode_t := 0.0
var _time := 0.0
var bob_phase := 0.0
var bob_smooth := 0.0
var press := 0.0


func _ready() -> void:
	flash = Node3D.new()
	flash.visible = false
	add_child(flash)
	rig = Node3D.new()
	add_child(rig)
	_build()


func _box(parent: Node3D, size: Vector3, pos: Vector3, mat: Material, rot: Vector3 = Vector3.ZERO) -> MeshInstance3D:
	var bm := BoxMesh.new()
	bm.size = size
	var mi := MeshInstance3D.new()
	mi.mesh = bm
	mi.material_override = mat
	mi.position = pos
	mi.rotation = rot
	mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	parent.add_child(mi)
	return mi


func _mat(c: Color, rough: float = 0.8) -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.albedo_color = c
	m.roughness = rough
	return m


func _build() -> void:
	var body_m := _mat(Color(0.20, 0.23, 0.15))
	var dark_m := _mat(Color(0.06, 0.06, 0.07))
	var strap_m := _mat(Color(0.12, 0.13, 0.10))
	# thân bom: khối chữ nhật + hai đai + mặt hiển thị + đèn
	_box(rig, Vector3(0.20, 0.060, 0.28), Vector3.ZERO, body_m)
	_box(rig, Vector3(0.205, 0.064, 0.030), Vector3(0.0, 0.0, -0.07), strap_m)
	_box(rig, Vector3(0.205, 0.064, 0.030), Vector3(0.0, 0.0, 0.07), strap_m)
	_box(rig, Vector3(0.12, 0.008, 0.075), Vector3(0.0, 0.034, 0.015), dark_m)
	var lm := StandardMaterial3D.new()
	lm.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	lm.albedo_color = Color(1.0, 0.12, 0.05)
	led = _box(rig, Vector3(0.050, 0.006, 0.024), Vector3(0.0, 0.039, 0.015), lm)
	var gm := StandardMaterial3D.new()
	gm.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	gm.albedo_color = Color(0.2, 0.9, 0.3)
	_box(rig, Vector3(0.030, 0.006, 0.012), Vector3(-0.035, 0.039, -0.020), gm)
	# dây điện
	_box(rig, Vector3(0.008, 0.008, 0.10), Vector3(0.070, 0.036, -0.050), _mat(Color(0.8, 0.1, 0.1)))
	_box(rig, Vector3(0.008, 0.008, 0.10), Vector3(0.085, 0.036, -0.050), _mat(Color(0.1, 0.2, 0.8)))
	# hai bàn tay ôm hai bên + hai cánh tay chúc xuống mép dưới màn hình
	var hm := Hands.material()
	_box(rig, Vector3(0.055, 0.070, 0.120), Vector3(-0.125, 0.004, 0.020), hm)
	_box(rig, Vector3(0.055, 0.070, 0.120), Vector3(0.125, 0.004, 0.020), hm)
	_box(rig, Vector3(0.050, 0.050, 0.42), Vector3(-0.150, -0.075, 0.30), hm, Vector3(-0.30, -0.10, 0.0))
	_box(rig, Vector3(0.050, 0.050, 0.42), Vector3(0.150, -0.075, 0.30), hm, Vector3(-0.30, 0.10, 0.0))


# =====================================================================
#  API CHO PLAYER
# =====================================================================
func is_busy() -> bool:
	return mode != Mode.NONE


func current_mode() -> int:
	return mode


func play_draw() -> void:
	mode = Mode.DRAW
	mode_t = 0.0
	sound.emit("rustle")


func play_reload(_empty: bool) -> float:
	return 0.0


func play_inspect() -> void:
	pass


func cancel() -> void:
	mode = Mode.NONE
	mode_t = 0.0


func set_slide_locked(_locked: bool) -> void:
	pass


func land(_strength: float) -> void:
	pass


func fire(_last_round: bool) -> void:
	pass


func dry_fire() -> void:
	pass


# =====================================================================
func _process(delta: float) -> void:
	delta = minf(delta, 0.05)
	_time += delta
	var draw := 1.0
	if mode == Mode.DRAW:
		mode_t += delta
		var k := clampf(mode_t / DRAW_TIME, 0.0, 1.0)
		draw = 1.0 - pow(1.0 - k, 3.0)
		if k >= 1.0:
			mode = Mode.NONE
			action_finished.emit("draw")
	press = lerpf(press, 1.0 if planting else 0.0, 1.0 - exp(-12.0 * delta))
	if move_amount > 0.05 and grounded:
		bob_phase += delta * (5.5 + 5.5 * move_amount)
	var bob_amp := move_amount * (0.6 if crouched else 1.0)
	if not grounded:
		bob_amp = 0.0
	bob_smooth = lerpf(bob_smooth, bob_amp, 1.0 - exp(-10.0 * delta))
	var pos := HIP_POS + Vector3(0.0, -0.32 * (1.0 - draw), 0.12 * (1.0 - draw))
	pos += Vector3(cos(bob_phase) * 0.007, sin(bob_phase * 2.0) * 0.006, 0.0) * bob_smooth
	pos.y += sin(_time * 1.7) * 0.001
	pos += Vector3(0.0, -0.030, 0.0) * press + Vector3(0.0, 0.004, 0.0) * sin(_time * 18.0) * press
	_wall_s = lerpf(_wall_s, wall_push, 1.0 - exp(-(28.0 if wall_push > _wall_s else 9.0) * delta))
	pos += Vector3(0.0, -0.03, WALL_BACK) * _wall_s
	var rot := Vector3(-0.10 * draw - 0.18 * press - WALL_RX * _wall_s, 0.0, 0.0)
	rot += Vector3(sin(bob_phase * 2.0) * 0.015, cos(bob_phase) * 0.02, cos(bob_phase) * 0.03) * bob_smooth
	rig.position = pos
	rig.rotation = rot
	led.visible = (not planting) or fmod(_time, 0.2) < 0.1
	mouse_delta = Vector2.ZERO
