Cong cu doi model CS 1.6 (.mdl) sang .glb (khong dung khi choi game, Godot bo qua thu muc nay neu co file .gdignore).
  python3 mdl2glb.py Faithful_terror.mdl terror.glb     (can numpy + Pillow)
  python3 render.py terror.glb xem_thu.png idle1 0       (ve thu 3 goc nhin de kiem tra)
Model goc: "Faithful - Terrorist" (KobraconSystems, GameBanana).

Model sung goc nhin thu nhat (v_*.mdl, gom ca tay + animation): python3 mdl2glb.py v_awp.mdl v_awp.glb --vm
  (--vm: giu nguyen goc toa do GoldSrc, scale 0.0254 m/inch, khong nang chan cham dat). Dung cho assets/awp/v_awp.glb.
Lap cac vach vo hinh cua map Mirage: python3 fill_hidden_walls.py assets/mirage_map.glb
  (them --atlas de gop moi manh + texture thanh MOT manh MOT texture: nhe may yeu. Dung cho assets/awp/v_awp.glb.)
Giam draw call cua map (gop texture thanh atlas, cat theo o lap): python3 optimize_map.py assets/mirage_map.glb  (chay SAU fill_hidden_walls.py)
glbslim.py da duoc dung de gon 7 model nhan vat (chi giu 16 animation can dung); file goc chua gon khong con trong zip.

mdl2glb.py --atlas: da sua cho texture rong 512 (atlas tu nang len 1024 rong) - dung cho assets/mp5/v_mp5.glb (v_mp5.mdl ban GSG9 trong goi low_poly_mp5-sd).
