import struct, sys, math
import numpy as np

class MDL:
    def __init__(self, path):
        d = open(path,'rb').read(); self.d = d
        assert d[:4]==b'IDST', d[:4]
        self.ver = struct.unpack_from('<i',d,4)[0]
        o = 8+64+4
        self.name = d[8:72].split(b'\0')[0].decode()
        f = struct.unpack_from('<3f3f3f3f3fi',d,o); o += 4*15+4
        self.flags = f[-1]
        names = ['numbones','boneindex','numbonecontrollers','bonecontrollerindex','numhitboxes','hitboxindex',
          'numseq','seqindex','numseqgroups','seqgroupindex','numtextures','textureindex','texturedataindex',
          'numskinref','numskinfamilies','skinindex','numbodyparts','bodypartindex','numattachments','attachmentindex',
          'soundtable','soundindex','soundgroups','soundgroupindex','numtransitions','transitionindex']
        v = struct.unpack_from('<%di'%len(names),d,o)
        for n,x in zip(names,v): setattr(self,n,x)
        self.read_bones(); self.read_seqs(); self.read_textures(); self.read_bodyparts()

    def read_bones(self):
        d=self.d; self.bones=[]
        for i in range(self.numbones):
            o=self.boneindex+i*112
            nm=d[o:o+32].split(b'\0')[0].decode()
            parent,flags=struct.unpack_from('<ii',d,o+32)
            bc=struct.unpack_from('<6i',d,o+40)
            val=struct.unpack_from('<6f',d,o+64)
            sc=struct.unpack_from('<6f',d,o+88)
            self.bones.append(dict(name=nm,parent=parent,val=val,scale=sc,bc=bc))

    def read_seqs(self):
        d=self.d; self.seqs=[]
        for i in range(self.numseq):
            o=self.seqindex+i*176
            label=d[o:o+32].split(b'\0')[0].decode()
            fps,flags,act,actw,nev,evi,nfr,npiv,piv,mtype,mbone=struct.unpack_from('<fiiiiiiiiii',d,o+32)
            lin=struct.unpack_from('<3f',d,o+76)
            nblend,animindex=struct.unpack_from('<ii',d,o+120)
            o2=o+128
            btype=struct.unpack_from('<2i',d,o2); bstart=struct.unpack_from('<2f',d,o2+8); bend=struct.unpack_from('<2f',d,o2+16)
            bparent,seqgroup=struct.unpack_from('<ii',d,o2+24)
            self.seqs.append(dict(label=label,fps=fps,flags=flags,act=act,nframes=nfr,nblend=nblend,animindex=animindex,
                seqgroup=seqgroup,motiontype=mtype,lin=lin,btype=btype,bstart=bstart,bend=bend))

    def read_textures(self):
        d=self.d; self.tex=[]
        for i in range(self.numtextures):
            o=self.textureindex+i*80
            nm=d[o:o+64].split(b'\0')[0].decode()
            flags,w,h,idx=struct.unpack_from('<iiii',d,o+64)
            pix=np.frombuffer(d,dtype=np.uint8,count=w*h,offset=idx).reshape(h,w)
            pal=np.frombuffer(d,dtype=np.uint8,count=768,offset=idx+w*h).reshape(256,3)
            self.tex.append(dict(name=nm,flags=flags,w=w,h=h,pix=pix,pal=pal))
        o=self.skinindex
        self.skinref=list(struct.unpack_from('<%dh'%(self.numskinref*self.numskinfamilies),d,o))

    def read_bodyparts(self):
        d=self.d; self.bodyparts=[]
        for i in range(self.numbodyparts):
            o=self.bodypartindex+i*76
            nm=d[o:o+64].split(b'\0')[0].decode()
            nmodels,base,modelindex=struct.unpack_from('<iii',d,o+64)
            models=[]
            for m in range(nmodels):
                mo=modelindex+m*112
                mname=d[mo:mo+64].split(b'\0')[0].decode()
                (mtype,rad,nmesh,meshindex,nverts,vertinfo,vertindex,nnorms,norminfo,normindex,ngroups,groupindex)=struct.unpack_from('<ifiiiiiiiiii',d,mo+64)
                vb=np.frombuffer(d,dtype=np.uint8,count=nverts,offset=vertinfo)
                vp=np.frombuffer(d,dtype='<f4',count=nverts*3,offset=vertindex).reshape(-1,3)
                nb=np.frombuffer(d,dtype=np.uint8,count=nnorms,offset=norminfo)
                npn=np.frombuffer(d,dtype='<f4',count=nnorms*3,offset=normindex).reshape(-1,3)
                meshes=[]
                for k in range(nmesh):
                    me=meshindex+k*20
                    ntris,triindex,skinref,nn,ni=struct.unpack_from('<5i',d,me)
                    meshes.append(dict(ntris=ntris,triindex=triindex,skinref=skinref))
                models.append(dict(name=mname,verts=vp,vbone=vb,norms=npn,nbone=nb,meshes=meshes))
            self.bodyparts.append(dict(name=nm,models=models))

    # ----- animation -----
    def seq_data(self, si):
        s=self.seqs[si]
        if s['seqgroup']!=0: return None
        return s

    def anim_frames(self, si, blend=0):
        """returns array [nframes, nbones, 7] (pos3 + quat xyzw) in MDL space"""
        s=self.seqs[si]; d=self.d
        nb=self.numbones; nf=s['nframes']
        base=s['animindex']+blend*nb*12
        out=np.zeros((nf,nb,7),dtype=np.float64)
        for b in range(nb):
            ao=base+b*12
            offs=struct.unpack_from('<6H',d,ao)
            bone=self.bones[b]
            for f in range(nf):
                vals=[0.0]*6
                for c in range(6):
                    v=bone['val'][c]
                    if offs[c]!=0:
                        p=ao+offs[c]; k=f
                        while True:
                            valid,total=d[p],d[p+1]
                            if total>k: break
                            k-=total; p+=(valid+1)*2
                        valid,total=d[p],d[p+1]
                        idx = k if valid>k else valid-1
                        raw=struct.unpack_from('<h',d,p+2+idx*2)[0]
                        v+=raw*bone['scale'][c]
                    vals[c]=v
                out[f,b,0:3]=vals[0:3]
                out[f,b,3:7]=angle_quat(vals[3:6])
        return out

def angle_quat(a):
    sy,cy=math.sin(a[2]*.5),math.cos(a[2]*.5)
    sp,cp=math.sin(a[1]*.5),math.cos(a[1]*.5)
    sr,cr=math.sin(a[0]*.5),math.cos(a[0]*.5)
    return [sr*cp*cy-cr*sp*sy, cr*sp*cy+sr*cp*sy, cr*cp*sy-sr*sp*cy, cr*cp*cy+sr*sp*sy]

if __name__=='__main__':
    m=MDL(sys.argv[1])
    print('ver',m.ver,m.name,'bones',m.numbones,'seq',m.numseq,'seqgroups',m.numseqgroups,'tex',m.numtextures,'bodyparts',m.numbodyparts,'attach',m.numattachments,'skinref',m.numskinref,m.numskinfamilies)
    for i,b in enumerate(m.bones): print(i,b['name'],b['parent'])
    for t in m.tex: print('tex',t['name'],t['w'],t['h'],hex(t['flags']))
    for bp in m.bodyparts:
        print('bodypart',bp['name'],[(mm['name'],len(mm['verts']),[(x['ntris'],x['skinref']) for x in mm['meshes']]) for mm in bp['models']])
    for i,s in enumerate(m.seqs): print(i,s['label'],'fps',s['fps'],'frames',s['nframes'],'blends',s['nblend'],'act',s['act'],'flags',s['flags'],'grp',s['seqgroup'],'mt',s['motiontype'])
