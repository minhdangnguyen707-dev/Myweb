import sys,json,struct,io,numpy as np
from PIL import Image
def load(path):
    b=open(path,'rb').read(); jl,=struct.unpack('<I',b[12:16]); j=json.loads(b[20:20+jl]); off=20+jl+8; return j,b[off:]
def acc(j,bin,i):
    a=j['accessors'][i]; bv=j['bufferViews'][a['bufferView']]
    n={'SCALAR':1,'VEC2':2,'VEC3':3,'VEC4':4,'MAT4':16}[a['type']]
    dt={5126:'<f4',5123:'<u2',5125:'<u4'}[a['componentType']]
    st=bv['byteOffset']+a.get('byteOffset',0)
    return np.frombuffer(bin,dtype=dt,count=a['count']*n,offset=st).reshape(a['count'],n)
def qmat(q):
    x,y,z,w=q
    return np.array([[1-2*(y*y+z*z),2*(x*y-z*w),2*(x*z+y*w)],[2*(x*y+z*w),1-2*(x*x+z*z),2*(y*z-x*w)],[2*(x*z-y*w),2*(y*z+x*w),1-2*(x*x+y*y)]])
def pose_world(j,anim=None,frame=0):
    nodes=j['nodes']; nb=len(j['skins'][0]['joints']); par=[-1]*len(nodes)
    for i,n in enumerate(nodes):
        for c in n.get('children',[]): par[c]=i if i<nb else -1
    loc=[]
    T=[np.array(nodes[i]['translation']) for i in range(nb)]; Q=[np.array(nodes[i]['rotation']) for i in range(nb)]
    if anim is not None:
        a=[x for x in j['animations'] if x['name']==anim][0]
        for ch in a['channels']:
            s=a['samplers'][ch['sampler']]; out=acc(j,BIN,s['output']); k=min(frame,len(out)-1)
            if ch['target']['path']=='translation': T[ch['target']['node']]=out[k]
            else: Q[ch['target']['node']]=out[k]
    W=[None]*nb
    for i in range(nb):
        M=np.eye(4); M[:3,:3]=qmat(Q[i]); M[:3,3]=T[i]; W[i]=M if par[i]<0 else W[par[i]]@M
    return W
def render(path,out,anim=None,frame=0,view='front',size=480):
    global BIN
    j,BIN=load(path); nb=len(j['skins'][0]['joints'])
    ibm=acc(j,BIN,j['skins'][0]['inverseBindMatrices']).reshape(nb,4,4).transpose(0,2,1)
    W=pose_world(j,anim,frame)
    skin=[W[i]@ibm[i] for i in range(nb)]
    imgs=[]
    for im in j['images']:
        bv=j['bufferViews'][im['bufferView']]; imgs.append(np.array(Image.open(io.BytesIO(BIN[bv['byteOffset']:bv['byteOffset']+bv['byteLength']])).convert('RGB')))
    tris=[]
    for pr in j['meshes'][0]['primitives']:
        P=acc(j,BIN,pr['attributes']['POSITION']); UV=acc(j,BIN,pr['attributes']['TEXCOORD_0']); J=acc(j,BIN,pr['attributes']['JOINTS_0'])[:,0]
        I=acc(j,BIN,pr['indices'])[:,0].reshape(-1,3)
        tex=imgs[j['textures'][j['materials'][pr['material']]['pbrMetallicRoughness']['baseColorTexture']['index']]['source']]
        Pw=np.array([ (skin[J[i]]@np.append(P[i],1))[:3] for i in range(len(P))])
        tris.append((Pw,UV,I,tex))
    if view=='front': proj=lambda p:(p[:,0]*-1,p[:,1],p[:,2]*-1)      # camera at +Z looking -Z (character faces +Z)
    elif view=='side': proj=lambda p:(p[:,2],p[:,1],p[:,0])
    else: proj=lambda p:(p[:,0],p[:,1],p[:,2])  # back
    H=size; Wd=size; img=np.full((H,Wd,3),(60,60,70),np.uint8); zb=np.full((H,Wd),1e9)
    allp=np.concatenate([t[0] for t in tris]); x,y,z=proj(allp)
    sc=H*0.9/(y.max()-y.min()); cx=(x.max()+x.min())/2; y0=y.min()
    for Pw,UV,I,tex in tris:
        x,y,z=proj(Pw); sx=(x-cx)*sc+Wd/2; sy=H*0.95-(y-y0)*sc
        th,tw=tex.shape[:2]
        for a,b,c in I:
            xs=sx[[a,b,c]]; ys=sy[[a,b,c]]; zs=z[[a,b,c]]
            # cull back faces by screen winding
            area=(xs[1]-xs[0])*(ys[2]-ys[0])-(xs[2]-xs[0])*(ys[1]-ys[0])
            if area==0: continue
            x0,x1=int(max(xs.min(),0)),int(min(xs.max()+1,Wd-1)); y0_,y1=int(max(ys.min(),0)),int(min(ys.max()+1,H-1))
            if x1<=x0 or y1<=y0_: continue
            gx,gy=np.meshgrid(np.arange(x0,x1+1),np.arange(y0_,y1+1))
            w0=((xs[1]-gx)*(ys[2]-gy)-(xs[2]-gx)*(ys[1]-gy))/area
            w1=((xs[2]-gx)*(ys[0]-gy)-(xs[0]-gx)*(ys[2]-gy))/area
            w2=1-w0-w1
            m=(w0>=-1e-6)&(w1>=-1e-6)&(w2>=-1e-6)
            if not m.any(): continue
            zz=w0*zs[0]+w1*zs[1]+w2*zs[2]
            u=(w0*UV[a,0]+w1*UV[b,0]+w2*UV[c,0]); v=(w0*UV[a,1]+w1*UV[b,1]+w2*UV[c,1])
            col=tex[(np.clip(v,0,.999)*th).astype(int)%th,(np.clip(u,0,.999)*tw).astype(int)%tw]
            sel=m&(zz<zb[gy,gx]); zb[gy[sel],gx[sel]]=zz[sel]; img[gy[sel],gx[sel]]=col[sel]
    Image.fromarray(img).save(out)
if __name__=='__main__':
    path=sys.argv[1]; outp=sys.argv[2]; anim=sys.argv[3] if len(sys.argv)>3 and sys.argv[3]!='-' else None; fr=int(sys.argv[4]) if len(sys.argv)>4 else 0
    imgs=[]
    for v in ['front','side','back']:
        render(path,f'/tmp/claude-0/work_tools/_{v}.png',anim,fr,v); imgs.append(Image.open(f'/tmp/claude-0/work_tools/_{v}.png'))
    W=Image.new('RGB',(480*3,480)); [W.paste(im,(480*i,0)) for i,im in enumerate(imgs)]; W.save(outp)
