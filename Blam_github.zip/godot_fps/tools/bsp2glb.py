#!/usr/bin/env python3
"""Doi map GoldSrc (.bsp v30, CS 1.6) sang .glb cho Godot.
Dung: python3 bsp2glb.py map.bsp out.glb [scale]
- Truc: Godot X = gs.x, Y = gs.z, Z = -gs.y (nhan scale), dich de CT spawn nam o y = 0, tam map o x,z = 0.
- Texture nhung san trong BSP (ha ve toi da 256 px). Anh sang lightmap nuong vao mau dinh.
- Chia o luoi (chunk) de Godot cat khuat. Mesh co ten ket thuc _hide = vat can vo hinh (chi co va cham).
In ra JSON cau hinh (spawn, bom...) o stdout dong cuoi.
"""
import sys, struct, json, re, io, math
import numpy as np
from PIL import Image

SCALE = float(sys.argv[3]) if len(sys.argv) > 3 else 0.0254
CHUNK = 1280.0
MAXTEX = 256
SKIP_TEX = ('aaatrigger', 'null', 'clip', 'origin', 'hint', 'skip', 'trigger', 'bevel', 'noshot')
HIDE_TEX = ('sky', 'nowallshot', '{invis')   # van la mat vat can nhung khong ve

d = open(sys.argv[1], 'rb').read()
ver = struct.unpack_from('<I', d, 0)[0]
assert ver == 30, 'khong phai BSP v30'
LUMP = [struct.unpack_from('<II', d, 4 + 8 * i) for i in range(15)]
def lump(i): o, l = LUMP[i]; return d[o:o + l]

ent_txt = lump(0).decode('latin1').rstrip('\0')
ENTS = [dict(re.findall(r'"([^"]*)" "([^"]*)"', m.group(1))) for m in re.finditer(r'\{(.*?)\}', ent_txt, re.S)]

verts = np.frombuffer(lump(3), dtype='<f4').reshape(-1, 3).astype(np.float64)
edges = np.frombuffer(lump(12), dtype='<u2').reshape(-1, 2)
surfedges = np.frombuffer(lump(13), dtype='<i4')
planes = []
pl = lump(1)
for i in range(len(pl) // 20):
    nx, ny, nz, dist, t = struct.unpack_from('<4fi', pl, i * 20)
    planes.append((np.array([nx, ny, nz]), dist))
texinfo = []
ti = lump(6)
for i in range(len(ti) // 40):
    v = struct.unpack_from('<8f2i', ti, i * 40)
    texinfo.append((np.array(v[0:3]), v[3], np.array(v[4:7]), v[7], v[8], v[9]))
faces = []
fb = lump(7)
for i in range(len(fb) // 20):
    faces.append(struct.unpack_from('<HHiHH4Bi', fb, i * 20))
light = lump(8)
models = []
mb = lump(14)
for i in range(len(mb) // 64):
    v = struct.unpack_from('<9f7i', mb, i * 64)
    models.append((v[0:3], v[3:6], v[9], v[14], v[15]))  # mins, maxs, headnode0, firstface, numfaces

# ---------- texture ----------
tl = lump(2)
ntex = struct.unpack_from('<I', tl, 0)[0]
toffs = struct.unpack_from('<%di' % ntex, tl, 4)
TEX = []   # dict(name,w,h,img (PIL RGBA or None), masked)
for of in toffs:
    if of < 0:
        TEX.append(None); continue
    name = tl[of:of + 16].split(b'\0')[0].decode('latin1')
    w, h = struct.unpack_from('<II', tl, of + 16)
    o0, o1, o2, o3 = struct.unpack_from('<4I', tl, of + 24)
    if o0 == 0:
        TEX.append(dict(name=name, w=w, h=h, img=None, masked=False)); continue
    idx = np.frombuffer(tl, dtype=np.uint8, count=w * h, offset=of + o0).reshape(h, w)
    pal_off = of + o3 + (w // 8) * (h // 8) + 2
    pal = np.frombuffer(tl, dtype=np.uint8, count=768, offset=pal_off).reshape(256, 3)
    masked = name.startswith('{')
    rgb = pal[idx]
    a = np.full((h, w), 255, np.uint8)
    if masked:
        a[idx == 255] = 0
        # tranh vien xanh: thay diem trong suot bang mau lan can
        rgb = rgb.copy(); rgb[idx == 255] = (0, 0, 0)
    img = Image.fromarray(np.dstack([rgb, a]), 'RGBA')
    TEX.append(dict(name=name, w=w, h=h, img=img, masked=masked))

def tex_name(t):
    n = t['name'] if t else ''
    return n.lstrip('{!+-').lower() if n[:1] in '{!' else n.lower()

# ---------- bao toan he truc ----------
def conv(p):  # gs (x,y,z) -> godot (nhan scale, chua dich)
    return np.array([p[0], p[2], -p[1]]) * SCALE

# ---------- spawn, bom ----------
def origin(e):
    return [float(x) for x in e['origin'].split()]
spawn_ct = [origin(e) for e in ENTS if e['classname'] == 'info_player_start']
spawn_t = [origin(e) for e in ENTS if e['classname'] == 'info_player_deathmatch']
bombs = []
for e in ENTS:
    if e['classname'] == 'func_bomb_target' and 'model' in e:
        m = models[int(e['model'][1:])]
        c = [(m[0][i] + m[1][i]) / 2 for i in range(3)]
        bombs.append(c)
bombs.sort(key=lambda c: c[1])   # A (y am) truoc, B sau
ct_c = np.mean(spawn_ct, axis=0); t_c = np.mean(spawn_t, axis=0)
# dich: tam giua hai phe -> x,z = 0 ; mat dat CT = 0
mid = (ct_c + t_c) / 2
shift_gs = np.array([mid[0], mid[1], float(np.mean([s[2] for s in spawn_ct])) - 36.0])
# (spawn o tam nguoi choi: chan = z - 36)
def tr(p):
    return conv(np.array(p) - shift_gs)

# ---------- lightmap ----------
def face_info(fi):
    pn, side, fe, ne, tinfo, s0, s1, s2, s3, lofs = faces[fi]
    se = surfedges[fe:fe + ne]
    vidx = []
    for e in se:
        if e >= 0: vidx.append(edges[e][0])
        else: vidx.append(edges[-e][1])
    P = verts[vidx]
    return pn, side, tinfo, lofs, P, s0

def lightmap_color(P, st, lofs, s0):
    """tra ve mau (N,3) 0..1 cho tung dinh, hoac None neu mat khong co lightmap"""
    if lofs < 0 or s0 != 0:
        return None
    ts = st
    S = P @ ts[0] + ts[1]; T = P @ ts[2] + ts[3]
    mins_s = math.floor(S.min() / 16); maxs_s = math.ceil(S.max() / 16)
    mins_t = math.floor(T.min() / 16); maxs_t = math.ceil(T.max() / 16)
    w = int(maxs_s - mins_s + 1); h = int(maxs_t - mins_t + 1)
    if w <= 0 or h <= 0 or lofs + w * h * 3 > len(light):
        return None
    lm = np.frombuffer(light, dtype=np.uint8, count=w * h * 3, offset=lofs).reshape(h, w, 3).astype(np.float64)
    u = S / 16.0 - mins_s; v = T / 16.0 - mins_t
    return sample_lm(lm, u, v, w, h)

def sample_lm(lm, u, v, w, h):
    u = np.clip(u, 0, w - 1); v = np.clip(v, 0, h - 1)
    x0 = np.floor(u).astype(int); y0 = np.floor(v).astype(int)
    x1 = np.minimum(x0 + 1, w - 1); y1 = np.minimum(y0 + 1, h - 1)
    fx = (u - x0)[:, None]; fy = (v - y0)[:, None]
    c = (lm[y0, x0] * (1 - fx) * (1 - fy) + lm[y0, x1] * fx * (1 - fy) + lm[y1, x0] * (1 - fx) * fy + lm[y1, x1] * fx * fy)
    return c / 255.0

def shade(c):
    """lightmap (0..1) -> mau dinh tuyen tinh. Quy uoc: gia tri hien thi (sRGB) = nhan voi texture."""
    c = np.clip(c * 1.55 + 0.06, 0.0, 1.0)
    return c ** 2.2

# ---------- chon mat theo model ----------
SOLID_CLASSES = ('func_wall', 'func_breakable')
parts = []   # (model idx, hide)
parts.append((0, False))
for e in ENTS:
    cl = e['classname']
    if cl in SOLID_CLASSES and 'model' in e:
        mi = int(e['model'][1:])
        hide = (cl == 'func_wall' and e.get('rendermode', '0') in ('2', '5') and e.get('renderamt', '255') == '0')
        parts.append((mi, hide))

def subdivide(tri_pos, tri_st, tri_lm, maxedge):
    pass

# ---------- dung mesh ----------
chunks = {}   # (cx,cz,hide) -> {texid: [verts list(pos, uv, col)]}
stat = dict(faces=0, tris=0, skipped=0)
tex_used = set()
MAXEDGE = float(sys.argv[4]) if len(sys.argv) > 4 else 128.0   # don vi gs

def emit(chunk_key, texid, tris):
    chunks.setdefault(chunk_key, {}).setdefault(texid, []).extend(tris)

for mi, hide in parts:
    m = models[mi]
    for fi in range(m[3], m[3] + m[4]):
        pn, side, tinfo, lofs, P, s0 = face_info(fi)
        st = texinfo[tinfo]
        t = TEX[st[4]] if st[4] < len(TEX) else None
        if t is None:
            stat['skipped'] += 1; continue
        nm = t['name'].lower()
        if any(nm.startswith(s) for s in SKIP_TEX):
            stat['skipped'] += 1; continue
        fhide = hide or any(nm.startswith(s) for s in HIDE_TEX)
        if len(P) < 3: continue
        # phap tuyen mat
        nrm, dist = planes[pn]
        if side: nrm = -nrm
        # uv tu texinfo
        S = P @ st[0] + st[1]; T = P @ st[2] + st[3]
        # mau lightmap
        lmcol = None
        lofs_ok = (not fhide) and lofs >= 0 and s0 == 0 and not (st[5] & 0x1)
        if lofs_ok:
            mins_s = math.floor(S.min() / 16); maxs_s = math.ceil(S.max() / 16)
            mins_t = math.floor(T.min() / 16); maxs_t = math.ceil(T.max() / 16)
            lw = int(maxs_s - mins_s + 1); lh = int(maxs_t - mins_t + 1)
            if lw > 0 and lh > 0 and lofs + lw * lh * 3 <= len(light):
                lm = np.frombuffer(light, dtype=np.uint8, count=lw * lh * 3, offset=lofs).reshape(lh, lw, 3).astype(np.float64)
                lmcol = (lm, mins_s, mins_t, lw, lh)
        # tam giac quat, roi chia nho
        poly = [(P[i], S[i], T[i]) for i in range(len(P))]
        base = poly[0]
        work = [(base, poly[i], poly[i + 1]) for i in range(1, len(poly) - 1)]
        out = []
        while work:
            a, b, c = work.pop()
            # canh dai nhat
            es = [(np.linalg.norm(a[0] - b[0]), 0), (np.linalg.norm(b[0] - c[0]), 1), (np.linalg.norm(c[0] - a[0]), 2)]
            ln, which = max(es)
            if ln > MAXEDGE and lmcol is not None:
                pts = [a, b, c]
                p0, p1, p2 = pts[which], pts[(which + 1) % 3], pts[(which + 2) % 3]
                mid = ((p0[0] + p1[0]) / 2, (p0[1] + p1[1]) / 2, (p0[2] + p1[2]) / 2)
                work.append((p0, mid, p2)); work.append((mid, p1, p2))
            else:
                out.append((a, b, c))
        # tam giac va ccham: KHONG chia nho (it canh trong => nguoi choi khong bi vap vao mep tam giac)
        ctris = []
        for i in range(1, len(poly) - 1):
            a, b, c = poly[0], poly[i], poly[i + 1]
            if np.dot(np.cross(b[0] - a[0], c[0] - a[0]), nrm) < 0:
                a, c = c, a
            ctris.append([(q[0], 0.0, 0.0, np.ones(3)) for q in (a, b, c)])
        # huong mat
        tris = []
        for a, b, c in out:
            n = np.cross(b[0] - a[0], c[0] - a[0])
            # chuyen sang he Godot de xet cuon: (x,y,z)->(x,z,-y) la phep quay, nen cuon giu nguyen; tam giac cung chieu nrm => CCW nhin tu ngoai
            if np.dot(n, nrm) < 0:
                a, c = c, a
            tv = []
            for p in (a, b, c):
                u = p[1] / max(1, t['w']); v = p[2] / max(1, t['h'])
                if lmcol is not None:
                    lm, ms, mt, lw, lh = lmcol
                    col = sample_lm(lm, np.array([p[1] / 16.0 - ms]), np.array([p[2] / 16.0 - mt]), lw, lh)[0]
                    col = shade(col)
                else:
                    col = np.array([1.0, 1.0, 1.0]) if not t['name'].startswith('{') else np.array([1.0, 1.0, 1.0])
                    col = col * (0.85 ** 2.2)
                tv.append((p[0], u, v, col))
            tris.append(tv)
        if not tris: continue
        ctr = np.mean(P, axis=0)
        cx_ = int(math.floor((ctr[0] - shift_gs[0]) / CHUNK)); cy_ = int(math.floor((ctr[1] - shift_gs[1]) / CHUNK))
        if fhide:
            emit((cx_, cy_, 'hide'), -1, ctris)           # vat can vo hinh (chi va cham)
        else:
            emit((cx_, cy_, 'vis'), st[4], tris)           # de nhin (chia nho de nuong anh sang), khong va cham
            emit((cx_, cy_, 'col'), -1, ctris)             # va cham (khong chia nho), khong ve
        tex_used.add(-1 if fhide else st[4])
        stat['faces'] += 1; stat['tris'] += len(tris)

print('faces', stat, 'textures used', len(tex_used), file=sys.stderr)

# ---------- ghi glb ----------
bin_chunks = []
def add_blob(b, align=4):
    off = sum(len(x) for x in bin_chunks)
    pad = (-len(b)) % align
    bin_chunks.append(b + b'\0' * pad)
    return off, len(b)

gl = dict(asset=dict(version='2.0', generator='bsp2glb'), scene=0, scenes=[dict(nodes=[])], nodes=[], meshes=[], materials=[], textures=[], images=[], samplers=[dict(magFilter=9729, minFilter=9987, wrapS=10497, wrapT=10497)], accessors=[], bufferViews=[], buffers=[])

mat_of = {}
def get_mat(tid):
    if tid in mat_of: return mat_of[tid]
    if tid < 0:
        gl['materials'].append(dict(name='hidden', pbrMetallicRoughness=dict(baseColorFactor=[0.5, 0.5, 0.5, 1.0], metallicFactor=0.0, roughnessFactor=1.0)))
        mat_of[tid] = len(gl['materials']) - 1
        return mat_of[tid]
    t = TEX[tid]
    pm = dict(metallicFactor=0.0, roughnessFactor=1.0)
    mat = dict(name=t['name'].replace(' ', '_') or 'mat%d' % tid, pbrMetallicRoughness=pm, doubleSided=bool(t['masked']))
    if t['img'] is not None:
        img = t['img']
        w, h = img.size
        sc = min(1.0, MAXTEX / max(w, h))
        if sc < 1.0:
            img = img.resize((max(4, int(w * sc)), max(4, int(h * sc))), Image.LANCZOS)
        buf = io.BytesIO()
        if t['masked']:
            img.save(buf, 'PNG', optimize=True); mime = 'image/png'
        else:
            img.convert('RGB').save(buf, 'JPEG', quality=82); mime = 'image/jpeg'
        off, ln = add_blob(buf.getvalue())
        gl['bufferViews'].append(dict(buffer=0, byteOffset=off, byteLength=ln))
        gl['images'].append(dict(bufferView=len(gl['bufferViews']) - 1, mimeType=mime))
        gl['textures'].append(dict(sampler=0, source=len(gl['images']) - 1))
        pm['baseColorTexture'] = dict(index=len(gl['textures']) - 1)
        if t['masked']:
            mat['alphaMode'] = 'MASK'; mat['alphaCutoff'] = 0.5
    else:
        pm['baseColorFactor'] = [0.55, 0.5, 0.45, 1.0]
    gl['materials'].append(mat)
    mat_of[tid] = len(gl['materials']) - 1
    return mat_of[tid]

def add_acc(arr, ctype, comp, target, with_minmax=False):
    off, ln = add_blob(arr.tobytes())
    gl['bufferViews'].append(dict(buffer=0, byteOffset=off, byteLength=ln, target=target))
    acc = dict(bufferView=len(gl['bufferViews']) - 1, componentType=comp, count=int(len(arr)), type=ctype)
    if with_minmax:
        acc['min'] = [float(x) for x in arr.min(axis=0)]; acc['max'] = [float(x) for x in arr.max(axis=0)]
    gl['accessors'].append(acc)
    return len(gl['accessors']) - 1

for key in sorted(chunks):
    cx, cy, kind = key
    prims = []
    for tid, tris in chunks[key].items():
        pos = []; uv = []; col = []
        for tv in tris:
            for p, u, v, c in tv:
                pos.append(tr(p)); uv.append((u, v)); col.append(c)
        pos = np.array(pos, dtype='<f4'); uv = np.array(uv, dtype='<f4'); col = np.array(col, dtype='<f4')
        if kind != 'vis':
            # mesh vat can: chi can toa do dinh + chi so (khong normal / uv / mau) cho nhe file
            uniq, inv = np.unique(np.round(pos, 5), axis=0, return_inverse=True)
            inv = inv.reshape(-1)
            idx16 = inv.astype('<u4')
            a_pos = add_acc(uniq.astype('<f4'), 'VEC3', 5126, 34962, True)
            a_idx = add_acc(idx16, 'SCALAR', 5125, 34963)
            prims.append(dict(attributes=dict(POSITION=a_pos), indices=a_idx, material=get_mat(tid), mode=4))
            continue
        col4 = np.hstack([col, np.ones((len(col), 1), np.float32)]).astype('<f4')
        # chi so: ghep dinh trung
        keyarr = np.hstack([pos, uv, col4])
        uniq, inv = np.unique(np.round(keyarr, 5), axis=0, return_inverse=True)
        inv = inv.reshape(-1)
        pos_u = uniq[:, 0:3].astype('<f4'); uv_u = uniq[:, 3:5].astype('<f4'); col_u = uniq[:, 5:9].astype('<f4')
        idx = inv.astype('<u4')
        # phap tuyen
        nrm = np.zeros_like(pos_u)
        p3 = pos_u[idx].reshape(-1, 3, 3)
        fn = np.cross(p3[:, 1] - p3[:, 0], p3[:, 2] - p3[:, 0])
        for k in range(3):
            np.add.at(nrm, idx.reshape(-1, 3)[:, k], fn)
        l = np.linalg.norm(nrm, axis=1, keepdims=True); l[l == 0] = 1
        nrm = (nrm / l).astype('<f4')
        a_pos = add_acc(pos_u, 'VEC3', 5126, 34962, True)
        a_nrm = add_acc(nrm, 'VEC3', 5126, 34962)
        a_uv = add_acc(uv_u, 'VEC2', 5126, 34962)
        a_col = add_acc(col_u, 'VEC4', 5126, 34962)
        a_idx = add_acc(idx, 'SCALAR', 5125, 34963)
        prims.append(dict(attributes=dict(POSITION=a_pos, NORMAL=a_nrm, TEXCOORD_0=a_uv, COLOR_0=a_col), indices=a_idx, material=get_mat(tid), mode=4))
    name = {'vis': 'chunk_%d_%d_nocol', 'hide': 'chunk_%d_%d_hide', 'col': 'col_%d_%d_hide'}[kind] % (cx, cy)
    gl['meshes'].append(dict(name=name, primitives=prims))
    gl['nodes'].append(dict(name=name, mesh=len(gl['meshes']) - 1))
    gl['scenes'][0]['nodes'].append(len(gl['nodes']) - 1)

total = sum(len(x) for x in bin_chunks)
gl['buffers'].append(dict(byteLength=total))
js = json.dumps(gl, separators=(',', ':')).encode()
js += b' ' * ((-len(js)) % 4)
binb = b''.join(bin_chunks)
out = struct.pack('<4sII', b'glTF', 2, 12 + 8 + len(js) + 8 + len(binb))
out += struct.pack('<I4s', len(js), b'JSON') + js + struct.pack('<I4s', len(binb), b'BIN\0') + binb
open(sys.argv[2], 'wb').write(out)
print('glb', len(out) / 1e6, 'MB; chunks', len(chunks), file=sys.stderr)

# ---------- cau hinh ----------
allp = np.concatenate([np.array([[q[0] for q in tv] for tv in []] or [[0]*3])]) if False else None
BMIN = np.array([1e9]*3); BMAX = np.array([-1e9]*3)
for key in chunks:
    for tid, tris in chunks[key].items():
        for tv in tris:
            for q in tv:
                w_ = tr(q[0]); BMIN = np.minimum(BMIN, w_); BMAX = np.maximum(BMAX, w_)
def xz(p):
    q = tr(p); return [round(float(q[0]), 2), round(float(q[2]), 2), round(float(q[1]), 2)]
cfg = dict(
    spawn_ct=[xz(s) for s in spawn_ct], spawn_t=[xz(s) for s in spawn_t],
    bombs=[xz(b) for b in bombs],
    ct_center=xz(ct_c), t_center=xz(t_c),
    bounds_min=[round(float(x), 1) for x in BMIN], bounds_max=[round(float(x), 1) for x in BMAX],
)
print(json.dumps(cfg))
