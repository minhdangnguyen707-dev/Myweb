#!/usr/bin/env python3
"""Lam nhe file .glb de nhung vao game: ha texture (toi da N px), chi giu cac animation can dung.
Dung: python3 glbslim.py in.glb out.glb [max_tex=256] [anim1,anim2,...|-] [head_tex=512]
 - anim: danh sach animation giu lai (mac dinh = cac animation ma terror_rig.gd can). '-' = giu het.
 - Keyframe thua (noi suy tuyen tinh tai hien duoc, sai so < 0.1 mm / 1e-4 quaternion) duoc gop lai: animation giu nguyen, file nhe di.
 - Texture co vien trong suot (alphaMode MASK) luu PNG, con lai luu JPEG chat luong 93.
 - Texture cua material ten 'head' / 'eyes' giu do phan giai head_tex (mat nguoi nhin gan).
"""
import sys, struct, json, io
import numpy as np
from PIL import Image

KEEP_DEFAULT = ['idle1', 'idle', 'crouch_idle', 'walk', 'run', 'crouchrun', 'jump', 'head', 'back', 'forward', 'left', 'right',
                'death1', 'death2', 'death3', 'gutshot', 'crouch_die']

def main():
    src, dst = sys.argv[1], sys.argv[2]
    max_tex = int(sys.argv[3]) if len(sys.argv) > 3 else 256
    keep = KEEP_DEFAULT if len(sys.argv) <= 4 else (None if sys.argv[4] == '-' else sys.argv[4].split(','))
    head_tex = int(sys.argv[5]) if len(sys.argv) > 5 else 512
    b = open(src, 'rb').read()
    jl = struct.unpack_from('<I', b, 12)[0]
    g = json.loads(b[20:20 + jl])
    bs = 20 + jl + 8
    bl = struct.unpack_from('<I', b, 20 + jl)[0]
    bb = b[bs:bs + bl]

    # --- animation ---
    if keep is not None:
        g['animations'] = [a for a in g.get('animations', []) if a.get('name') in keep]


    # --- gop keyframe thua (khong doi chuyen dong) ---
    def read_acc(i):
        a = g['accessors'][i]; v = g['bufferViews'][a['bufferView']]
        n = {'SCALAR': 1, 'VEC3': 3, 'VEC4': 4}[a['type']]
        return np.frombuffer(bb, dtype='<f4', count=a['count'] * n, offset=v.get('byteOffset', 0) + a.get('byteOffset', 0)).reshape(a['count'], n).astype(np.float64)
    extra = bytearray(bb)
    def add_acc(arr, typ, with_minmax=False):
        arr = np.ascontiguousarray(arr.astype('<f4'))
        pad = (-len(extra)) % 4
        extra.extend(b'\0' * pad)
        g['bufferViews'].append({'buffer': 0, 'byteOffset': len(extra), 'byteLength': arr.nbytes})
        extra.extend(arr.tobytes())
        acc = {'bufferView': len(g['bufferViews']) - 1, 'componentType': 5126, 'count': int(arr.shape[0]), 'type': typ}
        if with_minmax:
            acc['min'] = [float(arr.min())]; acc['max'] = [float(arr.max())]
        g['accessors'].append(acc)
        return len(g['accessors']) - 1
    def reduce_track(t, v, eps, quat):
        n = len(t)
        if n <= 2: return list(range(n))
        if quat:  # cung dau de noi suy dung
            v = v.copy()
            for i in range(1, n):
                if np.dot(v[i], v[i - 1]) < 0: v[i] = -v[i]
        keep = [0]; a = 0
        while a < n - 1:
            j = a + 1
            while j + 1 < n:
                k = j + 1
                f = ((t[a + 1:k] - t[a]) / (t[k] - t[a]))[:, None]
                est = v[a] + (v[k] - v[a]) * f
                if np.abs(est - v[a + 1:k]).max() > eps: break
                j = k
            keep.append(j); a = j
        return keep
    red_before = red_after = 0
    for an in g.get('animations', []):
        interp = {}
        for ch in an['channels']:
            interp[ch['sampler']] = ch['target']['path']
        done = {}
        for si, sm in enumerate(an['samplers']):
            path = interp.get(si, '')
            if sm.get('interpolation', 'LINEAR') != 'LINEAR' or path not in ('translation', 'rotation', 'scale'):
                continue
            t = read_acc(sm['input'])[:, 0]; v = read_acc(sm['output'])
            red_before += t.size * (1 + v.shape[1])
            keep = reduce_track(t, v, 1e-4, path == 'rotation')
            if path == 'rotation':  # giu dau da doi neu co
                v2 = v.copy()
                for i in range(1, len(v2)):
                    if np.dot(v2[i], v2[i - 1]) < 0: v2[i] = -v2[i]
                v = v2
            kt = t[keep]; kv = v[keep]
            red_after += kt.size * (1 + kv.shape[1])
            sm['input'] = add_acc(kt, 'SCALAR', True)
            sm['output'] = add_acc(kv, 'VEC3' if kv.shape[1] == 3 else 'VEC4')
    bb = bytes(extra)
    print('keyframe data %.2f -> %.2f MB' % (red_before * 4 / 1e6, red_after * 4 / 1e6))

    # --- accessor dung toi ---
    used = []
    def use(i):
        if i is not None and i not in used: used.append(i)
    for m in g['meshes']:
        for p in m['primitives']:
            for v in p['attributes'].values(): use(v)
            use(p.get('indices'))
            for t in p.get('targets', []):
                for v in t.values(): use(v)
    for s in g.get('skins', []): use(s.get('inverseBindMatrices'))
    for a in g.get('animations', []):
        for s in a['samplers']:
            use(s['input']); use(s['output'])
    used.sort()
    amap = {o: n for n, o in enumerate(used)}
    for m in g['meshes']:
        for p in m['primitives']:
            p['attributes'] = {k: amap[v] for k, v in p['attributes'].items()}
            if 'indices' in p: p['indices'] = amap[p['indices']]
            for t in p.get('targets', []):
                for k in list(t): t[k] = amap[t[k]]
    for s in g.get('skins', []):
        if 'inverseBindMatrices' in s: s['inverseBindMatrices'] = amap[s['inverseBindMatrices']]
    for a in g.get('animations', []):
        for s in a['samplers']:
            s['input'] = amap[s['input']]; s['output'] = amap[s['output']]
    old_acc = g['accessors']
    g['accessors'] = [old_acc[i] for i in used]

    # --- ten material cua tung image (de giu mat nguoi ro hon) ---
    img_mat = {}
    tex_img = [t.get('source') for t in g.get('textures', [])]
    for mt in g.get('materials', []):
        pm = mt.get('pbrMetallicRoughness', {})
        bt = pm.get('baseColorTexture')
        if bt is not None:
            img_mat[tex_img[bt['index']]] = (mt.get('name', ''), mt.get('alphaMode', 'OPAQUE'))

    # --- bufferView dung toi ---
    out_bin = bytearray()
    new_views = []
    def add_view(data, src_view=None):
        pad = (-len(out_bin)) % 4
        out_bin.extend(b'\0' * pad)
        v = {'buffer': 0, 'byteOffset': len(out_bin), 'byteLength': len(data)}
        if src_view:
            for k in ('byteStride', 'target'):
                if k in src_view: v[k] = src_view[k]
        out_bin.extend(data)
        new_views.append(v)
        return len(new_views) - 1
    vmap = {}
    old_views = g['bufferViews']
    for a in g['accessors']:
        ov = a['bufferView']
        if ov not in vmap:
            sv = old_views[ov]
            vmap[ov] = add_view(bb[sv['byteOffset']:sv['byteOffset'] + sv['byteLength']], sv)
        a['bufferView'] = vmap[ov]
    tot_before = tot_after = 0
    for i, im in enumerate(g.get('images', [])):
        sv = old_views[im['bufferView']]
        data = bb[sv['byteOffset']:sv['byteOffset'] + sv['byteLength']]
        tot_before += len(data)
        img = Image.open(io.BytesIO(data)); img.load()
        nm, am = img_mat.get(i, ('', 'OPAQUE'))
        lim = head_tex if nm.lower() in ('head', 'eyes') else max_tex
        if im.get('mimeType') == 'image/jpeg' and max(img.size) <= lim:
            tot_after += len(data)   # da la JPEG va khong can thu nho: giu nguyen byte (nen lai se hong chat luong va con nang them)
            im['bufferView'] = add_view(data)
            continue
        if max(img.size) > lim:
            sc = lim / max(img.size)
            img = img.resize((max(4, round(img.size[0] * sc)), max(4, round(img.size[1] * sc))), Image.LANCZOS)
        buf = io.BytesIO()
        has_alpha = img.mode in ('RGBA', 'LA') and img.getchannel('A').getextrema()[0] < 255
        if has_alpha:
            img.convert('RGBA').save(buf, 'PNG', optimize=True); im['mimeType'] = 'image/png'
        else:
            img.convert('RGB').save(buf, 'JPEG', quality=93, optimize=True); im['mimeType'] = 'image/jpeg'
        tot_after += buf.tell()
        im['bufferView'] = add_view(buf.getvalue())
    g['bufferViews'] = new_views
    g['buffers'] = [{'byteLength': len(out_bin)}]
    js = json.dumps(g, separators=(',', ':')).encode()
    js += b' ' * ((-len(js)) % 4)
    out_bin.extend(b'\0' * ((-len(out_bin)) % 4))
    out = struct.pack('<4sII', b'glTF', 2, 12 + 8 + len(js) + 8 + len(out_bin))
    out += struct.pack('<I4s', len(js), b'JSON') + js + struct.pack('<I4s', len(out_bin), b'BIN\0') + bytes(out_bin)
    open(dst, 'wb').write(out)
    print('anim', len(g.get('animations', [])), 'texture %.2f -> %.2f MB' % (tot_before / 1e6, tot_after / 1e6), 'glb %.2f -> %.2f MB' % (len(b) / 1e6, len(out) / 1e6))

main()
