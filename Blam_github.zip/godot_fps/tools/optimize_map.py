#!/usr/bin/env python3
"""Giam so draw call cua map Mirage (card Intel HD 4400 + Godot GL Compatibility rat nhay voi so draw call).

Dung: python3 optimize_map.py in.glb [out.glb]   (ghi de len in.glb neu khong co out.glb)
Chay SAU bsp2glb.py va fill_hidden_walls.py. Script tu dung neu file da duoc toi uu (co mesh chunk_*_atlas_nocol).

Truoc: moi (khu vuc x vat lieu) la mot draw call, 100-550 draw call moi khung hinh, 160 texture rieng.
Sau:   - MOI texture cua mat OPAQUE duoc xep vao MOT tam texture lon (atlas) co vien "lap" (gutter) quanh moi o => khong lo duong noi,
         mipmap sach den muc zoom xa;
       - texture trong map lap lai nhieu lan (UV vuot ngoai 0..1) nen moi mat duoc CAT theo o lap (tung manh co UV trong 0..1 roi doi sang
         toa do trong atlas) - dung StandardMaterial3D binh thuong, KHONG can shader rieng;
       - hinh hoc chia theo khu vuc nhu cu (chunk_<cx>_<cz>_atlas_nocol, 1 mieng / 1 vat lieu) nen Godot van loai bo phan ngoai tam nhin:
         moi khung hinh chi con ~10-30 draw call cho map thay vi 100-550;
       - 16 vat lieu "masked" (hang rao, luoi: can cat alpha) giu nguyen texture rieng, gop thanh 1 mesh world_mask_nocol (16 draw call);
       - mesh va cham / vach vo hinh (col_*_hide, chunk_*_hide) giu nguyen 100%.
Ten mesh ket thuc _nocol -> main.gd khong tao va cham cho chung (nhu cu)."""
import sys, json, struct, io, math, collections
import numpy as np
from PIL import Image

GUTTER = 16          # vien lap quanh moi texture trong atlas (mip den muc 4 van sach)
ATLAS_W = 4096
EPS = 1e-6

src = sys.argv[1]
dst = sys.argv[2] if len(sys.argv) > 2 else src
b = open(src, 'rb').read()
jl, = struct.unpack('<I', b[12:16])
J = json.loads(b[20:20 + jl])
bl, = struct.unpack('<I', b[20 + jl:24 + jl])
BIN = b[28 + jl:28 + jl + bl]

if any(m['name'].endswith('_atlas_nocol') for m in J['meshes']):
    print('File da duoc toi uu (co *_atlas_nocol). Dung lai.'); sys.exit(0)

def acc(i):
    a = J['accessors'][i]; bv = J['bufferViews'][a['bufferView']]
    n = {'SCALAR': 1, 'VEC2': 2, 'VEC3': 3, 'VEC4': 4}[a['type']]
    dt = {5126: '<f4', 5123: '<u2', 5125: '<u4', 5121: 'u1'}[a['componentType']]
    st = bv['byteOffset'] + a.get('byteOffset', 0)
    arr = np.frombuffer(BIN, dtype=dt, count=a['count'] * n, offset=st).reshape(a['count'], n)
    if a.get('normalized') and a['componentType'] == 5121:
        arr = arr.astype(np.float32) / 255.0
    return arr

def image_of_material(mi):
    t = J['materials'][mi]['pbrMetallicRoughness'].get('baseColorTexture')
    return None if t is None else J['textures'][t['index']]['source']

# ---------------- doc du lieu ----------------
vis_meshes = []     # (ten, [prims])
keep_meshes = []    # mesh va cham / vo hinh: giu nguyen
for m in J['meshes']:
    prims = []
    for p in m['primitives']:
        d = dict(mat=p['material'], idx=acc(p['indices']).reshape(-1).astype(np.int64),
                 attrs={k: acc(v) for k, v in p['attributes'].items()})
        prims.append(d)
    (vis_meshes if m['name'].endswith('_nocol') else keep_meshes).append((m['name'], prims))

opaque_imgs = collections.OrderedDict()   # chi so anh goc -> id
for nm, prims in vis_meshes:
    for p in prims:
        mt = J['materials'][p['mat']]
        if mt.get('alphaMode') == 'MASK':
            continue
        im = image_of_material(p['mat'])
        assert im is not None, 'vat lieu OPAQUE khong co texture: ' + mt['name']
        opaque_imgs.setdefault(im, len(opaque_imgs))

def decode(im):
    bv = J['bufferViews'][J['images'][im]['bufferView']]
    return Image.open(io.BytesIO(BIN[bv['byteOffset']:bv['byteOffset'] + bv['byteLength']])).convert('RGB')

# ---------------- xep atlas (shelf) ----------------
items = []
for im, tid in opaque_imgs.items():
    I = decode(im); items.append((tid, im, np.array(I)))
order = sorted(items, key=lambda it: (-it[2].shape[0], -it[2].shape[1]))
place = {}
x = y = rowh = 0
for tid, im, arr in order:
    h, w = arr.shape[:2]
    cw, ch = w + 2 * GUTTER, h + 2 * GUTTER
    cw += (-cw) % 4
    if x + cw > ATLAS_W:
        x = 0; y += rowh; rowh = 0
    place[tid] = (x, y, w, h)
    x += cw; rowh = max(rowh, ch + ((-ch) % 4))
ATLAS_H = y + rowh
ATLAS_H += (-ATLAS_H) % 16
canvas = np.zeros((ATLAS_H, ATLAS_W, 3), np.uint8)
for tid, im, arr in order:
    px, py, w, h = place[tid]
    pad = np.pad(arr, ((GUTTER, GUTTER), (GUTTER, GUTTER), (0, 0)), mode='wrap')   # lap xung quanh = noi lien mach khi texture lap lai
    canvas[py:py + h + 2 * GUTTER, px:px + w + 2 * GUTTER] = pad
print('atlas %d x %d tu %d texture (%.1f%% lap day)' % (ATLAS_W, ATLAS_H, len(items), 100.0 * sum(a.shape[0] * a.shape[1] for _, _, a in items) / (ATLAS_W * ATLAS_H)))
bio = io.BytesIO(); Image.fromarray(canvas, 'RGB').save(bio, 'JPEG', quality=95, subsampling=0, optimize=True)   # texture CS 256 màu: JPEG q95 4:4:4 không thấy khác, nhẹ hơn PNG ~3 lần
atlas_png = bio.getvalue()

# ---------------- cat tam giac theo o lap ----------------
# dinh: [x y z nx ny nz u v r g b a]
def clip(poly, axis, val, keep_ge):
    out = []
    n = len(poly)
    for i in range(n):
        a = poly[i]; c = poly[(i + 1) % n]
        da = a[axis] - val; dc = c[axis] - val
        ina = da >= 0 if keep_ge else da <= 0
        inc = dc >= 0 if keep_ge else dc <= 0
        if ina:
            out.append(a)
        if ina != inc:
            t = da / (da - dc)
            out.append(a + (c - a) * t)
    return out

def pieces(tri_vertices):
    """tam giac (3 dinh) -> list (ku, kv, polygon) moi o lap; polygon co UV goc (chua tru ku, kv)."""
    uv = np.array([v[6:8] for v in tri_vertices])
    u0, v0 = np.floor(uv.min(0) + EPS).astype(int)
    u1, v1 = np.floor(uv.max(0) - EPS).astype(int)
    if u1 < u0: u1 = u0
    if v1 < v0: v1 = v0
    if u0 == u1 and v0 == v1:
        return [(u0, v0, list(tri_vertices))]
    res = []
    for ku in range(u0, u1 + 1):
        pu = clip(clip(list(tri_vertices), 6, ku, True), 6, ku + 1, False) if (u1 > u0) else list(tri_vertices)
        if len(pu) < 3:
            continue
        for kv in range(v0, v1 + 1):
            pv = clip(clip(pu, 7, kv, True), 7, kv + 1, False) if (v1 > v0) else pu
            if len(pv) < 3:
                continue
            res.append((ku, kv, pv))
    return res

chunk_data = collections.defaultdict(lambda: dict(P=[], N=[], UV=[], C=[], I=[], n=0))
mask_data = collections.OrderedDict()      # vat lieu masked -> mang du lieu (giu nguyen)
tri_in = 0; tri_out = 0
for nm, prims in vis_meshes:
    for p in prims:
        mt = J['materials'][p['mat']]
        at = p['attrs']
        P = at['POSITION'].astype(np.float64); N = at['NORMAL'].astype(np.float64); UV = at['TEXCOORD_0'].astype(np.float64)
        C = at['COLOR_0'].astype(np.float64)
        if C.shape[1] == 3:
            C = np.hstack([C, np.ones((len(C), 1))])
        if mt.get('alphaMode') == 'MASK':
            d = mask_data.setdefault(p['mat'], dict(P=[], N=[], UV=[], C=[], I=[], n=0))
            d['P'].append(P); d['N'].append(N); d['UV'].append(UV); d['C'].append(C); d['I'].append(p['idx'] + d['n']); d['n'] += len(P)
            continue
        px, py, w, h = place[opaque_imgs[image_of_material(p['mat'])]]
        dbl = bool(mt.get('doubleSided', False))
        d = chunk_data[(nm.replace('chunk_fill_', 'chunk_'), p['mat'])]   # mảnh lấp vách (chunk_fill_*) gộp vào cùng khu vực
        V = np.hstack([P, N, UV, C])
        idx = p['idx'].reshape(-1, 3)
        tri_in += len(idx)
        for tri in idx:
            for ku, kv, poly in pieces([V[i] for i in tri]):
                if len(poly) < 3:
                    continue
                base = d['n']
                for v in poly:
                    ul = min(max(v[6] - ku, 0.0), 1.0); vl = min(max(v[7] - kv, 0.0), 1.0)
                    d['P'].append(v[0:3]); d['N'].append(v[3:6])
                    d['UV'].append(((px + ul * w) / ATLAS_W, (py + vl * h) / ATLAS_H)); d['C'].append(v[8:12])
                d['n'] += len(poly)
                for k in range(1, len(poly) - 1):
                    d['I'].append((base, base + k, base + k + 1)); tri_out += 1
                    if dbl:
                        d['I'].append((base, base + k + 1, base + k)); tri_out += 1
print('tam giac mat opaque: %d -> %d (chia theo o lap)' % (tri_in, tri_out))

# ---------------- ghi glb moi ----------------
NJ = dict(asset=dict(version='2.0', generator='bsp2glb+optimize_map'), scene=0, scenes=[dict(nodes=[])], nodes=[], meshes=[],
          materials=[], textures=[], images=[], samplers=J['samplers'], accessors=[], bufferViews=[], buffers=[dict(byteLength=0)])
OUT = bytearray()
def add_blob(data):
    off = len(OUT); OUT.extend(data); OUT.extend(b'\0' * ((-len(data)) % 4)); return off
def add_view(data, target=None):
    off = add_blob(data)
    bv = dict(buffer=0, byteOffset=off, byteLength=len(data))
    if target: bv['target'] = target
    NJ['bufferViews'].append(bv); return len(NJ['bufferViews']) - 1
def add_acc(arr, ctype, comp, target, mm=False, normalized=False):
    ac = dict(bufferView=add_view(arr.tobytes(), target), componentType=comp, count=int(len(arr)), type=ctype)
    if normalized: ac['normalized'] = True
    if mm:
        ac['min'] = [float(v) for v in arr.min(axis=0)]; ac['max'] = [float(v) for v in arr.max(axis=0)]
    NJ['accessors'].append(ac); return len(NJ['accessors']) - 1
def add_node(name, mesh):
    NJ['meshes'].append(mesh)
    NJ['nodes'].append(dict(name=name, mesh=len(NJ['meshes']) - 1))
    NJ['scenes'][0]['nodes'].append(len(NJ['nodes']) - 1)

# vat lieu: hidden (cho mesh va cham), atlas, masked
hidden_mat = None
img_remap = {}
def add_image_bytes(raw, name, mime='image/png'):
    NJ['images'].append(dict(bufferView=add_view(raw), mimeType=mime, name=name)); return len(NJ['images']) - 1
def mat_json_copy(mi):
    return json.loads(json.dumps(J['materials'][mi]))

# mesh va cham / vo hinh: giu nguyen
for nm, prims in keep_meshes:
    if hidden_mat is None:
        hidden_mat = len(NJ['materials'])
        NJ['materials'].append(mat_json_copy(prims[0]['mat']))
    out = []
    for p in prims:
        P = p['attrs']['POSITION'].astype('<f4')
        out.append(dict(attributes=dict(POSITION=add_acc(P, 'VEC3', 5126, 34962, True)),
                        indices=add_acc(p['idx'].astype('<u4'), 'SCALAR', 5125, 34963), material=hidden_mat, mode=4))
    add_node(nm, dict(name=nm, primitives=out))

# atlas: 1 vat lieu
atlas_img = add_image_bytes(atlas_png, 'mirage_atlas', 'image/jpeg')
NJ['textures'].append(dict(sampler=0, source=atlas_img))
atlas_mat = len(NJ['materials'])
NJ['materials'].append(dict(name='atlas', pbrMetallicRoughness=dict(baseColorTexture=dict(index=len(NJ['textures']) - 1), metallicFactor=0.0, roughnessFactor=1.0)))

def write_prim(d, mat, quant=True):
    P = np.array(d['P'], np.float64); UV = np.array(d['UV'], np.float64)
    if quant:   # làm tròn toạ độ tới 1 mm và UV tới 1/65536 atlas: mất < 1/16 texel, nhưng nén tốt hơn nhiều (các bit thấp luôn bằng 0)
        P = np.round(P * 1024.0) / 1024.0
        UV = np.round(UV * 65536.0) / 65536.0
    P = P.astype('<f4'); UV = UV.astype('<f4')
    N = np.zeros_like(P); N[:, 1] = 1.0   # map KHÔNG đổ bóng (unshaded) nên pháp tuyến không dùng: hằng số để nén gần như 0 byte
    C = np.clip(np.array(d['C']), 0.0, 1.0)
    C8 = np.round(C * 255.0).astype('u1')
    I = np.array(d['I']).reshape(-1)
    if len(P) < 65536:
        iacc = add_acc(I.astype('<u2'), 'SCALAR', 5123, 34963)
    else:
        iacc = add_acc(I.astype('<u4'), 'SCALAR', 5125, 34963)
    return dict(attributes=dict(POSITION=add_acc(P, 'VEC3', 5126, 34962, True), NORMAL=add_acc(N, 'VEC3', 5126, 34962),
                                TEXCOORD_0=add_acc(UV, 'VEC2', 5126, 34962), COLOR_0=add_acc(C8, 'VEC4', 5121, 34962, False, True)),
                indices=iacc, material=mat, mode=4)

by_chunk = collections.defaultdict(list)
for (nm, mi), d in chunk_data.items():
    by_chunk[nm].append(d)
n_chunk_meshes = 0
for nm in sorted(by_chunk):
    # gop moi vat lieu cua chunk thanh MOT primitive (cung atlas)
    big = dict(P=[], N=[], UV=[], C=[], I=[], n=0)
    for d in by_chunk[nm]:
        base = big['n']
        big['P'] += d['P']; big['N'] += d['N']; big['UV'] += d['UV']; big['C'] += d['C']
        big['I'] += [(a + base, b_ + base, c + base) for a, b_, c in d['I']]
        big['n'] += d['n']
    if not big['I']:
        continue
    name = nm.replace('_nocol', '_atlas_nocol')
    add_node(name, dict(name=name, primitives=[write_prim(big, atlas_mat)]))
    n_chunk_meshes += 1

# masked: giu texture rieng, gop thanh 1 mesh
mask_prims = []
for mi, d in mask_data.items():
    mj = mat_json_copy(mi)
    im = image_of_material(mi)
    nimg = img_remap.get(im)
    if nimg is None:
        bv = J['bufferViews'][J['images'][im]['bufferView']]
        nimg = add_image_bytes(BIN[bv['byteOffset']:bv['byteOffset'] + bv['byteLength']], J['images'][im].get('name', 'tex%d' % im))
        img_remap[im] = nimg
        NJ['textures'].append(dict(sampler=0, source=nimg))
    mj['pbrMetallicRoughness']['baseColorTexture'] = dict(index=len(NJ['textures']) - 1)
    NJ['materials'].append(mj)
    dd = dict(P=list(np.vstack(d['P'])), N=list(np.vstack(d['N'])), UV=list(np.vstack(d['UV'])), C=list(np.vstack(d['C'])), I=list(np.concatenate(d['I'])), n=0)
    pr = write_prim(dict(P=dd['P'], N=dd['N'], UV=dd['UV'], C=dd['C'], I=dd['I']), len(NJ['materials']) - 1, quant=False)
    mask_prims.append(pr)
if mask_prims:
    add_node('world_mask_nocol', dict(name='world_mask_nocol', primitives=mask_prims))
print('mesh hien thi: %d chunk atlas + 1 mesh masked (%d vat lieu)' % (n_chunk_meshes, len(mask_prims)))

NJ['buffers'][0]['byteLength'] = len(OUT)
js = json.dumps(NJ, separators=(',', ':')).encode()
js += b' ' * ((-len(js)) % 4)
out = struct.pack('<4sII', b'glTF', 2, 12 + 8 + len(js) + 8 + len(OUT))
out += struct.pack('<I4s', len(js), b'JSON') + js + struct.pack('<I4s', len(OUT), b'BIN\0') + bytes(OUT)
open(dst, 'wb').write(out)
print('ghi', dst, '%.1f MB' % (len(out) / 1e6))
