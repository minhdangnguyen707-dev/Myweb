import sys, json, struct, math, io
import numpy as np
from PIL import Image
import os; sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
from mdlparse import MDL, angle_quat

def qmat(q):
    x,y,z,w=q
    return np.array([[1-2*(y*y+z*z),2*(x*y-z*w),2*(x*z+y*w)],
                     [2*(x*y+z*w),1-2*(x*x+z*z),2*(y*z-x*w)],
                     [2*(x*z-y*w),2*(y*z+x*w),1-2*(x*x+y*y)]])

def build(mdl_path, out_path, target_h=1.89, skip_labels=('dummy','I_am_a_stupid_placeholder','so_am_I'), report=False, fixed_scale=None, viewmodel=False, atlas=False, atlas_scale=1.0, atlas_jpeg=False, no_normals=False, tex_from=None):
    # atlas=True: gộp MỌI mảnh + texture thành MỘT mảnh với MỘT texture (1 draw call, 1 vật liệu) - dành cho viewmodel để nhẹ máy yếu (UV phải nằm trong 0..1).
    # viewmodel=True (model súng góc nhìn thứ nhất v_*.mdl): giữ nguyên gốc toạ độ GoldSrc (gốc = mắt người chơi), KHÔNG dời cho chân chạm đất,
    # KHÔNG nâng animation; scale mặc định 0.0254 (1 đơn vị GoldSrc = 1 inch = 2,54 cm).
    m=MDL(mdl_path)
    if tex_from:
        # lấy lớp sơn súng (c / h / t / s / 1) từ một MDL khác để hai bản tay (CT / T) cùng một khẩu súng
        o=MDL(tex_from); ot={t['name']:t for t in o.tex}
        for t in m.tex:
            if t['name'] in ('c.bmp','h.bmp','t.bmp','s.bmp','1.bmp') and t['name'] in ot and (ot[t['name']]['w'],ot[t['name']]['h'])==(t['w'],t['h']):
                t['pix']=ot[t['name']]['pix']; t['pal']=ot[t['name']]['pal']
    nb=m.numbones
    # ---- rest world transforms (MDL space) ----
    rest_loc=[]
    for b in m.bones:
        R=qmat(angle_quat(b['val'][3:6])); T=np.eye(4); T[:3,:3]=R; T[:3,3]=b['val'][0:3]; rest_loc.append(T)
    world=[None]*nb
    for i,b in enumerate(m.bones):
        world[i]=rest_loc[i] if b['parent']<0 else world[b['parent']]@rest_loc[i]
    # ---- meshes ----
    # choose model 0 of each bodypart, except backpack -> blank (index 0)
    prims=[]  # dict(pos,nrm,uv,bone,idx,tex)
    allz=[]
    for bp in m.bodyparts:
        mod=bp['models'][0]
        if len(mod['verts'])==0: continue
        for me in mod['meshes']:
            tex=m.skinref[me['skinref']]
            d=m.d; o=me['triindex']; tris=[]
            verts={}; P=[];N=[];UV=[];B=[]
            def vid(vi,ni,s,t):
                key=(vi,ni,s,t)
                if key in verts: return verts[key]
                bone=int(mod['vbone'][vi]); W=world[bone]
                p=W[:3,:3]@mod['verts'][vi]+W[:3,3]
                nbn=int(mod['nbone'][ni]); n=world[nbn][:3,:3]@mod['norms'][ni]
                T=m.tex[tex]
                P.append(p);N.append(n);UV.append((s/T['w'],t/T['h']));B.append(bone)
                verts[key]=len(P)-1; return verts[key]
            while True:
                n=struct.unpack_from('<h',d,o)[0]; o+=2
                if n==0: break
                fan=n<0; cnt=abs(n); vs=[]
                for k in range(cnt):
                    vi,ni,s,t=struct.unpack_from('<4h',d,o); o+=8
                    vs.append(vid(vi,ni,s,t))
                if fan:
                    for k in range(1,cnt-1): tris.append((vs[0],vs[k],vs[k+1]))
                else:
                    for k in range(cnt-2):
                        tris.append((vs[k],vs[k+1],vs[k+2]) if k%2==0 else (vs[k+1],vs[k],vs[k+2]))
            prims.append(dict(P=np.array(P),N=np.array(N),UV=np.array(UV),B=np.array(B),I=np.array(tris),tex=tex,name=mod['name']))
            allz.append(np.array(P)[:,2])
    allz=np.concatenate(allz)
    zmin,zmax=allz.min(),allz.max()
    S=target_h/(zmax-zmin)
    if viewmodel and not fixed_scale: fixed_scale=0.0254
    if fixed_scale: S=fixed_scale
    print('rest z range',zmin,zmax,'scale',S)
    # winding check: geometric normal vs stored normal (MDL space)
    agree=0;tot=0
    for p in prims:
        a,b,c=p['P'][p['I'][:,0]],p['P'][p['I'][:,1]],p['P'][p['I'][:,2]]
        gn=np.cross(b-a,c-a); sn=p['N'][p['I'][:,0]]+p['N'][p['I'][:,1]]+p['N'][p['I'][:,2]]
        dd=(gn*sn).sum(1); agree+=(dd>0).sum(); tot+=len(dd)
    flip = agree<tot/2
    print('winding agree',agree,'/',tot,'-> flip' if flip else '-> keep')
    # permutation MDL(x fwd,y left,z up) -> glTF (x=y_s, y=z_s, z=x_s)
    def perm(v): v=np.asarray(v); return np.stack([v[...,1],v[...,2]-zmin if False else v[...,2],v[...,0]],-1)
    def pv(v): return np.stack([v[...,1],v[...,2],v[...,0]],-1)
    zoff=0.0 if viewmodel else -zmin
    # ---- GLB writer ----
    buf=bytearray(); bviews=[]; accs=[]
    def add_bv(data,target=None):
        while len(buf)%4: buf.append(0)
        off=len(buf); buf.extend(data)
        bv=dict(buffer=0,byteOffset=off,byteLength=len(data))
        if target: bv['target']=target
        bviews.append(bv); return len(bviews)-1
    def add_acc(arr,ctype,typ,target=None,minmax=False):
        arr=np.ascontiguousarray(arr)
        bv=add_bv(arr.tobytes(),target)
        a=dict(bufferView=bv,componentType=ctype,count=int(arr.shape[0]),type=typ)
        if minmax:
            mn=np.atleast_1d(arr.min(0)); mx=np.atleast_1d(arr.max(0)); a['min']=[float(x) for x in mn]; a['max']=[float(x) for x in mx]
        accs.append(a); return len(accs)-1
    F32,U16,U32=5126,5123,5125
    images=[];textures=[];materials=[];tex_mat={}
    def mat_for(ti):
        if ti in tex_mat: return tex_mat[ti]
        T=m.tex[ti]
        masked=bool(T['flags']&0x40)
        rgb=T['pal'][T['pix']].astype(np.uint8)
        if masked:
            al=np.where(T['pix']==255,0,255).astype(np.uint8)
            # pixel trong suot dang mau xanh la (0,255,0): loang mau lan can vao do, de loc song tuyen tinh khong ke vien xanh quanh mep
            hole=(al==0); rgb=rgb.copy()
            for _ in range(8):
                if not hole.any(): break
                acc=np.zeros(rgb.shape,np.int32); cnt=np.zeros(hole.shape,np.int32)
                for dy in (-1,0,1):
                    for dx in (-1,0,1):
                        if dy==0 and dx==0: continue
                        ok=np.roll(np.roll(~hole,dy,0),dx,1)
                        acc+=np.where(ok[...,None],np.roll(np.roll(rgb,dy,0),dx,1),0); cnt+=ok
                fill=hole&(cnt>0)
                rgb[fill]=(acc[fill]//cnt[fill][:,None]).astype(np.uint8)
                hole=hole&~fill
            img=Image.fromarray(np.dstack([rgb,al]),'RGBA')
        else:
            img=Image.fromarray(rgb,'RGB')
        bio=io.BytesIO(); img.save(bio,'PNG',optimize=True)
        bv=add_bv(bio.getvalue())
        images.append(dict(bufferView=bv,mimeType='image/png',name=T['name'].rsplit('.',1)[0]))
        textures.append(dict(source=len(images)-1,sampler=0))
        mat=dict(name=T['name'].rsplit('.',1)[0].replace(' ','_'),doubleSided=True,
            pbrMetallicRoughness=dict(baseColorTexture=dict(index=len(textures)-1),metallicFactor=0.0,roughnessFactor=1.0))
        if masked:
            mat['alphaMode']='MASK'; mat['alphaCutoff']=0.5
        materials.append(mat)
        tex_mat[ti]=len(materials)-1; return tex_mat[ti]
    gprims=[]
    if atlas:
        used=sorted(set(p['tex'] for p in prims), key=lambda t:-m.tex[t]['h'])
        for t in used:
            assert not (m.tex[t]['flags']&0x40), 'atlas: texture masked '+m.tex[t]['name']
        # atlas_scale < 1: thu nhỏ mọi texture trước khi gộp (model có hàng chục texture 512x512 -> atlas khổng lồ). Xếp theo hàng (shelf), rộng tối đa 2048.
        pad=6 if atlas_scale<1.0 else 4
        sz={t:(max(4,int(round(m.tex[t]['w']*atlas_scale))),max(4,int(round(m.tex[t]['h']*atlas_scale)))) for t in used}
        AW=512
        while AW<max(sz[t][0] for t in used)+2*pad: AW*=2  # texture rộng 512 + viền > 512 -> nới atlas lên 1024
        if atlas_scale<1.0 or len(used)>2: AW=max(AW,2048)
        x=0; y=0; rowh=0; place={}
        for t in used:
            w,h=sz[t]
            if x+w+2*pad>AW: x=0; y+=rowh; rowh=0
            place[t]=(x+pad,y+pad); x+=w+2*pad; rowh=max(rowh,h+2*pad)
        AH=1
        while AH<y+rowh: AH*=2
        canvas=np.zeros((AH,AW,3),np.uint8)
        for t,(px,py) in place.items():
            T=m.tex[t]; rgb=T['pal'][T['pix']].astype(np.uint8); w,h=sz[t]
            if (w,h)!=(T['w'],T['h']):
                rgb=np.asarray(Image.fromarray(rgb,'RGB').resize((w,h),Image.LANCZOS))
            canvas[py-pad:py+h+pad, px-pad:px+w+pad]=np.pad(rgb,((pad,pad),(pad,pad),(0,0)),mode='edge')
        print('atlas',AW,'x',AH,'from',len(used),'textures')
        bio=io.BytesIO()
        if atlas_jpeg: Image.fromarray(canvas,'RGB').save(bio,'JPEG',quality=88,subsampling=2)
        else: Image.fromarray(canvas,'RGB').save(bio,'PNG',optimize=True)
        bv=add_bv(bio.getvalue())
        images.append(dict(bufferView=bv,mimeType='image/jpeg' if atlas_jpeg else 'image/png',name='atlas'))
        textures.append(dict(source=len(images)-1,sampler=0))
        materials.append(dict(name='atlas',doubleSided=True,pbrMetallicRoughness=dict(baseColorTexture=dict(index=len(textures)-1),metallicFactor=0.0,roughnessFactor=1.0)))
        A_P=[];A_N=[];A_UV=[];A_J=[];A_I=[];base=0
        for p in prims:
            P=pv(p['P'])*S; P[:,1]+=zoff*S
            N=pv(p['N']); N=N/np.maximum(np.linalg.norm(N,axis=1,keepdims=True),1e-9)
            I=p['I']
            if flip: I=I[:,[0,2,1]]
            T=m.tex[p['tex']]; px,py=place[p['tex']]
            UV=np.stack([(px+p['UV'][:,0]*sz[p['tex']][0])/AW,(py+p['UV'][:,1]*sz[p['tex']][1])/AH],1)
            A_P.append(P);A_N.append(N);A_UV.append(UV);A_J.append(p['B']);A_I.append(I+base); base+=len(P)
        P=np.concatenate(A_P);N=np.concatenate(A_N);UV=np.concatenate(A_UV);B=np.concatenate(A_J);I=np.concatenate(A_I)
        J=np.zeros((len(P),4),dtype=np.uint16); J[:,0]=B
        Wt=np.zeros((len(P),4),dtype=np.float32); Wt[:,0]=1.0
        att=dict(POSITION=add_acc(P.astype(np.float32),F32,'VEC3',34962,True),
                 **({} if no_normals else dict(NORMAL=add_acc(N.astype(np.float32),F32,'VEC3',34962))),
                 TEXCOORD_0=add_acc(UV.astype(np.float32),F32,'VEC2',34962),
                 JOINTS_0=add_acc(J,U16,'VEC4',34962),
                 WEIGHTS_0=add_acc(Wt,F32,'VEC4',34962))
        gprims.append(dict(attributes=att,indices=(add_acc(I.astype(np.uint16).reshape(-1),U16,'SCALAR',34963) if len(P)<65536 else add_acc(I.astype(np.uint32).reshape(-1),U32,'SCALAR',34963)),material=len(materials)-1,mode=4))
    for p in ([] if atlas else prims):
        P=pv(p['P'])*S; P[:,1]+=zoff*S
        N=pv(p['N']); N=N/np.maximum(np.linalg.norm(N,axis=1,keepdims=True),1e-9)
        I=p['I']
        if flip: I=I[:,[0,2,1]]
        J=np.zeros((len(P),4),dtype=np.uint16); J[:,0]=p['B']
        Wt=np.zeros((len(P),4),dtype=np.float32); Wt[:,0]=1.0
        att=dict(POSITION=add_acc(P.astype(np.float32),F32,'VEC3',34962,True),
                 **({} if no_normals else dict(NORMAL=add_acc(N.astype(np.float32),F32,'VEC3',34962))),
                 TEXCOORD_0=add_acc(p['UV'].astype(np.float32),F32,'VEC2',34962),
                 JOINTS_0=add_acc(J,U16,'VEC4',34962),
                 WEIGHTS_0=add_acc(Wt,F32,'VEC4',34962))
        gprims.append(dict(attributes=att,indices=(add_acc(I.astype(np.uint16).reshape(-1),U16,'SCALAR',34963) if len(P)<65536 else add_acc(I.astype(np.uint32).reshape(-1),U32,'SCALAR',34963)),material=mat_for(p['tex']),mode=4))
    # ---- skeleton ----
    def bname(i):
        n=m.bones[i]['name'].strip()
        if n.startswith('--'): n='x_'+n[2:].strip()
        return n.replace(' ','_').replace('.','_')
    names=[bname(i) for i in range(nb)]
    assert len(set(names))==nb, 'dup bone names'
    nodes=[]
    for i,b in enumerate(m.bones):
        t=pv(np.array(b['val'][0:3]))*S
        q=angle_quat(b['val'][3:6]); qg=[q[1],q[2],q[0],q[3]]
        if b['parent']<0: t=t+np.array([0,zoff*S,0])
        nodes.append(dict(name=names[i],translation=[float(x) for x in t],rotation=[float(x) for x in qg]))
    for i,b in enumerate(m.bones):
        if b['parent']>=0: nodes[b['parent']].setdefault('children',[]).append(i)
    # world rest (glTF space) for inverse bind
    Wg=[None]*nb
    for i,b in enumerate(m.bones):
        n=nodes[i]; R=qmat(n['rotation']); T=np.eye(4); T[:3,:3]=R; T[:3,3]=n['translation']
        Wg[i]=T if b['parent']<0 else Wg[b['parent']]@T
    ibm=np.stack([np.linalg.inv(w).T.reshape(-1) if False else np.linalg.inv(w).T for w in Wg]).astype(np.float32)  # column-major = transpose of row-major
    ibm_acc=add_acc(ibm.reshape(nb,16),F32,'MAT4')
    roots=[i for i,bn in enumerate(m.bones) if bn['parent']<0]
    skin_root=0
    scene_nodes=list(roots)
    if len(roots)>1:
        # nhiều xương gốc (xương phụ ở đầu gối của model CS:O): gom dưới một nút Armature để Godot dựng MỘT bộ xương
        nodes.append(dict(name='Armature',children=list(roots)))
        skin_root=len(nodes)-1
        scene_nodes=[skin_root]
    mesh_node=len(nodes)
    nodes.append(dict(name='model_mesh',mesh=0,skin=0))
    # ---- animations ----
    allP=np.concatenate([p['P'] for p in prims]); allB=np.concatenate([p['B'] for p in prims])
    invW=[np.linalg.inv(w) for w in world]
    def lift_for(frame0):
        wa=[None]*nb
        for i,bn in enumerate(m.bones):
            M=np.eye(4); M[:3,:3]=qmat(frame0[i,3:7]); M[:3,3]=frame0[i,0:3]
            wa[i]=M if bn['parent']<0 else wa[bn['parent']]@M
        z=[(wa[b]@invW[b]@np.append(p,1))[2] for p,b in zip(allP,allB)]
        return -min(z)
    LIFT_STAND=0.0 if viewmodel else lift_for(m.anim_frames(1,0)[0])
    print('stand lift (units)',LIFT_STAND,'= %.3f m'%(LIFT_STAND*S))
    anims=[]; seen=set(); info={}
    for si,s in enumerate(m.seqs):
        lab=s['label']
        if lab in skip_labels or lab in seen: continue
        seen.add(lab)
        blend=s['nblend']//2 if s['nblend']>1 else 0
        fr=m.anim_frames(si,blend)  # [nf,nb,7] MDL space
        nf=s['nframes']; fps=s['fps']
        loop=bool(s['flags']&1)
        times=[f/fps for f in range(nf)]
        if loop and nf>1:
            fr=np.concatenate([fr,fr[:1]],0); times.append(nf/fps)
        # animation lấy mẫu > 45 khung/giây (idle 100 fps của AK-47) thì lấy lại 30 khung/giây cho nhẹ file (khác biệt không nhìn thấy được)
        if viewmodel and fps>45 and fr.shape[0]>8:
            tt=np.array(times); nt=np.arange(0.0,tt[-1]+1e-9,1.0/30.0)
            if nt[-1]<tt[-1]-1e-6: nt=np.append(nt,tt[-1])
            idx=np.clip(np.searchsorted(tt,nt,side='right')-1,0,len(tt)-2); w=((nt-tt[idx])/(tt[idx+1]-tt[idx]))[:,None,None]
            fa=fr[idx].copy(); fb=fr[idx+1].copy()
            sg=np.sign((fa[:,:,3:7]*fb[:,:,3:7]).sum(2,keepdims=True)); sg[sg==0]=1; fb[:,:,3:7]*=sg   # cùng phía trước khi trộn quaternion
            fr=fa*(1-w)+fb*w
            q0=fr[:,:,3:7]; fr[:,:,3:7]=q0/np.maximum(np.linalg.norm(q0,axis=2,keepdims=True),1e-9)
            times=list(nt)
        # animation rất dài (> 150 khung, ví dụ idle 6.7 giây của dao) lấy lại 15 khung/giây: chuyển động chậm nên không nhìn ra, file nhẹ gần một nửa
        if viewmodel and fr.shape[0]>150 and fps<=45:
            tt=np.array(times); nt=np.arange(0.0,tt[-1]+1e-9,1.0/15.0)
            if nt[-1]<tt[-1]-1e-6: nt=np.append(nt,tt[-1])
            idx=np.clip(np.searchsorted(tt,nt,side='right')-1,0,len(tt)-2); w=((nt-tt[idx])/(tt[idx+1]-tt[idx]))[:,None,None]
            fa=fr[idx].copy(); fb=fr[idx+1].copy()
            sg=np.sign((fa[:,:,3:7]*fb[:,:,3:7]).sum(2,keepdims=True)); sg[sg==0]=1; fb[:,:,3:7]*=sg
            fr=fa*(1-w)+fb*w
            q0=fr[:,:,3:7]; fr[:,:,3:7]=q0/np.maximum(np.linalg.norm(q0,axis=2,keepdims=True),1e-9)
            times=list(nt)
        # ---- nâng cả animation lên cho chân chạm đất (GoldSrc đặt gốc ở GIỮA người) ----
        if viewmodel:
            lift_units=0.0
        elif lab.startswith('crouch'):
            lift_units=lift_for(fr[0])
        else:
            lift_units=LIFT_STAND
        T=pv(fr[:,:,0:3])*S
        for bi in range(nb):
            if m.bones[bi]['parent']<0: T[:,bi,1]+=lift_units*S
        Q=fr[:,:,3:7][:,:,[1,2,0,3]].copy()
        # shortest-path continuity
        for bi in range(nb):
            for f in range(1,Q.shape[0]):
                if np.dot(Q[f,bi],Q[f-1,bi])<0: Q[f,bi]=-Q[f,bi]
        t_acc=None; samplers=[]; channels=[]
        const_acc=None
        for bi in range(nb):
            # dịch chuyển và xoay xét riêng: phần lớn xương chỉ xoay, nên track dịch chuyển bất biến chỉ cần 1 khoá (nhẹ file hơn nhiều)
            for path,arr,typ,dim in (('translation',T,'VEC3',3),('rotation',Q,'VEC4',4)):
                if np.allclose(arr[:,bi],arr[0,bi],atol=1e-6):
                    if const_acc is None: const_acc=add_acc(np.array([0.0],dtype=np.float32),F32,'SCALAR',None,True)
                    samplers.append(dict(input=const_acc,output=add_acc(arr[:1,bi].astype(np.float32),F32,typ),interpolation='LINEAR'))
                else:
                    if t_acc is None:
                        t_acc=add_acc(np.array(times,dtype=np.float32),F32,'SCALAR',None,True)
                    samplers.append(dict(input=t_acc,output=add_acc(arr[:,bi].astype(np.float32),F32,typ),interpolation='LINEAR'))
                channels.append(dict(sampler=len(samplers)-1,target=dict(node=bi,path=path)))
        anims.append(dict(name=lab,samplers=samplers,channels=channels))
        lin=s['lin']
        info[lab]=dict(loop=loop,frames=nf,fps=fps,dur=(nf if loop else nf-1)/fps,lin_m=float(lin[0]*S),lin_y_m=float(lin[1]*S))
    gltf=dict(asset=dict(version='2.0',generator='mdl2glb'),scene=0,scenes=[dict(nodes=scene_nodes+[mesh_node])],
        nodes=nodes,meshes=[dict(name='model',primitives=gprims)],skins=[dict(joints=list(range(nb)),inverseBindMatrices=ibm_acc,skeleton=skin_root)],
        materials=materials,textures=textures,images=images,samplers=[dict(magFilter=9729,minFilter=9987,wrapS=10497,wrapT=10497)],
        animations=anims,accessors=accs,bufferViews=bviews,buffers=[dict(byteLength=len(buf))])
    js=json.dumps(gltf,separators=(',',':')).encode()
    while len(js)%4: js+=b' '
    while len(buf)%4: buf.append(0)
    with open(out_path,'wb') as f:
        f.write(struct.pack('<4sII',b'glTF',2,12+8+len(js)+8+len(buf)))
        f.write(struct.pack('<I4s',len(js),b'JSON')); f.write(js)
        f.write(struct.pack('<I4s',len(buf),b'BIN\0')); f.write(buf)
    print('wrote',out_path,len(buf)/1e6,'MB bin; anims',len(anims))
    return m,info,names,S

if __name__=='__main__':
    # --atlas-scale=0.5: thu nhỏ texture khi gộp atlas; --jpeg: lưu atlas JPEG (nhẹ hơn PNG nhiều)
    asc=1.0
    nn='--no-normals' in sys.argv
    tf=None
    for a in sys.argv[1:]:
        if a.startswith('--gun-tex-from='): tf=a.split('=',1)[1]
    for a in sys.argv[1:]:
        if a.startswith('--atlas-scale='): asc=float(a.split('=')[1])
    args=[a for a in sys.argv[1:] if a not in ('--vm','--atlas','--jpeg','--no-normals') and not a.startswith('--atlas-scale=') and not a.startswith('--gun-tex-from=')]
    vmode='--vm' in sys.argv
    atl='--atlas' in sys.argv
    fs=float(args[2]) if len(args)>2 else None
    m,info,names,S=build(args[0],args[1],fixed_scale=fs,viewmodel=vmode,atlas=atl,atlas_scale=asc,atlas_jpeg='--jpeg' in sys.argv,no_normals=nn,tex_from=tf)
    json.dump(info,open(sys.argv[2]+'.anims.json','w'),indent=1)
