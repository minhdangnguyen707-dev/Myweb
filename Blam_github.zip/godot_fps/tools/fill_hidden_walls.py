#!/usr/bin/env python3
"""Lap cac vach "trong suot nhung la tuong" cua map Mirage (khong dung khi choi game).
Dung: python3 fill_hidden_walls.py assets/mirage_map.glb [out.glb]
Ghi de len chinh file neu khong co out.glb. Chay lai sau moi lan bsp2glb.py tao lai map.

Van de: bsp2glb xuat cac mat 'sky' / 'nowallshot' / '{invis' va cac func_wall an thanh mesh chunk_*_hide
(co va cham, KHONG ve) -> nguoi choi thay xuyen qua nhung dung phai tuong vo hinh (vi du cong vom o cho xuat phat CT).
Cach sua: voi cac mat DUNG (khong phai tran / san) trong mesh chunk_*_hide, them mot mesh VE duoc
'chunk_fill_<cx>_<cz>_nocol' (ten ket thuc _nocol nen main.gd KHONG tao va cham cho no - va cham da co san o mesh hide).
- Chi lap mat dung (|ny| < 0.7), cat o do cao <= FILL_YMAX (tuong sky cao toi 46 m, khong can ve het).
- Bo qua khoi co hang rao / luoi (mat masked) cham vao (<= 0.6 m): do co the la cho cu y nhin xuyen qua.
- Vat lieu: lay vat lieu gach cua map (de_mwall32), nhan ban hai mat (khong bi cull du huong mat nao).
"""
import sys, json, struct, io, collections
import numpy as np

FILL_YMAX = 14.0
FENCE_R = 0.6      # khoi chi bi bo qua neu hang rao cham vao no (cach <= 0.6 m)
BRICK_MAT = 'de_mwall32'
TEX_METERS = 256 * 0.0254      # mot lan lap texture 256 px = 6.5 m (scale bsp2glb 0.0254)
CHUNK_M = 1280.0 * 0.0254

src = sys.argv[1]
dst = sys.argv[2] if len(sys.argv) > 2 else src
b = open(src, 'rb').read()
jl, = struct.unpack('<I', b[12:16])
J = json.loads(b[20:20 + jl])
bl, = struct.unpack('<I', b[20 + jl:24 + jl])
BIN = bytearray(b[28 + jl:28 + jl + bl])

if any(m['name'].startswith('chunk_fill_') for m in J['meshes']):
    print('File da duoc lap roi (co chunk_fill_*). Dung lai.'); sys.exit(0)

def acc(i):
    a = J['accessors'][i]; bv = J['bufferViews'][a['bufferView']]
    n = {'SCALAR': 1, 'VEC2': 2, 'VEC3': 3, 'VEC4': 4}[a['type']]
    dt = {5126: '<f4', 5123: '<u2', 5125: '<u4'}[a['componentType']]
    st = bv['byteOffset'] + a.get('byteOffset', 0)
    return np.frombuffer(bytes(BIN), dtype=dt, count=a['count'] * n, offset=st).reshape(a['count'], n)

brick = [i for i, m in enumerate(J['materials']) if m['name'] == BRICK_MAT]
assert brick, 'khong thay vat lieu ' + BRICK_MAT
brick = brick[0]

hide, fence, brick_cols = [], [], []
for m in J['meshes']:
    nm = m['name']
    for p in m['primitives']:
        pos = acc(p['attributes']['POSITION']).astype(np.float64); idx = acc(p['indices']).reshape(-1, 3)
        if nm.startswith('chunk_') and nm.endswith('_hide'):
            hide.append(pos[idx])
        elif nm.endswith('_nocol'):
            if J['materials'][p['material']].get('alphaMode') == 'MASK':
                fence.append(pos[idx])
            if p['material'] == brick and 'COLOR_0' in p['attributes']:
                c = acc(p['attributes']['COLOR_0'])[:, :3].astype(np.float64)
                brick_cols.append(c[idx].mean(1))
T = np.concatenate(hide); F = np.concatenate(fence)
fc = F.mean(1)
vcol = np.median(np.concatenate(brick_cols), axis=0) if brick_cols else np.array([0.5, 0.5, 0.5])
print('hide tris', len(T), 'fence tris', len(F), 'vertex colour', vcol.round(3))

# ---- gom cum (cac tam giac chung dinh) ----
parent = list(range(len(T)))
def find(x):
    while parent[x] != x:
        parent[x] = parent[parent[x]]; x = parent[x]
    return x
seen = {}
for i in range(len(T)):
    for p in T[i]:
        k = tuple(np.round(p, 2))
        if k in seen: parent[find(i)] = find(seen[k])
        else: seen[k] = i
cl = collections.defaultdict(list)
for i in range(len(T)): cl[find(i)].append(i)

n = np.cross(T[:, 1] - T[:, 0], T[:, 2] - T[:, 0]); nl = np.linalg.norm(n, axis=1)
ny = np.abs(n[:, 1]) / np.maximum(nl, 1e-9)
cen = T.mean(1)
FV = F.reshape(-1, 3)
FV = FV[np.unique(np.round(FV, 2), axis=0, return_index=True)[1]]
near = np.zeros(len(T), bool)
for i in range(len(T)):
    pts = np.vstack([T[i], cen[i][None]])
    # diem cua hang rao gan tam giac nay (hop bao + FENCE_R) roi do khoang cach that tu 4 diem mau
    lo = T[i].min(0) - FENCE_R; hi = T[i].max(0) + FENCE_R
    sub = FV[((FV >= lo) & (FV <= hi)).all(1)]
    if len(sub): near[i] = (np.linalg.norm(sub[None, :, :] - pts[:, None, :], axis=2) <= FENCE_R).any()

use = np.zeros(len(T), bool)
for ids in cl.values():
    if len(ids) <= 200:
        if not near[ids].any(): use[ids] = True      # khoi nho: ca khoi hoac khong
    else:
        for i in ids:
            if not near[i]: use[i] = True            # cum lon (hop sky): xet tung tam giac
use &= (ny < 0.7) & (nl > 1e-9)
print('tam giac se lap', int(use.sum()))

# ---- cat o FILL_YMAX (Sutherland-Hodgman, chi theo truc y) ----
def clip_y(tri):
    out = []
    for k in range(3):
        a, c = tri[k], tri[(k + 1) % 3]
        ina, inc = a[1] <= FILL_YMAX, c[1] <= FILL_YMAX
        if ina: out.append(a)
        if ina != inc:
            t = (FILL_YMAX - a[1]) / (c[1] - a[1])
            out.append(a + (c - a) * t)
    return out

chunks = collections.defaultdict(lambda: ([], [], []))   # (cx,cz) -> pos, uv, col
for i in np.where(use)[0]:
    poly = clip_y(T[i])
    if len(poly) < 3: continue
    nn = n[i] / nl[i]
    a = np.array([-nn[2], 0.0, nn[0]]); al = np.linalg.norm(a)
    a = a / al if al > 1e-9 else np.array([1.0, 0.0, 0.0])
    c0 = cen[i]
    key = (int(np.floor(c0[0] / CHUNK_M)), int(np.floor(c0[2] / CHUNK_M)))
    P, U, C = chunks[key]
    for k in range(1, len(poly) - 1):
        for q in (poly[0], poly[k], poly[k + 1]):
            P.append(q); U.append((float(q @ a) / TEX_METERS, float(-q[1]) / TEX_METERS)); C.append(vcol)

# ---- ghi vao glb ----
def add_blob(data):
    off = len(BIN)
    BIN.extend(data)
    BIN.extend(b'\0' * ((-len(data)) % 4))
    return off

def add_acc(arr, ctype, comp, target, mm=False):
    off = add_blob(arr.tobytes())
    J['bufferViews'].append(dict(buffer=0, byteOffset=off, byteLength=int(arr.nbytes), target=target))
    ac = dict(bufferView=len(J['bufferViews']) - 1, componentType=comp, count=int(len(arr)), type=ctype)
    if mm:
        ac['min'] = [float(x) for x in arr.min(axis=0)]; ac['max'] = [float(x) for x in arr.max(axis=0)]
    J['accessors'].append(ac)
    return len(J['accessors']) - 1

mat = json.loads(json.dumps(J['materials'][brick]))
mat['name'] = 'fill_brick'; mat['doubleSided'] = True
J['materials'].append(mat); fill_mat = len(J['materials']) - 1

total = 0
for (cx, cz), (P, U, C) in sorted(chunks.items()):
    P = np.array(P, '<f4'); U = np.array(U, '<f4')
    C4 = np.hstack([np.array(C, '<f4'), np.ones((len(P), 1), '<f4')]).astype('<f4')
    fn = np.cross(P[1::3] - P[0::3], P[2::3] - P[0::3]).astype(np.float64)
    fl = np.linalg.norm(fn, axis=1, keepdims=True); fl[fl == 0] = 1
    N = np.repeat(fn / fl, 3, axis=0).astype('<f4')
    idx = np.arange(len(P), dtype='<u4')
    prim = dict(attributes=dict(POSITION=add_acc(P, 'VEC3', 5126, 34962, True), NORMAL=add_acc(N, 'VEC3', 5126, 34962),
                                TEXCOORD_0=add_acc(U, 'VEC2', 5126, 34962), COLOR_0=add_acc(C4, 'VEC4', 5126, 34962)),
                indices=add_acc(idx, 'SCALAR', 5125, 34963), material=fill_mat, mode=4)
    name = 'chunk_fill_%d_%d_nocol' % (cx, cz)
    J['meshes'].append(dict(name=name, primitives=[prim]))
    J['nodes'].append(dict(name=name, mesh=len(J['meshes']) - 1))
    J['scenes'][0]['nodes'].append(len(J['nodes']) - 1)
    total += len(P) // 3
print('mesh lap:', len(chunks), 'chunk,', total, 'tam giac')

J['buffers'][0]['byteLength'] = len(BIN)
js = json.dumps(J, separators=(',', ':')).encode()
js += b' ' * ((-len(js)) % 4)
out = struct.pack('<4sII', b'glTF', 2, 12 + 8 + len(js) + 8 + len(BIN))
out += struct.pack('<I4s', len(js), b'JSON') + js + struct.pack('<I4s', len(BIN), b'BIN\0') + bytes(BIN)
open(dst, 'wb').write(out)
print('ghi', dst, len(out) / 1e6, 'MB')
