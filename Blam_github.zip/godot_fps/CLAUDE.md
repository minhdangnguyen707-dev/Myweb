# Quy tắc cho Claude khi làm tiếp project này (đọc trước khi sửa)

Người dùng: người Việt, không biết lập trình, máy ThinkPad T440 (Intel HD 4400, GL Compatibility, cần >= 30 FPS).
Trả lời tiếng Việt, ngắn gọn. Máy Claude không có Godot: KHÔNG nói "đã chạy thử", luôn nói rõ chưa chạy thử và liệt kê vài việc để người dùng thử.
Chỉ dùng TAB để thụt dòng trong `scripts/*.gd`. Giao file: zip cả project thành `GlockFPS_Godot_Optimized.zip`, thư mục gốc `godot_fps/`. Có thay đổi người dùng thấy được thì cập nhật `README.md`.

## BÀN TAY: súng mới PHẢI dùng bàn tay thật (người dùng yêu cầu)
- Tay của mọi súng là **bàn tay + cẳng tay thật có găng** (`assets/hands/hand_r.glb`, `hand_l.glb`, nướng từ pack "M4 FPS weapon animations"), do `scripts/hands.gd` (`Hands.Arm`) điều khiển.
- **CẤM** vẽ kiểu tay khác cho súng mới: không dựng tay bằng khối hộp / mô hình tay khác, không tạo file tay mới, không gọi `Hands.add_hand` để làm tay chính. Các khối hộp tay cũ (dùng `Hands.material()`) sẽ tự bị ẩn khi `Hands.Arm` hoạt động, nên có copy code từ súng cũ cũng không sao.
- Cách làm đúng cho súng mới (copy từ `rifle.gd` hoặc `viewmodel.gd`):
  1. Cuối `_ready`: `limb_l = Hands.Arm.new(rig, true)` và `limb_r = Hands.Arm.new(rig)`.
  2. Mỗi khung hình gọi `limb_l.update(rig.basis, wrist_trái, ELBOW_L, delta)` và `limb_r.update(rig.basis, wrist_phải, ELBOW_R, delta)` (như các súng khác). Chỉ cần vậy là đã có bàn tay thật (đặt theo cổ tay / khuỷu).
  3. Muốn tay ôm khít: gọi thêm `limb_r.attach(node_tay_phải, xoay_nghỉ, tâm_báng_trong_node, Vector3(0,-1,0), 0.0, 0)` và `limb_l.attach(...)` ngay sau `Arm.new`. mode 0 = tay phải cầm báng; 1 = tay trái ôm ốp tay súng trường (giữ nguyên tư thế, thêm `rest_extra` để nâng lên ôm ốp tay); 2 = tay trái cầm báng súng ngắn (bàn tay phải lật đối xứng). Xem ví dụ ở cuối `_ready` của `viewmodel.gd`, `rifle.gd`. Sau `attach`, gọi `update()` vẫn cần để cập nhật đoạn cẳng tay nối dài.
  4. Khi tay trái đi lấy băng đạn / kéo cần gạt: dùng `limb_l.mag_extra` + `limb_l.mag_target`, `limb_l.ch_extra` + `limb_l.ch_k` + `limb_l.ch_yaw`, `limb_l.rest_k` (xem `ak47.gd`).
- Ngón tay chỉ có MỘT tư thế (nướng sẵn); đừng cố làm ngón cử động riêng.
- Các số chỉnh chung: `HAND_SCALE`, `GM_R`, `GM_L`, `HAND_BACK`, `HAND_SHIFT` đầu `scripts/hands.gd`.
- Bom C4 vẫn dùng tay khối hộp cũ (chưa chuyển); nếu sửa thì cứ giữ nguyên hoặc chuyển sang `Hands.Arm`, đừng vẽ tay kiểu thứ ba.

## ĐÃ XOÁ, KHÔNG ĐƯỢC THÊM LẠI (người dùng yêu cầu)
- **Ngắm (ADS)**: không có chức năng ngắm cho bất kỳ súng nào. Đừng gán `vm.ads`, đừng zoom FOV. Chuột phải chỉ để dao đâm.
- **Hạ / cụp súng khi sát tường** (`vm.wall_push`, bảng `WALL_DIMS`).
- **Tự nghiêng người (peek) khi đứng sát góc vật cản**.
- Trong các file mô hình súng vẫn còn code ADS / `wall_push` chết (không ai gọi nữa). Súng mới KHÔNG cần và KHÔNG nên có các cơ chế này; có thể giữ biến `ads`, `ads_t`, `wall_push` trong giao diện hàm của viewmodel để `player.gd` không lỗi, nhưng luôn là 0 / false.

## Các quy tắc cũ vẫn đúng
- Không dùng `class_name` trong script mới; nạp bằng `preload("res://scripts/xxx.gd")`.
- Giữ các nhánh dự phòng (không nạp được tài nguyên thì quay về cách cũ).
- Thêm súng mới: ~10 chỗ (`WEAPONS`, `owned/w_mag/w_res` và `reset_loadout()`, `_build_viewmodel`, phím, `cycle_weapon`, cửa hàng + phím mua nhanh, `ui_icon.gd`, `hud.gd`, `bomb.gd` thưởng tiền, README).
- Giao diện hàm viewmodel: signal `sound`, `reload_inserted`, `action_finished`; biến `ads, ads_t, crouched, grounded, move_amount, run_amount, wall_push, mouse_delta`; hàm `play_draw, play_holster, play_reload(empty)->float, play_inspect, cancel, is_busy, current_mode, set_slide_locked, is_slide_locked, land, fire(last_round), dry_fire, muzzle_global`.

## ĐÃ XOÁ: Dual Uzi + chế độ ZOMBIE (người dùng yêu cầu, KHÔNG thêm lại)
- Không còn súng `uzi` (phím 4 trống, cửa hàng 4 thẻ: M4A1 1, AK-47 2, Desert Eagle 3, Mua đạn 4), không còn chế độ Zombie / zombie / chó / Brute / đồng đội GIGN / nhà thủ thành / ngày sống sót / đèn pin / âm thanh kinh dị. Chỉ còn hai chế độ: ĐẤU ĐỘI và ĐẶT BOM.
- Đã xoá `scripts/uzi.gd zombie.gd dog.gd brute.gd ally.gd horror.gd` và `assets/uzi zombie dog brute audio zombie_map.glb`. `assets/gign` + `scripts/skin_rig.gd` (nhánh dự phòng GIGN) đã XOÁ ở đợt dọn dẹp cuối: không còn dùng.

## ĐÃ XOÁ: cụp súng khi chạy nước rút
- `vm.run_amount` luôn là 0 (`player.gd`). Đừng bật lại; súng mới không cần tư thế chạy.

## NHẶT / VỨT ĐỒ (người dùng yêu cầu)
- Mỗi người chơi cầm tối đa 1 súng chính + 1 súng lục + 1 dao (`SLOT_OF` trong `player.gd`). Mua / nhặt khẩu cùng loại thì khẩu cũ rơi xuống đất (`give_weapon`), cửa hàng KHÔNG còn khóa món đã có.
- E nhặt (nhìn vào súng, `scripts/pickups.gd`), G vứt (`Player.drop_current`), dao không vứt được.
- C4: phe T đi tới tự nhặt, CT không nhặt được (`bomb.gd`). Súng rơi nằm đến hết round (`pickups.clear_all()` ở đầu round / trận mới).
- Súng MỚI: thêm vào `SLOT_OF` (player.gd) và một nhánh `match` trong `_build_model` (pickups.gd) để có mô hình dưới đất.

## DAO BƯỚM CS:GO (người dùng yêu cầu: thay nắm đấm tay không bằng model dao bướm nhúng thẳng, kèm tay + animation + âm thanh)
- **Phím 3 (id "knife", file `scripts/knife.gd`) là dao bướm** từ gói `butterfly_knife`; nắm đấm cũ (dựng bằng code + `Hands.Arm`) đã XOÁ, đừng thêm lại. **NGOẠI LỆ có chủ đích** như AWP / MP5 / AK-47: dùng tay + dao + animation CÓ SẴN trong `assets/knife/v_knife_ct.glb` (phe CT, tay áo xanh) / `v_knife_t.glb` (phe T), KHÔNG dùng `Hands.Arm`; đổi bằng `python3 tools/mdl2glb.py CT/v_knife.mdl ... --vm --atlas --jpeg`. Chỉ lấy MỘT con dao (skin mặc định); 24 skin trong thư mục `Textures` của gói không dùng.
- KHÔNG lật gương (model dao vẽ cho tay phải, khác AK-47). Animation: `idle draw draw2 slash1 slash2 heavy_miss backstab inspect inspect2 inspect3` (midslash1/2 không dùng). Chuột trái = `play_attack("slash")` (slash1/2 xen kẽ), chuột phải = `play_attack("stab")` (heavy_miss, hoặc backstab khi `Player.melee_backstab_ready()`), F = múa dao. `melee_hit` phát ở HIT_SLASH 0.17 s / HIT_HEAVY 0.38 s / HIT_BACKSTAB 0.5 s (đo từ chuyển động lưỡi dao). `flash` PHẢI là Node3D thật (main._warmup đọc `flash.visible`).
- Âm thanh CÓ trong gói nên đã nhúng: `assets/knife/sounds/*.wav` (draw1/2, insp1a-c, insp2a-c, backstab), tự phát bằng `AudioStreamPlayer` trong `knife.gd` theo bảng `EVENTS` (sự kiện 5004 của model), giống cách `mp5.gd` làm. Không có tiếng chém / trúng trong gói nên không thêm.
- Tay áo theo phe giống AK-47 (`_sync_team`). `Player.WEAPONS["knife"]["name"]` = "BUTTERFLY". Sát thương 40 / 65 / 195 sau lưng và thưởng $1500 giữ nguyên. Chưa chạy thử trong Godot.

## MODEL PHE T (người dùng yêu cầu)
- Bot phe T (team == 1) dùng `scripts/terror_rig.gd` + `assets/terror/terror.glb` (model CS 1.6 "Faithful Terror", đổi từ .mdl bằng `tools/mdl2glb.py`, hướng mặt +Z, chân chạm y = 0, đã nâng animation lên cho chân chạm đất). Chỉ đổi ngoại hình bên ngoài, KHÔNG đổi tay góc nhìn thứ nhất. Dựng hỏng thì bot quay về các khối hộp (không còn model GIGN dự phòng). `bot.gd` gọi `rig.on_death(self, headshot)` / `rig.on_respawn()`.
- Animation chạy bằng `AnimationPlayer` ở chế độ MANUAL (`advance()` trong `drive`) để chỉnh xương sau animation. Đổi / thêm tài nguyên thì bump cờ `imported_vNN` trong `CHOI_GAME.bat` (đang là v34).
- Phe CT (team == 0) dùng CÙNG `terror_rig.gd` nhưng `configure("yuri")` -> `assets/yuri/yuri.glb` (CS Online "Yuri Classic", 97 xương, có xương gốc phụ ở đầu gối nên glb có nút `Armature`; texture masked -> alphaMode MASK). Thêm model CS 1.6 mới: chạy `tools/mdl2glb.py <file.mdl> <out.glb> [scale]`, thêm một mục vào `CONFIGS`, nhớ bump cờ import. (GIGN / `skin_rig.gd` đã xoá.)
- Người chơi cũng dùng cùng model: `scripts/corpse.gd` (thân người chơi hiện ở camera chết) tạo `terror_rig.gd` với `configure("yuri" if ct else "terror")`, gọi `on_death`, ẩn các khối hộp (trừ súng văng ra), `_process` gọi `rig.drive_corpse(dt)`. Hỏng thì giữ khối hộp.

## SKIN (người dùng yêu cầu)
- `scripts/skins.gd` giữ danh sách skin (`DATA`), đã mua, đang dùng, phạm vi (cả phe / riêng mình), lưu `user://skins.cfg`. `main.skins` là bản dùng chung. Hiện có `miho`, `abia`, `neko_gign`, `neko_gsg9` (đều chỉ phe CT, giá 0, cùng lúc chỉ dùng một skin). Mặc định CT = Yuri.
- Giao diện ở SẢNH: tab CỬA HÀNG (mua) + BỘ SƯU TẬP (chuột phải vào thẻ ra menu: Áp dụng/Gỡ, Cả phe, Riêng mình) trong `main.gd` (`_lobby_fill_shop`, `_lobby_fill_collection`, `_open_skin_menu`, `_skin_action`).
- Bot CT lấy model qua `bot.gd _build_rig()` (`skins.model_for_ct_bot()`), đổi giữa chừng bằng `bot.reload_rig()`; thân người chơi lấy qua `player.gd` -> `corpse.kind` (`model_for_player_ct()`).
- Skin `abia`: `assets/abia/abia.glb` đổi từ `[CSO]Abia/models/buffclass25s4tr.mdl` bằng `python3 tools/mdl2glb.py <mdl> assets/abia/abia.glb 0.0269` (tham số cuối = tỉ lệ cố định để cao bằng Yuri; bỏ tham số thì tự co về 1,89 m). `walk_mps/run_mps` trong `CONFIGS` lấy từ `lin_m / dur` của animation walk / run (file `.anims.json` do tool sinh ra, xoá sau khi dùng).
- Skin `neko_gign` / `neko_gsg9` (gói Nekopara, model CS 1.6 chuẩn, animation tên `idle1` nên `CONFIGS` đặt `"idle": "idle1"`): `python3 tools/mdl2glb.py <gign.mdl> assets/neko_gign/neko_gign.glb 0.028242` và `... <gsg9.mdl> assets/neko_gsg9/neko_gsg9.glb 0.029654` (tỉ lệ = 1,8514 m của Yuri / chiều cao gốc của model). Thêm skin mới theo mẫu này: glb + icon (render toàn thân, nền trong, cao 240 px) + mục `CONFIGS` + mục `DATA`/`ORDER` + bump cờ import.

## CẦM SÚNG TAY TRÁI (người dùng yêu cầu)
- Tuỳ chọn trong CÀI ĐẶT (`main.left_hand`, lưu `user://settings.cfg`). Bật thì `Player.set_left_hand(true)` lật gương mọi viewmodel bằng `scale.x = -1` (viewmodel là con của `camera`, đặt ở gốc nên lật quanh giữa màn hình). Đừng gán lại `transform` / `scale` của gốc viewmodel trong script súng mới, và đừng dùng toạ độ toàn cục của viewmodel để đoán "bên phải"; mọi thứ bên trong viewmodel (tay, vỏ đạn, băng rơi) tự lật theo.


## MAP MIRAGE (người dùng yêu cầu, thay bản đồ THÀNH PHỐ)
- Map thành phố đã xoá (`city_map.glb`). Bản đồ lớn 5 đấu 5 giờ là `mirage` (`assets/mirage_map.glb`, đổi từ BSP CS 1.6 bằng `tools/bsp2glb.py`). Đừng thêm lại map thành phố.
- `MAP_CFG["mirage"]` dùng thêm: `site_ymax`, `spawn_ymax`, `wp_y`, `unshaded`, spawn dạng `Vector3(x, độ cao sàn, z)`. Mesh có tên kết thúc `_hide` là vật cản vô hình (chỉ va chạm). Chưa chạy thử trong Godot: navmesh / bot / điểm bom cần người dùng kiểm tra.

## BOT GIỐNG NGƯỜI THẬT (người dùng yêu cầu)
- `bot.gd`: tầm nhìn 120 độ (`FOV_HALF`), thời gian nhận ra địch (`spot_acc`), nghe bước chân / tiếng súng (`_scan`, `hear`, `main.noise`), hô đồng đội (`_callout`), tính cách `aggr` / `patience`, băng đạn + nạp (`mag`, `reload_t`), bắn loạt + ngắm dần (`_shoot`, `engage_t`), lùi về chỗ nấp khi yếu máu (`_start_retreat`, `_retreat_step`, `hold_t`).
- `bomb.gd`: `exec_time` (mỗi round khác), `_t_ready` (carrier chờ đồng đội), `pp_pts` / `_build_pp` (chỗ canh sau khi đặt bom), logic gỡ bom có tính thời gian + chờ dọn địch, `approach_dir`, `hold_wait`. Đừng đưa bot về kiểu nhìn 360 độ / bắn đều như máy.
- CHƯA chạy thử trong Godot.

## SÚNG + TIỀN CỦA BOT (người dùng yêu cầu)
- Bot dùng `Player.WEAPONS` (glock / deagle / m4a1 / ak47): `weapon`, `money`, `res`, `mag` trong `bot.gd`; `WEAPON_AI` = nhịp bắn / độ lệch / vị trí tay bám từng súng; `set_weapon`, `round_start(full, lost)`, `_buy`. Mô hình súng lấy từ `pickups._build_model` (dựng thẳng, bỏ xoay nằm nghiêng).
- `bomb.gd`: `_start_round` gọi `n.round_start(full_reset, lost)`; tiền thưởng bot trong `_end_round`, `on_kill`, `_plant`, `_defuse`. `main.gd register_kill` thưởng tiền bot ở chế độ ĐẤU ĐỘI. Round pistol = $800 + Glock. Chưa chạy thử trong Godot.

## SKIN KRATOS + BỎ ÂM THANH (người dùng yêu cầu)
- `skins.gd` giờ lưu skin đang dùng THEO TỪNG PHE (`equipped_by[0/1]`, `scope_by[0/1]`); API: `is_on`, `team_of`, `unequip(team)`, `model_for_bot(team)`, `model_for_player(team)`. Skin `kratos` là skin phe T (`team: 1`; đổi thành 0 nếu muốn cho phe CT). Mặc định: CT = Yuri, T = Terror (có icon `assets/terror/terror_icon.png`).
- KHÔNG xoá animation nào của model skin (người dùng yêu cầu). `tools/glbslim.py ... -` giữ hết animation, chỉ ép texture + gộp keyframe thừa.
- Âm thanh đã bị xoá hoàn toàn theo yêu cầu: `main.play_at` và `player.play` chỉ còn là hàm rỗng, không còn `sfx.gd`, `AudioServer` bus 0 tắt tiếng. Đừng thêm lại âm thanh nếu người dùng không yêu cầu.
- Chưa chạy thử trong Godot.

## KẸT BẬC THỀM Ở MIRAGE (người dùng báo)
- `bsp2glb.py` xuất 3 loại mesh: `chunk_*_nocol` (hiển thị, chia nhỏ để nướng ánh sáng, KHÔNG va chạm), `col_*_hide` (va chạm, không chia nhỏ, chỉ có toạ độ), `chunk_*_hide` (trần trời / vật cản vô hình). `main.gd` bỏ qua `create_trimesh_collision` cho tên kết thúc `_nocol`. Đừng cho mesh chia nhỏ làm va chạm lại (vấp mép tam giác).
- `_slide_with_step` (player.gd, bot.gd) thử `STEP_HEIGHTS` x `STEP_FWD`, kích hoạt khi bị chặn bởi tường (`get_slide_collision`). Chưa chạy thử trong Godot.

## VÁCH VÔ HÌNH Ở MIRAGE + BOT KẸT (người dùng báo)
- `chunk_*_hide` (sky / nowallshot / {invis / func_wall ẩn) có va chạm nhưng không vẽ -> người chơi thấy "trong suốt mà là tường". `tools/fill_hidden_walls.py assets/mirage_map.glb` thêm mesh vẽ được `chunk_fill_*_nocol` (gạch `de_mwall32`, hai mặt, vách đứng, cắt ở 14 m, bỏ khối có hàng rào chạm vào). Tên kết thúc `_nocol` nên không tạo va chạm. **Chạy lại script sau mỗi lần `bsp2glb.py` tạo lại map** (script tự dừng nếu file đã được lấp). Đổi map thì bump cờ import.
- `bot.gd`: `collision_mask = 1 | 2` (bot không va cứng với bot, `_separate()` đẩy nhẹ), `_jam_check()` gỡ kẹt theo cấp (nhảy + né -> đổi đích -> `_unstick_hop()` đưa tới điểm kế trên đường đi khi người chơi không nhìn thấy). Chưa chạy thử trong Godot; chỗ kẹt cụ thể trong ảnh người dùng chưa xác định được.

## AWP (người dùng yêu cầu: bê cách chơi AWP của CS:GO / CS2 qua, NHÚNG THẲNG model CS vào game)
- **NGOẠI LỆ có chủ đích** với hai quy tắc ở trên: (1) AWP có **ngắm bằng ống ngắm** (chuột phải: zoom 1 -> zoom 2 -> tắt), CHỈ AWP; các súng khác vẫn KHÔNG có ADS. (2) AWP dùng **tay + súng + animation CÓ SẴN trong model** `assets/awp/v_awp.glb` (đổi từ `v_awp.mdl` bằng `python3 tools/mdl2glb.py v_awp.mdl v_awp.glb --vm`), KHÔNG dùng `Hands.Arm`. Đừng "sửa lại cho đúng quy tắc".
- `scripts/awp.gd` là viewmodel (cùng API với `rifle.gd`): AnimationPlayer của glb (`idle1 shoot1-3 reload draw inspect`), model xoay 180 độ quanh Y và dời `VM_OFFSET` (model GoldSrc đặt súng lệch trái mắt 15 cm), loé lửa + vị trí nòng lấy từ xương `Bone50`. `_complete_tracks()` bù các track xương Godot đã bỏ lúc import.
- Ngắm nằm trong `player.gd`: `scope_level / zoom_k / zoom_target`, `_scope_input`, `_set_scope`, `_zoomed_fov`; bảng `WEAPONS["awp"]` có `scope` (zoom theo tan(FOV/2): 0.364 / 0.0875, `move_mul` 0.5), `cs.sniper` (độ tỏa `_cs_spread_sniper`), `no_chamber`, `range`. Bắn xong tự thoát ngắm. Đang ngắm player ẩn viewmodel (`vm.visible = false`), HUD vẽ ống ngắm (`Hud.Scope`, `hud.set_scope`) và ẩn tâm ngắm.
- Cửa hàng: thẻ AWP phím 5, `PRICE_AWP = 4750` (`main.gd`). Súng rơi dưới đất: nhánh `"awp"` trong `pickups._build_model`. Bot KHÔNG dùng AWP (không có trong `WEAPON_AI`).
- Chưa chạy thử trong Godot: vị trí súng trên màn hình (`VM_OFFSET`), độ dày viền ống ngắm, và thời điểm thay băng đạn (`RELOAD_INSERT_AT`) có thể cần người dùng báo để chỉnh.
- Hiệu năng AWP (người dùng báo tụt còn 20-25 FPS khi cầm AWP trên ThinkPad T440): `v_awp.glb` được gộp thành MỘT mảnh + MỘT texture atlas (`python3 tools/mdl2glb.py v_awp.mdl v_awp.glb --vm --atlas`, trước đó 16 mảnh + 13 texture); `awp.gd` DỪNG AnimationPlayer (`anim.pause()`) khi súng đứng yên (`idle_hold_t`); `player.gd` chỉ gán `render_cam.far` khi đổi. Nếu vẫn chậm: nghi ngờ tiếp theo là bộ xương 42 xương bị skinning mỗi khung hình lúc bắn / nạp đạn (có thể đổi sang mesh cứng theo xương), hoặc chưa đo được nguyên nhân thật vì máy Claude không có Godot.

## TỐI ƯU FPS TOÀN GAME (người dùng: "chơi CS:GO 2014 60 FPS bình thường mà game này chỉ 30 FPS")
- **Nghẽn chính là số DRAW CALL của map Mirage** (đo bằng tay: 100-550 draw call mỗi khung hình, vì mỗi khu vực x mỗi vật liệu = 1 draw call; Godot GL Compatibility + Intel HD rất nhạy với việc này; số tam giác chỉ ~80k nên KHÔNG phải vấn đề).
  `tools/optimize_map.py` (chạy sau bsp2glb.py + fill_hidden_walls.py) gộp 143 texture opaque thành MỘT atlas 4096x2240 (viền lặp 16 px quanh mỗi texture, nên không lộ đường nối), CẮT các mặt theo ô lặp UV (UV của map vượt 0..1) để dùng StandardMaterial3D thường, KHÔNG cần shader riêng; mesh chia theo khu vực `chunk_<cx>_<cz>_atlas_nocol` (1 mảnh / khu vực) nên vẫn bị loại bỏ khi ngoài tầm nhìn; 16 vật liệu masked (hàng rào) gộp ở `world_mask_nocol`. Mesh va chạm / vách vô hình giữ nguyên 100% (navmesh, bot không đổi). Kết quả ước tính ~10-30 draw call cho map thay vì 100-550. Số tam giác tăng ~2x (76k -> 152k), chấp nhận được.
- `assets/mirage_map.glb.import` TẮT `generate_lods` / `create_shadow_meshes`: LOD tự sinh sẽ gộp tam giác qua ranh giới các ô atlas -> sai texture ở xa. ĐỪNG xoá file này.
- Chưa chạy thử trong Godot (máy Claude không có Godot). Nếu thấy đường nối / texture nhoè ở xa: tăng `GUTTER` trong optimize_map.py. Nếu map bể hình: khôi phục `mirage_map.glb` cũ (9 MB, bản có fill_hidden_walls) rồi báo người dùng.
- Bot: `Bot._process` bỏ qua animation + IK tay khi bot ngoài tầm nhìn (`_needs_anim`: sau lưng / ngoài ~78 độ) và cập nhật nửa số khung hình khi > 45 m; thời gian bỏ qua cộng dồn `anim_acc`.
- vsync TẮT (`project.godot`, `window/vsync/vsync_mode=0`) + `Engine.max_fps = 144`: vsync bật trên màn 60 Hz làm FPS rơi thẳng xuống 30 khi chậm hơn một chút. Tự hạ độ phân giải 3D khi FPS TB < 50 (trước đây 40).
- Khi người dùng báo FPS: nhờ bấm F3 và gửi dòng "FPS | script ms | physics ms | draw calls | tris" để biết nghẽn CPU (script/physics) hay GPU.
- Đợt 2 (người dùng: "ở chế độ đặt bom vẫn còn lag"): `Bot._slide_with_step` nghỉ 0.15 s (`step_cd`) sau khi tìm bậc thềm thất bại (mỗi lần tìm tới ~27 `test_move`, bot cọ tường lặp mỗi nhịp vật lý); `_separate` chỉ chạy 20 lần/giây và dùng bình phương khoảng cách; tự hạ độ phân giải giờ KIỂM TRA hiệu quả: hạ một bậc mà FPS không khá hơn 10% thì trả lại độ nét và tắt auto_res (nghẽn CPU, không phải card đồ họa) - tránh việc ngưỡng 50 FPS làm hình tụt xuống 427x240 vô ích. Logic bom (`bomb.gd`) đã đọc: nhẹ, không phải thủ phạm. Chưa đo được trên máy thật: cần dòng F3 trong chế độ đặt bom.

## DỌN DẸP + NÉN FILE (người dùng: "xoá code rác, nén dưới 25 MB, không ảnh hưởng game") - zip từ ~40 MB xuống ~20 MB
- 7 model nhân vật (`yuri terror miho abia neko_gign neko_gsg9 kratos`) đã chạy qua `tools/glbslim.py` (khung `idle1,idle,crouch_idle,walk,run,crouchrun,jump,head,back,forward,left,right,death1-3,gutshot,crouch_die` = đúng các animation `terror_rig.gd` gọi; sai số xương < 0.5 mm, kiểm bằng so sánh tư thế mọi xương). **Chỉ còn 16 animation mỗi model** (trước 100-108). Muốn dùng animation khác (ví dụ bot cầm súng kiểu `ref_aim_rifle`): phải đổi lại từ file .mdl gốc bằng `tools/mdl2glb.py` rồi (tuỳ chọn) chạy glbslim với danh sách animation cần giữ. Texture opaque lưu JPEG q93 (texture đã là JPEG giữ nguyên byte), texture có alpha giữ PNG.
- `mirage_map.glb` 28 MB -> 19 MB (nén zip ~6.5 MB): atlas lưu JPEG q95 4:4:4, pháp tuyến là hằng số (map unshaded không dùng), toạ độ làm tròn 1 mm (CHỈ mesh hiển thị, mesh va chạm giữ nguyên 100%), UV làm tròn 1/65536, chỉ số 16-bit. Nếu bật đổ bóng cho map phải tạo lại pháp tuyến.
- Đã xoá: `assets/gign/` + `scripts/skin_rig.gd` (nhánh dự phòng GIGN, chỉ chạy khi model Yuri/Terror không nạp được), cùng các biến/hằng số chết trong bot.gd (`BOT_DAMAGE stuck_t stuck_check_t stuck_pos GUN_GRIP_*_OLD GUN_READY_* GUN_AIM_POS MAG_SIZE`), `bomb.winner_text`, `main.lobby_tab`, `main.selected_map`. Tìm code chết bằng cách đếm số lần mỗi tên xuất hiện trong toàn bộ scripts (chỉ 1 lần = chỉ có khai báo) - đã làm hết.
- Giữ lại `assets/awp/v_awp.mdl` (file gốc người dùng đưa, 0.3 MB) và các hàm rỗng `play_at` (nhiều nơi gọi, bỏ đi thì rủi ro hơn lợi).

## MP5-SD (người dùng yêu cầu: nhúng thẳng model + tay + animation + âm thanh từ gói `low_poly_mp5-sd`, chỉ số y như CS:GO / CS2)
- **NGOẠI LỆ có chủ đích** giống AWP: dùng tay + súng + animation CÓ SẴN trong `assets/mp5/v_mp5.glb` (đổi từ `v_mp5.mdl` bản GSG9 bằng `python3 tools/mdl2glb.py v_mp5.mdl v_mp5.glb --vm --atlas`), KHÔNG dùng `Hands.Arm`. Đừng "sửa lại cho đúng quy tắc". Gói gốc có 5 bản tay áo (GSG9, ST6, FBI, LEET, PHOENIX), mỗi bản một `v_mp5.mdl` khác nhau; muốn đổi chỉ cần chạy lại lệnh trên với file khác (ghi đè `assets/mp5/v_mp5.glb`) rồi bump cờ import.
- `scripts/mp5.gd` (cùng API với `awp.gd`, không ngắm). Animation của model: `idle` (CHỈ 1 khung, độ dài 0: `mp5.gd` nới thành 0.1 s + LOOP), `draw`, `shoot1-3`, `reload` (2.575 s, chạy chậm lại cho đủ 2.97 s = CS2), `inspect`. Đầu nòng = xương có tên kết thúc `flash` (tìm theo đuôi vì Godot có thể đổi dấu `.` trong tên xương).
- **Âm thanh CHỈ cho MP5** (người dùng yêu cầu riêng): `assets/mp5/sounds/*.wav` do `mp5.gd` tự phát bằng `AudioStreamPlayer` (không qua `player.play`, vẫn là hàm rỗng). Thời điểm tiếng kéo khoá / tháo / lắp băng đạn / rút súng lấy từ sự kiện 5004 của model (`RELOAD_EVENTS`, `DRAW_EVENTS`). Vì vậy `main.gd` giờ `AudioServer.set_bus_mute(0, false)`. Các súng khác VẪN không có tiếng; đừng thêm tiếng cho chúng nếu người dùng không nhờ. `mp5-2.wav` trong gói giống hệt `mp5-1.wav` nên không chép.
- Chỉ số `Player.WEAPONS["mp5"]` (CS2, dữ liệu datamine tháng 6/2026): $1400 (`PRICE_MP5`), thưởng hạ gục $600 (`MP5_KILL_REWARD`, `bomb.gd on_kill`), 30/120, 750 RPM (`interval` 0.08, thực tế ~720 vì vật lý 60 Hz), sát thương 28, falloff 0.87 mỗi 12.7 m, đi 0.94, `noise` 20 m (ống giảm thanh; `_shoot` đọc `W.get("noise", 42.0)`). Không có giáp trong game nên bỏ "xuyên giáp 62.5%". Bảng `cs` (tỏa đạn + giật) do mình tự đặt theo kiểu SMG (giật nhẹ hơn M4A1, tỏa rộng hơn một chút), không phải số gốc của CS.
- Đã nối vào: `player.gd` (WEAPONS, SLOT_OF, owned/w_mag/w_res, reset_loadout, viewmodel, cycle_weapon, primary_id), `main.gd` (thẻ cửa hàng phím 6, `_buy_mp5`, `_refresh_shop`, thưởng tiền), `pickups.gd` (mô hình dưới đất), `ui_icon.gd` (biểu tượng "mp5"), `CHOI_GAME.bat` (cờ `imported_v35`). Bot KHÔNG dùng MP5 (không có trong `WEAPON_AI`).
- Chưa chạy thử trong Godot: vị trí súng trên màn hình (`VM_OFFSET`), tên xương `flash`, animation `idle` độ dài 0, âm thanh có phát không (cần import `.wav`).

## AK-47 (người dùng yêu cầu: NHÚNG THẲNG model CS2 + tay + animation, chỉ số y như CS2, XOÁ model AK cũ)
- **NGOẠI LỆ có chủ đích** giống AWP / MP5: dùng tay + súng + animation CÓ SẴN trong `assets/ak47/v_ak47.glb` (đổi từ `cstrike/models/v_ak47.mdl` gói `cs2ak47_cfrigs` bằng `python3 tools/mdl2glb.py v_ak47.mdl assets/ak47/v_ak47.glb --vm --atlas --atlas-scale=0.5 --jpeg`), KHÔNG dùng `Hands.Arm`. Đừng "sửa lại cho đúng quy tắc". Model AK cũ dựng bằng code đã XOÁ, đừng thêm lại; `rifle.gd` (M4A1) lấy lớp `MB` từ `scripts/mesh_builder.gd`.
- `scripts/ak47.gd` (cùng API với `mp5.gd`): animation `idle shoot1-3 reload draw inspect`; rig xoay 180 độ quanh Y + `scale = (-GUN_SCALE, GUN_SCALE, GUN_SCALE)` (model CS 1.6 vẽ cho tay trái nên phải lật gương; GUN_SCALE = 0.55 thu nhỏ đều quanh mắt: hình không đổi, súng ngắn lại); đầu nòng = attachment 0 gắn xương `Box001` (`MUZZLE_LOCAL`); `FREEZE_IDLE = false` (animation thở chạy liên tục).
- Không có âm thanh (gói không kèm file nào, các event 5004 trỏ tới `weapons/cs2/ak47/*.wav` không tồn tại). Đừng thêm âm thanh nếu người dùng không đưa file.
- Model có móc khoá cú mèo (mảnh `kc_missinglink_*`) là của gói gốc, giữ nguyên.
- Chỉ số `Player.WEAPONS["ak47"]` theo CS2: 36 sát thương, falloff 0.98 / 12.7 m, 0.1 s/phát (600 RPM), 30/90, đi 0.86, `PRICE_AK = 2700` (`main.gd`), `PRICE_RIFLE_T = 2700` (`bot.gd`). Bảng `cs` (giật / tỏa đạn) giữ như cũ.
- **Tay áo theo phe (người dùng yêu cầu):** phe CT (`Player.team == 0`) dùng `assets/ak47/v_ak47_ct.glb` (đổi từ `alt/v_ak47.mdl`, tay áo xanh, thêm texture `sleeve.bmp`), phe T (`team == 1`) dùng `v_ak47.glb` (tay trần). `ak47.gd` tìm Player qua tổ tiên có biến `team` + `viewmodels`, `_sync_team()` (gọi ở `_process` và đầu `play_draw / play_reload / play_inspect / fire`) dựng lại model khi phe đổi và giữ animation đang chạy. Tool `mdl2glb.py` giờ lấy lại mẫu animation > 45 fps xuống 30 fps (idle 100 fps của AK). Cờ import hiện là `imported_v40`.
- Chưa chạy thử trong Godot: vị trí súng trên màn hình (`VM_OFFSET`, `GUN_SCALE`), tay có bị đảo bên không, vị trí tia lửa nòng.

## DESERT EAGLE mới (người dùng yêu cầu: thay model DE bằng model trong gói `cs_go_deagle_74536`, nhúng thẳng tay + animation + âm thanh, XOÁ model cũ)
- **NGOẠI LỆ có chủ đích** như AWP / MP5 / AK-47 / dao: `scripts/deagle.gd` dùng súng + tay + animation CÓ SẴN trong `assets/deagle/v_deagle_ct.glb` (phe CT, găng + tay áo ô-liu) / `v_deagle_t.glb` (phe T, găng đen), KHÔNG dùng `Hands.Arm`. Model Desert Eagle cũ (`desert_eagle.glb` + ~1260 dòng dựng bằng code + animation tự viết) đã XOÁ, đừng thêm lại.
- Đổi bằng `python3 tools/mdl2glb.py "CT Arms/v_deagle.mdl" assets/deagle/v_deagle_ct.glb --vm --atlas --jpeg --no-normals` và `... "T Arms/v_deagle.mdl" ... v_deagle_t.glb ... --gun-tex-from="CT Arms/v_deagle.mdl"`. Hai file .mdl của gói nhúng HAI skin súng khác nhau (CT đen trắng vàng, T đỏ cam); người dùng muốn MỘT model nên cả hai phe dùng skin của CT Arms (`--gun-tex-from`). 9 skin trong `Texture(s)` của gói không dùng. Mô-đun StatTrak là của model gốc, giữ nguyên.
- Giống AK-47: model vẽ cho tay trái nên phải LẬT GƯƠNG (`rig.rotation.y = PI` + `scale.x` âm). Bản T trong gói to gấp ~2.6 lần bản CT nên mỗi phe một hệ số (`SCALE_CT = 1.0`, `SCALE_T = 0.39`; thu nhỏ đều quanh mắt thì hình không đổi). Đầu nòng = attachment 0 gắn xương `deagle_parent`, lệch khác nhau theo phe (`MUZZLE_LOCAL_CT/T`).
- Animation: `idle shoot1 shoot2 shoot_empty (viên cuối) reload (bản T tên "EMMASTONE") draw`. KHÔNG có inspect: `play_inspect()` để trống. Không có `play_holster` (player.gd kiểm tra `has_method`). `fire(last_round)` chạy `shoot_empty` ở viên cuối.
- Âm thanh CÓ trong gói, đã nhúng: `assets/deagle/sounds/` (clipin, clipout, slide, draw, deagle-1, deagle-2), `deagle.gd` tự phát bằng `AudioStreamPlayer` theo bảng `EVENTS_CT/EVENTS_T` (sự kiện 5004 của model) và tiếng bắn xen kẽ deagle-1 / deagle-2.
- Chỉ số `Player.WEAPONS["deagle"]` KHÔNG đổi (63 sát thương, tầm hao 0.81, 0.33 s/phát, 7/35, $700). Chưa chạy thử trong Godot: vị trí súng, tay có bị đảo bên không, vị trí tia lửa nòng, tiếng khớp animation. Cờ import hiện là `imported_v40`.

## ÂM THANH AWP (người dùng yêu cầu: lấy âm thanh trong gói `cs_10_beta_awp` gắn cho AWP, chỉ lấy âm thanh)
- `assets/awp/sounds/`: `awp1.wav` (tiếng bắn), `boltup.wav` / `boltpull1.wav` / `boltdown.wav` (kéo khoá). `scripts/awp.gd` tự phát bằng `AudioStreamPlayer` (như `mp5.gd` / `knife.gd`): `fire()` phát `awp1` rồi lên lịch 3 tiếng kéo khoá ở 0.429 / 0.543 / 0.914 giây (`BOLT_EVENTS`, đúng sự kiện 5004 trong `assets/awp/v_awp.mdl`). Rút súng / nạp đạn / xem súng làm huỷ lịch kéo khoá còn lại (animation bị thay), `cancel()` tắt hết tiếng khi đổi súng.
- KHÔNG tắt tiếng khi viewmodel bị ẩn (ngắm scope ẩn viewmodel; bắn lúc ngắm thì viewmodel đang ẩn mà tiếng vẫn phải phát; player.gd bỏ ngắm ngay sau phát bắn).
- Gói không có tiếng nạp đạn (`awp_clipin / clipout`) và tiếng rút súng nên hai hành động đó vẫn im lặng; đừng tự thêm nếu người dùng không đưa file. `bonus/go.wav` ("okay, let's go" của CS 1.0 beta) và `v_awp.mdl` trong gói KHÔNG dùng. Tool `tools/` thêm 2 bộ giải nén ngoài project (RAR4 / RAR5 viết bằng Python vì máy không có `unrar`) KHÔNG nằm trong zip. Cờ import hiện là `imported_v40`.
- Chưa chạy thử trong Godot: tiếng bắn có đủ to, 3 tiếng kéo khoá có khớp lúc tay kéo nắp.



## NÚT CẢM ỨNG CHO ĐIỆN THOẠI (người dùng yêu cầu)
- `scripts/touch_controls.gd` (CanvasLayer, tạo trong `main._setup_touch()`) vẽ và xử lý toàn bộ nút ảo. Chỉ bật khi `OS.has_feature("android")` / `"ios"` hoặc chạy với tham số `touch`. Bố cục tính theo khung ảo 720x405 (hàm `_build_buttons`).
- Nút gọi `Input.action_press/release` cho action có sẵn, hoặc gọi thẳng `Player.request_switch / drop_current`, `main._toggle_shop / _toggle_pause`. Xoay camera qua `Player.touch_look(rel)`. KHÔNG đổi tên action cũ, KHÔNG thêm lại chuột cho `fire` / `aim` trên điện thoại.
- Thêm phím mới thì thêm một dòng `_add(...)` trong `_build_buttons`, và một hàm `_do_xxx` nếu là nút chạm một lần.
- Chưa chạy thử trong Godot. Xuất APK: `HUONG_DAN_ANDROID.txt`, `export_presets.cfg`, `debug.keystore`.
