@echo off
setlocal
cd /d "%~dp0"
set "ARGS=%~1"
set "ENG=%~dp0godot_engine"
set "GODOT=%ENG%\Godot_v4.3-stable_win64.exe"
set "GODOTC=%ENG%\Godot_v4.3-stable_win64_console.exe"

rem Neu ban da co file Godot .exe dat canh file nay thi dung luon
for %%F in ("%~dp0Godot*.exe") do (
  echo %%~nxF | find /i "console" >nul && (set "GODOTC=%%~fF") || (set "GODOT=%%~fF")
)

if exist "%GODOT%" goto have_godot
if exist "%GODOTC%" goto have_godot
echo ============================================================
echo  Lan dau chay: dang tai Godot 4.3 (khoang 60 MB), vui long cho...
echo  (Can Internet. Chi tai 1 lan duy nhat.)
echo ============================================================
if not exist "%ENG%" mkdir "%ENG%"
powershell -NoProfile -ExecutionPolicy Bypass -Command "$ProgressPreference='SilentlyContinue'; [Net.ServicePointManager]::SecurityProtocol=[Net.SecurityProtocolType]::Tls12; Invoke-WebRequest -UseBasicParsing -Uri 'https://github.com/godotengine/godot/releases/download/4.3-stable/Godot_v4.3-stable_win64.exe.zip' -OutFile '%ENG%\godot.zip'; Add-Type -AssemblyName System.IO.Compression.FileSystem; [IO.Compression.ZipFile]::ExtractToDirectory('%ENG%\godot.zip','%ENG%')"
if not exist "%GODOT%" goto fail
del "%ENG%\godot.zip" >nul 2>&1

:have_godot
if not exist "%GODOTC%" set "GODOTC=%GODOT%"
if exist "%ENG%\imported_v40.flag" goto run
echo ============================================================
echo  Lan dau: dang nap map, mat khoang 1-2 phut. Dung tat cua so nay!
echo ============================================================
if not exist "%ENG%" mkdir "%ENG%"
if exist "%ENG%\import_log.txt" del "%ENG%\import_log.txt"
if exist ".godot" rmdir /s /q ".godot"
"%GODOTC%" --headless --path "." --import >> "%ENG%\import_log.txt" 2>&1
"%GODOTC%" --headless --path "." --import >> "%ENG%\import_log.txt" 2>&1
if not exist "%ENG%" mkdir "%ENG%"
echo ok> "%ENG%\imported_v40.flag"

:run
echo.
echo Dang mo game... (cua so den nay se hien thong bao loi neu co)
"%GODOTC%" --path "." -- %ARGS%
echo.
echo ============================================================
echo  Game da dong. Neu game KHONG hien len hoac bi loi,
echo  hay chup man hinh cua so nay (cac dong chu o tren) gui lai cho minh.
echo ============================================================
pause
exit /b 0

:fail
echo.
echo Khong tai duoc Godot tu dong.
echo Cach thu cong: vao https://godotengine.org/download/windows/ tai "Godot Engine - Standard" (ban 4.3 tro len),
echo giai nen, chep file Godot_v4.3-stable_win64.exe va Godot_v4.3-stable_win64_console.exe
echo vao thu muc "godot_engine" canh file nay, roi chay lai.
pause
exit /b 1
