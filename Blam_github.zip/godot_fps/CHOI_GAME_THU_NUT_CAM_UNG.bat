@echo off
call "%~dp0CHOI_GAME.bat" touch
