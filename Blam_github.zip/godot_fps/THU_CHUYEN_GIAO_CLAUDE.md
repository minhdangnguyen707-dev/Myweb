# THƯ CHUYỂN GIAO (bản 3) — Game "Glock FPS / Blam" (Godot 4.3)

> Gửi Claude tiếp theo: đọc hết thư này, rồi đọc `CLAUDE.md` và `README.md` trong project. Thư này thay thế bản 2. **Rất nhiều thứ chưa được chạy thử trong Godot** (mục 8), nên coi lỗi là chuyện dễ xảy ra và đọc kỹ ảnh người dùng gửi.

---

## 1. Người dùng là ai, phải nói chuyện thế nào

- Người Việt, **không biết lập trình**. Máy **ThinkPad T440 (Intel HD 4400)**, renderer **GL Compatibility** → game phải chạy **≥ 30 FPS** (hiện ~52-60 FPS theo ảnh người dùng). Đừng thêm hiệu ứng nặng, đừng dùng ảnh lớn.
- **Trả lời tiếng Việt, ngắn gọn, dễ hiểu.** Không đổ code ra khung chat.
- Máy Claude **không có Godot** → **không bao giờ nói "đã test / đã chạy thử"**. Luôn nói "mình CHƯA chạy thử trong Godot", liệt kê vài việc để người dùng thử, nhờ chụp ảnh nếu lỗi.
- Người dùng hay gửi ảnh chụp màn hình và câu nhờ rất ngắn ("fix", "vẫn vậy", "bị lỗi ở mấy cây súng khác"). **Nhìn kỹ ảnh**, suy ra đúng thời điểm trong ảnh (đang nạp đạn? đang kéo cần gạt? đang chạy?). Nhiều lần ảnh chụp lúc súng đang nghiêng khi chạy nên rất khó đoán; khi thật sự không đoán được, hãy hỏi người dùng chụp lúc **đứng yên** và nói rõ lỗi gì ("tay đè lên súng", "tay lơ lửng", "ngón chĩa lên trời").
- **Câu nhờ mơ hồ**: lần trước hiểu ngược ý ("tự nạp, không có bàn tay" nghĩa là *muốn có tay*). Nếu hai cách hiểu cho ra hai thứ hoàn toàn khác nhau (ví dụ "kiểu tay cũ" = tay hộp hay tay thật?), **dùng AskUserQuestion hỏi một câu** trước khi làm (lần trước đã làm vậy, người dùng chọn "bàn tay thật").
- Chỉ sửa đúng thứ được nhờ, không đụng hệ thống khác nếu không cần.

## 2. Quy tắc bắt buộc về file

1. **Chỉ dùng TAB để thụt dòng** trong `scripts/*.gd`. Kiểm tra: `grep -nP "^ +\S" scripts/*.gd` phải không in ra gì.
2. File `.bat` giữ CRLF. Chỉ sửa khi cần (đã sửa ở bản này, xem mục 4.1); khi sửa dùng Python ghi bytes, giữ `\r\n`.
3. **Không dùng `class_name` trong script mới** (chỉ `viewmodel.gd` còn `class_name Viewmodel`, `bot.gd` có `class_name Bot`). Nạp bằng `preload("res://scripts/xxx.gd")`.
4. Có thay đổi người dùng thấy được → **cập nhật `README.md`** (mỗi tính năng một mục, tiếng Việt).
5. **Cách giao file:** nén cả project thành `/mnt/user-data/outputs/GlockFPS_Godot_Optimized.zip`, thư mục gốc trong zip là `godot_fps/`, rồi gửi bằng `SendUserFile` (hoặc `present_files`).
   Lệnh: `cd /home/claude/work && rm -f /mnt/user-data/outputs/GlockFPS_Godot_Optimized.zip && zip -qr /mnt/user-data/outputs/GlockFPS_Godot_Optimized.zip godot_fps`
6. Thư mục làm việc: `/home/claude/work/godot_fps/`. Phiên mới không còn thì giải nén từ zip người dùng gửi. Các script phân tích dùng một lần (parser FBX, bake tay...) **sẽ mất**; cách làm được mô tả ở mục 6.
7. Giữ các nhánh **dự phòng**: không nạp được tài nguyên thì quay về cách cũ (DE → dựng bằng code; bot → khối hộp; **tay thật → tay khối hộp**). Đừng phá.
8. **Mạng của máy Claude bị tắt**: pip/npm không cài được. Chỉ dùng thứ đã có (Python + numpy + PIL + scipy + matplotlib có sẵn).
9. Khi thêm / đổi tài nguyên (.glb, .fbx, .png...) cần Godot import lại: **đổi số trong cờ `imported_vNN` của `CHOI_GAME.bat`** (hiện là `imported_v20`), nếu không game chạy ngay mà không import file mới (ResourceLoader.exists sai → rơi vào nhánh dự phòng một cách lặng lẽ).

## 3. Game hiện có gì

- Bắn súng góc nhìn thứ nhất. Hai map: `assets/map.glb` ("MINI SIZE") và map **THÀNH PHỐ** `assets/city_map.glb` (cấu hình trong `main.gd`, dict có `spawn_ct`, `spawn_t`, `site_want`).
- Sảnh chờ kiểu Valorant. 2 chế độ: ĐẤU ĐỘI (tdm 3v3), ĐẶT BOM (`scripts/bomb.gd`, luật CS). **Đã xoá chế độ ZOMBIE DEFENSE (zombie, chó, Brute, đồng đội GIGN, nhà thủ thành, kinh dị) và súng Dual Uzi theo yêu cầu người dùng, đừng thêm lại.**
- Vũ khí: Glock 17, M4A1, AK-47, Desert Eagle (DE), Dao, bom C4. Phím: 1=M4A1, 2=Glock, 3=Dao, 5=AK-47, 6=C4 (phím 4 trống) (DE theo phím/thẻ cửa hàng, xem `player.gd` `_unhandled_input`, `main.gd` `_build_shop`).
- Giao diện dựng bằng code trong khung ảo 720×405.
- **Không có ngắm (ADS)**, **không có cụp súng sát tường**, **không có tự nghiêng người (peek)** — người dùng đã yêu cầu xoá (mục 4.3). **Đừng thêm lại.**

## 4. Những việc đã làm ở phiên này

### 4.1 Lỗi / cảnh báo khi mở game (console)
- Lỗi đỏ `Animation name "firstperson_lookat01/02" already exists in library`: Godot tự cắt đuôi `_loop` khỏi tên animation nên hai tên đụng nhau. Đã **sửa thẳng trong `assets/deagle/desert_eagle.glb`** (đổi tên các animation `*_loop` thành `*_looping` bằng cách ghi lại chunk JSON của GLB, đệm khoảng trắng cho chia hết 4, cập nhật tổng độ dài). Game không dùng các animation này.
- Cảnh báo vàng `non-finite normal in LOD generation`: tạo `assets/gign/gign.fbx.import` (file của mô hình chó đã bị xoá cùng chế độ Zombie) với `meshes/generate_lods=false`. (Chưa chắc 100% mô hình nào là thủ phạm; nếu còn cảnh báo thì tắt LOD cho mô hình khác.)
- Cảnh báo `Adding ... as child to Skeleton3D will make owner '' inconsistent`: cảnh báo vô hại của Godot 4.3 khi nạp `.fbx`, **không sửa được tận gốc**. `CHOI_GAME.bat` giờ ghi output của bước `--import` vào `godot_engine\import_log.txt` thay vì hiện ra cửa sổ.
- `CHOI_GAME.bat`: cờ `imported_v20` (đã bump 2 lần để ép import lại).

### 4.2 BÀN TAY THẬT (phần lớn công sức của phiên này) — đọc kỹ mục 5
Người dùng gửi pack `m4-fps-weapon-animations-pack-v1.zip` (`source/M4.fbx` + `textures/`), yêu cầu: **lấy bàn tay trong file đó thay cho tay trong game, không lấy súng**. Đã làm, và người dùng muốn **mọi súng mới về sau đều dùng bàn tay này** (đã hỏi, chọn "Bàn tay thật").

### 4.3 Xoá cơ chế (theo yêu cầu người dùng)
- **Ngắm (ADS)** cho mọi súng: trong `player.gd` đã xoá biến `ads`, đọc phím `aim` để ngắm, zoom FOV, giảm tốc độ / tỏa đạn / giật khi ngắm, `vm.ads = ...`. Phím chuột phải chỉ còn dùng cho **dao đâm**. Bảng `WEAPONS` còn khoá `ads_spread`, `ads_kick`, `no_ads` nhưng vô tác dụng.
- **Hạ / cụp súng khi sát tường** (`WALL_DIMS`, `_wall_amount`, `vm.wall_push`) đã xoá khỏi `player.gd`.
- **Tự nghiêng người (peek) khi đứng sát góc vật cản** (`PEEK_*`, `_update_peek`, `peek_offset`) đã xoá. (`bot.gd` / `main.gd` còn `c.has_method("peek_offset")` nhưng đã có kiểm tra nên không lỗi.) Cú nghiêng camera nhẹ khi đi ngang (`lean`) vẫn còn, người dùng không nhờ xoá.
- Trong các file mô hình súng (`viewmodel.gd`, `rifle.gd`, `ak47.gd`, `deagle.gd`, `knife.gd`, `c4.gd`) **vẫn còn code ADS và `wall_push` nhưng chết** (player không bao giờ bật). Giữ nguyên biến `ads, ads_t, wall_push` vì `player.gd` / giao diện hàm vẫn tham chiếu.

### 4.4 `CLAUDE.md`
Mới tạo ở thư mục gốc project: quy tắc ngắn gọn cho Claude (bàn tay thật bắt buộc, danh sách thứ đã xoá). Hãy giữ nó cập nhật.

## 5. Hệ thống bàn tay thật (`scripts/hands.gd`)

### 5.1 Tài nguyên
- `assets/hands/hand_r.glb`, `hand_l.glb`: mỗi file một mesh tĩnh (hai primitive: da `Hand_D`, găng `Glove_D`, ảnh 512², double sided), **gốc toạ độ = khớp cổ tay**, hệ trục súng của game (nòng -Z, trên +Y, phải +X), đơn vị mét. Nướng từ animation **`Idle` thời điểm 7.5 s** của `M4.fbx`: tư thế cầm M4 (tay phải nắm báng pistol, tay trái ôm ốp tay). **Ngón tay chỉ có một tư thế, không cử động.**
- `M4.fbx` gốc KHÔNG được đưa vào project (nằm ngoài), chỉ có hai file GLB trên.

### 5.2 Hằng số quan trọng (đầu `hands.gd`)
- `AXIS_R/L`: hướng cẳng tay (cổ tay → khuỷu) trong hệ mô hình.
- `GM_R/GM_L`: **tâm vòng ôm của bốn ngón** (điểm mà báng / ốp tay / cán dao xuyên qua), tính trong hệ mô hình (gốc cổ tay). `YM_R`: trục báng (từ ngón trỏ xuống ngón út). `GM_R`, `GM_L` được tính bằng cách khớp vòng tròn qua khớp các ngón.
- `HAND_SCALE = 0.9`, `HAND_BACK`, `HAND_SHIFT` (chỉ cho nhánh súng mới chưa gọi `attach`).

### 5.3 `Hands.Arm`
- `Arm.new(rig, is_left)`: nạp mesh tay (`load_hand`), tạo hộp da `box` nối dài cẳng tay xuống mép màn hình (mesh chỉ có cẳng tay ~0.29 m).
- `attach(node, rest, grip_local, axis_local, roll_deg, mode, rest_extra)`: **gắn bàn tay làm con của node tay của súng** (nên tay đi theo mọi animation của node đó), sao cho tâm vòng ôm trùng `grip_local` trong hệ node. `rest` = xoay của node so với thân súng lúc nghỉ. `mode 0` = tay phải cầm báng; `mode 1` = tay trái ôm ốp tay, **giữ nguyên hướng gốc** (không xoay), `rest_extra` nâng tay lên ôm ốp tay lúc nghỉ; `mode 2` = tay trái cầm báng súng ngắn: lấy **bàn tay phải lật đối xứng** (scale x = -1).
- Biến điều khiển mỗi khung hình: `rest_k` (1 = tay ở chỗ nghỉ, tự nhỏ dần khi tay đi chỗ khác), `mag_target`/`mag_extra` (tay đi lấy băng đạn: dịch tới đúng tâm băng), `ch_k`/`ch_extra`/`ch_yaw` (tay nhéo cần gạt: dịch + xoay quanh trục đứng).
- `update(rig_basis, wrist, elbow, delta)` vẫn được súng gọi mỗi khung: nếu đã `attach` thì chỉ cập nhật đoạn cẳng tay nối dài (`update_tail`); nếu **chưa** `attach` (súng mới) thì đặt tay theo cổ tay + hướng khuỷu (nhánh `HAND_BACK`/`HAND_SHIFT`) → súng mới tự có tay thật.
- `hide_boxes(rig, [keep])`: tự ẩn mọi `MeshInstance3D` dùng `Hands.material()` (tay khối hộp cũ) lần đầu `update`.
- `set_shown(v)`: hiện / ẩn cả cánh tay (DE cầm một tay dùng).

### 5.4 Cách từng súng đang dùng
| Súng | Tay phải | Tay trái |
|---|---|---|
| Glock (`viewmodel.gd`) | `rh_node`, rest = Basis(X, GRIP_TILT), tâm (0,-0.05,0.002), mode 0 | `lh`, rest như trên, tâm (0.0245,0.004,-0.012), mode 2 (mirror) |
| Desert Eagle (`deagle.gd`) | `rh_node`, tâm (0,-0.064,-0.044) | `lh`, tâm (0.0255,0,0), mode 2; `limb_l.set_shown(lh_show)` |
| M4A1 (`rifle.gd`) | `rh_node` rest -20°X, tâm 0 | `lh`, mode 1, `rest_extra`=(0,0.05,0), `mag_extra`=(0.034,0,0.004) |
| AK-47 (`ak47.gd`) | `rh_node` rest -22°X | `lh_hand_node` (node riêng, **không xoay theo `lh.basis`** vì AK tự xoay `lh` theo cẳng tay cho tay hộp), mode 1, `rest_extra`=(0,0.05,-0.015), `mag_extra`=(0.041,0,0), `ch_extra`=(-0.027,-0.022,0.033), `ch_yaw`=-0.785 |
| Dao (`knife.gd`) | `hand_node` (theo `hand_t`, không xoay theo cú lật dao), rest = `hip_basis`, tâm `GRIP_LOCAL` (0,0,-0.004), trục +Z, roll 180° | không có |
| bom C4 | **chưa chuyển**, vẫn tay khối hộp | |

Các giá trị `rest_extra / mag_extra / ch_extra / ch_yaw` của AK/M4 được **tính toán từ hình học, chưa nhìn thấy tận mắt**.

## 6. Cách đã làm ra hai file tay (để làm lại nếu cần)
Máy không có Godot / Blender / thư viện FBX, nên đã **tự viết parser FBX binary bằng Python** (đọc node, giải nén mảng zlib) trong `/tmp/.../scratchpad` (**đã mất**). Tóm tắt:
1. Đọc `Objects`/`Connections`; mesh tay là Geometry 2346 đỉnh, 2 vật liệu (`Hand_D`, `Glove_D`), skin ~ 30 xương `Right*/Left*Hand*`.
2. Tính FK: `Local = T * Rpre * R(xyz: Rz*Ry*Rx) * S`, cha-con từ `Connections OO`; đọc các `AnimationCurve` (thời gian chia 46186158000) theo từng stack, lấy stack `Idle`.
3. Skin: `M = G_xương * inverse(TransformLink)` (**KHÔNG nhân `Transform` của cluster**; làm vậy ra rác), blend theo trọng số.
4. Đổi sang hệ game: xoay π quanh Y (x→-x, z→-z), nhân 0.01 (cm→m), dịch khớp cổ tay về gốc. Phân tay phải / trái theo xương trội của đỉnh.
5. Ghi GLB (JSON + BIN) bằng tay: POSITION/NORMAL/TEXCOORD_0 + chỉ số, 2 primitive, ảnh nhúng (Hand_D → JPEG 512, Glove_D → PNG 512), `doubleSided`. Pháp tuyến tính lại từ mesh đã skin.
6. Kiểm bằng cách vẽ thử bằng PIL (rasterizer tự viết) từ nhiều góc; mô phỏng tay đặt trên hộp súng Glock/AK để chỉnh `GM_*`.

## 7. Dễ sai / cần để ý khi sửa tiếp

- **Thêm súng mới**: xem `CLAUDE.md` (tay) + quy trình ~10 chỗ cũ (`WEAPONS`, `owned/w_mag/w_res` và `reset_loadout()`, `_build_viewmodel`, phím, `cycle_weapon`, cửa hàng + phím mua nhanh, `ui_icon.gd`, `sfx.gd`, `hud.gd`, `bomb.gd` thưởng tiền, README). Giao diện hàm mà viewmodel nào cũng phải có (để `player.gd` gọi): signal `sound`, `reload_inserted`, `action_finished`; biến `ads, ads_t, crouched, grounded, move_amount, run_amount, wall_push, mouse_delta`; hàm `play_draw, play_holster, play_reload(empty)->float, play_inspect, cancel, is_busy, current_mode, set_slide_locked, is_slide_locked, land, fire(last_round), dry_fire, muzzle_global`. Giữ `ads`/`wall_push` nhưng luôn 0.
- Bàn tay là **con của node tay** của súng; nếu node đó xoay vì lý do cho tay hộp (như `lh.basis` của AK), phải tạo node riêng cho bàn tay thật.
- `Quaternion(arc_from, arc_to)` lỗi nếu hai vector đối nhau; bàn tay dùng nó trong `attach` (trục báng → trục đích), góc nhỏ nên ổn.
- Mô hình DE: chuyển động cả súng = `hand_rest_T * (idle_T⁻¹ * anim_T) * hand_rest_T⁻¹`; luôn đi qua `sm_T` (xương→mô hình) rồi `fit_T` (mô hình→súng), đừng cộng trực tiếp vector. Xem README mục DE.
- Quy tắc nhân vật bot: `rig.drive` gọi **sau** khi bot cập nhật animation hộp; ẩn hộp bằng `visible=false` chứ không xoá.
- Hằng `FOV` game: `fov_base = 80` (dọc). Viewmodel vẽ bằng `render_cam` cùng FOV.

## 8. Việc đang chờ người dùng kiểm tra (đều CHƯA chạy thử)

1. **Bàn tay thật trên mọi súng**: Glock (đã xem ảnh, tay đã gần ổn), DE, M4A1, AK-47, Dao. Tay phải ôm báng? Tay trái ôm ốp tay? Cẳng tay có ra mép màn hình ổn không?
2. **Nạp đạn (R)** của M4A1 / AK-47: tay trái có nắm đúng băng đạn không (`mag_extra`)? Bản gần nhất người dùng báo "băng đạn bay lơ lửng", đã sửa nhưng chưa xác nhận.
3. **Kéo cần gạt AK-47 (hết đạn rồi R, hoặc F)**: người dùng báo hai lần "tay co co lại, không thèm đụng vào cần gạt". Đã thêm `ch_extra`/`ch_yaw` nhưng **chưa xác nhận**. Núm cần gạt ở bên **phải** thân súng, vị trí (0.0345..0.045, 0.0225, -0.065) trong hệ súng. Nếu vẫn sai, hỏi người dùng chụp từ bên phải và nói tay lệch hướng nào.
4. **Dao**: bàn tay có nắm đúng cán không (mô phỏng cho thấy roll 180° đúng, chưa thấy trong game).
5. Xoá ADS / sát tường / peek: chuột phải không còn ngắm; sát tường súng không bị cụp; sát góc không nghiêng. Chạy / bắn / nạp có lỗi mới không (chưa biên dịch bằng Godot, chỉ soát cú pháp bằng mắt và script kiểm tra khối rỗng).
6. Console khi mở game lần đầu còn lỗi đỏ nào không (mục 4.1).
7. Từ bản 2 còn nợ: **Bot người thật** (GIGN), **map thành phố** (spawn, cột sáng A/B, bot "suy nghĩ", T tụ điểm tập kết), **bom** (người chơi phe T luôn có bom), sảnh "CHỌN CHẾ ĐỘ".

## 9. Ý tưởng tiếp theo (chưa làm)

- Chuyển C4 sang `Hands.Arm`.
- Tay có ngón cử động (hiện chỉ một tư thế): cần nướng thêm vài tư thế (nắm, mở, nhéo) từ các animation khác của `M4.fbx` rồi blend.
- Mesh tay có thể đổi màu găng / da (hiện lấy từ ảnh pack).
- Dọn code ADS / `wall_push` chết trong 7 file viewmodel (an toàn nếu giữ nguyên giao diện hàm).

## 10. Cách nói chuyện khi giao bản mới

Một đoạn ngắn: đã sửa gì (tiếng đời thường), **nói rõ CHƯA chạy thử trong Godot**, 3-4 việc để người dùng thử, nhờ chụp ảnh nếu lỗi, tên file `GlockFPS_Godot_Optimized.zip`. Không dùng gạch đầu dòng khi từ chối việc gì đó.


## Cập nhật: rút súng Desert Eagle
- `deagle.gd` `play_draw()` bỏ 0,2 giây đầu animation, chạy 1,4x, áp khung đầu ngay (không chớp tư thế nghỉ). Lúc `Mode.DRAW`, `Hands.Arm.freeze_node/freeze_k` giữ bàn tay đứng yên (chỉ súng xoay). CHƯA chạy thử trong Godot.

## Cập nhật: Glock 17 dùng mô hình .glb
- `viewmodel.gd`: `_build_gun()` nạp `assets/glock17/glock17.glb` (nút `slide`, `frame`, `base`), nếu lỗi thì quay về `_build_gun_boxes()`. `GRIP_POS`, `MAG_CENTER_GRIP`, `MUZZLE` đã đổi theo mô hình. Nguồn: FBX giải nén từ RAR người dùng gửi, bake bằng script Python (toạ độ model x→game z, y→x, z→y; tỉ lệ 0.0616). CHƯA chạy thử; tay có thể lệch. Cờ import `imported_v21`.

## 11. Phiên sau cùng: cơ chế nhặt / vứt đồ (CHƯA chạy thử trong Godot)
- Người dùng yêu cầu: 1 súng chính + 1 súng lục + 1 dao; mua đồ không bị khóa; trùng loại thì món cũ tự rơi xuống đất (nằm đến hết round); nhìn vào đồ + **E** nhặt; **G** vứt (không vứt dao); C4 phe T đi tới tự nhặt, CT không nhặt được.
- File mới `scripts/pickups.gd` (không class_name; `main.pickups`). Sửa `player.gd` (`SLOT_OF`, `slot_of`, `give_weapon(id, keep_mag, keep_res)`, `_drop_weapon_item`, `drop_current`, `primary_id`, `best_weapon`, `pistol_id` giờ có thể trả "knife"), `bomb.gd` (`player_drop_c4`, `busy_prompt`, `c4_ignore_until`, dọn đồ rơi ở `_start_round`), `main.gd` (tạo `pickups`, phím `drop`=G, đèn pin dời sang **V**, `_set_card` + `_buy_*` bỏ khóa, `clear_all()` đầu trận).
- Chưa kiểm chứng trong Godot: dòng nhắc "Bấm E để nhặt" ghép với dòng nhắc của bomb.gd; mô hình súng dưới đất (khối hộp) nhìn có ổn không; súng rơi qua sàn / kẹt tường không; sau khi vứt hết súng, phím 2 / Q / lăn chuột có lỗi không.

## 12. Dao M9 Bayonet (thay model dao cũ, CHƯA chạy thử trong Godot)
- Nguồn: `m9-bayonet-knife.zip` (FBX nhị phân + 4 bộ texture 4096x4096). FBX được đọc bằng script Python tự viết rồi ghi ra `assets/knife_m9/m9_bayonet.obj` (+ `.mtl`), 3 texture màu thu nhỏ (`m9_handle.png` 512, `m9_guard.png` 512, `m9_blade.png` 1024). Bỏ normal / metallic / roughness cho nhẹ máy. Model cao 29 cm, gốc = giữa cán, mũi -Z, cạnh sắc -Y, lưng răng cưa +Y. Thư mục `assets/knife` (dao cũ) đã xoá.
- `knife.gd`: `_build_knife()` gán 3 vật liệu theo thứ tự surface (cán, chắn tay, lưỡi); `HOLD_ROLL` = -0.35 xoay dao quanh trục cán; `ROLL_PIVOT` = 0; `GRIP_LOCAL` = tâm nắm tay. Hướng cán dao giữ nguyên bản cũ nên tư thế bàn tay không đổi.
- `_build_keys()` viết lại toàn bộ (rút, chém 1, chém 2, đâm, múa dao) theo hướng mũi dao + hướng cạnh sắc. Chém 2 không còn lật cổ tay (`k_slash2_roll` giữ lại nhưng bằng 0). Thời điểm trúng đòn vẫn là 0.30 s (chém) và 0.41 s (đâm).
- Cờ import đã bump lên `imported_v22` trong `CHOI_GAME.bat`.
- Chưa kiểm chứng trong Godot: bàn tay có ôm vừa cán M9 (dày hơn cán cũ) không, dao có chui vào camera lúc vung không, mũi dao ngoài khung hình ở các đòn chém. Xem trước chỉ dựng bằng Python (không có bàn tay).

